package com.kimtho.portlet.employer;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.kimtho.portlet.WebKeysU;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.RegisterRecruitment;
import com.portlets.action.model.impl.RegisterRecruitmentImpl;
import com.portlets.action.service.EmployerLocalServiceUtil;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;

/**
 * Portlet implementation class EmployerPortlet
 */
public class EmployerPortlet extends MVCPortlet {
 
	/**
	 * 
	 * This method will persist the data in database
	 * @throws SystemException 
	 * @throws IOException 
	 */
	@ProcessAction(name = "followEmployer")
	public void followEmployer(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long employerId = ParamUtil.getLong(actionRequest, "employerId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		EmployerLocalServiceUtil.addUserObjectEmployer(userId, employerId);
		SessionMessages.add(actionRequest, "added-followEducator"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Added Follow Educator Successfully#########################");
	}
	
	@ProcessAction(name = "unFollowEmployer")
	public void unFollowEmployer(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long employerId = ParamUtil.getLong(actionRequest, "employerId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		EmployerLocalServiceUtil.deleteUserObjectEmployer(userId, employerId);
		SessionMessages.add(actionRequest, "deleted-followEducator"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################deleted Follow Educator Successfully#########################");
	}
	
	@ProcessAction(name = "loadListEmployer")
	public void loadListEmployer(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String select = ParamUtil.getString(actionRequest, "select","");
		System.out.println("------"+select);
		actionRequest.setAttribute(WebKeysU.LoadListEmployer, select); 
		SessionMessages.add(actionRequest, "deleted-followEmployer"); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/employer/view.jsp");
		
	   _log.info("#################Load List Educator Successfully#########################");
	}
	
	@ProcessAction(name = "registerRecruitment")
	public void registerRecruitment(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterRecruitment re = new RegisterRecruitmentImpl();
		re.setStatesId(new Long(10));
		re.setUserObjectId(userId);
		re.setRecruitmentId(recruitmentId);
		RegisterRecruitmentLocalServiceUtil.addRegisterRecruitment(re);
		SessionMessages.add(actionRequest, "added-registerrecruitmentId"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Added Register Recruitment Successfully#########################");
	}
	
	@ProcessAction(name = "unRegisterRecruitment")
	public void unRegisterEmployerInfo(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterRecruitment re = new RegisterRecruitmentImpl();
		re.setStatesId(new Long(10));
		re.setUserObjectId(userId);
		re.setRecruitmentId(recruitmentId);
		RegisterRecruitmentLocalServiceUtil.deleteRegisterRecruitment(re);
		SessionMessages.add(actionRequest, "deleted-registerrecruitment"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Deleted Register Recruitment Successfully#########################");
	}
	@ProcessAction(name = "searchEmployer")
	public void searchEmployer(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		//String redirect = ParamUtil.getString(actionRequest, "redirect","");
		String employerName = ParamUtil.getString(actionRequest, "employerName","");
		String employerAddress = ParamUtil.getString(actionRequest, "employerAddress","");
		String employerEmail = ParamUtil.getString(actionRequest, "employerEmail","");
		String employerPhone = ParamUtil.getString(actionRequest, "employerPhone","");
		actionRequest.setAttribute("employerName", employerName);
		actionRequest.setAttribute("employerAddress", employerAddress);
		actionRequest.setAttribute("employerEmail", employerEmail);
		actionRequest.setAttribute("employerPhone", employerPhone);
		SessionMessages.add(actionRequest, "load-search-employer"); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/employer/advancesearch.jsp");
	   _log.info("#################Search Employer Successfully#########################");
	}
	private Log _log = LogFactoryUtil.getLog(EmployerPortlet.class.getName());
}
