/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.portlets.action.service.persistence.UserSkillLevelPK;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.UserSkillLevelServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.UserSkillLevelServiceSoap
 * @generated
 */
public class UserSkillLevelSoap implements Serializable {
	public static UserSkillLevelSoap toSoapModel(UserSkillLevel model) {
		UserSkillLevelSoap soapModel = new UserSkillLevelSoap();

		soapModel.setUserObjectId(model.getUserObjectId());
		soapModel.setSkillId(model.getSkillId());
		soapModel.setLevelId(model.getLevelId());

		return soapModel;
	}

	public static UserSkillLevelSoap[] toSoapModels(UserSkillLevel[] models) {
		UserSkillLevelSoap[] soapModels = new UserSkillLevelSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static UserSkillLevelSoap[][] toSoapModels(UserSkillLevel[][] models) {
		UserSkillLevelSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new UserSkillLevelSoap[models.length][models[0].length];
		}
		else {
			soapModels = new UserSkillLevelSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static UserSkillLevelSoap[] toSoapModels(List<UserSkillLevel> models) {
		List<UserSkillLevelSoap> soapModels = new ArrayList<UserSkillLevelSoap>(models.size());

		for (UserSkillLevel model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new UserSkillLevelSoap[soapModels.size()]);
	}

	public UserSkillLevelSoap() {
	}

	public UserSkillLevelPK getPrimaryKey() {
		return new UserSkillLevelPK(_userObjectId, _skillId);
	}

	public void setPrimaryKey(UserSkillLevelPK pk) {
		setUserObjectId(pk.userObjectId);
		setSkillId(pk.skillId);
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	public long getSkillId() {
		return _skillId;
	}

	public void setSkillId(long skillId) {
		_skillId = skillId;
	}

	public long getLevelId() {
		return _levelId;
	}

	public void setLevelId(long levelId) {
		_levelId = levelId;
	}

	private long _userObjectId;
	private long _skillId;
	private long _levelId;
}