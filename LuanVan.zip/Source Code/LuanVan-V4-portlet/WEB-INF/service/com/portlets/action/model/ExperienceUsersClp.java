/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.ExperienceUsersLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class ExperienceUsersClp extends BaseModelImpl<ExperienceUsers>
	implements ExperienceUsers {
	public ExperienceUsersClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return ExperienceUsers.class;
	}

	@Override
	public String getModelClassName() {
		return ExperienceUsers.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _experienceUsersId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setExperienceUsersId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _experienceUsersId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("experienceUsersId", getExperienceUsersId());
		attributes.put("experienceUsersJob", getExperienceUsersJob());
		attributes.put("experienceUsersCompany", getExperienceUsersCompany());
		attributes.put("experienceUsersDateStart", getExperienceUsersDateStart());
		attributes.put("experienceUsersDateFinish",
			getExperienceUsersDateFinish());
		attributes.put("experienceUsersDescription",
			getExperienceUsersDescription());
		attributes.put("userObjectId", getUserObjectId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long experienceUsersId = (Long)attributes.get("experienceUsersId");

		if (experienceUsersId != null) {
			setExperienceUsersId(experienceUsersId);
		}

		String experienceUsersJob = (String)attributes.get("experienceUsersJob");

		if (experienceUsersJob != null) {
			setExperienceUsersJob(experienceUsersJob);
		}

		String experienceUsersCompany = (String)attributes.get(
				"experienceUsersCompany");

		if (experienceUsersCompany != null) {
			setExperienceUsersCompany(experienceUsersCompany);
		}

		Date experienceUsersDateStart = (Date)attributes.get(
				"experienceUsersDateStart");

		if (experienceUsersDateStart != null) {
			setExperienceUsersDateStart(experienceUsersDateStart);
		}

		Date experienceUsersDateFinish = (Date)attributes.get(
				"experienceUsersDateFinish");

		if (experienceUsersDateFinish != null) {
			setExperienceUsersDateFinish(experienceUsersDateFinish);
		}

		String experienceUsersDescription = (String)attributes.get(
				"experienceUsersDescription");

		if (experienceUsersDescription != null) {
			setExperienceUsersDescription(experienceUsersDescription);
		}

		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}
	}

	@Override
	public long getExperienceUsersId() {
		return _experienceUsersId;
	}

	@Override
	public void setExperienceUsersId(long experienceUsersId) {
		_experienceUsersId = experienceUsersId;

		if (_experienceUsersRemoteModel != null) {
			try {
				Class<?> clazz = _experienceUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setExperienceUsersId",
						long.class);

				method.invoke(_experienceUsersRemoteModel, experienceUsersId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getExperienceUsersJob() {
		return _experienceUsersJob;
	}

	@Override
	public void setExperienceUsersJob(String experienceUsersJob) {
		_experienceUsersJob = experienceUsersJob;

		if (_experienceUsersRemoteModel != null) {
			try {
				Class<?> clazz = _experienceUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setExperienceUsersJob",
						String.class);

				method.invoke(_experienceUsersRemoteModel, experienceUsersJob);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getExperienceUsersCompany() {
		return _experienceUsersCompany;
	}

	@Override
	public void setExperienceUsersCompany(String experienceUsersCompany) {
		_experienceUsersCompany = experienceUsersCompany;

		if (_experienceUsersRemoteModel != null) {
			try {
				Class<?> clazz = _experienceUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setExperienceUsersCompany",
						String.class);

				method.invoke(_experienceUsersRemoteModel,
					experienceUsersCompany);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getExperienceUsersDateStart() {
		return _experienceUsersDateStart;
	}

	@Override
	public void setExperienceUsersDateStart(Date experienceUsersDateStart) {
		_experienceUsersDateStart = experienceUsersDateStart;

		if (_experienceUsersRemoteModel != null) {
			try {
				Class<?> clazz = _experienceUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setExperienceUsersDateStart",
						Date.class);

				method.invoke(_experienceUsersRemoteModel,
					experienceUsersDateStart);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getExperienceUsersDateFinish() {
		return _experienceUsersDateFinish;
	}

	@Override
	public void setExperienceUsersDateFinish(Date experienceUsersDateFinish) {
		_experienceUsersDateFinish = experienceUsersDateFinish;

		if (_experienceUsersRemoteModel != null) {
			try {
				Class<?> clazz = _experienceUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setExperienceUsersDateFinish",
						Date.class);

				method.invoke(_experienceUsersRemoteModel,
					experienceUsersDateFinish);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getExperienceUsersDescription() {
		return _experienceUsersDescription;
	}

	@Override
	public void setExperienceUsersDescription(String experienceUsersDescription) {
		_experienceUsersDescription = experienceUsersDescription;

		if (_experienceUsersRemoteModel != null) {
			try {
				Class<?> clazz = _experienceUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setExperienceUsersDescription",
						String.class);

				method.invoke(_experienceUsersRemoteModel,
					experienceUsersDescription);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserObjectId() {
		return _userObjectId;
	}

	@Override
	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;

		if (_experienceUsersRemoteModel != null) {
			try {
				Class<?> clazz = _experienceUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectId", long.class);

				method.invoke(_experienceUsersRemoteModel, userObjectId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getExperienceUsersRemoteModel() {
		return _experienceUsersRemoteModel;
	}

	public void setExperienceUsersRemoteModel(
		BaseModel<?> experienceUsersRemoteModel) {
		_experienceUsersRemoteModel = experienceUsersRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _experienceUsersRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_experienceUsersRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			ExperienceUsersLocalServiceUtil.addExperienceUsers(this);
		}
		else {
			ExperienceUsersLocalServiceUtil.updateExperienceUsers(this);
		}
	}

	@Override
	public ExperienceUsers toEscapedModel() {
		return (ExperienceUsers)ProxyUtil.newProxyInstance(ExperienceUsers.class.getClassLoader(),
			new Class[] { ExperienceUsers.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		ExperienceUsersClp clone = new ExperienceUsersClp();

		clone.setExperienceUsersId(getExperienceUsersId());
		clone.setExperienceUsersJob(getExperienceUsersJob());
		clone.setExperienceUsersCompany(getExperienceUsersCompany());
		clone.setExperienceUsersDateStart(getExperienceUsersDateStart());
		clone.setExperienceUsersDateFinish(getExperienceUsersDateFinish());
		clone.setExperienceUsersDescription(getExperienceUsersDescription());
		clone.setUserObjectId(getUserObjectId());

		return clone;
	}

	@Override
	public int compareTo(ExperienceUsers experienceUsers) {
		long primaryKey = experienceUsers.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ExperienceUsersClp)) {
			return false;
		}

		ExperienceUsersClp experienceUsers = (ExperienceUsersClp)obj;

		long primaryKey = experienceUsers.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{experienceUsersId=");
		sb.append(getExperienceUsersId());
		sb.append(", experienceUsersJob=");
		sb.append(getExperienceUsersJob());
		sb.append(", experienceUsersCompany=");
		sb.append(getExperienceUsersCompany());
		sb.append(", experienceUsersDateStart=");
		sb.append(getExperienceUsersDateStart());
		sb.append(", experienceUsersDateFinish=");
		sb.append(getExperienceUsersDateFinish());
		sb.append(", experienceUsersDescription=");
		sb.append(getExperienceUsersDescription());
		sb.append(", userObjectId=");
		sb.append(getUserObjectId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(25);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.ExperienceUsers");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>experienceUsersId</column-name><column-value><![CDATA[");
		sb.append(getExperienceUsersId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>experienceUsersJob</column-name><column-value><![CDATA[");
		sb.append(getExperienceUsersJob());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>experienceUsersCompany</column-name><column-value><![CDATA[");
		sb.append(getExperienceUsersCompany());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>experienceUsersDateStart</column-name><column-value><![CDATA[");
		sb.append(getExperienceUsersDateStart());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>experienceUsersDateFinish</column-name><column-value><![CDATA[");
		sb.append(getExperienceUsersDateFinish());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>experienceUsersDescription</column-name><column-value><![CDATA[");
		sb.append(getExperienceUsersDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectId</column-name><column-value><![CDATA[");
		sb.append(getUserObjectId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _experienceUsersId;
	private String _experienceUsersJob;
	private String _experienceUsersCompany;
	private Date _experienceUsersDateStart;
	private Date _experienceUsersDateFinish;
	private String _experienceUsersDescription;
	private long _userObjectId;
	private BaseModel<?> _experienceUsersRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}