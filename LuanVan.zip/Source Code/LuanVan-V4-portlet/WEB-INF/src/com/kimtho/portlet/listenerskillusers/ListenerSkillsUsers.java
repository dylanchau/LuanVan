package com.kimtho.portlet.listenerskillusers;

import java.util.ArrayList;
import java.util.List;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.portlets.action.model.LinkUsers;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.model.impl.LinkUsersImpl;
import com.portlets.action.service.LinkUsersLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;

public class ListenerSkillsUsers {
	
	public ListenerSkillsUsers() {
		// TODO Auto-generated constructor stub
	}
	
	public void addLinkUsers(Long userId, Long skillId) throws SystemException, PortalException {
		List<UserSkillListener> userSkillListener = new ArrayList<UserSkillListener>();
		userSkillListener = UserSkillListenerLocalServiceUtil.getBySkillId(skillId);
		
		LinkUsers linkUsers1 = new LinkUsersImpl();
		LinkUsers linkUsers2 = new LinkUsersImpl();
		linkUsers1.setUserIdA(userId);
		linkUsers2.setUserIdB(userId);
		linkUsers1.setLinkUsersNumber(1);
		linkUsers2.setLinkUsersNumber(1);
		for(UserSkillListener su:userSkillListener){
			if(su.getUserObjectId()!=userId){
				System.out.println("#################"+su.getUserObjectId()+"################"+userId+"##############");
				linkUsers1.setUserIdB(su.getUserObjectId());
				linkUsers2.setUserIdA(su.getUserObjectId());
				
				try {
					LinkUsersLocalServiceUtil.getLinkUsers(linkUsers1.getPrimaryKey());
					
					linkUsers1=LinkUsersLocalServiceUtil.getLinkUsers(linkUsers1.getPrimaryKey());
					linkUsers1.setLinkUsersNumber(linkUsers1.getLinkUsersNumber()+1);
					LinkUsersLocalServiceUtil.updateLinkUsers(linkUsers1);
					linkUsers2=LinkUsersLocalServiceUtil.getLinkUsers(linkUsers2.getPrimaryKey());
					linkUsers2.setLinkUsersNumber(linkUsers2.getLinkUsersNumber()+1);
					LinkUsersLocalServiceUtil.updateLinkUsers(linkUsers2);
				} catch (Exception e){
					LinkUsersLocalServiceUtil.addLinkUsers(linkUsers1);
					LinkUsersLocalServiceUtil.addLinkUsers(linkUsers2);
				}
			}
		}
	}
	
	public void deleteLinkUsers(Long userId, Long skillId) throws SystemException, PortalException {
		List<UserSkillListener> userSkillListener = new ArrayList<UserSkillListener>();
		userSkillListener =UserSkillListenerLocalServiceUtil.getBySkillId(skillId);
		
		LinkUsers linkUsers1 = new LinkUsersImpl();
		LinkUsers linkUsers2 = new LinkUsersImpl();
		linkUsers1.setUserIdA(userId);
		linkUsers2.setUserIdB(userId);
		linkUsers1.setLinkUsersNumber(1);
		linkUsers2.setLinkUsersNumber(1);
		for(UserSkillListener su:userSkillListener){
			if(su.getUserObjectId()!=userId){
				System.out.println("#################"+su.getUserObjectId()+"################"+userId+"##############");
				linkUsers1.setUserIdB(su.getUserObjectId());
				linkUsers2.setUserIdA(su.getUserObjectId());
				try {
					LinkUsersLocalServiceUtil.getLinkUsers(linkUsers1.getPrimaryKey());
					
					linkUsers1=LinkUsersLocalServiceUtil.getLinkUsers(linkUsers1.getPrimaryKey());
					if(linkUsers1.getLinkUsersNumber()==1){
						LinkUsersLocalServiceUtil.deleteLinkUsers(linkUsers1);
					} else {
						linkUsers1.setLinkUsersNumber(linkUsers1.getLinkUsersNumber()-1);
						LinkUsersLocalServiceUtil.updateLinkUsers(linkUsers1);
					}
					linkUsers2=LinkUsersLocalServiceUtil.getLinkUsers(linkUsers2.getPrimaryKey());
					if(linkUsers2.getLinkUsersNumber()==1){
						LinkUsersLocalServiceUtil.deleteLinkUsers(linkUsers2);
					} else {
						linkUsers2.setLinkUsersNumber(linkUsers2.getLinkUsersNumber()-1);
						LinkUsersLocalServiceUtil.updateLinkUsers(linkUsers2);
					}
				} catch (Exception e){

				}
			}
		}
	}
}
