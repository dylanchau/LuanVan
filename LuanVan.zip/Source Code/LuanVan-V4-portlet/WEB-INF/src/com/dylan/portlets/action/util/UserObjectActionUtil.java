package com.dylan.portlets.action.util;

import java.util.ArrayList;
import java.util.List;

import com.portlets.action.model.UserObject;
import com.portlets.action.service.UserObjectLocalServiceUtil;

public class UserObjectActionUtil {

	public static List<UserObject> getUserById(long[] userId) 
			throws Exception {
		
		List<UserObject> users = new ArrayList<UserObject>();
		//DynamicQuery dq = DynamicQueryFactoryUtil.forClass(UserObject.class);
		
		try {
			for(int i=0; i<userId.length; i++) {
				
				System.out.println(userId[i]);
				
				//dq.add(PropertyFactoryUtil.forName("userObjectId").eq(userId[i]));
				UserObject user = UserObjectLocalServiceUtil.getUserObject(userId[i]);
				
				users.add(user);
			}
			
			return users;
			
		}catch(Exception e) {
			System.err.println(e.getMessage()); return null;
		}
	}
}
