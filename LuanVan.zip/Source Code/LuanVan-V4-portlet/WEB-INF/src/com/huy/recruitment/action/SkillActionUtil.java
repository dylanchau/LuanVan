package com.huy.recruitment.action;
import java.util.List;




import com.portlets.action.model.Skill;
import com.portlets.action.service.SkillLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;


public class SkillActionUtil {	
	

		@SuppressWarnings("unchecked")
		public static List<com.portlets.action.model.Skill> getSkillsByFieldId(long fieldId) 
				throws Exception {
			
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Skill.class);
			dq.add(PropertyFactoryUtil.forName("fieldId").eq(fieldId));
			
			try {
				return SkillLocalServiceUtil.dynamicQuery(dq); 
			} catch(SystemException e) {
				System.err.println("Loi"); 
				return null;
			}
		}
		
		
	}


