package com.dylan.messagebus.listenerImp;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.mail.internet.InternetAddress;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.json.JSONException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.notifications.ChannelHubManagerUtil;
import com.liferay.portal.kernel.notifications.NotificationEvent;
import com.liferay.portal.kernel.notifications.NotificationEventFactoryUtil;
import com.portlets.action.model.UserObject;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.EducatorLocalServiceUtil;
import com.portlets.action.service.UserObjectLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;

public class UserObjectMessagingListenerImpl_2 
				implements MessageListener {

	@Override
	public void receive(Message message) 
			throws MessageListenerException {
		
		try {
			doReceive(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void doReceive(Message message) throws JSONException {
		
		String payLoad = (String) message.getPayload();
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject(payLoad);
		long id = jsonObject.getLong("id");
		String url = jsonObject.getString("url");
		String skillsList = jsonObject.getString("skillIds"); 
		long companyId = jsonObject.getLong("companyId");
		long educatorId = jsonObject.getLong("educatorId");
		String testURL = jsonObject.getString("testURL");
		long courseId = jsonObject.getLong("courseId");
		
		_log.info(id + "\n" + companyId + "\n" + educatorId);
		
		String[] skillList = skillsList.split(" ");
		
		_log.info(url + skillList + "\n" + testURL);
		
		long[] ids = new long[skillList.length];
		for(int i = 0; i < skillList.length; i++) {
			ids[i] = Long.parseLong(skillList[i]);
			_log.info(ids[i]);
		}
		
		List<Long> userIdsList = new ArrayList<Long>();
		
		try {
			//get userId who has skills match with the course has
			int userListenSkillsCount = UserSkillListenerLocalServiceUtil.getUserSkillListenersCount();
			List<UserSkillListener> userListenSkills = UserSkillListenerLocalServiceUtil
					.getUserSkillListeners(0, userListenSkillsCount);
			
			for(UserSkillListener userListenSkills2 : userListenSkills) {
				long flag2 = compare(userListenSkills2.getUserObjectId(), ids); _log.info(flag2);
				if(flag2 != 0) {
					userIdsList.add(flag2);
				}
			}
			
			//get userId who has skills match with the course has
			List<UserObject> users = UserObjectLocalServiceUtil.getEducatorUserObjects(educatorId);
			
			for(UserObject user : users) {
				userIdsList.add(user.getUserObjectId());
			}
			
			for(Long a : userIdsList)
				_log.info("userIdsList before distinct: " + a);
			
			/* Create set of Long from List */
	        /* Set will store only unique values from userIdsList */
	        Set<Long> setString = new HashSet<Long>(userIdsList);
	        
	        /* Clear the userIdsList */
	        userIdsList.clear();
	        
	        /* Add setString(Unique) values back to userIdsList */
	        userIdsList.addAll(setString);
	        
	        //send message to set of userIds 
	        for(Long userId : userIdsList) {
	        	_log.info("userIdsList after distinct: " + userId);
	        }
	        
	        for(Long userId : userIdsList) {
	        	UserObject user2 = UserObjectLocalServiceUtil
						.getUserObject(userId);
	        	NotificationEvent notificationEvent = NotificationEventFactoryUtil
						.createNotificationEvent(System.currentTimeMillis(), 
								UserNotificationHandler.PORTLET_ID, jsonObject);
				
				notificationEvent.setDeliveryRequired(0);
				
				ChannelHubManagerUtil.sendNotificationEvent(companyId,
						user2.getUserObjectId(), notificationEvent);
				
				//send mail
				String From= "liferay.luanvan@gmail.com";
				String to = user2.getUserObjectEmail(); _log.info(to);
				InternetAddress From1 = new InternetAddress(From);
				InternetAddress to1 = new InternetAddress(to);
				
				MailMessage mailMessage =new MailMessage(); 

                mailMessage.setFrom(From1);
                mailMessage.setTo(to1);
                String subject = "A course is detected";
                String messageBody = "<span style=\"color: red; font-weight: bold;\">" + 
                						EducatorLocalServiceUtil.getEducator(educatorId).getEducatorName() + "</span>" + 
                						" has just open a new course whose name is " + "<span style=\"color: red; font-weight: bold;\">" +
                						CourseLocalServiceUtil.getCourse(courseId).getCourseName() + "</span>" 
                						+ ". Go back our website to get more detail.";
                
                mailMessage.setSubject(subject);
                mailMessage.setBody(messageBody);
                mailMessage.setHTMLFormat(true);
                
                MailServiceUtil.sendEmail(mailMessage);
	        }
			
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
}

	private long compare(long userId, long[] skills) {
		
		long flag = 0;
		boolean breakLoop = false;
		
		try {
			
			List<UserSkillListener> userSkills = UserSkillListenerLocalServiceUtil.getByUserId(userId); 
			
			for(int i = 0; i < userSkills.size(); i++) {
				for(int j = 0; j < skills.length; j++) {
					_log.info(skills[j]);
					if(userSkills.get(i).getSkillId() == skills[j]) {
						flag = userSkills.get(i).getUserObjectId();
						breakLoop = true; 
						break;
					} else {
						j++;
					}
				}
				if(breakLoop) 
					break;
			}
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
		
		return flag;
	}
	
	
	Log _log = LogFactoryUtil.getLog(UserObjectMessagingListenerImpl_2.class);
}
