package com.dylan.messagebus.listenerImp;

import java.util.List;

import javax.mail.internet.InternetAddress;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.notifications.ChannelHubManagerUtil;
import com.liferay.portal.kernel.notifications.NotificationEvent;
import com.liferay.portal.kernel.notifications.NotificationEventFactoryUtil;
import com.portlets.action.model.UserObject;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.EducatorLocalServiceUtil;
import com.portlets.action.service.UserObjectLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;

public class UserObjectMessagingListenerImpl implements MessageListener{

	@Override
	public void receive(Message message) 
			throws MessageListenerException {
		
		try {
			doReceive(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doReceive(Message message) throws Exception {
		
		String payLoad = (String) message.getPayload();
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject(payLoad);
		long id = jsonObject.getLong("id");
		String url = jsonObject.getString("url");
		String skillsList = jsonObject.getString("skillIds"); 
		long companyId = jsonObject.getLong("companyId");
		long educatorId = jsonObject.getLong("educatorId");
		String testURL = jsonObject.getString("testURL");
		long courseId = jsonObject.getLong("courseId");
		
		_log.info(id + "\n" + companyId + "\n" + educatorId);
		
		String[] skillList = skillsList.split(" ");
		
		System.out.println(url + skillList + "\n" + testURL);
		
		long[] ids = new long[skillList.length];
		for(int i = 0; i < skillList.length; i++) {
			ids[i] = Long.parseLong(skillList[i]);
			_log.info(ids[i]);
		}
		
		try {
	/*		
			//get users whose skills match with the skills of class that educator open
			int userCount = UserObjectLocalServiceUtil.getUserObjectsCount();
			List<UserObject> users = UserObjectLocalServiceUtil.getUserObjects(0, userCount);
			for(UserObject user : users) {
				boolean flag = compare(user.getUserObjectId(), ids);
				_log.info(user.getUserObjectId());
				_log.info(flag);
				if(flag) {
					
					NotificationEvent notificationEvent = NotificationEventFactoryUtil
							.createNotificationEvent(System.currentTimeMillis(), UserNotificationHandler.PORTLET_ID, jsonObject);
					
					notificationEvent.setDeliveryRequired(0);
					
					ChannelHubManagerUtil.sendNotificationEvent(companyId,
							user.getUserObjectId(), notificationEvent);
					
					//send mail
					String From= "liferay.luanvan@gmail.com";
					String to = user.getUserObjectEmail(); _log.info(to);
					InternetAddress From1 = new InternetAddress(From);
					InternetAddress to1 = new InternetAddress(to);
					
					MailMessage mailMessage =new MailMessage(); 

                    mailMessage.setFrom(From1);
                    mailMessage.setTo(to1);
                    String subject = "A course is detected";
                    String messageBody = "<span style=\"color: red; font-weight: bold;\">" + 
                    						EducatorLocalServiceUtil.getEducator(educatorId).getEducatorName() + "</span>" + 
                    						" has just open a new course whose name is " + "<span style=\"color: red; font-weight: bold;\">" +
                    						CourseLocalServiceUtil.getCourse(courseId).getCourseName() + "</span>" 
                    						+ ". Go back our website to get more detail.";
                    
                    mailMessage.setSubject(subject);
                    mailMessage.setBody(messageBody);
                    mailMessage.setHTMLFormat(true);
                    
                    MailServiceUtil.sendEmail(mailMessage);
				}
			}
	*/		
			//get users who registered listen skills that match with course's skills
			
			//get listener in userskilllistener table
			int userListenSkillsCount = UserSkillListenerLocalServiceUtil.getUserSkillListenersCount();
			List<UserSkillListener> userListenSkills = UserSkillListenerLocalServiceUtil
					.getUserSkillListeners(0, userListenSkillsCount);
			
			for(UserSkillListener userListenSkills2 : userListenSkills) {
				boolean flag2 = compare(userListenSkills2.getUserObjectId(), ids); _log.info(flag2);
				if(flag2) {
					
					UserObject user2 = UserObjectLocalServiceUtil
							.getUserObject(userListenSkills2.getUserObjectId());
					
					NotificationEvent notificationEvent = NotificationEventFactoryUtil
							.createNotificationEvent(System.currentTimeMillis(), 
									UserNotificationHandler.PORTLET_ID, jsonObject);
					
					notificationEvent.setDeliveryRequired(0);
					
					ChannelHubManagerUtil.sendNotificationEvent(companyId,
							user2.getUserObjectId(), notificationEvent);
					
					//send mail
					String From= "liferay.luanvan@gmail.com";
					String to = user2.getUserObjectEmail(); _log.info(to);
					InternetAddress From1 = new InternetAddress(From);
					InternetAddress to1 = new InternetAddress(to);
					
					MailMessage mailMessage =new MailMessage(); 

                    mailMessage.setFrom(From1);
                    mailMessage.setTo(to1);
                    String subject = "A course is detected";
                    String messageBody = "<span style=\"color: red; font-weight: bold;\">" + 
                    						EducatorLocalServiceUtil.getEducator(educatorId).getEducatorName() + "</span>" + 
                    						" has just open a new course whose name is " + "<span style=\"color: red; font-weight: bold;\">" +
                    						CourseLocalServiceUtil.getCourse(courseId).getCourseName() + "</span>" 
                    						+ ". Go back our website to get more detail.";
                    
                    mailMessage.setSubject(subject);
                    mailMessage.setBody(messageBody);
                    mailMessage.setHTMLFormat(true);
                    
                    MailServiceUtil.sendEmail(mailMessage);
				}
			}
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}
	
	private boolean compare(long userId, long[] skills) {
		
		boolean flag = false;
		boolean breakLoop = false;
		
		try {
			
			List<UserSkillListener> userSkills = UserSkillListenerLocalServiceUtil.getByUserId(userId); 
			
			for(int i = 0; i < userSkills.size(); i++) {
				for(int j = 0; j < skills.length; j++) {
					_log.info(skills[j]);
					if(userSkills.get(i).getSkillId() == skills[j]) {
						flag = breakLoop = true; 
						break;
					} else {
						j++;
					}
				}
				if(breakLoop) 
					break;
			}
			
			
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
		
		return flag;
	}
	
	
	Log _log = LogFactoryUtil.getLog(UserObjectMessagingListenerImpl.class);
}
