/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.sql.Blob;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.EducatorServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.EducatorServiceSoap
 * @generated
 */
public class EducatorSoap implements Serializable {
	public static EducatorSoap toSoapModel(Educator model) {
		EducatorSoap soapModel = new EducatorSoap();

		soapModel.setEducatorId(model.getEducatorId());
		soapModel.setEducatorName(model.getEducatorName());
		soapModel.setEducatorAddress(model.getEducatorAddress());
		soapModel.setEducatorEmail(model.getEducatorEmail());
		soapModel.setEducatorPhone(model.getEducatorPhone());
		soapModel.setEducatorIntroduce(model.getEducatorIntroduce());
		soapModel.setEuducatorAchievements(model.getEuducatorAchievements());
		soapModel.setEducatorLogoName(model.getEducatorLogoName());
		soapModel.setEducatorLogo(model.getEducatorLogo());

		return soapModel;
	}

	public static EducatorSoap[] toSoapModels(Educator[] models) {
		EducatorSoap[] soapModels = new EducatorSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static EducatorSoap[][] toSoapModels(Educator[][] models) {
		EducatorSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new EducatorSoap[models.length][models[0].length];
		}
		else {
			soapModels = new EducatorSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static EducatorSoap[] toSoapModels(List<Educator> models) {
		List<EducatorSoap> soapModels = new ArrayList<EducatorSoap>(models.size());

		for (Educator model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new EducatorSoap[soapModels.size()]);
	}

	public EducatorSoap() {
	}

	public long getPrimaryKey() {
		return _educatorId;
	}

	public void setPrimaryKey(long pk) {
		setEducatorId(pk);
	}

	public long getEducatorId() {
		return _educatorId;
	}

	public void setEducatorId(long educatorId) {
		_educatorId = educatorId;
	}

	public String getEducatorName() {
		return _educatorName;
	}

	public void setEducatorName(String educatorName) {
		_educatorName = educatorName;
	}

	public String getEducatorAddress() {
		return _educatorAddress;
	}

	public void setEducatorAddress(String educatorAddress) {
		_educatorAddress = educatorAddress;
	}

	public String getEducatorEmail() {
		return _educatorEmail;
	}

	public void setEducatorEmail(String educatorEmail) {
		_educatorEmail = educatorEmail;
	}

	public String getEducatorPhone() {
		return _educatorPhone;
	}

	public void setEducatorPhone(String educatorPhone) {
		_educatorPhone = educatorPhone;
	}

	public String getEducatorIntroduce() {
		return _educatorIntroduce;
	}

	public void setEducatorIntroduce(String educatorIntroduce) {
		_educatorIntroduce = educatorIntroduce;
	}

	public String getEuducatorAchievements() {
		return _euducatorAchievements;
	}

	public void setEuducatorAchievements(String euducatorAchievements) {
		_euducatorAchievements = euducatorAchievements;
	}

	public String getEducatorLogoName() {
		return _educatorLogoName;
	}

	public void setEducatorLogoName(String educatorLogoName) {
		_educatorLogoName = educatorLogoName;
	}

	public Blob getEducatorLogo() {
		return _educatorLogo;
	}

	public void setEducatorLogo(Blob educatorLogo) {
		_educatorLogo = educatorLogo;
	}

	private long _educatorId;
	private String _educatorName;
	private String _educatorAddress;
	private String _educatorEmail;
	private String _educatorPhone;
	private String _educatorIntroduce;
	private String _euducatorAchievements;
	private String _educatorLogoName;
	private Blob _educatorLogo;
}