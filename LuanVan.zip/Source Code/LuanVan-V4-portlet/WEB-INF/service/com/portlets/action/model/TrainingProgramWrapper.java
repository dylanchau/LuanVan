/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link TrainingProgram}.
 * </p>
 *
 * @author Computer
 * @see TrainingProgram
 * @generated
 */
public class TrainingProgramWrapper implements TrainingProgram,
	ModelWrapper<TrainingProgram> {
	public TrainingProgramWrapper(TrainingProgram trainingProgram) {
		_trainingProgram = trainingProgram;
	}

	@Override
	public Class<?> getModelClass() {
		return TrainingProgram.class;
	}

	@Override
	public String getModelClassName() {
		return TrainingProgram.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("trainingProgramId", getTrainingProgramId());
		attributes.put("trainingProgramName", getTrainingProgramName());
		attributes.put("trainingProgramPeriod", getTrainingProgramPeriod());
		attributes.put("trainingProgramPurpose", getTrainingProgramPurpose());
		attributes.put("trainingProgramDiploma", getTrainingProgramDiploma());
		attributes.put("trainingProgramFee", getTrainingProgramFee());
		attributes.put("trainingProgramItems", getTrainingProgramItems());
		attributes.put("trainingProgramContent", getTrainingProgramContent());
		attributes.put("trainingProgramDescription",
			getTrainingProgramDescription());
		attributes.put("educatorId", getEducatorId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long trainingProgramId = (Long)attributes.get("trainingProgramId");

		if (trainingProgramId != null) {
			setTrainingProgramId(trainingProgramId);
		}

		String trainingProgramName = (String)attributes.get(
				"trainingProgramName");

		if (trainingProgramName != null) {
			setTrainingProgramName(trainingProgramName);
		}

		String trainingProgramPeriod = (String)attributes.get(
				"trainingProgramPeriod");

		if (trainingProgramPeriod != null) {
			setTrainingProgramPeriod(trainingProgramPeriod);
		}

		String trainingProgramPurpose = (String)attributes.get(
				"trainingProgramPurpose");

		if (trainingProgramPurpose != null) {
			setTrainingProgramPurpose(trainingProgramPurpose);
		}

		String trainingProgramDiploma = (String)attributes.get(
				"trainingProgramDiploma");

		if (trainingProgramDiploma != null) {
			setTrainingProgramDiploma(trainingProgramDiploma);
		}

		Double trainingProgramFee = (Double)attributes.get("trainingProgramFee");

		if (trainingProgramFee != null) {
			setTrainingProgramFee(trainingProgramFee);
		}

		String trainingProgramItems = (String)attributes.get(
				"trainingProgramItems");

		if (trainingProgramItems != null) {
			setTrainingProgramItems(trainingProgramItems);
		}

		String trainingProgramContent = (String)attributes.get(
				"trainingProgramContent");

		if (trainingProgramContent != null) {
			setTrainingProgramContent(trainingProgramContent);
		}

		String trainingProgramDescription = (String)attributes.get(
				"trainingProgramDescription");

		if (trainingProgramDescription != null) {
			setTrainingProgramDescription(trainingProgramDescription);
		}

		Long educatorId = (Long)attributes.get("educatorId");

		if (educatorId != null) {
			setEducatorId(educatorId);
		}
	}

	/**
	* Returns the primary key of this training program.
	*
	* @return the primary key of this training program
	*/
	@Override
	public long getPrimaryKey() {
		return _trainingProgram.getPrimaryKey();
	}

	/**
	* Sets the primary key of this training program.
	*
	* @param primaryKey the primary key of this training program
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_trainingProgram.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the training program ID of this training program.
	*
	* @return the training program ID of this training program
	*/
	@Override
	public long getTrainingProgramId() {
		return _trainingProgram.getTrainingProgramId();
	}

	/**
	* Sets the training program ID of this training program.
	*
	* @param trainingProgramId the training program ID of this training program
	*/
	@Override
	public void setTrainingProgramId(long trainingProgramId) {
		_trainingProgram.setTrainingProgramId(trainingProgramId);
	}

	/**
	* Returns the training program name of this training program.
	*
	* @return the training program name of this training program
	*/
	@Override
	public java.lang.String getTrainingProgramName() {
		return _trainingProgram.getTrainingProgramName();
	}

	/**
	* Sets the training program name of this training program.
	*
	* @param trainingProgramName the training program name of this training program
	*/
	@Override
	public void setTrainingProgramName(java.lang.String trainingProgramName) {
		_trainingProgram.setTrainingProgramName(trainingProgramName);
	}

	/**
	* Returns the training program period of this training program.
	*
	* @return the training program period of this training program
	*/
	@Override
	public java.lang.String getTrainingProgramPeriod() {
		return _trainingProgram.getTrainingProgramPeriod();
	}

	/**
	* Sets the training program period of this training program.
	*
	* @param trainingProgramPeriod the training program period of this training program
	*/
	@Override
	public void setTrainingProgramPeriod(java.lang.String trainingProgramPeriod) {
		_trainingProgram.setTrainingProgramPeriod(trainingProgramPeriod);
	}

	/**
	* Returns the training program purpose of this training program.
	*
	* @return the training program purpose of this training program
	*/
	@Override
	public java.lang.String getTrainingProgramPurpose() {
		return _trainingProgram.getTrainingProgramPurpose();
	}

	/**
	* Sets the training program purpose of this training program.
	*
	* @param trainingProgramPurpose the training program purpose of this training program
	*/
	@Override
	public void setTrainingProgramPurpose(
		java.lang.String trainingProgramPurpose) {
		_trainingProgram.setTrainingProgramPurpose(trainingProgramPurpose);
	}

	/**
	* Returns the training program diploma of this training program.
	*
	* @return the training program diploma of this training program
	*/
	@Override
	public java.lang.String getTrainingProgramDiploma() {
		return _trainingProgram.getTrainingProgramDiploma();
	}

	/**
	* Sets the training program diploma of this training program.
	*
	* @param trainingProgramDiploma the training program diploma of this training program
	*/
	@Override
	public void setTrainingProgramDiploma(
		java.lang.String trainingProgramDiploma) {
		_trainingProgram.setTrainingProgramDiploma(trainingProgramDiploma);
	}

	/**
	* Returns the training program fee of this training program.
	*
	* @return the training program fee of this training program
	*/
	@Override
	public double getTrainingProgramFee() {
		return _trainingProgram.getTrainingProgramFee();
	}

	/**
	* Sets the training program fee of this training program.
	*
	* @param trainingProgramFee the training program fee of this training program
	*/
	@Override
	public void setTrainingProgramFee(double trainingProgramFee) {
		_trainingProgram.setTrainingProgramFee(trainingProgramFee);
	}

	/**
	* Returns the training program items of this training program.
	*
	* @return the training program items of this training program
	*/
	@Override
	public java.lang.String getTrainingProgramItems() {
		return _trainingProgram.getTrainingProgramItems();
	}

	/**
	* Sets the training program items of this training program.
	*
	* @param trainingProgramItems the training program items of this training program
	*/
	@Override
	public void setTrainingProgramItems(java.lang.String trainingProgramItems) {
		_trainingProgram.setTrainingProgramItems(trainingProgramItems);
	}

	/**
	* Returns the training program content of this training program.
	*
	* @return the training program content of this training program
	*/
	@Override
	public java.lang.String getTrainingProgramContent() {
		return _trainingProgram.getTrainingProgramContent();
	}

	/**
	* Sets the training program content of this training program.
	*
	* @param trainingProgramContent the training program content of this training program
	*/
	@Override
	public void setTrainingProgramContent(
		java.lang.String trainingProgramContent) {
		_trainingProgram.setTrainingProgramContent(trainingProgramContent);
	}

	/**
	* Returns the training program description of this training program.
	*
	* @return the training program description of this training program
	*/
	@Override
	public java.lang.String getTrainingProgramDescription() {
		return _trainingProgram.getTrainingProgramDescription();
	}

	/**
	* Sets the training program description of this training program.
	*
	* @param trainingProgramDescription the training program description of this training program
	*/
	@Override
	public void setTrainingProgramDescription(
		java.lang.String trainingProgramDescription) {
		_trainingProgram.setTrainingProgramDescription(trainingProgramDescription);
	}

	/**
	* Returns the educator ID of this training program.
	*
	* @return the educator ID of this training program
	*/
	@Override
	public long getEducatorId() {
		return _trainingProgram.getEducatorId();
	}

	/**
	* Sets the educator ID of this training program.
	*
	* @param educatorId the educator ID of this training program
	*/
	@Override
	public void setEducatorId(long educatorId) {
		_trainingProgram.setEducatorId(educatorId);
	}

	@Override
	public boolean isNew() {
		return _trainingProgram.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_trainingProgram.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _trainingProgram.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_trainingProgram.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _trainingProgram.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _trainingProgram.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_trainingProgram.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _trainingProgram.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_trainingProgram.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_trainingProgram.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_trainingProgram.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new TrainingProgramWrapper((TrainingProgram)_trainingProgram.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.TrainingProgram trainingProgram) {
		return _trainingProgram.compareTo(trainingProgram);
	}

	@Override
	public int hashCode() {
		return _trainingProgram.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.TrainingProgram> toCacheModel() {
		return _trainingProgram.toCacheModel();
	}

	@Override
	public com.portlets.action.model.TrainingProgram toEscapedModel() {
		return new TrainingProgramWrapper(_trainingProgram.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.TrainingProgram toUnescapedModel() {
		return new TrainingProgramWrapper(_trainingProgram.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _trainingProgram.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _trainingProgram.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_trainingProgram.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TrainingProgramWrapper)) {
			return false;
		}

		TrainingProgramWrapper trainingProgramWrapper = (TrainingProgramWrapper)obj;

		if (Validator.equals(_trainingProgram,
					trainingProgramWrapper._trainingProgram)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public TrainingProgram getWrappedTrainingProgram() {
		return _trainingProgram;
	}

	@Override
	public TrainingProgram getWrappedModel() {
		return _trainingProgram;
	}

	@Override
	public void resetOriginalValues() {
		_trainingProgram.resetOriginalValues();
	}

	private TrainingProgram _trainingProgram;
}