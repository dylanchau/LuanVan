/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.portlets.action.model.TrainingProgram;

/**
 * The persistence interface for the training program service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see TrainingProgramPersistenceImpl
 * @see TrainingProgramUtil
 * @generated
 */
public interface TrainingProgramPersistence extends BasePersistence<TrainingProgram> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link TrainingProgramUtil} to access the training program persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the training programs where educatorId = &#63;.
	*
	* @param educatorId the educator ID
	* @return the matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findByEducatorId(
		long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the training programs where educatorId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorId the educator ID
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @return the range of matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findByEducatorId(
		long educatorId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the training programs where educatorId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorId the educator ID
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findByEducatorId(
		long educatorId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first training program in the ordered set where educatorId = &#63;.
	*
	* @param educatorId the educator ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching training program
	* @throws com.portlets.action.NoSuchTrainingProgramException if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram findByEducatorId_First(
		long educatorId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	/**
	* Returns the first training program in the ordered set where educatorId = &#63;.
	*
	* @param educatorId the educator ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching training program, or <code>null</code> if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram fetchByEducatorId_First(
		long educatorId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last training program in the ordered set where educatorId = &#63;.
	*
	* @param educatorId the educator ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching training program
	* @throws com.portlets.action.NoSuchTrainingProgramException if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram findByEducatorId_Last(
		long educatorId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	/**
	* Returns the last training program in the ordered set where educatorId = &#63;.
	*
	* @param educatorId the educator ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching training program, or <code>null</code> if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram fetchByEducatorId_Last(
		long educatorId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the training programs before and after the current training program in the ordered set where educatorId = &#63;.
	*
	* @param trainingProgramId the primary key of the current training program
	* @param educatorId the educator ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next training program
	* @throws com.portlets.action.NoSuchTrainingProgramException if a training program with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram[] findByEducatorId_PrevAndNext(
		long trainingProgramId, long educatorId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	/**
	* Removes all the training programs where educatorId = &#63; from the database.
	*
	* @param educatorId the educator ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByEducatorId(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of training programs where educatorId = &#63;.
	*
	* @param educatorId the educator ID
	* @return the number of matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public int countByEducatorId(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the training programs where trainingProgramName = &#63;.
	*
	* @param trainingProgramName the training program name
	* @return the matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findBytrainingProgramName(
		java.lang.String trainingProgramName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the training programs where trainingProgramName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param trainingProgramName the training program name
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @return the range of matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findBytrainingProgramName(
		java.lang.String trainingProgramName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the training programs where trainingProgramName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param trainingProgramName the training program name
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findBytrainingProgramName(
		java.lang.String trainingProgramName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first training program in the ordered set where trainingProgramName = &#63;.
	*
	* @param trainingProgramName the training program name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching training program
	* @throws com.portlets.action.NoSuchTrainingProgramException if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram findBytrainingProgramName_First(
		java.lang.String trainingProgramName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	/**
	* Returns the first training program in the ordered set where trainingProgramName = &#63;.
	*
	* @param trainingProgramName the training program name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching training program, or <code>null</code> if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram fetchBytrainingProgramName_First(
		java.lang.String trainingProgramName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last training program in the ordered set where trainingProgramName = &#63;.
	*
	* @param trainingProgramName the training program name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching training program
	* @throws com.portlets.action.NoSuchTrainingProgramException if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram findBytrainingProgramName_Last(
		java.lang.String trainingProgramName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	/**
	* Returns the last training program in the ordered set where trainingProgramName = &#63;.
	*
	* @param trainingProgramName the training program name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching training program, or <code>null</code> if a matching training program could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram fetchBytrainingProgramName_Last(
		java.lang.String trainingProgramName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the training programs before and after the current training program in the ordered set where trainingProgramName = &#63;.
	*
	* @param trainingProgramId the primary key of the current training program
	* @param trainingProgramName the training program name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next training program
	* @throws com.portlets.action.NoSuchTrainingProgramException if a training program with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram[] findBytrainingProgramName_PrevAndNext(
		long trainingProgramId, java.lang.String trainingProgramName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	/**
	* Removes all the training programs where trainingProgramName = &#63; from the database.
	*
	* @param trainingProgramName the training program name
	* @throws SystemException if a system exception occurred
	*/
	public void removeBytrainingProgramName(
		java.lang.String trainingProgramName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of training programs where trainingProgramName = &#63;.
	*
	* @param trainingProgramName the training program name
	* @return the number of matching training programs
	* @throws SystemException if a system exception occurred
	*/
	public int countBytrainingProgramName(java.lang.String trainingProgramName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the training program in the entity cache if it is enabled.
	*
	* @param trainingProgram the training program
	*/
	public void cacheResult(
		com.portlets.action.model.TrainingProgram trainingProgram);

	/**
	* Caches the training programs in the entity cache if it is enabled.
	*
	* @param trainingPrograms the training programs
	*/
	public void cacheResult(
		java.util.List<com.portlets.action.model.TrainingProgram> trainingPrograms);

	/**
	* Creates a new training program with the primary key. Does not add the training program to the database.
	*
	* @param trainingProgramId the primary key for the new training program
	* @return the new training program
	*/
	public com.portlets.action.model.TrainingProgram create(
		long trainingProgramId);

	/**
	* Removes the training program with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param trainingProgramId the primary key of the training program
	* @return the training program that was removed
	* @throws com.portlets.action.NoSuchTrainingProgramException if a training program with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram remove(
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	public com.portlets.action.model.TrainingProgram updateImpl(
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the training program with the primary key or throws a {@link com.portlets.action.NoSuchTrainingProgramException} if it could not be found.
	*
	* @param trainingProgramId the primary key of the training program
	* @return the training program
	* @throws com.portlets.action.NoSuchTrainingProgramException if a training program with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram findByPrimaryKey(
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchTrainingProgramException;

	/**
	* Returns the training program with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param trainingProgramId the primary key of the training program
	* @return the training program, or <code>null</code> if a training program with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.TrainingProgram fetchByPrimaryKey(
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the training programs.
	*
	* @return the training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the training programs.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @return the range of training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the training programs.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of training programs
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the training programs from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of training programs.
	*
	* @return the number of training programs
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the skills associated with the training program.
	*
	* @param pk the primary key of the training program
	* @return the skills associated with the training program
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> getSkills(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the skills associated with the training program.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the training program
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @return the range of skills associated with the training program
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> getSkills(long pk,
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the skills associated with the training program.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the training program
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of skills associated with the training program
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> getSkills(long pk,
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of skills associated with the training program.
	*
	* @param pk the primary key of the training program
	* @return the number of skills associated with the training program
	* @throws SystemException if a system exception occurred
	*/
	public int getSkillsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the skill is associated with the training program.
	*
	* @param pk the primary key of the training program
	* @param skillPK the primary key of the skill
	* @return <code>true</code> if the skill is associated with the training program; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsSkill(long pk, long skillPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the training program has any skills associated with it.
	*
	* @param pk the primary key of the training program to check for associations with skills
	* @return <code>true</code> if the training program has any skills associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsSkills(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the training program and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skillPK the primary key of the skill
	* @throws SystemException if a system exception occurred
	*/
	public void addSkill(long pk, long skillPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the training program and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skill the skill
	* @throws SystemException if a system exception occurred
	*/
	public void addSkill(long pk, com.portlets.action.model.Skill skill)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the training program and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skillPKs the primary keys of the skills
	* @throws SystemException if a system exception occurred
	*/
	public void addSkills(long pk, long[] skillPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the training program and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skills the skills
	* @throws SystemException if a system exception occurred
	*/
	public void addSkills(long pk,
		java.util.List<com.portlets.action.model.Skill> skills)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the training program and its skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program to clear the associated skills from
	* @throws SystemException if a system exception occurred
	*/
	public void clearSkills(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the training program and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skillPK the primary key of the skill
	* @throws SystemException if a system exception occurred
	*/
	public void removeSkill(long pk, long skillPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the training program and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skill the skill
	* @throws SystemException if a system exception occurred
	*/
	public void removeSkill(long pk, com.portlets.action.model.Skill skill)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the training program and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skillPKs the primary keys of the skills
	* @throws SystemException if a system exception occurred
	*/
	public void removeSkills(long pk, long[] skillPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the training program and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skills the skills
	* @throws SystemException if a system exception occurred
	*/
	public void removeSkills(long pk,
		java.util.List<com.portlets.action.model.Skill> skills)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the skills associated with the training program, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skillPKs the primary keys of the skills to be associated with the training program
	* @throws SystemException if a system exception occurred
	*/
	public void setSkills(long pk, long[] skillPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the skills associated with the training program, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the training program
	* @param skills the skills to be associated with the training program
	* @throws SystemException if a system exception occurred
	*/
	public void setSkills(long pk,
		java.util.List<com.portlets.action.model.Skill> skills)
		throws com.liferay.portal.kernel.exception.SystemException;
}