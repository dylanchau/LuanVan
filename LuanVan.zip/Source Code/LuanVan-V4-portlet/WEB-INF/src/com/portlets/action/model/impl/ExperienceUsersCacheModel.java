/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.ExperienceUsers;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing ExperienceUsers in entity cache.
 *
 * @author Computer
 * @see ExperienceUsers
 * @generated
 */
public class ExperienceUsersCacheModel implements CacheModel<ExperienceUsers>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(15);

		sb.append("{experienceUsersId=");
		sb.append(experienceUsersId);
		sb.append(", experienceUsersJob=");
		sb.append(experienceUsersJob);
		sb.append(", experienceUsersCompany=");
		sb.append(experienceUsersCompany);
		sb.append(", experienceUsersDateStart=");
		sb.append(experienceUsersDateStart);
		sb.append(", experienceUsersDateFinish=");
		sb.append(experienceUsersDateFinish);
		sb.append(", experienceUsersDescription=");
		sb.append(experienceUsersDescription);
		sb.append(", userObjectId=");
		sb.append(userObjectId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public ExperienceUsers toEntityModel() {
		ExperienceUsersImpl experienceUsersImpl = new ExperienceUsersImpl();

		experienceUsersImpl.setExperienceUsersId(experienceUsersId);

		if (experienceUsersJob == null) {
			experienceUsersImpl.setExperienceUsersJob(StringPool.BLANK);
		}
		else {
			experienceUsersImpl.setExperienceUsersJob(experienceUsersJob);
		}

		if (experienceUsersCompany == null) {
			experienceUsersImpl.setExperienceUsersCompany(StringPool.BLANK);
		}
		else {
			experienceUsersImpl.setExperienceUsersCompany(experienceUsersCompany);
		}

		if (experienceUsersDateStart == Long.MIN_VALUE) {
			experienceUsersImpl.setExperienceUsersDateStart(null);
		}
		else {
			experienceUsersImpl.setExperienceUsersDateStart(new Date(
					experienceUsersDateStart));
		}

		if (experienceUsersDateFinish == Long.MIN_VALUE) {
			experienceUsersImpl.setExperienceUsersDateFinish(null);
		}
		else {
			experienceUsersImpl.setExperienceUsersDateFinish(new Date(
					experienceUsersDateFinish));
		}

		if (experienceUsersDescription == null) {
			experienceUsersImpl.setExperienceUsersDescription(StringPool.BLANK);
		}
		else {
			experienceUsersImpl.setExperienceUsersDescription(experienceUsersDescription);
		}

		experienceUsersImpl.setUserObjectId(userObjectId);

		experienceUsersImpl.resetOriginalValues();

		return experienceUsersImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		experienceUsersId = objectInput.readLong();
		experienceUsersJob = objectInput.readUTF();
		experienceUsersCompany = objectInput.readUTF();
		experienceUsersDateStart = objectInput.readLong();
		experienceUsersDateFinish = objectInput.readLong();
		experienceUsersDescription = objectInput.readUTF();
		userObjectId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(experienceUsersId);

		if (experienceUsersJob == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(experienceUsersJob);
		}

		if (experienceUsersCompany == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(experienceUsersCompany);
		}

		objectOutput.writeLong(experienceUsersDateStart);
		objectOutput.writeLong(experienceUsersDateFinish);

		if (experienceUsersDescription == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(experienceUsersDescription);
		}

		objectOutput.writeLong(userObjectId);
	}

	public long experienceUsersId;
	public String experienceUsersJob;
	public String experienceUsersCompany;
	public long experienceUsersDateStart;
	public long experienceUsersDateFinish;
	public String experienceUsersDescription;
	public long userObjectId;
}