/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link UserObjectLocalService}.
 *
 * @author Computer
 * @see UserObjectLocalService
 * @generated
 */
public class UserObjectLocalServiceWrapper implements UserObjectLocalService,
	ServiceWrapper<UserObjectLocalService> {
	public UserObjectLocalServiceWrapper(
		UserObjectLocalService userObjectLocalService) {
		_userObjectLocalService = userObjectLocalService;
	}

	/**
	* Adds the user object to the database. Also notifies the appropriate model listeners.
	*
	* @param userObject the user object
	* @return the user object that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.UserObject addUserObject(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.addUserObject(userObject);
	}

	/**
	* Creates a new user object with the primary key. Does not add the user object to the database.
	*
	* @param userObjectId the primary key for the new user object
	* @return the new user object
	*/
	@Override
	public com.portlets.action.model.UserObject createUserObject(
		long userObjectId) {
		return _userObjectLocalService.createUserObject(userObjectId);
	}

	/**
	* Deletes the user object with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object that was removed
	* @throws PortalException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.UserObject deleteUserObject(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.deleteUserObject(userObjectId);
	}

	/**
	* Deletes the user object from the database. Also notifies the appropriate model listeners.
	*
	* @param userObject the user object
	* @return the user object that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.UserObject deleteUserObject(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.deleteUserObject(userObject);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _userObjectLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.portlets.action.model.UserObject fetchUserObject(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.fetchUserObject(userObjectId);
	}

	/**
	* Returns the user object with the primary key.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object
	* @throws PortalException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.UserObject getUserObject(long userObjectId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getUserObject(userObjectId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the user objects.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of user objects
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getUserObjects(start, end);
	}

	/**
	* Returns the number of user objects.
	*
	* @return the number of user objects
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getUserObjectsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getUserObjectsCount();
	}

	/**
	* Updates the user object in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param userObject the user object
	* @return the user object that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.UserObject updateUserObject(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.updateUserObject(userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEducatorUserObject(long educatorId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEducatorUserObject(educatorId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEducatorUserObject(long educatorId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEducatorUserObject(educatorId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEducatorUserObjects(long educatorId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEducatorUserObjects(educatorId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEducatorUserObjects(long educatorId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEducatorUserObjects(educatorId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void clearEducatorUserObjects(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.clearEducatorUserObjects(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEducatorUserObject(long educatorId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEducatorUserObject(educatorId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEducatorUserObject(long educatorId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEducatorUserObject(educatorId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEducatorUserObjects(long educatorId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEducatorUserObjects(educatorId,
			userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEducatorUserObjects(long educatorId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEducatorUserObjects(educatorId,
			UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getEducatorUserObjects(
		long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEducatorUserObjects(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getEducatorUserObjects(
		long educatorId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEducatorUserObjects(educatorId,
			start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getEducatorUserObjects(
		long educatorId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEducatorUserObjects(educatorId,
			start, end, orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getEducatorUserObjectsCount(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEducatorUserObjectsCount(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasEducatorUserObject(long educatorId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasEducatorUserObject(educatorId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasEducatorUserObjects(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasEducatorUserObjects(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void setEducatorUserObjects(long educatorId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.setEducatorUserObjects(educatorId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addCourseUserObject(long courseId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addCourseUserObject(courseId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addCourseUserObject(long courseId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addCourseUserObject(courseId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addCourseUserObjects(long courseId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addCourseUserObjects(courseId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addCourseUserObjects(long courseId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addCourseUserObjects(courseId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void clearCourseUserObjects(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.clearCourseUserObjects(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteCourseUserObject(long courseId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteCourseUserObject(courseId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteCourseUserObject(long courseId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteCourseUserObject(courseId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteCourseUserObjects(long courseId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteCourseUserObjects(courseId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteCourseUserObjects(long courseId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteCourseUserObjects(courseId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getCourseUserObjects(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getCourseUserObjects(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getCourseUserObjects(
		long courseId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getCourseUserObjects(courseId, start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getCourseUserObjects(
		long courseId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getCourseUserObjects(courseId, start,
			end, orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getCourseUserObjectsCount(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getCourseUserObjectsCount(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasCourseUserObject(long courseId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasCourseUserObject(courseId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasCourseUserObjects(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasCourseUserObjects(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void setCourseUserObjects(long courseId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.setCourseUserObjects(courseId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEmployerUserObject(long employerId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEmployerUserObject(employerId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEmployerUserObject(long employerId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEmployerUserObject(employerId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEmployerUserObjects(long employerId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEmployerUserObjects(employerId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addEmployerUserObjects(long employerId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addEmployerUserObjects(employerId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void clearEmployerUserObjects(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.clearEmployerUserObjects(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEmployerUserObject(long employerId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEmployerUserObject(employerId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEmployerUserObject(long employerId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEmployerUserObject(employerId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEmployerUserObjects(long employerId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEmployerUserObjects(employerId,
			userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteEmployerUserObjects(long employerId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteEmployerUserObjects(employerId,
			UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getEmployerUserObjects(
		long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEmployerUserObjects(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getEmployerUserObjects(
		long employerId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEmployerUserObjects(employerId,
			start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getEmployerUserObjects(
		long employerId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEmployerUserObjects(employerId,
			start, end, orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getEmployerUserObjectsCount(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getEmployerUserObjectsCount(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasEmployerUserObject(long employerId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasEmployerUserObject(employerId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasEmployerUserObjects(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasEmployerUserObjects(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void setEmployerUserObjects(long employerId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.setEmployerUserObjects(employerId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addRecruitmentUserObject(long recruitmentId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addRecruitmentUserObject(recruitmentId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addRecruitmentUserObject(long recruitmentId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addRecruitmentUserObject(recruitmentId,
			userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addRecruitmentUserObjects(long recruitmentId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addRecruitmentUserObjects(recruitmentId,
			userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addRecruitmentUserObjects(long recruitmentId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.addRecruitmentUserObjects(recruitmentId,
			UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void clearRecruitmentUserObjects(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.clearRecruitmentUserObjects(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteRecruitmentUserObject(long recruitmentId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteRecruitmentUserObject(recruitmentId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteRecruitmentUserObject(long recruitmentId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteRecruitmentUserObject(recruitmentId,
			userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteRecruitmentUserObjects(long recruitmentId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteRecruitmentUserObjects(recruitmentId,
			userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteRecruitmentUserObjects(long recruitmentId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.deleteRecruitmentUserObjects(recruitmentId,
			UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getRecruitmentUserObjects(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getRecruitmentUserObjects(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getRecruitmentUserObjects(
		long recruitmentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getRecruitmentUserObjects(recruitmentId,
			start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.UserObject> getRecruitmentUserObjects(
		long recruitmentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getRecruitmentUserObjects(recruitmentId,
			start, end, orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getRecruitmentUserObjectsCount(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.getRecruitmentUserObjectsCount(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasRecruitmentUserObject(long recruitmentId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasRecruitmentUserObject(recruitmentId,
			userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasRecruitmentUserObjects(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _userObjectLocalService.hasRecruitmentUserObjects(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void setRecruitmentUserObjects(long recruitmentId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObjectLocalService.setRecruitmentUserObjects(recruitmentId,
			userObjectIds);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _userObjectLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_userObjectLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _userObjectLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public UserObjectLocalService getWrappedUserObjectLocalService() {
		return _userObjectLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedUserObjectLocalService(
		UserObjectLocalService userObjectLocalService) {
		_userObjectLocalService = userObjectLocalService;
	}

	@Override
	public UserObjectLocalService getWrappedService() {
		return _userObjectLocalService;
	}

	@Override
	public void setWrappedService(UserObjectLocalService userObjectLocalService) {
		_userObjectLocalService = userObjectLocalService;
	}

	private UserObjectLocalService _userObjectLocalService;
}