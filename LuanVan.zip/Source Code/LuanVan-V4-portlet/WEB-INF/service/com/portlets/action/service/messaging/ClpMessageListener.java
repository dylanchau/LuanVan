/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.messaging;

import com.liferay.portal.kernel.messaging.BaseMessageListener;
import com.liferay.portal.kernel.messaging.Message;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.CourseServiceUtil;
import com.portlets.action.service.EducationUsersLocalServiceUtil;
import com.portlets.action.service.EducationUsersServiceUtil;
import com.portlets.action.service.EducatorLocalServiceUtil;
import com.portlets.action.service.EducatorServiceUtil;
import com.portlets.action.service.EmployerLocalServiceUtil;
import com.portlets.action.service.EmployerServiceUtil;
import com.portlets.action.service.ExperienceUsersLocalServiceUtil;
import com.portlets.action.service.ExperienceUsersServiceUtil;
import com.portlets.action.service.LevelLocalServiceUtil;
import com.portlets.action.service.LevelServiceUtil;
import com.portlets.action.service.LinkUserCourseLocalServiceUtil;
import com.portlets.action.service.LinkUserCourseServiceUtil;
import com.portlets.action.service.LinkUserRecruitmentLocalServiceUtil;
import com.portlets.action.service.LinkUserRecruitmentServiceUtil;
import com.portlets.action.service.LinkUsersLocalServiceUtil;
import com.portlets.action.service.LinkUsersServiceUtil;
import com.portlets.action.service.RecruitmentLocalServiceUtil;
import com.portlets.action.service.RecruitmentServiceUtil;
import com.portlets.action.service.RegisterCourseLocalServiceUtil;
import com.portlets.action.service.RegisterCourseServiceUtil;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;
import com.portlets.action.service.RegisterRecruitmentServiceUtil;
import com.portlets.action.service.SkillLocalServiceUtil;
import com.portlets.action.service.SkillServiceUtil;
import com.portlets.action.service.StatesLocalServiceUtil;
import com.portlets.action.service.StatesServiceUtil;
import com.portlets.action.service.TrainingProgramLocalServiceUtil;
import com.portlets.action.service.TrainingProgramServiceUtil;
import com.portlets.action.service.UserObjectLocalServiceUtil;
import com.portlets.action.service.UserObjectServiceUtil;
import com.portlets.action.service.UserSkillLevelLocalServiceUtil;
import com.portlets.action.service.UserSkillLevelServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerServiceUtil;

/**
 * @author Computer
 */
public class ClpMessageListener extends BaseMessageListener {
	public static String getServletContextName() {
		return ClpSerializer.getServletContextName();
	}

	@Override
	protected void doReceive(Message message) throws Exception {
		String command = message.getString("command");
		String servletContextName = message.getString("servletContextName");

		if (command.equals("undeploy") &&
				servletContextName.equals(getServletContextName())) {
			CourseLocalServiceUtil.clearService();

			CourseServiceUtil.clearService();
			EducationUsersLocalServiceUtil.clearService();

			EducationUsersServiceUtil.clearService();
			EducatorLocalServiceUtil.clearService();

			EducatorServiceUtil.clearService();
			EmployerLocalServiceUtil.clearService();

			EmployerServiceUtil.clearService();
			ExperienceUsersLocalServiceUtil.clearService();

			ExperienceUsersServiceUtil.clearService();
			LevelLocalServiceUtil.clearService();

			LevelServiceUtil.clearService();
			LinkUserCourseLocalServiceUtil.clearService();

			LinkUserCourseServiceUtil.clearService();
			LinkUserRecruitmentLocalServiceUtil.clearService();

			LinkUserRecruitmentServiceUtil.clearService();
			LinkUsersLocalServiceUtil.clearService();

			LinkUsersServiceUtil.clearService();
			RecruitmentLocalServiceUtil.clearService();

			RecruitmentServiceUtil.clearService();
			RegisterCourseLocalServiceUtil.clearService();

			RegisterCourseServiceUtil.clearService();
			RegisterRecruitmentLocalServiceUtil.clearService();

			RegisterRecruitmentServiceUtil.clearService();
			SkillLocalServiceUtil.clearService();

			SkillServiceUtil.clearService();
			StatesLocalServiceUtil.clearService();

			StatesServiceUtil.clearService();
			TrainingProgramLocalServiceUtil.clearService();

			TrainingProgramServiceUtil.clearService();
			UserObjectLocalServiceUtil.clearService();

			UserObjectServiceUtil.clearService();
			UserSkillLevelLocalServiceUtil.clearService();

			UserSkillLevelServiceUtil.clearService();
			UserSkillListenerLocalServiceUtil.clearService();

			UserSkillListenerServiceUtil.clearService();
		}
	}
}