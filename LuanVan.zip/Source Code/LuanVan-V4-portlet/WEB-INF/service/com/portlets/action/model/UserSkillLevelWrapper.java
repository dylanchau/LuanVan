/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link UserSkillLevel}.
 * </p>
 *
 * @author Computer
 * @see UserSkillLevel
 * @generated
 */
public class UserSkillLevelWrapper implements UserSkillLevel,
	ModelWrapper<UserSkillLevel> {
	public UserSkillLevelWrapper(UserSkillLevel userSkillLevel) {
		_userSkillLevel = userSkillLevel;
	}

	@Override
	public Class<?> getModelClass() {
		return UserSkillLevel.class;
	}

	@Override
	public String getModelClassName() {
		return UserSkillLevel.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userObjectId", getUserObjectId());
		attributes.put("skillId", getSkillId());
		attributes.put("levelId", getLevelId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		Long skillId = (Long)attributes.get("skillId");

		if (skillId != null) {
			setSkillId(skillId);
		}

		Long levelId = (Long)attributes.get("levelId");

		if (levelId != null) {
			setLevelId(levelId);
		}
	}

	/**
	* Returns the primary key of this user skill level.
	*
	* @return the primary key of this user skill level
	*/
	@Override
	public com.portlets.action.service.persistence.UserSkillLevelPK getPrimaryKey() {
		return _userSkillLevel.getPrimaryKey();
	}

	/**
	* Sets the primary key of this user skill level.
	*
	* @param primaryKey the primary key of this user skill level
	*/
	@Override
	public void setPrimaryKey(
		com.portlets.action.service.persistence.UserSkillLevelPK primaryKey) {
		_userSkillLevel.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the user object ID of this user skill level.
	*
	* @return the user object ID of this user skill level
	*/
	@Override
	public long getUserObjectId() {
		return _userSkillLevel.getUserObjectId();
	}

	/**
	* Sets the user object ID of this user skill level.
	*
	* @param userObjectId the user object ID of this user skill level
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_userSkillLevel.setUserObjectId(userObjectId);
	}

	/**
	* Returns the skill ID of this user skill level.
	*
	* @return the skill ID of this user skill level
	*/
	@Override
	public long getSkillId() {
		return _userSkillLevel.getSkillId();
	}

	/**
	* Sets the skill ID of this user skill level.
	*
	* @param skillId the skill ID of this user skill level
	*/
	@Override
	public void setSkillId(long skillId) {
		_userSkillLevel.setSkillId(skillId);
	}

	/**
	* Returns the level ID of this user skill level.
	*
	* @return the level ID of this user skill level
	*/
	@Override
	public long getLevelId() {
		return _userSkillLevel.getLevelId();
	}

	/**
	* Sets the level ID of this user skill level.
	*
	* @param levelId the level ID of this user skill level
	*/
	@Override
	public void setLevelId(long levelId) {
		_userSkillLevel.setLevelId(levelId);
	}

	@Override
	public boolean isNew() {
		return _userSkillLevel.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_userSkillLevel.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _userSkillLevel.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_userSkillLevel.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _userSkillLevel.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _userSkillLevel.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_userSkillLevel.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _userSkillLevel.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_userSkillLevel.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_userSkillLevel.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_userSkillLevel.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new UserSkillLevelWrapper((UserSkillLevel)_userSkillLevel.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.UserSkillLevel userSkillLevel) {
		return _userSkillLevel.compareTo(userSkillLevel);
	}

	@Override
	public int hashCode() {
		return _userSkillLevel.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.UserSkillLevel> toCacheModel() {
		return _userSkillLevel.toCacheModel();
	}

	@Override
	public com.portlets.action.model.UserSkillLevel toEscapedModel() {
		return new UserSkillLevelWrapper(_userSkillLevel.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.UserSkillLevel toUnescapedModel() {
		return new UserSkillLevelWrapper(_userSkillLevel.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _userSkillLevel.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _userSkillLevel.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_userSkillLevel.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserSkillLevelWrapper)) {
			return false;
		}

		UserSkillLevelWrapper userSkillLevelWrapper = (UserSkillLevelWrapper)obj;

		if (Validator.equals(_userSkillLevel,
					userSkillLevelWrapper._userSkillLevel)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public UserSkillLevel getWrappedUserSkillLevel() {
		return _userSkillLevel;
	}

	@Override
	public UserSkillLevel getWrappedModel() {
		return _userSkillLevel;
	}

	@Override
	public void resetOriginalValues() {
		_userSkillLevel.resetOriginalValues();
	}

	private UserSkillLevel _userSkillLevel;
}