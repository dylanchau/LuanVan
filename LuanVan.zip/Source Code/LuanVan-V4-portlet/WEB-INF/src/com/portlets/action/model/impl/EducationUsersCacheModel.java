/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.EducationUsers;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing EducationUsers in entity cache.
 *
 * @author Computer
 * @see EducationUsers
 * @generated
 */
public class EducationUsersCacheModel implements CacheModel<EducationUsers>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{educationUsersId=");
		sb.append(educationUsersId);
		sb.append(", educationUsersSchool=");
		sb.append(educationUsersSchool);
		sb.append(", educationUsersMajor=");
		sb.append(educationUsersMajor);
		sb.append(", educationUsersDateStart=");
		sb.append(educationUsersDateStart);
		sb.append(", educationUsersDateFinish=");
		sb.append(educationUsersDateFinish);
		sb.append(", educationUsersDegree=");
		sb.append(educationUsersDegree);
		sb.append(", educationUsersDescription=");
		sb.append(educationUsersDescription);
		sb.append(", userObjectId=");
		sb.append(userObjectId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public EducationUsers toEntityModel() {
		EducationUsersImpl educationUsersImpl = new EducationUsersImpl();

		educationUsersImpl.setEducationUsersId(educationUsersId);

		if (educationUsersSchool == null) {
			educationUsersImpl.setEducationUsersSchool(StringPool.BLANK);
		}
		else {
			educationUsersImpl.setEducationUsersSchool(educationUsersSchool);
		}

		if (educationUsersMajor == null) {
			educationUsersImpl.setEducationUsersMajor(StringPool.BLANK);
		}
		else {
			educationUsersImpl.setEducationUsersMajor(educationUsersMajor);
		}

		if (educationUsersDateStart == Long.MIN_VALUE) {
			educationUsersImpl.setEducationUsersDateStart(null);
		}
		else {
			educationUsersImpl.setEducationUsersDateStart(new Date(
					educationUsersDateStart));
		}

		if (educationUsersDateFinish == Long.MIN_VALUE) {
			educationUsersImpl.setEducationUsersDateFinish(null);
		}
		else {
			educationUsersImpl.setEducationUsersDateFinish(new Date(
					educationUsersDateFinish));
		}

		if (educationUsersDegree == null) {
			educationUsersImpl.setEducationUsersDegree(StringPool.BLANK);
		}
		else {
			educationUsersImpl.setEducationUsersDegree(educationUsersDegree);
		}

		if (educationUsersDescription == null) {
			educationUsersImpl.setEducationUsersDescription(StringPool.BLANK);
		}
		else {
			educationUsersImpl.setEducationUsersDescription(educationUsersDescription);
		}

		educationUsersImpl.setUserObjectId(userObjectId);

		educationUsersImpl.resetOriginalValues();

		return educationUsersImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		educationUsersId = objectInput.readLong();
		educationUsersSchool = objectInput.readUTF();
		educationUsersMajor = objectInput.readUTF();
		educationUsersDateStart = objectInput.readLong();
		educationUsersDateFinish = objectInput.readLong();
		educationUsersDegree = objectInput.readUTF();
		educationUsersDescription = objectInput.readUTF();
		userObjectId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(educationUsersId);

		if (educationUsersSchool == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educationUsersSchool);
		}

		if (educationUsersMajor == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educationUsersMajor);
		}

		objectOutput.writeLong(educationUsersDateStart);
		objectOutput.writeLong(educationUsersDateFinish);

		if (educationUsersDegree == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educationUsersDegree);
		}

		if (educationUsersDescription == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educationUsersDescription);
		}

		objectOutput.writeLong(userObjectId);
	}

	public long educationUsersId;
	public String educationUsersSchool;
	public String educationUsersMajor;
	public long educationUsersDateStart;
	public long educationUsersDateFinish;
	public String educationUsersDegree;
	public String educationUsersDescription;
	public long userObjectId;
}