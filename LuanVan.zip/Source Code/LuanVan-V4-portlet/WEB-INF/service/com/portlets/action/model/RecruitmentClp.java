/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.RecruitmentLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class RecruitmentClp extends BaseModelImpl<Recruitment>
	implements Recruitment {
	public RecruitmentClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Recruitment.class;
	}

	@Override
	public String getModelClassName() {
		return Recruitment.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _recruitmentId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setRecruitmentId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _recruitmentId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recruitmentId", getRecruitmentId());
		attributes.put("recruitmentName", getRecruitmentName());
		attributes.put("recruitmentPosition", getRecruitmentPosition());
		attributes.put("recruitmentDescription", getRecruitmentDescription());
		attributes.put("recruitmentBenefit", getRecruitmentBenefit());
		attributes.put("recruitmentJobType", getRecruitmentJobType());
		attributes.put("recruitmentFileReq", getRecruitmentFileReq());
		attributes.put("recruitmentFileDeadlineFrom",
			getRecruitmentFileDeadlineFrom());
		attributes.put("recruitmentFileDeadlineTo",
			getRecruitmentFileDeadlineTo());
		attributes.put("recruitmentSalary", getRecruitmentSalary());
		attributes.put("recruitmentNo", getRecruitmentNo());
		attributes.put("recruitmentGender", getRecruitmentGender());
		attributes.put("recruitmentQualification", getRecruitmentQualification());
		attributes.put("recruitmentAgeFrom", getRecruitmentAgeFrom());
		attributes.put("recruitmentAgeTo", getRecruitmentAgeTo());
		attributes.put("recruitmentExper", getRecruitmentExper());
		attributes.put("employerId", getEmployerId());
		attributes.put("statesId", getStatesId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long recruitmentId = (Long)attributes.get("recruitmentId");

		if (recruitmentId != null) {
			setRecruitmentId(recruitmentId);
		}

		String recruitmentName = (String)attributes.get("recruitmentName");

		if (recruitmentName != null) {
			setRecruitmentName(recruitmentName);
		}

		String recruitmentPosition = (String)attributes.get(
				"recruitmentPosition");

		if (recruitmentPosition != null) {
			setRecruitmentPosition(recruitmentPosition);
		}

		String recruitmentDescription = (String)attributes.get(
				"recruitmentDescription");

		if (recruitmentDescription != null) {
			setRecruitmentDescription(recruitmentDescription);
		}

		String recruitmentBenefit = (String)attributes.get("recruitmentBenefit");

		if (recruitmentBenefit != null) {
			setRecruitmentBenefit(recruitmentBenefit);
		}

		String recruitmentJobType = (String)attributes.get("recruitmentJobType");

		if (recruitmentJobType != null) {
			setRecruitmentJobType(recruitmentJobType);
		}

		String recruitmentFileReq = (String)attributes.get("recruitmentFileReq");

		if (recruitmentFileReq != null) {
			setRecruitmentFileReq(recruitmentFileReq);
		}

		Date recruitmentFileDeadlineFrom = (Date)attributes.get(
				"recruitmentFileDeadlineFrom");

		if (recruitmentFileDeadlineFrom != null) {
			setRecruitmentFileDeadlineFrom(recruitmentFileDeadlineFrom);
		}

		Date recruitmentFileDeadlineTo = (Date)attributes.get(
				"recruitmentFileDeadlineTo");

		if (recruitmentFileDeadlineTo != null) {
			setRecruitmentFileDeadlineTo(recruitmentFileDeadlineTo);
		}

		String recruitmentSalary = (String)attributes.get("recruitmentSalary");

		if (recruitmentSalary != null) {
			setRecruitmentSalary(recruitmentSalary);
		}

		Integer recruitmentNo = (Integer)attributes.get("recruitmentNo");

		if (recruitmentNo != null) {
			setRecruitmentNo(recruitmentNo);
		}

		String recruitmentGender = (String)attributes.get("recruitmentGender");

		if (recruitmentGender != null) {
			setRecruitmentGender(recruitmentGender);
		}

		String recruitmentQualification = (String)attributes.get(
				"recruitmentQualification");

		if (recruitmentQualification != null) {
			setRecruitmentQualification(recruitmentQualification);
		}

		Integer recruitmentAgeFrom = (Integer)attributes.get(
				"recruitmentAgeFrom");

		if (recruitmentAgeFrom != null) {
			setRecruitmentAgeFrom(recruitmentAgeFrom);
		}

		Integer recruitmentAgeTo = (Integer)attributes.get("recruitmentAgeTo");

		if (recruitmentAgeTo != null) {
			setRecruitmentAgeTo(recruitmentAgeTo);
		}

		String recruitmentExper = (String)attributes.get("recruitmentExper");

		if (recruitmentExper != null) {
			setRecruitmentExper(recruitmentExper);
		}

		Long employerId = (Long)attributes.get("employerId");

		if (employerId != null) {
			setEmployerId(employerId);
		}

		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}
	}

	@Override
	public long getRecruitmentId() {
		return _recruitmentId;
	}

	@Override
	public void setRecruitmentId(long recruitmentId) {
		_recruitmentId = recruitmentId;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentId", long.class);

				method.invoke(_recruitmentRemoteModel, recruitmentId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentName() {
		return _recruitmentName;
	}

	@Override
	public void setRecruitmentName(String recruitmentName) {
		_recruitmentName = recruitmentName;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentName",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentPosition() {
		return _recruitmentPosition;
	}

	@Override
	public void setRecruitmentPosition(String recruitmentPosition) {
		_recruitmentPosition = recruitmentPosition;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentPosition",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentPosition);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentDescription() {
		return _recruitmentDescription;
	}

	@Override
	public void setRecruitmentDescription(String recruitmentDescription) {
		_recruitmentDescription = recruitmentDescription;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentDescription",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentDescription);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentBenefit() {
		return _recruitmentBenefit;
	}

	@Override
	public void setRecruitmentBenefit(String recruitmentBenefit) {
		_recruitmentBenefit = recruitmentBenefit;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentBenefit",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentBenefit);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentJobType() {
		return _recruitmentJobType;
	}

	@Override
	public void setRecruitmentJobType(String recruitmentJobType) {
		_recruitmentJobType = recruitmentJobType;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentJobType",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentJobType);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentFileReq() {
		return _recruitmentFileReq;
	}

	@Override
	public void setRecruitmentFileReq(String recruitmentFileReq) {
		_recruitmentFileReq = recruitmentFileReq;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentFileReq",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentFileReq);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getRecruitmentFileDeadlineFrom() {
		return _recruitmentFileDeadlineFrom;
	}

	@Override
	public void setRecruitmentFileDeadlineFrom(Date recruitmentFileDeadlineFrom) {
		_recruitmentFileDeadlineFrom = recruitmentFileDeadlineFrom;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentFileDeadlineFrom",
						Date.class);

				method.invoke(_recruitmentRemoteModel,
					recruitmentFileDeadlineFrom);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getRecruitmentFileDeadlineTo() {
		return _recruitmentFileDeadlineTo;
	}

	@Override
	public void setRecruitmentFileDeadlineTo(Date recruitmentFileDeadlineTo) {
		_recruitmentFileDeadlineTo = recruitmentFileDeadlineTo;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentFileDeadlineTo",
						Date.class);

				method.invoke(_recruitmentRemoteModel, recruitmentFileDeadlineTo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentSalary() {
		return _recruitmentSalary;
	}

	@Override
	public void setRecruitmentSalary(String recruitmentSalary) {
		_recruitmentSalary = recruitmentSalary;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentSalary",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentSalary);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRecruitmentNo() {
		return _recruitmentNo;
	}

	@Override
	public void setRecruitmentNo(int recruitmentNo) {
		_recruitmentNo = recruitmentNo;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentNo", int.class);

				method.invoke(_recruitmentRemoteModel, recruitmentNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentGender() {
		return _recruitmentGender;
	}

	@Override
	public void setRecruitmentGender(String recruitmentGender) {
		_recruitmentGender = recruitmentGender;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentGender",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentGender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentQualification() {
		return _recruitmentQualification;
	}

	@Override
	public void setRecruitmentQualification(String recruitmentQualification) {
		_recruitmentQualification = recruitmentQualification;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentQualification",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentQualification);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRecruitmentAgeFrom() {
		return _recruitmentAgeFrom;
	}

	@Override
	public void setRecruitmentAgeFrom(int recruitmentAgeFrom) {
		_recruitmentAgeFrom = recruitmentAgeFrom;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentAgeFrom",
						int.class);

				method.invoke(_recruitmentRemoteModel, recruitmentAgeFrom);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getRecruitmentAgeTo() {
		return _recruitmentAgeTo;
	}

	@Override
	public void setRecruitmentAgeTo(int recruitmentAgeTo) {
		_recruitmentAgeTo = recruitmentAgeTo;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentAgeTo", int.class);

				method.invoke(_recruitmentRemoteModel, recruitmentAgeTo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getRecruitmentExper() {
		return _recruitmentExper;
	}

	@Override
	public void setRecruitmentExper(String recruitmentExper) {
		_recruitmentExper = recruitmentExper;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentExper",
						String.class);

				method.invoke(_recruitmentRemoteModel, recruitmentExper);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getEmployerId() {
		return _employerId;
	}

	@Override
	public void setEmployerId(long employerId) {
		_employerId = employerId;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerId", long.class);

				method.invoke(_recruitmentRemoteModel, employerId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getStatesId() {
		return _statesId;
	}

	@Override
	public void setStatesId(long statesId) {
		_statesId = statesId;

		if (_recruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _recruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setStatesId", long.class);

				method.invoke(_recruitmentRemoteModel, statesId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getRecruitmentRemoteModel() {
		return _recruitmentRemoteModel;
	}

	public void setRecruitmentRemoteModel(BaseModel<?> recruitmentRemoteModel) {
		_recruitmentRemoteModel = recruitmentRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _recruitmentRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_recruitmentRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			RecruitmentLocalServiceUtil.addRecruitment(this);
		}
		else {
			RecruitmentLocalServiceUtil.updateRecruitment(this);
		}
	}

	@Override
	public Recruitment toEscapedModel() {
		return (Recruitment)ProxyUtil.newProxyInstance(Recruitment.class.getClassLoader(),
			new Class[] { Recruitment.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		RecruitmentClp clone = new RecruitmentClp();

		clone.setRecruitmentId(getRecruitmentId());
		clone.setRecruitmentName(getRecruitmentName());
		clone.setRecruitmentPosition(getRecruitmentPosition());
		clone.setRecruitmentDescription(getRecruitmentDescription());
		clone.setRecruitmentBenefit(getRecruitmentBenefit());
		clone.setRecruitmentJobType(getRecruitmentJobType());
		clone.setRecruitmentFileReq(getRecruitmentFileReq());
		clone.setRecruitmentFileDeadlineFrom(getRecruitmentFileDeadlineFrom());
		clone.setRecruitmentFileDeadlineTo(getRecruitmentFileDeadlineTo());
		clone.setRecruitmentSalary(getRecruitmentSalary());
		clone.setRecruitmentNo(getRecruitmentNo());
		clone.setRecruitmentGender(getRecruitmentGender());
		clone.setRecruitmentQualification(getRecruitmentQualification());
		clone.setRecruitmentAgeFrom(getRecruitmentAgeFrom());
		clone.setRecruitmentAgeTo(getRecruitmentAgeTo());
		clone.setRecruitmentExper(getRecruitmentExper());
		clone.setEmployerId(getEmployerId());
		clone.setStatesId(getStatesId());

		return clone;
	}

	@Override
	public int compareTo(Recruitment recruitment) {
		long primaryKey = recruitment.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RecruitmentClp)) {
			return false;
		}

		RecruitmentClp recruitment = (RecruitmentClp)obj;

		long primaryKey = recruitment.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(37);

		sb.append("{recruitmentId=");
		sb.append(getRecruitmentId());
		sb.append(", recruitmentName=");
		sb.append(getRecruitmentName());
		sb.append(", recruitmentPosition=");
		sb.append(getRecruitmentPosition());
		sb.append(", recruitmentDescription=");
		sb.append(getRecruitmentDescription());
		sb.append(", recruitmentBenefit=");
		sb.append(getRecruitmentBenefit());
		sb.append(", recruitmentJobType=");
		sb.append(getRecruitmentJobType());
		sb.append(", recruitmentFileReq=");
		sb.append(getRecruitmentFileReq());
		sb.append(", recruitmentFileDeadlineFrom=");
		sb.append(getRecruitmentFileDeadlineFrom());
		sb.append(", recruitmentFileDeadlineTo=");
		sb.append(getRecruitmentFileDeadlineTo());
		sb.append(", recruitmentSalary=");
		sb.append(getRecruitmentSalary());
		sb.append(", recruitmentNo=");
		sb.append(getRecruitmentNo());
		sb.append(", recruitmentGender=");
		sb.append(getRecruitmentGender());
		sb.append(", recruitmentQualification=");
		sb.append(getRecruitmentQualification());
		sb.append(", recruitmentAgeFrom=");
		sb.append(getRecruitmentAgeFrom());
		sb.append(", recruitmentAgeTo=");
		sb.append(getRecruitmentAgeTo());
		sb.append(", recruitmentExper=");
		sb.append(getRecruitmentExper());
		sb.append(", employerId=");
		sb.append(getEmployerId());
		sb.append(", statesId=");
		sb.append(getStatesId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(58);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.Recruitment");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>recruitmentId</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentName</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentPosition</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentPosition());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentDescription</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentBenefit</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentBenefit());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentJobType</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentJobType());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentFileReq</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentFileReq());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentFileDeadlineFrom</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentFileDeadlineFrom());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentFileDeadlineTo</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentFileDeadlineTo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentSalary</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentSalary());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentNo</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentGender</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentGender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentQualification</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentQualification());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentAgeFrom</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentAgeFrom());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentAgeTo</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentAgeTo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>recruitmentExper</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentExper());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerId</column-name><column-value><![CDATA[");
		sb.append(getEmployerId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statesId</column-name><column-value><![CDATA[");
		sb.append(getStatesId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _recruitmentId;
	private String _recruitmentName;
	private String _recruitmentPosition;
	private String _recruitmentDescription;
	private String _recruitmentBenefit;
	private String _recruitmentJobType;
	private String _recruitmentFileReq;
	private Date _recruitmentFileDeadlineFrom;
	private Date _recruitmentFileDeadlineTo;
	private String _recruitmentSalary;
	private int _recruitmentNo;
	private String _recruitmentGender;
	private String _recruitmentQualification;
	private int _recruitmentAgeFrom;
	private int _recruitmentAgeTo;
	private String _recruitmentExper;
	private long _employerId;
	private long _statesId;
	private BaseModel<?> _recruitmentRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}