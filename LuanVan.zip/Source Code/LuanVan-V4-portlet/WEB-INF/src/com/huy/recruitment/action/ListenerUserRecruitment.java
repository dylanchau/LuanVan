package com.huy.recruitment.action;
import java.util.ArrayList;
import java.util.List;

import com.portlets.action.model.LinkUserRecruitment;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.model.impl.LinkUserRecruitmentImpl;
import com.portlets.action.service.LinkUserRecruitmentLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
public class ListenerUserRecruitment {
	
		
		public ListenerUserRecruitment() {
			// TODO Auto-generated constructor stub
		}
		
		public void addLinkUserRecruitmentId(Long recruitmentId, Long skillId) throws SystemException, PortalException {
			List<UserSkillListener> userSkillListener = new ArrayList<UserSkillListener>();
			userSkillListener = UserSkillListenerLocalServiceUtil.getBySkillId(skillId);
			
			LinkUserRecruitment linkUserRecruitment1 = new LinkUserRecruitmentImpl();
			linkUserRecruitment1.setRecruitmentId(recruitmentId);
			linkUserRecruitment1.setLinkUserRecruitmentNo(1);
			for(UserSkillListener su:userSkillListener){
				System.out.println("#################"+su.getUserObjectId()+"################"+recruitmentId+"##############");
				linkUserRecruitment1.setUserObjectId(su.getUserObjectId());
				try {
					LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
					
					linkUserRecruitment1=LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
					linkUserRecruitment1.setLinkUserRecruitmentNo(linkUserRecruitment1.getLinkUserRecruitmentNo()+1);
					LinkUserRecruitmentLocalServiceUtil.updateLinkUserRecruitment(linkUserRecruitment1);
				} catch(Exception e){
					LinkUserRecruitmentLocalServiceUtil.addLinkUserRecruitment(linkUserRecruitment1);
				}
			}
		}
		
		public void deleteLinkUserRecruitmentId(Long RecruitmentId, Long skillId) throws SystemException, PortalException {
			List<UserSkillListener> userSkillListener = new ArrayList<UserSkillListener>();
			userSkillListener =UserSkillListenerLocalServiceUtil.getBySkillId(skillId);
			
			LinkUserRecruitment linkUserRecruitment1 = new LinkUserRecruitmentImpl();
			linkUserRecruitment1.setRecruitmentId(RecruitmentId);
			linkUserRecruitment1.setLinkUserRecruitmentNo(1);
			for(UserSkillListener su:userSkillListener){
				System.out.println("#################"+su.getUserObjectId()+"################"+RecruitmentId+"##############");
				linkUserRecruitment1.setUserObjectId(su.getUserObjectId());
				try {
					LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
					
					linkUserRecruitment1=LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
					if(linkUserRecruitment1.getLinkUserRecruitmentNo()==1){
						LinkUserRecruitmentLocalServiceUtil.deleteLinkUserRecruitment(linkUserRecruitment1);
					} else {
						linkUserRecruitment1.setLinkUserRecruitmentNo(linkUserRecruitment1.getLinkUserRecruitmentNo()-1);
						LinkUserRecruitmentLocalServiceUtil.updateLinkUserRecruitment(linkUserRecruitment1);
					}
				} catch(Exception e){
					LinkUserRecruitmentLocalServiceUtil.addLinkUserRecruitment(linkUserRecruitment1);
				}
			}
		}
	}


