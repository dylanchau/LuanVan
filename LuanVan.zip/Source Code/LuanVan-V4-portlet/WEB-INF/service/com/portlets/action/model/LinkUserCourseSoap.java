/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.portlets.action.service.persistence.LinkUserCoursePK;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.LinkUserCourseServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.LinkUserCourseServiceSoap
 * @generated
 */
public class LinkUserCourseSoap implements Serializable {
	public static LinkUserCourseSoap toSoapModel(LinkUserCourse model) {
		LinkUserCourseSoap soapModel = new LinkUserCourseSoap();

		soapModel.setUserObjectId(model.getUserObjectId());
		soapModel.setCourseId(model.getCourseId());
		soapModel.setLinkUserCourseNo(model.getLinkUserCourseNo());

		return soapModel;
	}

	public static LinkUserCourseSoap[] toSoapModels(LinkUserCourse[] models) {
		LinkUserCourseSoap[] soapModels = new LinkUserCourseSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static LinkUserCourseSoap[][] toSoapModels(LinkUserCourse[][] models) {
		LinkUserCourseSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new LinkUserCourseSoap[models.length][models[0].length];
		}
		else {
			soapModels = new LinkUserCourseSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static LinkUserCourseSoap[] toSoapModels(List<LinkUserCourse> models) {
		List<LinkUserCourseSoap> soapModels = new ArrayList<LinkUserCourseSoap>(models.size());

		for (LinkUserCourse model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new LinkUserCourseSoap[soapModels.size()]);
	}

	public LinkUserCourseSoap() {
	}

	public LinkUserCoursePK getPrimaryKey() {
		return new LinkUserCoursePK(_userObjectId, _courseId);
	}

	public void setPrimaryKey(LinkUserCoursePK pk) {
		setUserObjectId(pk.userObjectId);
		setCourseId(pk.courseId);
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	public long getCourseId() {
		return _courseId;
	}

	public void setCourseId(long courseId) {
		_courseId = courseId;
	}

	public int getLinkUserCourseNo() {
		return _linkUserCourseNo;
	}

	public void setLinkUserCourseNo(int linkUserCourseNo) {
		_linkUserCourseNo = linkUserCourseNo;
	}

	private long _userObjectId;
	private long _courseId;
	private int _linkUserCourseNo;
}