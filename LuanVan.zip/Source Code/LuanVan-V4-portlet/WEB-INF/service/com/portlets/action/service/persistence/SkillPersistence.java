/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.portlets.action.model.Skill;

/**
 * The persistence interface for the skill service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see SkillPersistenceImpl
 * @see SkillUtil
 * @generated
 */
public interface SkillPersistence extends BasePersistence<Skill> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link SkillUtil} to access the skill persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the skills where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @return the matching skills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> findByskillAncestor(
		long skillAncestor)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the skills where skillAncestor = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param skillAncestor the skill ancestor
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> findByskillAncestor(
		long skillAncestor, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the skills where skillAncestor = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param skillAncestor the skill ancestor
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> findByskillAncestor(
		long skillAncestor, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching skill
	* @throws com.portlets.action.NoSuchSkillException if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill findByskillAncestor_First(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException;

	/**
	* Returns the first skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill fetchByskillAncestor_First(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching skill
	* @throws com.portlets.action.NoSuchSkillException if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill findByskillAncestor_Last(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException;

	/**
	* Returns the last skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill fetchByskillAncestor_Last(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the skills before and after the current skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillId the primary key of the current skill
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next skill
	* @throws com.portlets.action.NoSuchSkillException if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill[] findByskillAncestor_PrevAndNext(
		long skillId, long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException;

	/**
	* Removes all the skills where skillAncestor = &#63; from the database.
	*
	* @param skillAncestor the skill ancestor
	* @throws SystemException if a system exception occurred
	*/
	public void removeByskillAncestor(long skillAncestor)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of skills where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @return the number of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public int countByskillAncestor(long skillAncestor)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the skill where skillName = &#63; or throws a {@link com.portlets.action.NoSuchSkillException} if it could not be found.
	*
	* @param skillName the skill name
	* @return the matching skill
	* @throws com.portlets.action.NoSuchSkillException if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill findBySkillName(
		java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException;

	/**
	* Returns the skill where skillName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param skillName the skill name
	* @return the matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill fetchBySkillName(
		java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the skill where skillName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param skillName the skill name
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill fetchBySkillName(
		java.lang.String skillName, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the skill where skillName = &#63; from the database.
	*
	* @param skillName the skill name
	* @return the skill that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill removeBySkillName(
		java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException;

	/**
	* Returns the number of skills where skillName = &#63;.
	*
	* @param skillName the skill name
	* @return the number of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public int countBySkillName(java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the skill in the entity cache if it is enabled.
	*
	* @param skill the skill
	*/
	public void cacheResult(com.portlets.action.model.Skill skill);

	/**
	* Caches the skills in the entity cache if it is enabled.
	*
	* @param skills the skills
	*/
	public void cacheResult(
		java.util.List<com.portlets.action.model.Skill> skills);

	/**
	* Creates a new skill with the primary key. Does not add the skill to the database.
	*
	* @param skillId the primary key for the new skill
	* @return the new skill
	*/
	public com.portlets.action.model.Skill create(long skillId);

	/**
	* Removes the skill with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param skillId the primary key of the skill
	* @return the skill that was removed
	* @throws com.portlets.action.NoSuchSkillException if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill remove(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException;

	public com.portlets.action.model.Skill updateImpl(
		com.portlets.action.model.Skill skill)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the skill with the primary key or throws a {@link com.portlets.action.NoSuchSkillException} if it could not be found.
	*
	* @param skillId the primary key of the skill
	* @return the skill
	* @throws com.portlets.action.NoSuchSkillException if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill findByPrimaryKey(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException;

	/**
	* Returns the skill with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param skillId the primary key of the skill
	* @return the skill, or <code>null</code> if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Skill fetchByPrimaryKey(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the skills.
	*
	* @return the skills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the skills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of skills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> findAll(int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the skills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of skills
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Skill> findAll(int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the skills from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of skills.
	*
	* @return the number of skills
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the training programs associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> getTrainingPrograms(
		long pk) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the training programs associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> getTrainingPrograms(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the training programs associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.TrainingProgram> getTrainingPrograms(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of training programs associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the number of training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public int getTrainingProgramsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the training program is associated with the skill.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPK the primary key of the training program
	* @return <code>true</code> if the training program is associated with the skill; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsTrainingProgram(long pk, long trainingProgramPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the skill has any training programs associated with it.
	*
	* @param pk the primary key of the skill to check for associations with training programs
	* @return <code>true</code> if the skill has any training programs associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsTrainingPrograms(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPK the primary key of the training program
	* @throws SystemException if a system exception occurred
	*/
	public void addTrainingProgram(long pk, long trainingProgramPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgram the training program
	* @throws SystemException if a system exception occurred
	*/
	public void addTrainingProgram(long pk,
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPKs the primary keys of the training programs
	* @throws SystemException if a system exception occurred
	*/
	public void addTrainingPrograms(long pk, long[] trainingProgramPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingPrograms the training programs
	* @throws SystemException if a system exception occurred
	*/
	public void addTrainingPrograms(long pk,
		java.util.List<com.portlets.action.model.TrainingProgram> trainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the skill and its training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill to clear the associated training programs from
	* @throws SystemException if a system exception occurred
	*/
	public void clearTrainingPrograms(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPK the primary key of the training program
	* @throws SystemException if a system exception occurred
	*/
	public void removeTrainingProgram(long pk, long trainingProgramPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgram the training program
	* @throws SystemException if a system exception occurred
	*/
	public void removeTrainingProgram(long pk,
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPKs the primary keys of the training programs
	* @throws SystemException if a system exception occurred
	*/
	public void removeTrainingPrograms(long pk, long[] trainingProgramPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingPrograms the training programs
	* @throws SystemException if a system exception occurred
	*/
	public void removeTrainingPrograms(long pk,
		java.util.List<com.portlets.action.model.TrainingProgram> trainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the training programs associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPKs the primary keys of the training programs to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public void setTrainingPrograms(long pk, long[] trainingProgramPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the training programs associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingPrograms the training programs to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public void setTrainingPrograms(long pk,
		java.util.List<com.portlets.action.model.TrainingProgram> trainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the recruitments associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the recruitments associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the recruitments associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of recruitments associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the number of recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public int getRecruitmentsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the recruitment is associated with the skill.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPK the primary key of the recruitment
	* @return <code>true</code> if the recruitment is associated with the skill; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the skill has any recruitments associated with it.
	*
	* @param pk the primary key of the skill to check for associations with recruitments
	* @return <code>true</code> if the skill has any recruitments associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the skill and its recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill to clear the associated recruitments from
	* @throws SystemException if a system exception occurred
	*/
	public void clearRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the recruitments associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPKs the primary keys of the recruitments to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public void setRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the recruitments associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitments the recruitments to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public void setRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException;
}