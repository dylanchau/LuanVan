package com.kimtho.portlet.recruitment;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.kimtho.portlet.WebKeysU;
import com.kimtho.portlet.job.JobPortlet;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.RegisterRecruitment;
import com.portlets.action.model.impl.RegisterRecruitmentImpl;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;

/**
 * Portlet implementation class RecruitmentPortlet
 */
public class RecruitmentPortlet extends MVCPortlet {
 
	@ProcessAction(name = "loadListRecruitment")
	public void loadListRecruitment(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String select = ParamUtil.getString(actionRequest, "select","");
		System.out.println("------"+select);
		actionRequest.setAttribute(WebKeysU.LoadListRecruitment, select); 
		SessionMessages.add(actionRequest, "deleted-followRecruitment"); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/recruitment/view.jsp");
		
	   _log.info("#################Load List Recruitment Successfully#########################");
	}
	
	@ProcessAction(name = "registerRecruitment")
	public void registerRecruitment(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterRecruitment re = new RegisterRecruitmentImpl();
		re.setStatesId(new Long(10));
		re.setUserObjectId(userId);
		re.setRecruitmentId(recruitmentId);
		RegisterRecruitmentLocalServiceUtil.addRegisterRecruitment(re);
		SessionMessages.add(actionRequest, "added-registerrecruitmentId"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Added Register Recruitment Successfully#########################");
	}
	
	@ProcessAction(name = "unRegisterRecruitment")
	public void unRegisterEmployerInfo(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterRecruitment re = new RegisterRecruitmentImpl();
		re.setStatesId(new Long(10));
		re.setUserObjectId(userId);
		re.setRecruitmentId(recruitmentId);
		RegisterRecruitmentLocalServiceUtil.deleteRegisterRecruitment(re);
		SessionMessages.add(actionRequest, "deleted-registerrecruitment"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Deleted Register Recruitment Successfully#########################");
	}
	
	private Log _log = LogFactoryUtil.getLog(JobPortlet.class.getName());
}
