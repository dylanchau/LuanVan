/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.EmployerLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.sql.Blob;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class EmployerClp extends BaseModelImpl<Employer> implements Employer {
	public EmployerClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Employer.class;
	}

	@Override
	public String getModelClassName() {
		return Employer.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _employerId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setEmployerId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _employerId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("employerId", getEmployerId());
		attributes.put("employerName", getEmployerName());
		attributes.put("employerAddress", getEmployerAddress());
		attributes.put("employerEmail", getEmployerEmail());
		attributes.put("employerPhone", getEmployerPhone());
		attributes.put("employerIntroduce", getEmployerIntroduce());
		attributes.put("employerAchievements", getEmployerAchievements());
		attributes.put("employerLogoName", getEmployerLogoName());
		attributes.put("employerLogo", getEmployerLogo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long employerId = (Long)attributes.get("employerId");

		if (employerId != null) {
			setEmployerId(employerId);
		}

		String employerName = (String)attributes.get("employerName");

		if (employerName != null) {
			setEmployerName(employerName);
		}

		String employerAddress = (String)attributes.get("employerAddress");

		if (employerAddress != null) {
			setEmployerAddress(employerAddress);
		}

		String employerEmail = (String)attributes.get("employerEmail");

		if (employerEmail != null) {
			setEmployerEmail(employerEmail);
		}

		String employerPhone = (String)attributes.get("employerPhone");

		if (employerPhone != null) {
			setEmployerPhone(employerPhone);
		}

		String employerIntroduce = (String)attributes.get("employerIntroduce");

		if (employerIntroduce != null) {
			setEmployerIntroduce(employerIntroduce);
		}

		String employerAchievements = (String)attributes.get(
				"employerAchievements");

		if (employerAchievements != null) {
			setEmployerAchievements(employerAchievements);
		}

		String employerLogoName = (String)attributes.get("employerLogoName");

		if (employerLogoName != null) {
			setEmployerLogoName(employerLogoName);
		}

		Blob employerLogo = (Blob)attributes.get("employerLogo");

		if (employerLogo != null) {
			setEmployerLogo(employerLogo);
		}
	}

	@Override
	public long getEmployerId() {
		return _employerId;
	}

	@Override
	public void setEmployerId(long employerId) {
		_employerId = employerId;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerId", long.class);

				method.invoke(_employerRemoteModel, employerId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmployerName() {
		return _employerName;
	}

	@Override
	public void setEmployerName(String employerName) {
		_employerName = employerName;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerName", String.class);

				method.invoke(_employerRemoteModel, employerName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmployerAddress() {
		return _employerAddress;
	}

	@Override
	public void setEmployerAddress(String employerAddress) {
		_employerAddress = employerAddress;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerAddress",
						String.class);

				method.invoke(_employerRemoteModel, employerAddress);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmployerEmail() {
		return _employerEmail;
	}

	@Override
	public void setEmployerEmail(String employerEmail) {
		_employerEmail = employerEmail;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerEmail", String.class);

				method.invoke(_employerRemoteModel, employerEmail);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmployerPhone() {
		return _employerPhone;
	}

	@Override
	public void setEmployerPhone(String employerPhone) {
		_employerPhone = employerPhone;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerPhone", String.class);

				method.invoke(_employerRemoteModel, employerPhone);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmployerIntroduce() {
		return _employerIntroduce;
	}

	@Override
	public void setEmployerIntroduce(String employerIntroduce) {
		_employerIntroduce = employerIntroduce;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerIntroduce",
						String.class);

				method.invoke(_employerRemoteModel, employerIntroduce);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmployerAchievements() {
		return _employerAchievements;
	}

	@Override
	public void setEmployerAchievements(String employerAchievements) {
		_employerAchievements = employerAchievements;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerAchievements",
						String.class);

				method.invoke(_employerRemoteModel, employerAchievements);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEmployerLogoName() {
		return _employerLogoName;
	}

	@Override
	public void setEmployerLogoName(String employerLogoName) {
		_employerLogoName = employerLogoName;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerLogoName",
						String.class);

				method.invoke(_employerRemoteModel, employerLogoName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Blob getEmployerLogo() {
		return _employerLogo;
	}

	@Override
	public void setEmployerLogo(Blob employerLogo) {
		_employerLogo = employerLogo;

		if (_employerRemoteModel != null) {
			try {
				Class<?> clazz = _employerRemoteModel.getClass();

				Method method = clazz.getMethod("setEmployerLogo", Blob.class);

				method.invoke(_employerRemoteModel, employerLogo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getEmployerRemoteModel() {
		return _employerRemoteModel;
	}

	public void setEmployerRemoteModel(BaseModel<?> employerRemoteModel) {
		_employerRemoteModel = employerRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _employerRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_employerRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			EmployerLocalServiceUtil.addEmployer(this);
		}
		else {
			EmployerLocalServiceUtil.updateEmployer(this);
		}
	}

	@Override
	public Employer toEscapedModel() {
		return (Employer)ProxyUtil.newProxyInstance(Employer.class.getClassLoader(),
			new Class[] { Employer.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		EmployerClp clone = new EmployerClp();

		clone.setEmployerId(getEmployerId());
		clone.setEmployerName(getEmployerName());
		clone.setEmployerAddress(getEmployerAddress());
		clone.setEmployerEmail(getEmployerEmail());
		clone.setEmployerPhone(getEmployerPhone());
		clone.setEmployerIntroduce(getEmployerIntroduce());
		clone.setEmployerAchievements(getEmployerAchievements());
		clone.setEmployerLogoName(getEmployerLogoName());
		clone.setEmployerLogo(getEmployerLogo());

		return clone;
	}

	@Override
	public int compareTo(Employer employer) {
		long primaryKey = employer.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EmployerClp)) {
			return false;
		}

		EmployerClp employer = (EmployerClp)obj;

		long primaryKey = employer.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(19);

		sb.append("{employerId=");
		sb.append(getEmployerId());
		sb.append(", employerName=");
		sb.append(getEmployerName());
		sb.append(", employerAddress=");
		sb.append(getEmployerAddress());
		sb.append(", employerEmail=");
		sb.append(getEmployerEmail());
		sb.append(", employerPhone=");
		sb.append(getEmployerPhone());
		sb.append(", employerIntroduce=");
		sb.append(getEmployerIntroduce());
		sb.append(", employerAchievements=");
		sb.append(getEmployerAchievements());
		sb.append(", employerLogoName=");
		sb.append(getEmployerLogoName());
		sb.append(", employerLogo=");
		sb.append(getEmployerLogo());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(31);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.Employer");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>employerId</column-name><column-value><![CDATA[");
		sb.append(getEmployerId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerName</column-name><column-value><![CDATA[");
		sb.append(getEmployerName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerAddress</column-name><column-value><![CDATA[");
		sb.append(getEmployerAddress());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerEmail</column-name><column-value><![CDATA[");
		sb.append(getEmployerEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerPhone</column-name><column-value><![CDATA[");
		sb.append(getEmployerPhone());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerIntroduce</column-name><column-value><![CDATA[");
		sb.append(getEmployerIntroduce());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerAchievements</column-name><column-value><![CDATA[");
		sb.append(getEmployerAchievements());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerLogoName</column-name><column-value><![CDATA[");
		sb.append(getEmployerLogoName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>employerLogo</column-name><column-value><![CDATA[");
		sb.append(getEmployerLogo());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _employerId;
	private String _employerName;
	private String _employerAddress;
	private String _employerEmail;
	private String _employerPhone;
	private String _employerIntroduce;
	private String _employerAchievements;
	private String _employerLogoName;
	private Blob _employerLogo;
	private BaseModel<?> _employerRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}