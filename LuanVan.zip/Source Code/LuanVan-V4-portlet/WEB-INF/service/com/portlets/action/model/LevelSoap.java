/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.LevelServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.LevelServiceSoap
 * @generated
 */
public class LevelSoap implements Serializable {
	public static LevelSoap toSoapModel(Level model) {
		LevelSoap soapModel = new LevelSoap();

		soapModel.setLevelId(model.getLevelId());
		soapModel.setLevelName(model.getLevelName());
		soapModel.setLevelExplain(model.getLevelExplain());

		return soapModel;
	}

	public static LevelSoap[] toSoapModels(Level[] models) {
		LevelSoap[] soapModels = new LevelSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static LevelSoap[][] toSoapModels(Level[][] models) {
		LevelSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new LevelSoap[models.length][models[0].length];
		}
		else {
			soapModels = new LevelSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static LevelSoap[] toSoapModels(List<Level> models) {
		List<LevelSoap> soapModels = new ArrayList<LevelSoap>(models.size());

		for (Level model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new LevelSoap[soapModels.size()]);
	}

	public LevelSoap() {
	}

	public long getPrimaryKey() {
		return _levelId;
	}

	public void setPrimaryKey(long pk) {
		setLevelId(pk);
	}

	public long getLevelId() {
		return _levelId;
	}

	public void setLevelId(long levelId) {
		_levelId = levelId;
	}

	public String getLevelName() {
		return _levelName;
	}

	public void setLevelName(String levelName) {
		_levelName = levelName;
	}

	public String getLevelExplain() {
		return _levelExplain;
	}

	public void setLevelExplain(String levelExplain) {
		_levelExplain = levelExplain;
	}

	private long _levelId;
	private String _levelName;
	private String _levelExplain;
}