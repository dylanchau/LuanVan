/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for UserObject. This utility wraps
 * {@link com.portlets.action.service.impl.UserObjectLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Computer
 * @see UserObjectLocalService
 * @see com.portlets.action.service.base.UserObjectLocalServiceBaseImpl
 * @see com.portlets.action.service.impl.UserObjectLocalServiceImpl
 * @generated
 */
public class UserObjectLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.portlets.action.service.impl.UserObjectLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the user object to the database. Also notifies the appropriate model listeners.
	*
	* @param userObject the user object
	* @return the user object that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject addUserObject(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addUserObject(userObject);
	}

	/**
	* Creates a new user object with the primary key. Does not add the user object to the database.
	*
	* @param userObjectId the primary key for the new user object
	* @return the new user object
	*/
	public static com.portlets.action.model.UserObject createUserObject(
		long userObjectId) {
		return getService().createUserObject(userObjectId);
	}

	/**
	* Deletes the user object with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object that was removed
	* @throws PortalException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject deleteUserObject(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteUserObject(userObjectId);
	}

	/**
	* Deletes the user object from the database. Also notifies the appropriate model listeners.
	*
	* @param userObject the user object
	* @return the user object that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject deleteUserObject(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteUserObject(userObject);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.portlets.action.model.UserObject fetchUserObject(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchUserObject(userObjectId);
	}

	/**
	* Returns the user object with the primary key.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object
	* @throws PortalException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject getUserObject(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserObject(userObjectId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the user objects.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of user objects
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserObjects(start, end);
	}

	/**
	* Returns the number of user objects.
	*
	* @return the number of user objects
	* @throws SystemException if a system exception occurred
	*/
	public static int getUserObjectsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserObjectsCount();
	}

	/**
	* Updates the user object in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param userObject the user object
	* @return the user object that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject updateUserObject(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateUserObject(userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducatorUserObject(long educatorId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEducatorUserObject(educatorId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducatorUserObject(long educatorId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEducatorUserObject(educatorId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducatorUserObjects(long educatorId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEducatorUserObjects(educatorId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducatorUserObjects(long educatorId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEducatorUserObjects(educatorId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void clearEducatorUserObjects(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().clearEducatorUserObjects(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEducatorUserObject(long educatorId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEducatorUserObject(educatorId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEducatorUserObject(long educatorId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEducatorUserObject(educatorId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEducatorUserObjects(long educatorId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEducatorUserObjects(educatorId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEducatorUserObjects(long educatorId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEducatorUserObjects(educatorId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getEducatorUserObjects(
		long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEducatorUserObjects(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getEducatorUserObjects(
		long educatorId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEducatorUserObjects(educatorId, start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getEducatorUserObjects(
		long educatorId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getEducatorUserObjects(educatorId, start, end,
			orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static int getEducatorUserObjectsCount(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEducatorUserObjectsCount(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasEducatorUserObject(long educatorId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasEducatorUserObject(educatorId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasEducatorUserObjects(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasEducatorUserObjects(educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void setEducatorUserObjects(long educatorId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().setEducatorUserObjects(educatorId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourseUserObject(long courseId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addCourseUserObject(courseId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourseUserObject(long courseId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addCourseUserObject(courseId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourseUserObjects(long courseId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addCourseUserObjects(courseId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourseUserObjects(long courseId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addCourseUserObjects(courseId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void clearCourseUserObjects(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().clearCourseUserObjects(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteCourseUserObject(long courseId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteCourseUserObject(courseId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteCourseUserObject(long courseId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteCourseUserObject(courseId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteCourseUserObjects(long courseId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteCourseUserObjects(courseId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteCourseUserObjects(long courseId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteCourseUserObjects(courseId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getCourseUserObjects(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getCourseUserObjects(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getCourseUserObjects(
		long courseId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getCourseUserObjects(courseId, start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getCourseUserObjects(
		long courseId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getCourseUserObjects(courseId, start, end, orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static int getCourseUserObjectsCount(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getCourseUserObjectsCount(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasCourseUserObject(long courseId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasCourseUserObject(courseId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasCourseUserObjects(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasCourseUserObjects(courseId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void setCourseUserObjects(long courseId, long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().setCourseUserObjects(courseId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployerUserObject(long employerId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEmployerUserObject(employerId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployerUserObject(long employerId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEmployerUserObject(employerId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployerUserObjects(long employerId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEmployerUserObjects(employerId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployerUserObjects(long employerId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addEmployerUserObjects(employerId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void clearEmployerUserObjects(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().clearEmployerUserObjects(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEmployerUserObject(long employerId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEmployerUserObject(employerId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEmployerUserObject(long employerId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEmployerUserObject(employerId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEmployerUserObjects(long employerId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEmployerUserObjects(employerId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteEmployerUserObjects(long employerId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteEmployerUserObjects(employerId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getEmployerUserObjects(
		long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployerUserObjects(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getEmployerUserObjects(
		long employerId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployerUserObjects(employerId, start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getEmployerUserObjects(
		long employerId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getEmployerUserObjects(employerId, start, end,
			orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static int getEmployerUserObjectsCount(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployerUserObjectsCount(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasEmployerUserObject(long employerId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasEmployerUserObject(employerId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasEmployerUserObjects(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasEmployerUserObjects(employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void setEmployerUserObjects(long employerId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().setEmployerUserObjects(employerId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitmentUserObject(long recruitmentId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addRecruitmentUserObject(recruitmentId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitmentUserObject(long recruitmentId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addRecruitmentUserObject(recruitmentId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitmentUserObjects(long recruitmentId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addRecruitmentUserObjects(recruitmentId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitmentUserObjects(long recruitmentId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addRecruitmentUserObjects(recruitmentId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void clearRecruitmentUserObjects(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().clearRecruitmentUserObjects(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteRecruitmentUserObject(long recruitmentId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteRecruitmentUserObject(recruitmentId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteRecruitmentUserObject(long recruitmentId,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteRecruitmentUserObject(recruitmentId, userObject);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteRecruitmentUserObjects(long recruitmentId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteRecruitmentUserObjects(recruitmentId, userObjectIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteRecruitmentUserObjects(long recruitmentId,
		java.util.List<com.portlets.action.model.UserObject> UserObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteRecruitmentUserObjects(recruitmentId, UserObjects);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getRecruitmentUserObjects(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getRecruitmentUserObjects(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getRecruitmentUserObjects(
		long recruitmentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getRecruitmentUserObjects(recruitmentId, start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getRecruitmentUserObjects(
		long recruitmentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getRecruitmentUserObjects(recruitmentId, start, end,
			orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static int getRecruitmentUserObjectsCount(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getRecruitmentUserObjectsCount(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasRecruitmentUserObject(long recruitmentId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasRecruitmentUserObject(recruitmentId, userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasRecruitmentUserObjects(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasRecruitmentUserObjects(recruitmentId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void setRecruitmentUserObjects(long recruitmentId,
		long[] userObjectIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().setRecruitmentUserObjects(recruitmentId, userObjectIds);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static void clearService() {
		_service = null;
	}

	public static UserObjectLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					UserObjectLocalService.class.getName());

			if (invokableLocalService instanceof UserObjectLocalService) {
				_service = (UserObjectLocalService)invokableLocalService;
			}
			else {
				_service = new UserObjectLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(UserObjectLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(UserObjectLocalService service) {
	}

	private static UserObjectLocalService _service;
}