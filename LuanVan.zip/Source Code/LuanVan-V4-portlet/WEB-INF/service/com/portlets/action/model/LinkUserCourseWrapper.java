/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link LinkUserCourse}.
 * </p>
 *
 * @author Computer
 * @see LinkUserCourse
 * @generated
 */
public class LinkUserCourseWrapper implements LinkUserCourse,
	ModelWrapper<LinkUserCourse> {
	public LinkUserCourseWrapper(LinkUserCourse linkUserCourse) {
		_linkUserCourse = linkUserCourse;
	}

	@Override
	public Class<?> getModelClass() {
		return LinkUserCourse.class;
	}

	@Override
	public String getModelClassName() {
		return LinkUserCourse.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userObjectId", getUserObjectId());
		attributes.put("courseId", getCourseId());
		attributes.put("linkUserCourseNo", getLinkUserCourseNo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		Long courseId = (Long)attributes.get("courseId");

		if (courseId != null) {
			setCourseId(courseId);
		}

		Integer linkUserCourseNo = (Integer)attributes.get("linkUserCourseNo");

		if (linkUserCourseNo != null) {
			setLinkUserCourseNo(linkUserCourseNo);
		}
	}

	/**
	* Returns the primary key of this link user course.
	*
	* @return the primary key of this link user course
	*/
	@Override
	public com.portlets.action.service.persistence.LinkUserCoursePK getPrimaryKey() {
		return _linkUserCourse.getPrimaryKey();
	}

	/**
	* Sets the primary key of this link user course.
	*
	* @param primaryKey the primary key of this link user course
	*/
	@Override
	public void setPrimaryKey(
		com.portlets.action.service.persistence.LinkUserCoursePK primaryKey) {
		_linkUserCourse.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the user object ID of this link user course.
	*
	* @return the user object ID of this link user course
	*/
	@Override
	public long getUserObjectId() {
		return _linkUserCourse.getUserObjectId();
	}

	/**
	* Sets the user object ID of this link user course.
	*
	* @param userObjectId the user object ID of this link user course
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_linkUserCourse.setUserObjectId(userObjectId);
	}

	/**
	* Returns the course ID of this link user course.
	*
	* @return the course ID of this link user course
	*/
	@Override
	public long getCourseId() {
		return _linkUserCourse.getCourseId();
	}

	/**
	* Sets the course ID of this link user course.
	*
	* @param courseId the course ID of this link user course
	*/
	@Override
	public void setCourseId(long courseId) {
		_linkUserCourse.setCourseId(courseId);
	}

	/**
	* Returns the link user course no of this link user course.
	*
	* @return the link user course no of this link user course
	*/
	@Override
	public int getLinkUserCourseNo() {
		return _linkUserCourse.getLinkUserCourseNo();
	}

	/**
	* Sets the link user course no of this link user course.
	*
	* @param linkUserCourseNo the link user course no of this link user course
	*/
	@Override
	public void setLinkUserCourseNo(int linkUserCourseNo) {
		_linkUserCourse.setLinkUserCourseNo(linkUserCourseNo);
	}

	@Override
	public boolean isNew() {
		return _linkUserCourse.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_linkUserCourse.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _linkUserCourse.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_linkUserCourse.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _linkUserCourse.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _linkUserCourse.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_linkUserCourse.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _linkUserCourse.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_linkUserCourse.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_linkUserCourse.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_linkUserCourse.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new LinkUserCourseWrapper((LinkUserCourse)_linkUserCourse.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.LinkUserCourse linkUserCourse) {
		return _linkUserCourse.compareTo(linkUserCourse);
	}

	@Override
	public int hashCode() {
		return _linkUserCourse.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.LinkUserCourse> toCacheModel() {
		return _linkUserCourse.toCacheModel();
	}

	@Override
	public com.portlets.action.model.LinkUserCourse toEscapedModel() {
		return new LinkUserCourseWrapper(_linkUserCourse.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.LinkUserCourse toUnescapedModel() {
		return new LinkUserCourseWrapper(_linkUserCourse.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _linkUserCourse.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _linkUserCourse.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_linkUserCourse.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LinkUserCourseWrapper)) {
			return false;
		}

		LinkUserCourseWrapper linkUserCourseWrapper = (LinkUserCourseWrapper)obj;

		if (Validator.equals(_linkUserCourse,
					linkUserCourseWrapper._linkUserCourse)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public LinkUserCourse getWrappedLinkUserCourse() {
		return _linkUserCourse;
	}

	@Override
	public LinkUserCourse getWrappedModel() {
		return _linkUserCourse;
	}

	@Override
	public void resetOriginalValues() {
		_linkUserCourse.resetOriginalValues();
	}

	private LinkUserCourse _linkUserCourse;
}