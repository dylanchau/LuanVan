/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.LinkUsers;

import java.util.List;

/**
 * The persistence utility for the link users service. This utility wraps {@link LinkUsersPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see LinkUsersPersistence
 * @see LinkUsersPersistenceImpl
 * @generated
 */
public class LinkUsersUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(LinkUsers linkUsers) {
		getPersistence().clearCache(linkUsers);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<LinkUsers> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<LinkUsers> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<LinkUsers> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static LinkUsers update(LinkUsers linkUsers)
		throws SystemException {
		return getPersistence().update(linkUsers);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static LinkUsers update(LinkUsers linkUsers,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(linkUsers, serviceContext);
	}

	/**
	* Returns all the link userses where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @return the matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findByuserIdA(
		long userIdA)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserIdA(userIdA);
	}

	/**
	* Returns a range of all the link userses where userIdA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdA the user ID a
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findByuserIdA(
		long userIdA, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserIdA(userIdA, start, end);
	}

	/**
	* Returns an ordered range of all the link userses where userIdA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdA the user ID a
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findByuserIdA(
		long userIdA, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserIdA(userIdA, start, end, orderByComparator);
	}

	/**
	* Returns the first link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers findByuserIdA_First(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence().findByuserIdA_First(userIdA, orderByComparator);
	}

	/**
	* Returns the first link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers fetchByuserIdA_First(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByuserIdA_First(userIdA, orderByComparator);
	}

	/**
	* Returns the last link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers findByuserIdA_Last(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence().findByuserIdA_Last(userIdA, orderByComparator);
	}

	/**
	* Returns the last link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers fetchByuserIdA_Last(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByuserIdA_Last(userIdA, orderByComparator);
	}

	/**
	* Returns the link userses before and after the current link users in the ordered set where userIdA = &#63;.
	*
	* @param linkUsersPK the primary key of the current link users
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers[] findByuserIdA_PrevAndNext(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK,
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence()
				   .findByuserIdA_PrevAndNext(linkUsersPK, userIdA,
			orderByComparator);
	}

	/**
	* Removes all the link userses where userIdA = &#63; from the database.
	*
	* @param userIdA the user ID a
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserIdA(long userIdA)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserIdA(userIdA);
	}

	/**
	* Returns the number of link userses where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @return the number of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserIdA(long userIdA)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserIdA(userIdA);
	}

	/**
	* Returns all the link userses where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @return the matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findByuserIdB(
		long userIdB)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserIdB(userIdB);
	}

	/**
	* Returns a range of all the link userses where userIdB = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdB the user ID b
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findByuserIdB(
		long userIdB, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserIdB(userIdB, start, end);
	}

	/**
	* Returns an ordered range of all the link userses where userIdB = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdB the user ID b
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findByuserIdB(
		long userIdB, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserIdB(userIdB, start, end, orderByComparator);
	}

	/**
	* Returns the first link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers findByuserIdB_First(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence().findByuserIdB_First(userIdB, orderByComparator);
	}

	/**
	* Returns the first link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers fetchByuserIdB_First(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByuserIdB_First(userIdB, orderByComparator);
	}

	/**
	* Returns the last link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers findByuserIdB_Last(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence().findByuserIdB_Last(userIdB, orderByComparator);
	}

	/**
	* Returns the last link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers fetchByuserIdB_Last(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByuserIdB_Last(userIdB, orderByComparator);
	}

	/**
	* Returns the link userses before and after the current link users in the ordered set where userIdB = &#63;.
	*
	* @param linkUsersPK the primary key of the current link users
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers[] findByuserIdB_PrevAndNext(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK,
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence()
				   .findByuserIdB_PrevAndNext(linkUsersPK, userIdB,
			orderByComparator);
	}

	/**
	* Removes all the link userses where userIdB = &#63; from the database.
	*
	* @param userIdB the user ID b
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserIdB(long userIdB)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserIdB(userIdB);
	}

	/**
	* Returns the number of link userses where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @return the number of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserIdB(long userIdB)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserIdB(userIdB);
	}

	/**
	* Returns all the link userses where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @return the matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findBylinkUsersNumber(
		int linkUsersNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBylinkUsersNumber(linkUsersNumber);
	}

	/**
	* Returns a range of all the link userses where linkUsersNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUsersNumber the link users number
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findBylinkUsersNumber(
		int linkUsersNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylinkUsersNumber(linkUsersNumber, start, end);
	}

	/**
	* Returns an ordered range of all the link userses where linkUsersNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUsersNumber the link users number
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findBylinkUsersNumber(
		int linkUsersNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylinkUsersNumber(linkUsersNumber, start, end,
			orderByComparator);
	}

	/**
	* Returns the first link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers findBylinkUsersNumber_First(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence()
				   .findBylinkUsersNumber_First(linkUsersNumber,
			orderByComparator);
	}

	/**
	* Returns the first link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers fetchBylinkUsersNumber_First(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylinkUsersNumber_First(linkUsersNumber,
			orderByComparator);
	}

	/**
	* Returns the last link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers findBylinkUsersNumber_Last(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence()
				   .findBylinkUsersNumber_Last(linkUsersNumber,
			orderByComparator);
	}

	/**
	* Returns the last link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers fetchBylinkUsersNumber_Last(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylinkUsersNumber_Last(linkUsersNumber,
			orderByComparator);
	}

	/**
	* Returns the link userses before and after the current link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersPK the primary key of the current link users
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers[] findBylinkUsersNumber_PrevAndNext(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK,
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence()
				   .findBylinkUsersNumber_PrevAndNext(linkUsersPK,
			linkUsersNumber, orderByComparator);
	}

	/**
	* Removes all the link userses where linkUsersNumber = &#63; from the database.
	*
	* @param linkUsersNumber the link users number
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBylinkUsersNumber(int linkUsersNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBylinkUsersNumber(linkUsersNumber);
	}

	/**
	* Returns the number of link userses where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @return the number of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public static int countBylinkUsersNumber(int linkUsersNumber)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBylinkUsersNumber(linkUsersNumber);
	}

	/**
	* Caches the link users in the entity cache if it is enabled.
	*
	* @param linkUsers the link users
	*/
	public static void cacheResult(
		com.portlets.action.model.LinkUsers linkUsers) {
		getPersistence().cacheResult(linkUsers);
	}

	/**
	* Caches the link userses in the entity cache if it is enabled.
	*
	* @param linkUserses the link userses
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.LinkUsers> linkUserses) {
		getPersistence().cacheResult(linkUserses);
	}

	/**
	* Creates a new link users with the primary key. Does not add the link users to the database.
	*
	* @param linkUsersPK the primary key for the new link users
	* @return the new link users
	*/
	public static com.portlets.action.model.LinkUsers create(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK) {
		return getPersistence().create(linkUsersPK);
	}

	/**
	* Removes the link users with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param linkUsersPK the primary key of the link users
	* @return the link users that was removed
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers remove(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence().remove(linkUsersPK);
	}

	public static com.portlets.action.model.LinkUsers updateImpl(
		com.portlets.action.model.LinkUsers linkUsers)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(linkUsers);
	}

	/**
	* Returns the link users with the primary key or throws a {@link com.portlets.action.NoSuchLinkUsersException} if it could not be found.
	*
	* @param linkUsersPK the primary key of the link users
	* @return the link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers findByPrimaryKey(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException {
		return getPersistence().findByPrimaryKey(linkUsersPK);
	}

	/**
	* Returns the link users with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param linkUsersPK the primary key of the link users
	* @return the link users, or <code>null</code> if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUsers fetchByPrimaryKey(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(linkUsersPK);
	}

	/**
	* Returns all the link userses.
	*
	* @return the link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the link userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the link userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of link userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUsers> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the link userses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of link userses.
	*
	* @return the number of link userses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static LinkUsersPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (LinkUsersPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					LinkUsersPersistence.class.getName());

			ReferenceRegistry.registerReference(LinkUsersUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(LinkUsersPersistence persistence) {
	}

	private static LinkUsersPersistence _persistence;
}