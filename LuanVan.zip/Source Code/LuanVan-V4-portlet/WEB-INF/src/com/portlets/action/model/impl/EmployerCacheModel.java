/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.Employer;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Employer in entity cache.
 *
 * @author Computer
 * @see Employer
 * @generated
 */
public class EmployerCacheModel implements CacheModel<Employer>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{employerId=");
		sb.append(employerId);
		sb.append(", employerName=");
		sb.append(employerName);
		sb.append(", employerAddress=");
		sb.append(employerAddress);
		sb.append(", employerEmail=");
		sb.append(employerEmail);
		sb.append(", employerPhone=");
		sb.append(employerPhone);
		sb.append(", employerIntroduce=");
		sb.append(employerIntroduce);
		sb.append(", employerAchievements=");
		sb.append(employerAchievements);
		sb.append(", employerLogoName=");
		sb.append(employerLogoName);

		return sb.toString();
	}

	@Override
	public Employer toEntityModel() {
		EmployerImpl employerImpl = new EmployerImpl();

		employerImpl.setEmployerId(employerId);

		if (employerName == null) {
			employerImpl.setEmployerName(StringPool.BLANK);
		}
		else {
			employerImpl.setEmployerName(employerName);
		}

		if (employerAddress == null) {
			employerImpl.setEmployerAddress(StringPool.BLANK);
		}
		else {
			employerImpl.setEmployerAddress(employerAddress);
		}

		if (employerEmail == null) {
			employerImpl.setEmployerEmail(StringPool.BLANK);
		}
		else {
			employerImpl.setEmployerEmail(employerEmail);
		}

		if (employerPhone == null) {
			employerImpl.setEmployerPhone(StringPool.BLANK);
		}
		else {
			employerImpl.setEmployerPhone(employerPhone);
		}

		if (employerIntroduce == null) {
			employerImpl.setEmployerIntroduce(StringPool.BLANK);
		}
		else {
			employerImpl.setEmployerIntroduce(employerIntroduce);
		}

		if (employerAchievements == null) {
			employerImpl.setEmployerAchievements(StringPool.BLANK);
		}
		else {
			employerImpl.setEmployerAchievements(employerAchievements);
		}

		if (employerLogoName == null) {
			employerImpl.setEmployerLogoName(StringPool.BLANK);
		}
		else {
			employerImpl.setEmployerLogoName(employerLogoName);
		}

		employerImpl.resetOriginalValues();

		return employerImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		employerId = objectInput.readLong();
		employerName = objectInput.readUTF();
		employerAddress = objectInput.readUTF();
		employerEmail = objectInput.readUTF();
		employerPhone = objectInput.readUTF();
		employerIntroduce = objectInput.readUTF();
		employerAchievements = objectInput.readUTF();
		employerLogoName = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(employerId);

		if (employerName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(employerName);
		}

		if (employerAddress == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(employerAddress);
		}

		if (employerEmail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(employerEmail);
		}

		if (employerPhone == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(employerPhone);
		}

		if (employerIntroduce == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(employerIntroduce);
		}

		if (employerAchievements == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(employerAchievements);
		}

		if (employerLogoName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(employerLogoName);
		}
	}

	public long employerId;
	public String employerName;
	public String employerAddress;
	public String employerEmail;
	public String employerPhone;
	public String employerIntroduce;
	public String employerAchievements;
	public String employerLogoName;
}