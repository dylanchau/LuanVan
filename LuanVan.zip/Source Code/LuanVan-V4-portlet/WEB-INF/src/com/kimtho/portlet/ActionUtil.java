package com.kimtho.portlet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.portlet.ActionRequest;

import com.liferay.portal.kernel.util.ParamUtil;
import com.portlets.action.model.Course;
import com.portlets.action.model.EducationUsers;
import com.portlets.action.model.ExperienceUsers;
import com.portlets.action.model.Recruitment;
import com.portlets.action.model.Skill;
import com.portlets.action.model.UserSkillLevel;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.model.impl.EducationUsersImpl;
import com.portlets.action.model.impl.ExperienceUsersImpl;
import com.portlets.action.model.impl.SkillImpl;
import com.portlets.action.model.impl.UserSkillLevelImpl;
import com.portlets.action.model.impl.UserSkillListenerImpl;


public class ActionUtil {
	
	  public static Skill skillsFromRequest(ActionRequest request) {
		  Skill ds = new SkillImpl();
		  ds.setSkillName(ParamUtil.getString(request, "skillName",""));
		  ds.setSkillAncestor(ParamUtil.getLong(request, "skillAncestor",0));
		  ds.setSkillExplain(ParamUtil.getString(request, "skillExplain",""));
		
		  return ds;
	  }
	  
	  public static UserSkillLevel userSkillLevelFromRequest(ActionRequest request) {
		  UserSkillLevel ds = new UserSkillLevelImpl();
		  ds.setSkillId(ParamUtil.getLong(request, "skillId",0));
		  ds.setUserObjectId(ParamUtil.getLong(request, "userObjectId",0));
		  ds.setLevelId(ParamUtil.getLong(request, "levelId",0));
		  return ds;
	  }
	  
	  public static UserSkillListener userSkillListenerFromRequest(ActionRequest request) {
		  UserSkillListener ds = new UserSkillListenerImpl();
		  ds.setSkillId(ParamUtil.getLong(request, "skillId",0));
		  ds.setUserObjectId(ParamUtil.getLong(request, "userObjectId",0));
		  return ds;
	  }
	  
	  public static ExperienceUsers experienceUsersFromRequest(ActionRequest request) {
		  SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
		  ExperienceUsers ds = new ExperienceUsersImpl();
		  ds.setExperienceUsersJob(ParamUtil.getString(request, "experienceUsersJob",""));
		  ds.setExperienceUsersCompany(ParamUtil.getString(request, "experienceUsersCompany",""));
		  try {
				ds.setExperienceUsersDateStart(df.parse(ParamUtil.getString(request, "experienceUsersDateStart","")));
				ds.setExperienceUsersDateFinish(df.parse(ParamUtil.getString(request, "experienceUsersDateFinish","")));			  
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  ds.setExperienceUsersDescription(ParamUtil.getString(request, "experienceUsersDescription",""));
		  ds.setUserObjectId(ParamUtil.getLong(request, "userObjectId",0));
		
		  return ds;
	  }
	  
	  public static EducationUsers educationUsersFromRequest(ActionRequest request) {
		  SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
		  EducationUsers ds = new EducationUsersImpl();
		  ds.setEducationUsersSchool(ParamUtil.getString(request, "educationUsersSchool",""));
		  ds.setEducationUsersMajor(ParamUtil.getString(request, "educationUsersMajor",""));
		  System.out.println("--------"+ParamUtil.getString(request, "educationUsersDateStart",""));
		  try {
				ds.setEducationUsersDateStart(df.parse(ParamUtil.getString(request, "educationUsersDateStart","")));
				ds.setEducationUsersDateFinish(df.parse(ParamUtil.getString(request, "educationUsersDateFinish","")));			  
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		  ds.setEducationUsersDegree(ParamUtil.getString(request, "educationUsersDegree",""));
		  ds.setEducationUsersDescription(ParamUtil.getString(request, "educationUsersDescription",""));
		  ds.setUserObjectId(ParamUtil.getLong(request, "userObjectId",0));
		
		  return ds;
	  }
	  
	  public static List<Course> changeCourseByStates(List<Course> list, long statesId){
		  List<Course> temp = new ArrayList<Course>(list.size());
		  for(int i=0; i<list.size(); i++){
			  if(list.get(i).getStatesId()==statesId){
				  temp.add(list.get(i));
			  }
		  }
		  return temp;
	  }
	  
	  public static List<Recruitment> changeRecruitmentByStates(List<Recruitment> list, long statesId){
		  List<Recruitment> temp = new ArrayList<Recruitment>(list.size());
		  for(int i=0; i<list.size(); i++){
			  if(list.get(i).getStatesId()==statesId){
				  temp.add(list.get(i));
			  }
		  }
		  return temp;
	  }
	  
}
