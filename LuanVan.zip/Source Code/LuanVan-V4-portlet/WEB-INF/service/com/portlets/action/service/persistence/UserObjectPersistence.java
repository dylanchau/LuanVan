/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.portlets.action.model.UserObject;

/**
 * The persistence interface for the user object service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see UserObjectPersistenceImpl
 * @see UserObjectUtil
 * @generated
 */
public interface UserObjectPersistence extends BasePersistence<UserObject> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link UserObjectUtil} to access the user object persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns the user object where userObjectId = &#63; or throws a {@link com.portlets.action.NoSuchUserObjectException} if it could not be found.
	*
	* @param userObjectId the user object ID
	* @return the matching user object
	* @throws com.portlets.action.NoSuchUserObjectException if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject findByUserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException;

	/**
	* Returns the user object where userObjectId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param userObjectId the user object ID
	* @return the matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject fetchByUserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user object where userObjectId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param userObjectId the user object ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject fetchByUserObjectId(
		long userObjectId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the user object where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @return the user object that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject removeByUserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException;

	/**
	* Returns the number of user objects where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public int countByUserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the user objects where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @return the matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> findByUserObjectName(
		java.lang.String userObjectName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the user objects where userObjectName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectName the user object name
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> findByUserObjectName(
		java.lang.String userObjectName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the user objects where userObjectName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectName the user object name
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> findByUserObjectName(
		java.lang.String userObjectName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user object
	* @throws com.portlets.action.NoSuchUserObjectException if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject findByUserObjectName_First(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException;

	/**
	* Returns the first user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject fetchByUserObjectName_First(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user object
	* @throws com.portlets.action.NoSuchUserObjectException if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject findByUserObjectName_Last(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException;

	/**
	* Returns the last user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject fetchByUserObjectName_Last(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user objects before and after the current user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectId the primary key of the current user object
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user object
	* @throws com.portlets.action.NoSuchUserObjectException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject[] findByUserObjectName_PrevAndNext(
		long userObjectId, java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException;

	/**
	* Removes all the user objects where userObjectName = &#63; from the database.
	*
	* @param userObjectName the user object name
	* @throws SystemException if a system exception occurred
	*/
	public void removeByUserObjectName(java.lang.String userObjectName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user objects where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @return the number of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public int countByUserObjectName(java.lang.String userObjectName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the user object in the entity cache if it is enabled.
	*
	* @param userObject the user object
	*/
	public void cacheResult(com.portlets.action.model.UserObject userObject);

	/**
	* Caches the user objects in the entity cache if it is enabled.
	*
	* @param userObjects the user objects
	*/
	public void cacheResult(
		java.util.List<com.portlets.action.model.UserObject> userObjects);

	/**
	* Creates a new user object with the primary key. Does not add the user object to the database.
	*
	* @param userObjectId the primary key for the new user object
	* @return the new user object
	*/
	public com.portlets.action.model.UserObject create(long userObjectId);

	/**
	* Removes the user object with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object that was removed
	* @throws com.portlets.action.NoSuchUserObjectException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject remove(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException;

	public com.portlets.action.model.UserObject updateImpl(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the user object with the primary key or throws a {@link com.portlets.action.NoSuchUserObjectException} if it could not be found.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object
	* @throws com.portlets.action.NoSuchUserObjectException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject findByPrimaryKey(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException;

	/**
	* Returns the user object with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object, or <code>null</code> if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.UserObject fetchByPrimaryKey(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the user objects.
	*
	* @return the user objects
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the user objects.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of user objects
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the user objects.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user objects
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the user objects from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user objects.
	*
	* @return the number of user objects
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the educators associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> getEducators(
		long pk) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the educators associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> getEducators(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the educators associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> getEducators(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of educators associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public int getEducatorsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the educator is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param educatorPK the primary key of the educator
	* @return <code>true</code> if the educator is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsEducator(long pk, long educatorPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the user object has any educators associated with it.
	*
	* @param pk the primary key of the user object to check for associations with educators
	* @return <code>true</code> if the user object has any educators associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsEducators(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPK the primary key of the educator
	* @throws SystemException if a system exception occurred
	*/
	public void addEducator(long pk, long educatorPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educator the educator
	* @throws SystemException if a system exception occurred
	*/
	public void addEducator(long pk, com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPKs the primary keys of the educators
	* @throws SystemException if a system exception occurred
	*/
	public void addEducators(long pk, long[] educatorPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educators the educators
	* @throws SystemException if a system exception occurred
	*/
	public void addEducators(long pk,
		java.util.List<com.portlets.action.model.Educator> educators)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the user object and its educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated educators from
	* @throws SystemException if a system exception occurred
	*/
	public void clearEducators(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPK the primary key of the educator
	* @throws SystemException if a system exception occurred
	*/
	public void removeEducator(long pk, long educatorPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educator the educator
	* @throws SystemException if a system exception occurred
	*/
	public void removeEducator(long pk,
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPKs the primary keys of the educators
	* @throws SystemException if a system exception occurred
	*/
	public void removeEducators(long pk, long[] educatorPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educators the educators
	* @throws SystemException if a system exception occurred
	*/
	public void removeEducators(long pk,
		java.util.List<com.portlets.action.model.Educator> educators)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the educators associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPKs the primary keys of the educators to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setEducators(long pk, long[] educatorPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the educators associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educators the educators to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setEducators(long pk,
		java.util.List<com.portlets.action.model.Educator> educators)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the courses associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Course> getCourses(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the courses associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Course> getCourses(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the courses associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Course> getCourses(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of courses associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public int getCoursesSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the course is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param coursePK the primary key of the course
	* @return <code>true</code> if the course is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsCourse(long pk, long coursePK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the user object has any courses associated with it.
	*
	* @param pk the primary key of the user object to check for associations with courses
	* @return <code>true</code> if the user object has any courses associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsCourses(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePK the primary key of the course
	* @throws SystemException if a system exception occurred
	*/
	public void addCourse(long pk, long coursePK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param course the course
	* @throws SystemException if a system exception occurred
	*/
	public void addCourse(long pk, com.portlets.action.model.Course course)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePKs the primary keys of the courses
	* @throws SystemException if a system exception occurred
	*/
	public void addCourses(long pk, long[] coursePKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param courses the courses
	* @throws SystemException if a system exception occurred
	*/
	public void addCourses(long pk,
		java.util.List<com.portlets.action.model.Course> courses)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the user object and its courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated courses from
	* @throws SystemException if a system exception occurred
	*/
	public void clearCourses(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePK the primary key of the course
	* @throws SystemException if a system exception occurred
	*/
	public void removeCourse(long pk, long coursePK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param course the course
	* @throws SystemException if a system exception occurred
	*/
	public void removeCourse(long pk, com.portlets.action.model.Course course)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePKs the primary keys of the courses
	* @throws SystemException if a system exception occurred
	*/
	public void removeCourses(long pk, long[] coursePKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param courses the courses
	* @throws SystemException if a system exception occurred
	*/
	public void removeCourses(long pk,
		java.util.List<com.portlets.action.model.Course> courses)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the courses associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePKs the primary keys of the courses to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setCourses(long pk, long[] coursePKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the courses associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param courses the courses to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setCourses(long pk,
		java.util.List<com.portlets.action.model.Course> courses)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the employers associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Employer> getEmployers(
		long pk) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the employers associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Employer> getEmployers(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the employers associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Employer> getEmployers(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of employers associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public int getEmployersSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the employer is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param employerPK the primary key of the employer
	* @return <code>true</code> if the employer is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsEmployer(long pk, long employerPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the user object has any employers associated with it.
	*
	* @param pk the primary key of the user object to check for associations with employers
	* @return <code>true</code> if the user object has any employers associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsEmployers(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPK the primary key of the employer
	* @throws SystemException if a system exception occurred
	*/
	public void addEmployer(long pk, long employerPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employer the employer
	* @throws SystemException if a system exception occurred
	*/
	public void addEmployer(long pk, com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPKs the primary keys of the employers
	* @throws SystemException if a system exception occurred
	*/
	public void addEmployers(long pk, long[] employerPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employers the employers
	* @throws SystemException if a system exception occurred
	*/
	public void addEmployers(long pk,
		java.util.List<com.portlets.action.model.Employer> employers)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the user object and its employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated employers from
	* @throws SystemException if a system exception occurred
	*/
	public void clearEmployers(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPK the primary key of the employer
	* @throws SystemException if a system exception occurred
	*/
	public void removeEmployer(long pk, long employerPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employer the employer
	* @throws SystemException if a system exception occurred
	*/
	public void removeEmployer(long pk,
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPKs the primary keys of the employers
	* @throws SystemException if a system exception occurred
	*/
	public void removeEmployers(long pk, long[] employerPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employers the employers
	* @throws SystemException if a system exception occurred
	*/
	public void removeEmployers(long pk,
		java.util.List<com.portlets.action.model.Employer> employers)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the employers associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPKs the primary keys of the employers to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setEmployers(long pk, long[] employerPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the employers associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employers the employers to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setEmployers(long pk,
		java.util.List<com.portlets.action.model.Employer> employers)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the recruitments associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the recruitments associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the recruitments associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of recruitments associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public int getRecruitmentsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the recruitment is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPK the primary key of the recruitment
	* @return <code>true</code> if the recruitment is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the user object has any recruitments associated with it.
	*
	* @param pk the primary key of the user object to check for associations with recruitments
	* @return <code>true</code> if the user object has any recruitments associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void addRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the user object and its recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated recruitments from
	* @throws SystemException if a system exception occurred
	*/
	public void clearRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public void removeRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the recruitments associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPKs the primary keys of the recruitments to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the recruitments associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitments the recruitments to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public void setRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException;
}