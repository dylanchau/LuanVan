package com.dylan.portlets.action.util;

import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.model.Address;
import com.liferay.portal.service.AddressLocalServiceUtil;

public class AddressActionUtill {

	@SuppressWarnings("unchecked")
	public static List<Address> getAddressByUserId(long userId) 
			throws Exception {
		
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Address.class);
		dq.add(PropertyFactoryUtil.forName("userId").eq(userId));
		
		try {
			
			return AddressLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			System.err.println(e.getMessage()); return null;
		}
	}
}
