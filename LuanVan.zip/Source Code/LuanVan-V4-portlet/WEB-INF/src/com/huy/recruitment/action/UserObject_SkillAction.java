package com.huy.recruitment.action;
import java.util.List;




import com.portlets.action.model.UserObject;
import com.portlets.action.service.UserObjectLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;


public class UserObject_SkillAction {
	
	

		@SuppressWarnings("unchecked")
		public static List<UserObject> getUserObjectByskillIds(long[] ids) 
				throws Exception {
			
			List<UserObject> users = null;
			
			try {
								DynamicQuery dq = DynamicQueryFactoryUtil.forClass(UserObject.class);
				
				dq.add(PropertyFactoryUtil.forName("skillId").eq(ids));
				
				users = UserObjectLocalServiceUtil.dynamicQuery(dq);
				
				return users;
				
			}catch(SystemException e) {
				System.err.println(e.getMessage());
				return null;
			}
		}
	}


