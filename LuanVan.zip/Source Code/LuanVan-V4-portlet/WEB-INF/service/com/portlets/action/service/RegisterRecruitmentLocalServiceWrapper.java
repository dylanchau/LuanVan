/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link RegisterRecruitmentLocalService}.
 *
 * @author Computer
 * @see RegisterRecruitmentLocalService
 * @generated
 */
public class RegisterRecruitmentLocalServiceWrapper
	implements RegisterRecruitmentLocalService,
		ServiceWrapper<RegisterRecruitmentLocalService> {
	public RegisterRecruitmentLocalServiceWrapper(
		RegisterRecruitmentLocalService registerRecruitmentLocalService) {
		_registerRecruitmentLocalService = registerRecruitmentLocalService;
	}

	/**
	* Adds the register recruitment to the database. Also notifies the appropriate model listeners.
	*
	* @param registerRecruitment the register recruitment
	* @return the register recruitment that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.RegisterRecruitment addRegisterRecruitment(
		com.portlets.action.model.RegisterRecruitment registerRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.addRegisterRecruitment(registerRecruitment);
	}

	/**
	* Creates a new register recruitment with the primary key. Does not add the register recruitment to the database.
	*
	* @param registerRecruitmentPK the primary key for the new register recruitment
	* @return the new register recruitment
	*/
	@Override
	public com.portlets.action.model.RegisterRecruitment createRegisterRecruitment(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK) {
		return _registerRecruitmentLocalService.createRegisterRecruitment(registerRecruitmentPK);
	}

	/**
	* Deletes the register recruitment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param registerRecruitmentPK the primary key of the register recruitment
	* @return the register recruitment that was removed
	* @throws PortalException if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.RegisterRecruitment deleteRegisterRecruitment(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.deleteRegisterRecruitment(registerRecruitmentPK);
	}

	/**
	* Deletes the register recruitment from the database. Also notifies the appropriate model listeners.
	*
	* @param registerRecruitment the register recruitment
	* @return the register recruitment that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.RegisterRecruitment deleteRegisterRecruitment(
		com.portlets.action.model.RegisterRecruitment registerRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.deleteRegisterRecruitment(registerRecruitment);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _registerRecruitmentLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.dynamicQuery(dynamicQuery,
			start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.dynamicQuery(dynamicQuery,
			start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.portlets.action.model.RegisterRecruitment fetchRegisterRecruitment(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.fetchRegisterRecruitment(registerRecruitmentPK);
	}

	/**
	* Returns the register recruitment with the primary key.
	*
	* @param registerRecruitmentPK the primary key of the register recruitment
	* @return the register recruitment
	* @throws PortalException if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.RegisterRecruitment getRegisterRecruitment(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.getRegisterRecruitment(registerRecruitmentPK);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the register recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @return the range of register recruitments
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.RegisterRecruitment> getRegisterRecruitments(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.getRegisterRecruitments(start,
			end);
	}

	/**
	* Returns the number of register recruitments.
	*
	* @return the number of register recruitments
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getRegisterRecruitmentsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.getRegisterRecruitmentsCount();
	}

	/**
	* Updates the register recruitment in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param registerRecruitment the register recruitment
	* @return the register recruitment that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.RegisterRecruitment updateRegisterRecruitment(
		com.portlets.action.model.RegisterRecruitment registerRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _registerRecruitmentLocalService.updateRegisterRecruitment(registerRecruitment);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _registerRecruitmentLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_registerRecruitmentLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _registerRecruitmentLocalService.invokeMethod(name,
			parameterTypes, arguments);
	}

	@Override
	public java.util.List<com.portlets.action.model.RegisterRecruitment> getByUserId(
		java.lang.Long userId) {
		return _registerRecruitmentLocalService.getByUserId(userId);
	}

	@Override
	public java.util.List<com.portlets.action.model.RegisterRecruitment> getByRecruitmentId(
		java.lang.Long recruitmentId) {
		return _registerRecruitmentLocalService.getByRecruitmentId(recruitmentId);
	}

	@Override
	public java.util.List<com.portlets.action.model.RegisterRecruitment> getByStatesId(
		java.lang.Long statesId) {
		return _registerRecruitmentLocalService.getByStatesId(statesId);
	}

	@Override
	public boolean hasRegisterRecruitment(java.lang.Long recruitmentId,
		java.lang.Long userId) {
		return _registerRecruitmentLocalService.hasRegisterRecruitment(recruitmentId,
			userId);
	}

	@Override
	public java.util.List<com.portlets.action.model.RegisterRecruitment> getListOfRegisteredByRecruitmentId(
		long recruitmentId) throws java.lang.Exception {
		return _registerRecruitmentLocalService.getListOfRegisteredByRecruitmentId(recruitmentId);
	}

	@Override
	public com.portlets.action.model.RegisterRecruitment getRegisterRecruitmentByRe_Use(
		long recruitmentId, long userObjectId) throws java.lang.Exception {
		return _registerRecruitmentLocalService.getRegisterRecruitmentByRe_Use(recruitmentId,
			userObjectId);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public RegisterRecruitmentLocalService getWrappedRegisterRecruitmentLocalService() {
		return _registerRecruitmentLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedRegisterRecruitmentLocalService(
		RegisterRecruitmentLocalService registerRecruitmentLocalService) {
		_registerRecruitmentLocalService = registerRecruitmentLocalService;
	}

	@Override
	public RegisterRecruitmentLocalService getWrappedService() {
		return _registerRecruitmentLocalService;
	}

	@Override
	public void setWrappedService(
		RegisterRecruitmentLocalService registerRecruitmentLocalService) {
		_registerRecruitmentLocalService = registerRecruitmentLocalService;
	}

	private RegisterRecruitmentLocalService _registerRecruitmentLocalService;
}