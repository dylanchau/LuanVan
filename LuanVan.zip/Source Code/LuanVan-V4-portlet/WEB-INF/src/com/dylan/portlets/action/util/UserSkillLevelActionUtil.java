package com.dylan.portlets.action.util;

import java.util.List;

import javax.portlet.PortletException;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.portlets.action.model.UserSkillLevel;
import com.portlets.action.model.impl.UserSkillLevelImpl;
import com.portlets.action.service.UserSkillLevelLocalServiceUtil;

public class UserSkillLevelActionUtil {

	@SuppressWarnings("unchecked")
	public static List<UserSkillLevel> getUserSkillId(long userObjectId) 
			throws SystemException, PortletException {
		
		try {
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(UserSkillLevel.class);
			dq.add(PropertyFactoryUtil.forName("userObjectId").eq(userObjectId));
			
			return UserSkillLevelLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			_log.info("loi dq");
			_log.error(e.getClass() + "\n" + e.getMessage());
			return null;
		}
	}
	
	public static UserSkillLevel addUserSkills(long userId, long skillId, long levelId) 
			throws SystemException, PortletException {
		
		try {
			
			UserSkillLevel userSkill = new UserSkillLevelImpl();
			userSkill.setSkillId(skillId);
			userSkill.setUserObjectId(userId);
			userSkill.setLevelId(levelId);
			
			userSkill = UserSkillLevelLocalServiceUtil.addUserSkillLevel(userSkill);
			
			return userSkill;
			
		}catch(Exception e){
			_log.error(e.getMessage() + "\n" + e);
			return null;
		}
	}
	
	private static Log _log = LogFactoryUtil.getLog(UserSkillLevelActionUtil.class);
}
