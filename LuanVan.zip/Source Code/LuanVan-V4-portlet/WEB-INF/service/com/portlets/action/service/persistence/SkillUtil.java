/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.Skill;

import java.util.List;

/**
 * The persistence utility for the skill service. This utility wraps {@link SkillPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see SkillPersistence
 * @see SkillPersistenceImpl
 * @generated
 */
public class SkillUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Skill skill) {
		getPersistence().clearCache(skill);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Skill> findWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Skill> findWithDynamicQuery(DynamicQuery dynamicQuery,
		int start, int end) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Skill> findWithDynamicQuery(DynamicQuery dynamicQuery,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Skill update(Skill skill) throws SystemException {
		return getPersistence().update(skill);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Skill update(Skill skill, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(skill, serviceContext);
	}

	/**
	* Returns all the skills where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @return the matching skills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> findByskillAncestor(
		long skillAncestor)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByskillAncestor(skillAncestor);
	}

	/**
	* Returns a range of all the skills where skillAncestor = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param skillAncestor the skill ancestor
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> findByskillAncestor(
		long skillAncestor, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByskillAncestor(skillAncestor, start, end);
	}

	/**
	* Returns an ordered range of all the skills where skillAncestor = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param skillAncestor the skill ancestor
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> findByskillAncestor(
		long skillAncestor, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByskillAncestor(skillAncestor, start, end,
			orderByComparator);
	}

	/**
	* Returns the first skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching skill
	* @throws com.portlets.action.NoSuchSkillException if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill findByskillAncestor_First(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException {
		return getPersistence()
				   .findByskillAncestor_First(skillAncestor, orderByComparator);
	}

	/**
	* Returns the first skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill fetchByskillAncestor_First(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByskillAncestor_First(skillAncestor, orderByComparator);
	}

	/**
	* Returns the last skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching skill
	* @throws com.portlets.action.NoSuchSkillException if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill findByskillAncestor_Last(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException {
		return getPersistence()
				   .findByskillAncestor_Last(skillAncestor, orderByComparator);
	}

	/**
	* Returns the last skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill fetchByskillAncestor_Last(
		long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByskillAncestor_Last(skillAncestor, orderByComparator);
	}

	/**
	* Returns the skills before and after the current skill in the ordered set where skillAncestor = &#63;.
	*
	* @param skillId the primary key of the current skill
	* @param skillAncestor the skill ancestor
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next skill
	* @throws com.portlets.action.NoSuchSkillException if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill[] findByskillAncestor_PrevAndNext(
		long skillId, long skillAncestor,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException {
		return getPersistence()
				   .findByskillAncestor_PrevAndNext(skillId, skillAncestor,
			orderByComparator);
	}

	/**
	* Removes all the skills where skillAncestor = &#63; from the database.
	*
	* @param skillAncestor the skill ancestor
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByskillAncestor(long skillAncestor)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByskillAncestor(skillAncestor);
	}

	/**
	* Returns the number of skills where skillAncestor = &#63;.
	*
	* @param skillAncestor the skill ancestor
	* @return the number of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public static int countByskillAncestor(long skillAncestor)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByskillAncestor(skillAncestor);
	}

	/**
	* Returns the skill where skillName = &#63; or throws a {@link com.portlets.action.NoSuchSkillException} if it could not be found.
	*
	* @param skillName the skill name
	* @return the matching skill
	* @throws com.portlets.action.NoSuchSkillException if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill findBySkillName(
		java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException {
		return getPersistence().findBySkillName(skillName);
	}

	/**
	* Returns the skill where skillName = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param skillName the skill name
	* @return the matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill fetchBySkillName(
		java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBySkillName(skillName);
	}

	/**
	* Returns the skill where skillName = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param skillName the skill name
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching skill, or <code>null</code> if a matching skill could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill fetchBySkillName(
		java.lang.String skillName, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBySkillName(skillName, retrieveFromCache);
	}

	/**
	* Removes the skill where skillName = &#63; from the database.
	*
	* @param skillName the skill name
	* @return the skill that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill removeBySkillName(
		java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException {
		return getPersistence().removeBySkillName(skillName);
	}

	/**
	* Returns the number of skills where skillName = &#63;.
	*
	* @param skillName the skill name
	* @return the number of matching skills
	* @throws SystemException if a system exception occurred
	*/
	public static int countBySkillName(java.lang.String skillName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBySkillName(skillName);
	}

	/**
	* Caches the skill in the entity cache if it is enabled.
	*
	* @param skill the skill
	*/
	public static void cacheResult(com.portlets.action.model.Skill skill) {
		getPersistence().cacheResult(skill);
	}

	/**
	* Caches the skills in the entity cache if it is enabled.
	*
	* @param skills the skills
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.Skill> skills) {
		getPersistence().cacheResult(skills);
	}

	/**
	* Creates a new skill with the primary key. Does not add the skill to the database.
	*
	* @param skillId the primary key for the new skill
	* @return the new skill
	*/
	public static com.portlets.action.model.Skill create(long skillId) {
		return getPersistence().create(skillId);
	}

	/**
	* Removes the skill with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param skillId the primary key of the skill
	* @return the skill that was removed
	* @throws com.portlets.action.NoSuchSkillException if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill remove(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException {
		return getPersistence().remove(skillId);
	}

	public static com.portlets.action.model.Skill updateImpl(
		com.portlets.action.model.Skill skill)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(skill);
	}

	/**
	* Returns the skill with the primary key or throws a {@link com.portlets.action.NoSuchSkillException} if it could not be found.
	*
	* @param skillId the primary key of the skill
	* @return the skill
	* @throws com.portlets.action.NoSuchSkillException if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill findByPrimaryKey(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchSkillException {
		return getPersistence().findByPrimaryKey(skillId);
	}

	/**
	* Returns the skill with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param skillId the primary key of the skill
	* @return the skill, or <code>null</code> if a skill with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Skill fetchByPrimaryKey(
		long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(skillId);
	}

	/**
	* Returns all the skills.
	*
	* @return the skills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the skills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of skills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the skills.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of skills
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the skills from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of skills.
	*
	* @return the number of skills
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	/**
	* Returns all the training programs associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.TrainingProgram> getTrainingPrograms(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getTrainingPrograms(pk);
	}

	/**
	* Returns a range of all the training programs associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.TrainingProgram> getTrainingPrograms(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getTrainingPrograms(pk, start, end);
	}

	/**
	* Returns an ordered range of all the training programs associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.TrainingProgram> getTrainingPrograms(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .getTrainingPrograms(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of training programs associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the number of training programs associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static int getTrainingProgramsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getTrainingProgramsSize(pk);
	}

	/**
	* Returns <code>true</code> if the training program is associated with the skill.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPK the primary key of the training program
	* @return <code>true</code> if the training program is associated with the skill; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsTrainingProgram(long pk,
		long trainingProgramPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsTrainingProgram(pk, trainingProgramPK);
	}

	/**
	* Returns <code>true</code> if the skill has any training programs associated with it.
	*
	* @param pk the primary key of the skill to check for associations with training programs
	* @return <code>true</code> if the skill has any training programs associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsTrainingPrograms(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsTrainingPrograms(pk);
	}

	/**
	* Adds an association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPK the primary key of the training program
	* @throws SystemException if a system exception occurred
	*/
	public static void addTrainingProgram(long pk, long trainingProgramPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addTrainingProgram(pk, trainingProgramPK);
	}

	/**
	* Adds an association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgram the training program
	* @throws SystemException if a system exception occurred
	*/
	public static void addTrainingProgram(long pk,
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addTrainingProgram(pk, trainingProgram);
	}

	/**
	* Adds an association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPKs the primary keys of the training programs
	* @throws SystemException if a system exception occurred
	*/
	public static void addTrainingPrograms(long pk, long[] trainingProgramPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addTrainingPrograms(pk, trainingProgramPKs);
	}

	/**
	* Adds an association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingPrograms the training programs
	* @throws SystemException if a system exception occurred
	*/
	public static void addTrainingPrograms(long pk,
		java.util.List<com.portlets.action.model.TrainingProgram> trainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addTrainingPrograms(pk, trainingPrograms);
	}

	/**
	* Clears all associations between the skill and its training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill to clear the associated training programs from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearTrainingPrograms(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearTrainingPrograms(pk);
	}

	/**
	* Removes the association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPK the primary key of the training program
	* @throws SystemException if a system exception occurred
	*/
	public static void removeTrainingProgram(long pk, long trainingProgramPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeTrainingProgram(pk, trainingProgramPK);
	}

	/**
	* Removes the association between the skill and the training program. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgram the training program
	* @throws SystemException if a system exception occurred
	*/
	public static void removeTrainingProgram(long pk,
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeTrainingProgram(pk, trainingProgram);
	}

	/**
	* Removes the association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPKs the primary keys of the training programs
	* @throws SystemException if a system exception occurred
	*/
	public static void removeTrainingPrograms(long pk, long[] trainingProgramPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeTrainingPrograms(pk, trainingProgramPKs);
	}

	/**
	* Removes the association between the skill and the training programs. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingPrograms the training programs
	* @throws SystemException if a system exception occurred
	*/
	public static void removeTrainingPrograms(long pk,
		java.util.List<com.portlets.action.model.TrainingProgram> trainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeTrainingPrograms(pk, trainingPrograms);
	}

	/**
	* Sets the training programs associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingProgramPKs the primary keys of the training programs to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void setTrainingPrograms(long pk, long[] trainingProgramPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setTrainingPrograms(pk, trainingProgramPKs);
	}

	/**
	* Sets the training programs associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param trainingPrograms the training programs to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void setTrainingPrograms(long pk,
		java.util.List<com.portlets.action.model.TrainingProgram> trainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setTrainingPrograms(pk, trainingPrograms);
	}

	/**
	* Returns all the recruitments associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getRecruitments(pk);
	}

	/**
	* Returns a range of all the recruitments associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @return the range of recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getRecruitments(pk, start, end);
	}

	/**
	* Returns an ordered range of all the recruitments associated with the skill.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.SkillModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the skill
	* @param start the lower bound of the range of skills
	* @param end the upper bound of the range of skills (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .getRecruitments(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of recruitments associated with the skill.
	*
	* @param pk the primary key of the skill
	* @return the number of recruitments associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static int getRecruitmentsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getRecruitmentsSize(pk);
	}

	/**
	* Returns <code>true</code> if the recruitment is associated with the skill.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPK the primary key of the recruitment
	* @return <code>true</code> if the recruitment is associated with the skill; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsRecruitment(pk, recruitmentPK);
	}

	/**
	* Returns <code>true</code> if the skill has any recruitments associated with it.
	*
	* @param pk the primary key of the skill to check for associations with recruitments
	* @return <code>true</code> if the skill has any recruitments associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsRecruitments(pk);
	}

	/**
	* Adds an association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitment(pk, recruitmentPK);
	}

	/**
	* Adds an association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitment(pk, recruitment);
	}

	/**
	* Adds an association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitments(pk, recruitmentPKs);
	}

	/**
	* Adds an association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitments(pk, recruitments);
	}

	/**
	* Clears all associations between the skill and its recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill to clear the associated recruitments from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearRecruitments(pk);
	}

	/**
	* Removes the association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitment(pk, recruitmentPK);
	}

	/**
	* Removes the association between the skill and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitment(pk, recruitment);
	}

	/**
	* Removes the association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitments(pk, recruitmentPKs);
	}

	/**
	* Removes the association between the skill and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitments(pk, recruitments);
	}

	/**
	* Sets the recruitments associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitmentPKs the primary keys of the recruitments to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void setRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setRecruitments(pk, recruitmentPKs);
	}

	/**
	* Sets the recruitments associated with the skill, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the skill
	* @param recruitments the recruitments to be associated with the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void setRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setRecruitments(pk, recruitments);
	}

	public static SkillPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (SkillPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					SkillPersistence.class.getName());

			ReferenceRegistry.registerReference(SkillUtil.class, "_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(SkillPersistence persistence) {
	}

	private static SkillPersistence _persistence;
}