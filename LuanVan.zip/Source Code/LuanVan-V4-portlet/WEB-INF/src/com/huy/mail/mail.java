package com.huy.mail;

import java.io.IOException;

import javax.mail.internet.InternetAddress;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class mail
 */
public class mail extends MVCPortlet {

	public void sendMail(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		try {
			

	             System.out.println("====sendMailMessage===");
	             String From= "liferay.luanvan@gmail.com";
	             String To =ParamUtil.getString(actionRequest,"To");
	             String Subject = ParamUtil.getString(actionRequest, "Subject");
	             String body = ParamUtil.getString(actionRequest, "body");
	             
	             InternetAddress From1 = new InternetAddress(From);
	             InternetAddress To1 = new InternetAddress(To);
	             
	             try {
	            	 
	            	 MailMessage mailMessage =new MailMessage(); 

	                    mailMessage.setFrom(From1);
	                    mailMessage.setTo(To1);
	                    
	                    mailMessage.setSubject(Subject);
	                    mailMessage.setBody(body);
	                    mailMessage.setHTMLFormat(true);
	                    
	                    
	                    MailServiceUtil.sendEmail(mailMessage);
	                             
	                    SessionMessages.add(actionRequest.getPortletSession(),"mail-send-success");
	                    
	             } catch (Exception e) {
						e.printStackTrace();
					}
	             
			} catch (Exception e) {
					e.printStackTrace();
				}
			}


}
