/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.StatesServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.StatesServiceSoap
 * @generated
 */
public class StatesSoap implements Serializable {
	public static StatesSoap toSoapModel(States model) {
		StatesSoap soapModel = new StatesSoap();

		soapModel.setStatesId(model.getStatesId());
		soapModel.setStatesName(model.getStatesName());
		soapModel.setStatesExplain(model.getStatesExplain());

		return soapModel;
	}

	public static StatesSoap[] toSoapModels(States[] models) {
		StatesSoap[] soapModels = new StatesSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static StatesSoap[][] toSoapModels(States[][] models) {
		StatesSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new StatesSoap[models.length][models[0].length];
		}
		else {
			soapModels = new StatesSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static StatesSoap[] toSoapModels(List<States> models) {
		List<StatesSoap> soapModels = new ArrayList<StatesSoap>(models.size());

		for (States model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new StatesSoap[soapModels.size()]);
	}

	public StatesSoap() {
	}

	public long getPrimaryKey() {
		return _statesId;
	}

	public void setPrimaryKey(long pk) {
		setStatesId(pk);
	}

	public long getStatesId() {
		return _statesId;
	}

	public void setStatesId(long statesId) {
		_statesId = statesId;
	}

	public String getStatesName() {
		return _statesName;
	}

	public void setStatesName(String statesName) {
		_statesName = statesName;
	}

	public String getStatesExplain() {
		return _statesExplain;
	}

	public void setStatesExplain(String statesExplain) {
		_statesExplain = statesExplain;
	}

	private long _statesId;
	private String _statesName;
	private String _statesExplain;
}