package com.huy.recruitment;

import com.kimtho.portlet.listener.ListenerUserRecruitment;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletURL;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
import com.portlets.action.model.LinkUserRecruitment;
import com.portlets.action.model.Recruitment;
import com.portlets.action.model.RegisterRecruitment;
import com.portlets.action.model.impl.RecruitmentImpl;
import com.portlets.action.service.LinkUserRecruitmentLocalServiceUtil;
import com.portlets.action.service.RecruitmentLocalServiceUtil;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;
import com.portlets.action.model.Skill;
import com.portlets.action.service.SkillLocalServiceUtil;


/**
 * Portlet implementation class Actionrecruitment
 */
public class Actionrecruitment extends MVCPortlet {
 
	/**
	 * Portlet implementation class ActionRecruitment
	 */
	public void addRecruitment(ActionRequest actionRequest,ActionResponse actionResponse) 
				throws IOException, PortletException {
		try {
			ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
			String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
			PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
					portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
			User user = themeDisplay.getUser();
	
			SimpleDateFormat df = new SimpleDateFormat("dd/mm/yyyy");
				String ten = ParamUtil.getString(actionRequest, "tenTin"); _log.info(ten);
				String vitri = ParamUtil.getString(actionRequest, "vitriTin"); _log.info(vitri);
				String mota = ParamUtil.getString(actionRequest, "motaTin"); _log.info(mota);
				
				String[] kynangs = ParamUtil.getParameterValues(actionRequest, "skills");
				for(int i=0; i<kynangs.length; i++) {
					_log.info(kynangs[i]);
				}
				String skillsList = Arrays.toString(kynangs);
				skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
				
				long[] skillIds = new long[kynangs.length];
				for(int i = 0; i < kynangs.length; i++) {
					skillIds[i] = Long.parseLong(kynangs[i]);
				}
				
				
				String gioitinh = ParamUtil.getString(actionRequest, "gioitinhTin");
				int dotuoitu = ParamUtil.getInteger(actionRequest, "dotuoituTin");
				int dotuoiden = ParamUtil.getInteger(actionRequest, "dotuoidenTin");
				String kinhnghiem = ParamUtil.getString(actionRequest, "kinhnghiemTin");
				String bangcap = ParamUtil.getString(actionRequest, "bangcapTin");
				String htlv = ParamUtil.getString(actionRequest, "htlvTin");
				String loiich = ParamUtil.getString(actionRequest, "loiichTin");
				String hoso = ParamUtil.getString(actionRequest, "hosoTin");
				int soluong = ParamUtil.getInteger(actionRequest, "soluongTin");
				String mucluong = ParamUtil.getString(actionRequest, "mucluongTin"); 
				Date thoigiantu =ParamUtil.getDate(actionRequest, "thoigiantuTin", df);
				Date thoigianden = ParamUtil.getDate(actionRequest, "thoigiandenTin", df); 
				long tdID = user.getUserId();
				
				long statesId = 2;
					// add tintuyendung record
					long ma = CounterLocalServiceUtil.increment();
					// create tintuyendung persistance object
					Recruitment Recruitment = null;
					Recruitment = new RecruitmentImpl();
					Recruitment = RecruitmentLocalServiceUtil.createRecruitment(ma);
					// fill the data in persistance object
					Recruitment.setRecruitmentName(ten);
					Recruitment.setRecruitmentPosition(vitri);
					Recruitment.setRecruitmentDescription(mota);
					Recruitment.setRecruitmentGender(gioitinh);
					Recruitment.setRecruitmentAgeFrom(dotuoitu);
					Recruitment.setRecruitmentAgeTo(dotuoiden);
					Recruitment.setRecruitmentExper(kinhnghiem);
					Recruitment.setRecruitmentQualification(bangcap);
					Recruitment.setRecruitmentJobType(htlv);
					Recruitment.setRecruitmentBenefit(loiich);
					Recruitment.setRecruitmentFileReq(hoso);
					Recruitment.setRecruitmentNo(soluong);
					Recruitment.setRecruitmentSalary(mucluong);
					Recruitment.setRecruitmentFileDeadlineFrom(thoigiantu);
					Recruitment.setRecruitmentFileDeadlineTo(thoigianden);
					Recruitment.setEmployerId(tdID);
					Recruitment.setStatesId(statesId);
					
					// Add tintuyendung persistance object to database tintuyendung table
					Recruitment = RecruitmentLocalServiceUtil.addRecruitment(Recruitment);
					SkillLocalServiceUtil.addRecruitmentSkills(ma, skillIds);
					//listener
					ListenerUserRecruitment lis = new ListenerUserRecruitment();
					for(Long s:skillIds){
						lis.addLinkUserEmployerInfoId(Recruitment.getRecruitmentId(), s);
						
					}
					if (Recruitment != null) {
						// adding success message
						
						
						
						SessionMessages.add(actionRequest.getPortletSession(),"Them-thanh-cong");_log.info("Da them thanh cong!!!");} 
					else {
						SessionErrors.add(actionRequest.getPortletSession()," loi them tin tuyen dung ");_log.error("loi trong khi them");}
						
					
					actionResponse.sendRedirect(redirectURL.toString());
		
		} 
		catch (Exception e) {SessionErrors.add(actionRequest.getPortletSession(),"loi khi them ");e.printStackTrace();
		}
	}

	public void addPublicRecruitment(ActionRequest actionRequest,ActionResponse actionResponse) 
			throws IOException, PortletException {
					try {
						ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
						String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
						PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
								portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
						User user = themeDisplay.getUser();
				
						SimpleDateFormat df = new SimpleDateFormat("dd/mm/yyyy");
							String ten = ParamUtil.getString(actionRequest, "tenTin");
							String vitri = ParamUtil.getString(actionRequest, "vitriTin");
							String mota = ParamUtil.getString(actionRequest, "motaTin");
							
							String[] kynangs = ParamUtil.getParameterValues(actionRequest, "skills");
							String skillsList = Arrays.toString(kynangs);
							long[] skillIds = new long[kynangs.length];
							for(int i = 0; i < kynangs.length; i++) {
								skillIds[i] = Long.parseLong(kynangs[i]);
								System.out.println(skillIds[i]);
							}
							skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
							
							String gioitinh = ParamUtil.getString(actionRequest, "gioitinhTin");
							int dotuoitu = ParamUtil.getInteger(actionRequest, "dotuoituTin");
							int dotuoiden = ParamUtil.getInteger(actionRequest, "dotuoidenTin");
							String kinhnghiem = ParamUtil.getString(actionRequest, "kinhnghiemTin");
							String bangcap = ParamUtil.getString(actionRequest, "bangcapTin");
							String htlv = ParamUtil.getString(actionRequest, "htlvTin");
							String loiich = ParamUtil.getString(actionRequest, "loiichTin");
							String hoso = ParamUtil.getString(actionRequest, "hosoTin");
							int soluong = ParamUtil.getInteger(actionRequest, "soluongTin");
							String mucluong = ParamUtil.getString(actionRequest, "mucluongTin"); 
							Date thoigiantu =ParamUtil.getDate(actionRequest, "thoigiantuTin", df);
							Date thoigianden = ParamUtil.getDate(actionRequest, "thoigiandenTin", df); 
							long tdID = user.getUserId();
							
							long statesId = 1;
								// add tintuyendung record
								long ma = CounterLocalServiceUtil.increment();
								// create tintuyendung persistance object
								Recruitment Recruitment = null;
								Recruitment = new RecruitmentImpl();
								Recruitment = RecruitmentLocalServiceUtil.createRecruitment(ma);
								// fill the data in persistance object
								Recruitment.setRecruitmentName(ten);
								Recruitment.setRecruitmentPosition(vitri);
								Recruitment.setRecruitmentDescription(mota);
								Recruitment.setRecruitmentGender(gioitinh);
								Recruitment.setRecruitmentAgeFrom(dotuoitu);
								Recruitment.setRecruitmentAgeTo(dotuoiden);
								Recruitment.setRecruitmentExper(kinhnghiem);
								Recruitment.setRecruitmentQualification(bangcap);
								Recruitment.setRecruitmentJobType(htlv);
								Recruitment.setRecruitmentBenefit(loiich);
								Recruitment.setRecruitmentFileReq(hoso);
								Recruitment.setRecruitmentNo(soluong);
								Recruitment.setRecruitmentSalary(mucluong);
								Recruitment.setRecruitmentFileDeadlineFrom(thoigiantu);
								Recruitment.setRecruitmentFileDeadlineTo(thoigianden);
								Recruitment.setEmployerId(tdID);
								Recruitment.setStatesId(statesId);
								
								// Add tintuyendung persistance object to database tintuyendung table
								Recruitment = RecruitmentLocalServiceUtil.addRecruitment(Recruitment);
								SkillLocalServiceUtil.addRecruitmentSkills(ma, skillIds);
								
								if (Recruitment != null) {
									// adding success message
									SessionMessages.add(actionRequest.getPortletSession(),"Them-thanh-cong");_log.info("Da them thanh cong!!!");} 
								else {
									SessionErrors.add(actionRequest.getPortletSession()," loi them tin tuyen dung ");_log.error("loi trong khi them");
									}
							
								
							
								// add new massage
								String destination = "messageListener/employer_usesrObject/destination";
								System.out.println("Send message method is calling...");
								JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
								
								redirectURL.setParameter("mvcPath", "/html/actionRecruitment/DetailInFo.jsp");
								redirectURL.setParameter("employerId", String.valueOf(tdID));
								redirectURL.setParameter("RecruitmentId", String.valueOf(Recruitment.getRecruitmentId()) );
								
								String message = "A new Job is public!";
								jsonObject.put("employerId", themeDisplay.getUserId());
								jsonObject.put("id", Recruitment.getRecruitmentId());
								jsonObject.put("url", message);
								jsonObject.put("skillIds", skillsList);
								jsonObject.put("companyId", themeDisplay.getCompanyId());
								jsonObject.put("testURL", redirectURL.toString());
								
								MessageBusUtil.sendMessage(destination, jsonObject.toString());
	
								actionResponse.sendRedirect(redirectURL.toString());
					
					} 
					catch (Exception e) {SessionErrors.add(actionRequest.getPortletSession(),"loi khi them ");e.printStackTrace();
					}
				}

	public void deleteRecruitment(ActionRequest actionRequest, ActionResponse actionResponse) 
					throws IOException, PortletException {	
						long ma = ParamUtil.getLong(actionRequest, "recruitmentId");
				
						try{
							RecruitmentLocalServiceUtil.deleteRecruitment(ma);
							
							List<RegisterRecruitment> registered = RegisterRecruitmentLocalServiceUtil
									.getByRecruitmentId(ma);
							
							for(RegisterRecruitment a : registered) 
								RegisterRecruitmentLocalServiceUtil.deleteRegisterRecruitment(a);
							
							List<LinkUserRecruitment> linkUser = LinkUserRecruitmentLocalServiceUtil
									.getLinkUserRecruitmentByRecruitmentId(ma);
							for(LinkUserRecruitment b : linkUser) 
								LinkUserRecruitmentLocalServiceUtil.deleteLinkUserRecruitment(b);
							
							/*
							List<LinkUserRecruitment> linkUser = GetIdAll
									.getLinkUserRecruitmentByRecruitmentId(ma);
							for(LinkUserRecruitment b : linkUser) 
								LinkUserRecruitmentLocalServiceUtil.deleteLinkUserRecruitment(b);
							*/
						} catch(Exception ex) {
			                ex.printStackTrace();}
						
						
						}

	public void updateRecruitment(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws IOException, PortletException {
				try {
					ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
					String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
					PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
							portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
					User user = themeDisplay.getUser();
					long tdID = user.getUserId();
					SimpleDateFormat df = new SimpleDateFormat("dd/mm/yyyy");
					long ma = ParamUtil.getLong(actionRequest, "recruitmentId");
					String ten = ParamUtil.getString(actionRequest, "tenTin");
					String vitri = ParamUtil.getString(actionRequest, "vitriTin");
					String mota = ParamUtil.getString(actionRequest, "motaTin");
					String gioitinh = ParamUtil.getString(actionRequest, "gioitinhTin");
					int dotuoitu = ParamUtil.getInteger(actionRequest, "dotuoituTin");
					int dotuoiden = ParamUtil.getInteger(actionRequest, "dotuoidenTin");
					String kinhnghiem = ParamUtil.getString(actionRequest, "kinhnghiemTin");
					String bangcap = ParamUtil.getString(actionRequest, "bangcapTin");
					String htlv = ParamUtil.getString(actionRequest, "htlvTin");
					String loiich = ParamUtil.getString(actionRequest, "loiichTin");
					String hoso = ParamUtil.getString(actionRequest, "hosoTin");
					int soluong = ParamUtil.getInteger(actionRequest, "soluongTin");
					String mucluong= ParamUtil.getString(actionRequest, "mucluongTin");
					Date thoigiantu = ParamUtil.getDate(actionRequest, "thoigiantuTin", df);
					Date thoigianden = ParamUtil.getDate(actionRequest, "thoigiandenTin", df);
					long statesId =2;
					List<Skill> skillList =  SkillLocalServiceUtil.getRecruitmentSkills(ma);
					long[] skillListIds = new long[skillList.size()];  
					for(int i=0; i < skillList.size(); i++) {
						skillListIds[i] = skillList.get(i).getSkillId();
						_log.info("skills: " + skillList.get(i).getSkillId() + "\t skillIds: " + skillListIds[i]);
					}
					
					SkillLocalServiceUtil.deleteRecruitmentSkills(ma, skillList);
					
					String[] kynangs = ParamUtil.getParameterValues(actionRequest, "skills");
					String skillsList = Arrays.toString(kynangs);
					long[] skillIds = new long[kynangs.length];
					for(int i = 0; i < kynangs.length; i++) {
						skillIds[i] = Long.parseLong(kynangs[i]);
						System.out.println(skillIds[i]);
					}
					skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
					
					Recruitment Recruitment = (Recruitment) RecruitmentLocalServiceUtil.getRecruitment(ma);
					
					
				if (Recruitment != null) {
				// fill update information
					Recruitment.setRecruitmentName(ten);
					Recruitment.setRecruitmentPosition(vitri);
					Recruitment.setRecruitmentDescription(mota);
					Recruitment.setRecruitmentGender(gioitinh);
					Recruitment.setRecruitmentAgeTo(dotuoitu);
					Recruitment.setRecruitmentAgeFrom(dotuoiden);
					Recruitment.setRecruitmentExper(kinhnghiem);
					Recruitment.setRecruitmentQualification(bangcap);
					Recruitment.setRecruitmentJobType(htlv);
					Recruitment.setRecruitmentBenefit(loiich);
					Recruitment.setRecruitmentFileReq(hoso);
					Recruitment.setRecruitmentNo(soluong);
					Recruitment.setRecruitmentSalary(mucluong);
					Recruitment.setRecruitmentFileDeadlineFrom(thoigiantu);
					Recruitment.setRecruitmentFileDeadlineTo(thoigianden);
					Recruitment.setEmployerId(tdID);
					Recruitment.setStatesId(statesId);
					
					Recruitment = RecruitmentLocalServiceUtil.updateRecruitment(Recruitment);
					SkillLocalServiceUtil.addRecruitmentSkills(ma, skillIds);
				if (Recruitment != null) {
				// adding success message
					SessionMessages.add(actionRequest.getPortletSession(),"thanhcong");
					_log.info("Thong Tin Cap Nhat Thanh Cong");
						} 
				else {
					SessionErrors.add(actionRequest.getPortletSession(),"thatbai");
					_log.error("Loi trong cap nhat");
						}
					} 
				else {
					SessionErrors.add(actionRequest.getPortletSession(),"thatbai");
					_log.error("Khong tim thay Tin tuyen dung");
					}
					actionResponse.sendRedirect(redirectURL.toString());
					} 
				catch (Exception e) {
					SessionErrors.add(actionRequest.getPortletSession(),"thatbai");
					e.printStackTrace();
						}
				}	
	// changes the status
	public void changeState(ActionRequest actionRequest, ActionResponse actionResponse) 
					throws Exception {
				ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
				String portletName = "p_p_id_job_WAR_LuanVanV4portlet";
				PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
						portletName, 61659, PortletRequest.RENDER_PHASE);
				
				long stateId = ParamUtil.getLong(actionRequest, "states");
				long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId"); 
				Recruitment recruitment = RecruitmentLocalServiceUtil.getRecruitment(recruitmentId);
				long tdID = recruitment.getEmployerId();
				try {
					
					recruitment.setStatesId(stateId);
					recruitment = RecruitmentLocalServiceUtil.updateRecruitment(recruitment);
					if(stateId == 1) {
					//message bus
					List<Skill> skills = SkillLocalServiceUtil.getRecruitmentSkills(recruitmentId);
					String[] skillIdsStr = new String[skills.size()];
					for(int i=0; i<skills.size(); i++) {
						skillIdsStr[i] = String.valueOf(skills.get(i).getSkillId());
					}
					
					String skillsList = Arrays.toString(skillIdsStr);
					skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
						// add new massage
						String destination = "messageListener/employer_usesrObject/destination";
						System.out.println("Send message method is calling...");
						JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
						
						redirectURL.setParameter("mvcPath", "/html/actionrecruitment/DetailInFo.jsp");
						redirectURL.setParameter("employerId", String.valueOf(tdID));
						redirectURL.setParameter("recruitmentId", String.valueOf(recruitment.getRecruitmentId()) );
						
						String message = "A new Job is published!";
						jsonObject.put("employerId", themeDisplay.getUserId());
						jsonObject.put("id", recruitment.getRecruitmentId());
						jsonObject.put("url", message);
						jsonObject.put("skillIds", skillsList);
						jsonObject.put("companyId", themeDisplay.getCompanyId());
						jsonObject.put("testURL", redirectURL.toString());
						
						MessageBusUtil.sendMessage(destination, jsonObject.toString());
						
					}
					
					
				} catch(Exception e) 
				{
					_log.error(e);
				}
			}


				@SuppressWarnings("static-access")
				public void serveResource(ResourceRequest resourceRequest,
			            ResourceResponse resourceResponse) throws IOException, PortletException {
					
					JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
					String cmd = ParamUtil.getString(resourceRequest, "cmd");
					if (cmd.equals("getskill")){
						Skill skill= null;
						long[] skillIds = ParamUtil.getLongValues(resourceRequest, "skillIds");
						int skillIdslength = skillIds.length;
						_log.info(skillIdslength);
						if(skillIdslength > 0) {
							for(int i = 0; i < skillIds.length; i++) {
								_log.info(skillIds[i]);
								try {
								 skill = SkillLocalServiceUtil.getSkill(skillIds[i]);
								} catch (PortalException e) {
									e.printStackTrace();
								} catch (SystemException e) {
									e.printStackTrace();
								}
								JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
								jsonObject.put("id", skillIds[i]);
								jsonObject.put("name", skill.getSkillName());
								jsonArray.put(jsonObject);
							}
								PrintWriter writer = resourceResponse.getWriter();
								writer.print(jsonArray.toString());
								writer.flush(); writer.close();
							
							}
						}
						
					 
					super.serveResource(resourceRequest, resourceResponse);
				}
				private static Log _log = LogFactoryUtil.getLog(Recruitment.class);
		}



