/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Recruitment}.
 * </p>
 *
 * @author Computer
 * @see Recruitment
 * @generated
 */
public class RecruitmentWrapper implements Recruitment,
	ModelWrapper<Recruitment> {
	public RecruitmentWrapper(Recruitment recruitment) {
		_recruitment = recruitment;
	}

	@Override
	public Class<?> getModelClass() {
		return Recruitment.class;
	}

	@Override
	public String getModelClassName() {
		return Recruitment.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recruitmentId", getRecruitmentId());
		attributes.put("recruitmentName", getRecruitmentName());
		attributes.put("recruitmentPosition", getRecruitmentPosition());
		attributes.put("recruitmentDescription", getRecruitmentDescription());
		attributes.put("recruitmentBenefit", getRecruitmentBenefit());
		attributes.put("recruitmentJobType", getRecruitmentJobType());
		attributes.put("recruitmentFileReq", getRecruitmentFileReq());
		attributes.put("recruitmentFileDeadlineFrom",
			getRecruitmentFileDeadlineFrom());
		attributes.put("recruitmentFileDeadlineTo",
			getRecruitmentFileDeadlineTo());
		attributes.put("recruitmentSalary", getRecruitmentSalary());
		attributes.put("recruitmentNo", getRecruitmentNo());
		attributes.put("recruitmentGender", getRecruitmentGender());
		attributes.put("recruitmentQualification", getRecruitmentQualification());
		attributes.put("recruitmentAgeFrom", getRecruitmentAgeFrom());
		attributes.put("recruitmentAgeTo", getRecruitmentAgeTo());
		attributes.put("recruitmentExper", getRecruitmentExper());
		attributes.put("employerId", getEmployerId());
		attributes.put("statesId", getStatesId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long recruitmentId = (Long)attributes.get("recruitmentId");

		if (recruitmentId != null) {
			setRecruitmentId(recruitmentId);
		}

		String recruitmentName = (String)attributes.get("recruitmentName");

		if (recruitmentName != null) {
			setRecruitmentName(recruitmentName);
		}

		String recruitmentPosition = (String)attributes.get(
				"recruitmentPosition");

		if (recruitmentPosition != null) {
			setRecruitmentPosition(recruitmentPosition);
		}

		String recruitmentDescription = (String)attributes.get(
				"recruitmentDescription");

		if (recruitmentDescription != null) {
			setRecruitmentDescription(recruitmentDescription);
		}

		String recruitmentBenefit = (String)attributes.get("recruitmentBenefit");

		if (recruitmentBenefit != null) {
			setRecruitmentBenefit(recruitmentBenefit);
		}

		String recruitmentJobType = (String)attributes.get("recruitmentJobType");

		if (recruitmentJobType != null) {
			setRecruitmentJobType(recruitmentJobType);
		}

		String recruitmentFileReq = (String)attributes.get("recruitmentFileReq");

		if (recruitmentFileReq != null) {
			setRecruitmentFileReq(recruitmentFileReq);
		}

		Date recruitmentFileDeadlineFrom = (Date)attributes.get(
				"recruitmentFileDeadlineFrom");

		if (recruitmentFileDeadlineFrom != null) {
			setRecruitmentFileDeadlineFrom(recruitmentFileDeadlineFrom);
		}

		Date recruitmentFileDeadlineTo = (Date)attributes.get(
				"recruitmentFileDeadlineTo");

		if (recruitmentFileDeadlineTo != null) {
			setRecruitmentFileDeadlineTo(recruitmentFileDeadlineTo);
		}

		String recruitmentSalary = (String)attributes.get("recruitmentSalary");

		if (recruitmentSalary != null) {
			setRecruitmentSalary(recruitmentSalary);
		}

		Integer recruitmentNo = (Integer)attributes.get("recruitmentNo");

		if (recruitmentNo != null) {
			setRecruitmentNo(recruitmentNo);
		}

		String recruitmentGender = (String)attributes.get("recruitmentGender");

		if (recruitmentGender != null) {
			setRecruitmentGender(recruitmentGender);
		}

		String recruitmentQualification = (String)attributes.get(
				"recruitmentQualification");

		if (recruitmentQualification != null) {
			setRecruitmentQualification(recruitmentQualification);
		}

		Integer recruitmentAgeFrom = (Integer)attributes.get(
				"recruitmentAgeFrom");

		if (recruitmentAgeFrom != null) {
			setRecruitmentAgeFrom(recruitmentAgeFrom);
		}

		Integer recruitmentAgeTo = (Integer)attributes.get("recruitmentAgeTo");

		if (recruitmentAgeTo != null) {
			setRecruitmentAgeTo(recruitmentAgeTo);
		}

		String recruitmentExper = (String)attributes.get("recruitmentExper");

		if (recruitmentExper != null) {
			setRecruitmentExper(recruitmentExper);
		}

		Long employerId = (Long)attributes.get("employerId");

		if (employerId != null) {
			setEmployerId(employerId);
		}

		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}
	}

	/**
	* Returns the primary key of this recruitment.
	*
	* @return the primary key of this recruitment
	*/
	@Override
	public long getPrimaryKey() {
		return _recruitment.getPrimaryKey();
	}

	/**
	* Sets the primary key of this recruitment.
	*
	* @param primaryKey the primary key of this recruitment
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_recruitment.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the recruitment ID of this recruitment.
	*
	* @return the recruitment ID of this recruitment
	*/
	@Override
	public long getRecruitmentId() {
		return _recruitment.getRecruitmentId();
	}

	/**
	* Sets the recruitment ID of this recruitment.
	*
	* @param recruitmentId the recruitment ID of this recruitment
	*/
	@Override
	public void setRecruitmentId(long recruitmentId) {
		_recruitment.setRecruitmentId(recruitmentId);
	}

	/**
	* Returns the recruitment name of this recruitment.
	*
	* @return the recruitment name of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentName() {
		return _recruitment.getRecruitmentName();
	}

	/**
	* Sets the recruitment name of this recruitment.
	*
	* @param recruitmentName the recruitment name of this recruitment
	*/
	@Override
	public void setRecruitmentName(java.lang.String recruitmentName) {
		_recruitment.setRecruitmentName(recruitmentName);
	}

	/**
	* Returns the recruitment position of this recruitment.
	*
	* @return the recruitment position of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentPosition() {
		return _recruitment.getRecruitmentPosition();
	}

	/**
	* Sets the recruitment position of this recruitment.
	*
	* @param recruitmentPosition the recruitment position of this recruitment
	*/
	@Override
	public void setRecruitmentPosition(java.lang.String recruitmentPosition) {
		_recruitment.setRecruitmentPosition(recruitmentPosition);
	}

	/**
	* Returns the recruitment description of this recruitment.
	*
	* @return the recruitment description of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentDescription() {
		return _recruitment.getRecruitmentDescription();
	}

	/**
	* Sets the recruitment description of this recruitment.
	*
	* @param recruitmentDescription the recruitment description of this recruitment
	*/
	@Override
	public void setRecruitmentDescription(
		java.lang.String recruitmentDescription) {
		_recruitment.setRecruitmentDescription(recruitmentDescription);
	}

	/**
	* Returns the recruitment benefit of this recruitment.
	*
	* @return the recruitment benefit of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentBenefit() {
		return _recruitment.getRecruitmentBenefit();
	}

	/**
	* Sets the recruitment benefit of this recruitment.
	*
	* @param recruitmentBenefit the recruitment benefit of this recruitment
	*/
	@Override
	public void setRecruitmentBenefit(java.lang.String recruitmentBenefit) {
		_recruitment.setRecruitmentBenefit(recruitmentBenefit);
	}

	/**
	* Returns the recruitment job type of this recruitment.
	*
	* @return the recruitment job type of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentJobType() {
		return _recruitment.getRecruitmentJobType();
	}

	/**
	* Sets the recruitment job type of this recruitment.
	*
	* @param recruitmentJobType the recruitment job type of this recruitment
	*/
	@Override
	public void setRecruitmentJobType(java.lang.String recruitmentJobType) {
		_recruitment.setRecruitmentJobType(recruitmentJobType);
	}

	/**
	* Returns the recruitment file req of this recruitment.
	*
	* @return the recruitment file req of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentFileReq() {
		return _recruitment.getRecruitmentFileReq();
	}

	/**
	* Sets the recruitment file req of this recruitment.
	*
	* @param recruitmentFileReq the recruitment file req of this recruitment
	*/
	@Override
	public void setRecruitmentFileReq(java.lang.String recruitmentFileReq) {
		_recruitment.setRecruitmentFileReq(recruitmentFileReq);
	}

	/**
	* Returns the recruitment file deadline from of this recruitment.
	*
	* @return the recruitment file deadline from of this recruitment
	*/
	@Override
	public java.util.Date getRecruitmentFileDeadlineFrom() {
		return _recruitment.getRecruitmentFileDeadlineFrom();
	}

	/**
	* Sets the recruitment file deadline from of this recruitment.
	*
	* @param recruitmentFileDeadlineFrom the recruitment file deadline from of this recruitment
	*/
	@Override
	public void setRecruitmentFileDeadlineFrom(
		java.util.Date recruitmentFileDeadlineFrom) {
		_recruitment.setRecruitmentFileDeadlineFrom(recruitmentFileDeadlineFrom);
	}

	/**
	* Returns the recruitment file deadline to of this recruitment.
	*
	* @return the recruitment file deadline to of this recruitment
	*/
	@Override
	public java.util.Date getRecruitmentFileDeadlineTo() {
		return _recruitment.getRecruitmentFileDeadlineTo();
	}

	/**
	* Sets the recruitment file deadline to of this recruitment.
	*
	* @param recruitmentFileDeadlineTo the recruitment file deadline to of this recruitment
	*/
	@Override
	public void setRecruitmentFileDeadlineTo(
		java.util.Date recruitmentFileDeadlineTo) {
		_recruitment.setRecruitmentFileDeadlineTo(recruitmentFileDeadlineTo);
	}

	/**
	* Returns the recruitment salary of this recruitment.
	*
	* @return the recruitment salary of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentSalary() {
		return _recruitment.getRecruitmentSalary();
	}

	/**
	* Sets the recruitment salary of this recruitment.
	*
	* @param recruitmentSalary the recruitment salary of this recruitment
	*/
	@Override
	public void setRecruitmentSalary(java.lang.String recruitmentSalary) {
		_recruitment.setRecruitmentSalary(recruitmentSalary);
	}

	/**
	* Returns the recruitment no of this recruitment.
	*
	* @return the recruitment no of this recruitment
	*/
	@Override
	public int getRecruitmentNo() {
		return _recruitment.getRecruitmentNo();
	}

	/**
	* Sets the recruitment no of this recruitment.
	*
	* @param recruitmentNo the recruitment no of this recruitment
	*/
	@Override
	public void setRecruitmentNo(int recruitmentNo) {
		_recruitment.setRecruitmentNo(recruitmentNo);
	}

	/**
	* Returns the recruitment gender of this recruitment.
	*
	* @return the recruitment gender of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentGender() {
		return _recruitment.getRecruitmentGender();
	}

	/**
	* Sets the recruitment gender of this recruitment.
	*
	* @param recruitmentGender the recruitment gender of this recruitment
	*/
	@Override
	public void setRecruitmentGender(java.lang.String recruitmentGender) {
		_recruitment.setRecruitmentGender(recruitmentGender);
	}

	/**
	* Returns the recruitment qualification of this recruitment.
	*
	* @return the recruitment qualification of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentQualification() {
		return _recruitment.getRecruitmentQualification();
	}

	/**
	* Sets the recruitment qualification of this recruitment.
	*
	* @param recruitmentQualification the recruitment qualification of this recruitment
	*/
	@Override
	public void setRecruitmentQualification(
		java.lang.String recruitmentQualification) {
		_recruitment.setRecruitmentQualification(recruitmentQualification);
	}

	/**
	* Returns the recruitment age from of this recruitment.
	*
	* @return the recruitment age from of this recruitment
	*/
	@Override
	public int getRecruitmentAgeFrom() {
		return _recruitment.getRecruitmentAgeFrom();
	}

	/**
	* Sets the recruitment age from of this recruitment.
	*
	* @param recruitmentAgeFrom the recruitment age from of this recruitment
	*/
	@Override
	public void setRecruitmentAgeFrom(int recruitmentAgeFrom) {
		_recruitment.setRecruitmentAgeFrom(recruitmentAgeFrom);
	}

	/**
	* Returns the recruitment age to of this recruitment.
	*
	* @return the recruitment age to of this recruitment
	*/
	@Override
	public int getRecruitmentAgeTo() {
		return _recruitment.getRecruitmentAgeTo();
	}

	/**
	* Sets the recruitment age to of this recruitment.
	*
	* @param recruitmentAgeTo the recruitment age to of this recruitment
	*/
	@Override
	public void setRecruitmentAgeTo(int recruitmentAgeTo) {
		_recruitment.setRecruitmentAgeTo(recruitmentAgeTo);
	}

	/**
	* Returns the recruitment exper of this recruitment.
	*
	* @return the recruitment exper of this recruitment
	*/
	@Override
	public java.lang.String getRecruitmentExper() {
		return _recruitment.getRecruitmentExper();
	}

	/**
	* Sets the recruitment exper of this recruitment.
	*
	* @param recruitmentExper the recruitment exper of this recruitment
	*/
	@Override
	public void setRecruitmentExper(java.lang.String recruitmentExper) {
		_recruitment.setRecruitmentExper(recruitmentExper);
	}

	/**
	* Returns the employer ID of this recruitment.
	*
	* @return the employer ID of this recruitment
	*/
	@Override
	public long getEmployerId() {
		return _recruitment.getEmployerId();
	}

	/**
	* Sets the employer ID of this recruitment.
	*
	* @param employerId the employer ID of this recruitment
	*/
	@Override
	public void setEmployerId(long employerId) {
		_recruitment.setEmployerId(employerId);
	}

	/**
	* Returns the states ID of this recruitment.
	*
	* @return the states ID of this recruitment
	*/
	@Override
	public long getStatesId() {
		return _recruitment.getStatesId();
	}

	/**
	* Sets the states ID of this recruitment.
	*
	* @param statesId the states ID of this recruitment
	*/
	@Override
	public void setStatesId(long statesId) {
		_recruitment.setStatesId(statesId);
	}

	@Override
	public boolean isNew() {
		return _recruitment.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_recruitment.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _recruitment.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_recruitment.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _recruitment.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _recruitment.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_recruitment.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _recruitment.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_recruitment.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_recruitment.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_recruitment.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new RecruitmentWrapper((Recruitment)_recruitment.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.Recruitment recruitment) {
		return _recruitment.compareTo(recruitment);
	}

	@Override
	public int hashCode() {
		return _recruitment.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.Recruitment> toCacheModel() {
		return _recruitment.toCacheModel();
	}

	@Override
	public com.portlets.action.model.Recruitment toEscapedModel() {
		return new RecruitmentWrapper(_recruitment.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.Recruitment toUnescapedModel() {
		return new RecruitmentWrapper(_recruitment.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _recruitment.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _recruitment.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_recruitment.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RecruitmentWrapper)) {
			return false;
		}

		RecruitmentWrapper recruitmentWrapper = (RecruitmentWrapper)obj;

		if (Validator.equals(_recruitment, recruitmentWrapper._recruitment)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Recruitment getWrappedRecruitment() {
		return _recruitment;
	}

	@Override
	public Recruitment getWrappedModel() {
		return _recruitment;
	}

	@Override
	public void resetOriginalValues() {
		_recruitment.resetOriginalValues();
	}

	private Recruitment _recruitment;
}