package com.dylan.portlets.action.util;

import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.portlets.action.model.RegisterCourse;
import com.portlets.action.service.RegisterCourseLocalServiceUtil;

public class RegisterCourseActionUtil {

	@SuppressWarnings("unchecked")
	public static List<RegisterCourse> getRegisterCourseByCourseId(long courseId) 
			throws Exception {
		
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(RegisterCourse.class);
			dq.add(PropertyFactoryUtil.forName("courseId").eq(courseId));
			
			try {
				
				return RegisterCourseLocalServiceUtil.dynamicQuery(dq);
				
			}catch(Exception e) {
				System.err.println(e.getMessage()); return null;
			}
		}
}
