package com.dylan.portlets.action.util;

import java.util.Date;
import java.util.List;

import javax.portlet.PortletException;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.Criterion;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.portlet.PortletClassLoaderUtil;
import com.portlets.action.model.Course;
import com.portlets.action.service.CourseLocalServiceUtil;

public class CourseActionUtil {

	@SuppressWarnings("unchecked")
	public static List<Course> getCourseByEduId(long eduId) 
			throws SystemException, PortletException {
		
		try {
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Course.class);
			dq.add(PropertyFactoryUtil.forName("educatorId").eq(eduId));
			
			return CourseLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			_log.info("loi dq");
			_log.error(e.getClass() + "\n" + e.getMessage());
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<Course> getCourseByEduId_State(long eduId, long state) 
			throws Exception {
		
		try {
			
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Course.class, PortletClassLoaderUtil.getClassLoader());
			dq.add(PropertyFactoryUtil.forName("educatorId").eq(eduId));
			dq.add(PropertyFactoryUtil.forName("statesId").eq(state));
			
			return CourseLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			_log.error(e);
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<Course> getCourseByStateId(long states) throws Exception {
		
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Course.class);
		dq.add(PropertyFactoryUtil.forName("statesId").eq(states));
		return CourseLocalServiceUtil.dynamicQuery(dq);
	}
	
	
	@SuppressWarnings({ "unchecked", "unused" })
	private static List<Course> getCourseThroughTrainIds(long[] trainIds) 
			throws Exception {
		
		List<Course> results = null;
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Course.class);
		try {
			for(int i=0; i<trainIds.length; i++) {
				dq.add(PropertyFactoryUtil.forName("trainingProgramId").eq(trainIds[i]));
				results = CourseLocalServiceUtil.dynamicQuery(dq);
				_log.info(results.get(i).getCourseName());
			}
			return results;
		}catch(Exception e) {
			_log.error(e);
			return null;
		}
	}
	
	public static Course addCourse(String name, int studentNo, Date registerStartDate, 
			Date registerEndDate, Date startCourseDate, String skillClassSchoolDayList, long trainProId, long userId, long stateId) 
			throws Exception {
		
		Course course = null;
		try {
			long id = CounterLocalServiceUtil.increment();
			course = CourseLocalServiceUtil.createCourse(id);
			
			course.setCourseName(name);
			course.setCourseStudentNo(studentNo);
			course.setCourseEnrollStartDate(registerStartDate);
			course.setCourseEnrollDeadLine(registerEndDate);
			course.setCourseStartDate(startCourseDate);
			course.setCourseSchoolDay(skillClassSchoolDayList);
			course.setTrainingProgramId(trainProId);
			course.setEducatorId(userId);
			course.setStatesId(stateId);
			
			course = CourseLocalServiceUtil.addCourse(course);
			
			return course;
		}catch(Exception e) {
			_log.error(e.getMessage());
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<Course> getCourseByProId(long proId) 
			throws SystemException, PortletException {
		
		try {
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Course.class);
			dq.add(PropertyFactoryUtil.forName("trainingProgramId").eq(proId));
			
			return CourseLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			_log.info("loi dq");
			_log.error(e.getClass() + "\n" + e.getMessage());
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<Course> getCourseByProId_StateId(long proId, long stateId) 
			throws SystemException, PortletException {
		
		try {
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Course.class, PortletClassLoaderUtil.getClassLoader());
			
			dq.add(PropertyFactoryUtil.forName("trainingProgramId").eq(proId));
			dq.add(PropertyFactoryUtil.forName("statesId").eq(stateId));
			
			return CourseLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			_log.info("loi dq");
			_log.error(e.getClass() + "\n" + e.getMessage());
			return null;
		}
	}
	
	private static Log _log = LogFactoryUtil.getLog(Course.class);
}
