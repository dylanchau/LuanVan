/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.portlets.action.service.persistence.LinkUsersPK;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.LinkUsersServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.LinkUsersServiceSoap
 * @generated
 */
public class LinkUsersSoap implements Serializable {
	public static LinkUsersSoap toSoapModel(LinkUsers model) {
		LinkUsersSoap soapModel = new LinkUsersSoap();

		soapModel.setUserIdA(model.getUserIdA());
		soapModel.setUserIdB(model.getUserIdB());
		soapModel.setLinkUsersNumber(model.getLinkUsersNumber());

		return soapModel;
	}

	public static LinkUsersSoap[] toSoapModels(LinkUsers[] models) {
		LinkUsersSoap[] soapModels = new LinkUsersSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static LinkUsersSoap[][] toSoapModels(LinkUsers[][] models) {
		LinkUsersSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new LinkUsersSoap[models.length][models[0].length];
		}
		else {
			soapModels = new LinkUsersSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static LinkUsersSoap[] toSoapModels(List<LinkUsers> models) {
		List<LinkUsersSoap> soapModels = new ArrayList<LinkUsersSoap>(models.size());

		for (LinkUsers model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new LinkUsersSoap[soapModels.size()]);
	}

	public LinkUsersSoap() {
	}

	public LinkUsersPK getPrimaryKey() {
		return new LinkUsersPK(_userIdA, _userIdB);
	}

	public void setPrimaryKey(LinkUsersPK pk) {
		setUserIdA(pk.userIdA);
		setUserIdB(pk.userIdB);
	}

	public long getUserIdA() {
		return _userIdA;
	}

	public void setUserIdA(long userIdA) {
		_userIdA = userIdA;
	}

	public long getUserIdB() {
		return _userIdB;
	}

	public void setUserIdB(long userIdB) {
		_userIdB = userIdB;
	}

	public int getLinkUsersNumber() {
		return _linkUsersNumber;
	}

	public void setLinkUsersNumber(int linkUsersNumber) {
		_linkUsersNumber = linkUsersNumber;
	}

	private long _userIdA;
	private long _userIdB;
	private int _linkUsersNumber;
}