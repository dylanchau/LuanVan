/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.LinkUserCourse;

import java.util.List;

/**
 * The persistence utility for the link user course service. This utility wraps {@link LinkUserCoursePersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see LinkUserCoursePersistence
 * @see LinkUserCoursePersistenceImpl
 * @generated
 */
public class LinkUserCourseUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(LinkUserCourse linkUserCourse) {
		getPersistence().clearCache(linkUserCourse);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<LinkUserCourse> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<LinkUserCourse> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<LinkUserCourse> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static LinkUserCourse update(LinkUserCourse linkUserCourse)
		throws SystemException {
		return getPersistence().update(linkUserCourse);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static LinkUserCourse update(LinkUserCourse linkUserCourse,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(linkUserCourse, serviceContext);
	}

	/**
	* Returns all the link user courses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findByuserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId);
	}

	/**
	* Returns a range of all the link user courses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @return the range of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findByuserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId, start, end);
	}

	/**
	* Returns an ordered range of all the link user courses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findByuserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserObjectId(userObjectId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first link user course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse findByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence()
				   .findByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the first link user course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user course, or <code>null</code> if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse fetchByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the last link user course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse findByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence()
				   .findByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the last link user course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user course, or <code>null</code> if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse fetchByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the link user courses before and after the current link user course in the ordered set where userObjectId = &#63;.
	*
	* @param linkUserCoursePK the primary key of the current link user course
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a link user course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse[] findByuserObjectId_PrevAndNext(
		com.portlets.action.service.persistence.LinkUserCoursePK linkUserCoursePK,
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence()
				   .findByuserObjectId_PrevAndNext(linkUserCoursePK,
			userObjectId, orderByComparator);
	}

	/**
	* Removes all the link user courses where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserObjectId(userObjectId);
	}

	/**
	* Returns the number of link user courses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserObjectId(userObjectId);
	}

	/**
	* Returns all the link user courses where courseId = &#63;.
	*
	* @param courseId the course ID
	* @return the matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findBycourseId(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycourseId(courseId);
	}

	/**
	* Returns a range of all the link user courses where courseId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param courseId the course ID
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @return the range of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findBycourseId(
		long courseId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycourseId(courseId, start, end);
	}

	/**
	* Returns an ordered range of all the link user courses where courseId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param courseId the course ID
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findBycourseId(
		long courseId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBycourseId(courseId, start, end, orderByComparator);
	}

	/**
	* Returns the first link user course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse findBycourseId_First(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence().findBycourseId_First(courseId, orderByComparator);
	}

	/**
	* Returns the first link user course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user course, or <code>null</code> if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse fetchBycourseId_First(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycourseId_First(courseId, orderByComparator);
	}

	/**
	* Returns the last link user course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse findBycourseId_Last(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence().findBycourseId_Last(courseId, orderByComparator);
	}

	/**
	* Returns the last link user course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user course, or <code>null</code> if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse fetchBycourseId_Last(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBycourseId_Last(courseId, orderByComparator);
	}

	/**
	* Returns the link user courses before and after the current link user course in the ordered set where courseId = &#63;.
	*
	* @param linkUserCoursePK the primary key of the current link user course
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a link user course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse[] findBycourseId_PrevAndNext(
		com.portlets.action.service.persistence.LinkUserCoursePK linkUserCoursePK,
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence()
				   .findBycourseId_PrevAndNext(linkUserCoursePK, courseId,
			orderByComparator);
	}

	/**
	* Removes all the link user courses where courseId = &#63; from the database.
	*
	* @param courseId the course ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBycourseId(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBycourseId(courseId);
	}

	/**
	* Returns the number of link user courses where courseId = &#63;.
	*
	* @param courseId the course ID
	* @return the number of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countBycourseId(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBycourseId(courseId);
	}

	/**
	* Returns all the link user courses where linkUserCourseNo = &#63;.
	*
	* @param linkUserCourseNo the link user course no
	* @return the matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findBylinkUserCourseNo(
		int linkUserCourseNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBylinkUserCourseNo(linkUserCourseNo);
	}

	/**
	* Returns a range of all the link user courses where linkUserCourseNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUserCourseNo the link user course no
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @return the range of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findBylinkUserCourseNo(
		int linkUserCourseNo, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylinkUserCourseNo(linkUserCourseNo, start, end);
	}

	/**
	* Returns an ordered range of all the link user courses where linkUserCourseNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUserCourseNo the link user course no
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findBylinkUserCourseNo(
		int linkUserCourseNo, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylinkUserCourseNo(linkUserCourseNo, start, end,
			orderByComparator);
	}

	/**
	* Returns the first link user course in the ordered set where linkUserCourseNo = &#63;.
	*
	* @param linkUserCourseNo the link user course no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse findBylinkUserCourseNo_First(
		int linkUserCourseNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence()
				   .findBylinkUserCourseNo_First(linkUserCourseNo,
			orderByComparator);
	}

	/**
	* Returns the first link user course in the ordered set where linkUserCourseNo = &#63;.
	*
	* @param linkUserCourseNo the link user course no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user course, or <code>null</code> if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse fetchBylinkUserCourseNo_First(
		int linkUserCourseNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylinkUserCourseNo_First(linkUserCourseNo,
			orderByComparator);
	}

	/**
	* Returns the last link user course in the ordered set where linkUserCourseNo = &#63;.
	*
	* @param linkUserCourseNo the link user course no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse findBylinkUserCourseNo_Last(
		int linkUserCourseNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence()
				   .findBylinkUserCourseNo_Last(linkUserCourseNo,
			orderByComparator);
	}

	/**
	* Returns the last link user course in the ordered set where linkUserCourseNo = &#63;.
	*
	* @param linkUserCourseNo the link user course no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user course, or <code>null</code> if a matching link user course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse fetchBylinkUserCourseNo_Last(
		int linkUserCourseNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylinkUserCourseNo_Last(linkUserCourseNo,
			orderByComparator);
	}

	/**
	* Returns the link user courses before and after the current link user course in the ordered set where linkUserCourseNo = &#63;.
	*
	* @param linkUserCoursePK the primary key of the current link user course
	* @param linkUserCourseNo the link user course no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a link user course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse[] findBylinkUserCourseNo_PrevAndNext(
		com.portlets.action.service.persistence.LinkUserCoursePK linkUserCoursePK,
		int linkUserCourseNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence()
				   .findBylinkUserCourseNo_PrevAndNext(linkUserCoursePK,
			linkUserCourseNo, orderByComparator);
	}

	/**
	* Removes all the link user courses where linkUserCourseNo = &#63; from the database.
	*
	* @param linkUserCourseNo the link user course no
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBylinkUserCourseNo(int linkUserCourseNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBylinkUserCourseNo(linkUserCourseNo);
	}

	/**
	* Returns the number of link user courses where linkUserCourseNo = &#63;.
	*
	* @param linkUserCourseNo the link user course no
	* @return the number of matching link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countBylinkUserCourseNo(int linkUserCourseNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBylinkUserCourseNo(linkUserCourseNo);
	}

	/**
	* Caches the link user course in the entity cache if it is enabled.
	*
	* @param linkUserCourse the link user course
	*/
	public static void cacheResult(
		com.portlets.action.model.LinkUserCourse linkUserCourse) {
		getPersistence().cacheResult(linkUserCourse);
	}

	/**
	* Caches the link user courses in the entity cache if it is enabled.
	*
	* @param linkUserCourses the link user courses
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.LinkUserCourse> linkUserCourses) {
		getPersistence().cacheResult(linkUserCourses);
	}

	/**
	* Creates a new link user course with the primary key. Does not add the link user course to the database.
	*
	* @param linkUserCoursePK the primary key for the new link user course
	* @return the new link user course
	*/
	public static com.portlets.action.model.LinkUserCourse create(
		com.portlets.action.service.persistence.LinkUserCoursePK linkUserCoursePK) {
		return getPersistence().create(linkUserCoursePK);
	}

	/**
	* Removes the link user course with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param linkUserCoursePK the primary key of the link user course
	* @return the link user course that was removed
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a link user course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse remove(
		com.portlets.action.service.persistence.LinkUserCoursePK linkUserCoursePK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence().remove(linkUserCoursePK);
	}

	public static com.portlets.action.model.LinkUserCourse updateImpl(
		com.portlets.action.model.LinkUserCourse linkUserCourse)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(linkUserCourse);
	}

	/**
	* Returns the link user course with the primary key or throws a {@link com.portlets.action.NoSuchLinkUserCourseException} if it could not be found.
	*
	* @param linkUserCoursePK the primary key of the link user course
	* @return the link user course
	* @throws com.portlets.action.NoSuchLinkUserCourseException if a link user course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse findByPrimaryKey(
		com.portlets.action.service.persistence.LinkUserCoursePK linkUserCoursePK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserCourseException {
		return getPersistence().findByPrimaryKey(linkUserCoursePK);
	}

	/**
	* Returns the link user course with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param linkUserCoursePK the primary key of the link user course
	* @return the link user course, or <code>null</code> if a link user course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserCourse fetchByPrimaryKey(
		com.portlets.action.service.persistence.LinkUserCoursePK linkUserCoursePK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(linkUserCoursePK);
	}

	/**
	* Returns all the link user courses.
	*
	* @return the link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the link user courses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @return the range of link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the link user courses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link user courses
	* @param end the upper bound of the range of link user courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserCourse> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the link user courses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of link user courses.
	*
	* @return the number of link user courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static LinkUserCoursePersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (LinkUserCoursePersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					LinkUserCoursePersistence.class.getName());

			ReferenceRegistry.registerReference(LinkUserCourseUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(LinkUserCoursePersistence persistence) {
	}

	private static LinkUserCoursePersistence _persistence;
}