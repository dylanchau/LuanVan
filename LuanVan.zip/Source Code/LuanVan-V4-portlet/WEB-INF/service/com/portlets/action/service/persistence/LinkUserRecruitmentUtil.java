/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.LinkUserRecruitment;

import java.util.List;

/**
 * The persistence utility for the link user recruitment service. This utility wraps {@link LinkUserRecruitmentPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see LinkUserRecruitmentPersistence
 * @see LinkUserRecruitmentPersistenceImpl
 * @generated
 */
public class LinkUserRecruitmentUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(LinkUserRecruitment linkUserRecruitment) {
		getPersistence().clearCache(linkUserRecruitment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<LinkUserRecruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<LinkUserRecruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<LinkUserRecruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static LinkUserRecruitment update(
		LinkUserRecruitment linkUserRecruitment) throws SystemException {
		return getPersistence().update(linkUserRecruitment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static LinkUserRecruitment update(
		LinkUserRecruitment linkUserRecruitment, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(linkUserRecruitment, serviceContext);
	}

	/**
	* Returns all the link user recruitments where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findByuserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId);
	}

	/**
	* Returns a range of all the link user recruitments where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @return the range of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findByuserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId, start, end);
	}

	/**
	* Returns an ordered range of all the link user recruitments where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findByuserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserObjectId(userObjectId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first link user recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment findByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the first link user recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user recruitment, or <code>null</code> if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment fetchByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the last link user recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment findByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the last link user recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user recruitment, or <code>null</code> if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment fetchByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the link user recruitments before and after the current link user recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param linkUserRecruitmentPK the primary key of the current link user recruitment
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment[] findByuserObjectId_PrevAndNext(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK,
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findByuserObjectId_PrevAndNext(linkUserRecruitmentPK,
			userObjectId, orderByComparator);
	}

	/**
	* Removes all the link user recruitments where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserObjectId(userObjectId);
	}

	/**
	* Returns the number of link user recruitments where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserObjectId(userObjectId);
	}

	/**
	* Returns all the link user recruitments where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @return the matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findByrecuitmentId(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByrecuitmentId(recruitmentId);
	}

	/**
	* Returns a range of all the link user recruitments where recruitmentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param recruitmentId the recruitment ID
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @return the range of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findByrecuitmentId(
		long recruitmentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByrecuitmentId(recruitmentId, start, end);
	}

	/**
	* Returns an ordered range of all the link user recruitments where recruitmentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param recruitmentId the recruitment ID
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findByrecuitmentId(
		long recruitmentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByrecuitmentId(recruitmentId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first link user recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment findByrecuitmentId_First(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findByrecuitmentId_First(recruitmentId, orderByComparator);
	}

	/**
	* Returns the first link user recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user recruitment, or <code>null</code> if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment fetchByrecuitmentId_First(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByrecuitmentId_First(recruitmentId, orderByComparator);
	}

	/**
	* Returns the last link user recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment findByrecuitmentId_Last(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findByrecuitmentId_Last(recruitmentId, orderByComparator);
	}

	/**
	* Returns the last link user recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user recruitment, or <code>null</code> if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment fetchByrecuitmentId_Last(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByrecuitmentId_Last(recruitmentId, orderByComparator);
	}

	/**
	* Returns the link user recruitments before and after the current link user recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param linkUserRecruitmentPK the primary key of the current link user recruitment
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment[] findByrecuitmentId_PrevAndNext(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK,
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findByrecuitmentId_PrevAndNext(linkUserRecruitmentPK,
			recruitmentId, orderByComparator);
	}

	/**
	* Removes all the link user recruitments where recruitmentId = &#63; from the database.
	*
	* @param recruitmentId the recruitment ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByrecuitmentId(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByrecuitmentId(recruitmentId);
	}

	/**
	* Returns the number of link user recruitments where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @return the number of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByrecuitmentId(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByrecuitmentId(recruitmentId);
	}

	/**
	* Returns all the link user recruitments where linkUserRecruitmentNo = &#63;.
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @return the matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findBylinkUserRecuitmentNo(
		int linkUserRecruitmentNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBylinkUserRecuitmentNo(linkUserRecruitmentNo);
	}

	/**
	* Returns a range of all the link user recruitments where linkUserRecruitmentNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @return the range of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findBylinkUserRecuitmentNo(
		int linkUserRecruitmentNo, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylinkUserRecuitmentNo(linkUserRecruitmentNo, start, end);
	}

	/**
	* Returns an ordered range of all the link user recruitments where linkUserRecruitmentNo = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findBylinkUserRecuitmentNo(
		int linkUserRecruitmentNo, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylinkUserRecuitmentNo(linkUserRecruitmentNo, start,
			end, orderByComparator);
	}

	/**
	* Returns the first link user recruitment in the ordered set where linkUserRecruitmentNo = &#63;.
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment findBylinkUserRecuitmentNo_First(
		int linkUserRecruitmentNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findBylinkUserRecuitmentNo_First(linkUserRecruitmentNo,
			orderByComparator);
	}

	/**
	* Returns the first link user recruitment in the ordered set where linkUserRecruitmentNo = &#63;.
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link user recruitment, or <code>null</code> if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment fetchBylinkUserRecuitmentNo_First(
		int linkUserRecruitmentNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylinkUserRecuitmentNo_First(linkUserRecruitmentNo,
			orderByComparator);
	}

	/**
	* Returns the last link user recruitment in the ordered set where linkUserRecruitmentNo = &#63;.
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment findBylinkUserRecuitmentNo_Last(
		int linkUserRecruitmentNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findBylinkUserRecuitmentNo_Last(linkUserRecruitmentNo,
			orderByComparator);
	}

	/**
	* Returns the last link user recruitment in the ordered set where linkUserRecruitmentNo = &#63;.
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link user recruitment, or <code>null</code> if a matching link user recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment fetchBylinkUserRecuitmentNo_Last(
		int linkUserRecruitmentNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylinkUserRecuitmentNo_Last(linkUserRecruitmentNo,
			orderByComparator);
	}

	/**
	* Returns the link user recruitments before and after the current link user recruitment in the ordered set where linkUserRecruitmentNo = &#63;.
	*
	* @param linkUserRecruitmentPK the primary key of the current link user recruitment
	* @param linkUserRecruitmentNo the link user recruitment no
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment[] findBylinkUserRecuitmentNo_PrevAndNext(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK,
		int linkUserRecruitmentNo,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence()
				   .findBylinkUserRecuitmentNo_PrevAndNext(linkUserRecruitmentPK,
			linkUserRecruitmentNo, orderByComparator);
	}

	/**
	* Removes all the link user recruitments where linkUserRecruitmentNo = &#63; from the database.
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBylinkUserRecuitmentNo(int linkUserRecruitmentNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBylinkUserRecuitmentNo(linkUserRecruitmentNo);
	}

	/**
	* Returns the number of link user recruitments where linkUserRecruitmentNo = &#63;.
	*
	* @param linkUserRecruitmentNo the link user recruitment no
	* @return the number of matching link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countBylinkUserRecuitmentNo(int linkUserRecruitmentNo)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countBylinkUserRecuitmentNo(linkUserRecruitmentNo);
	}

	/**
	* Caches the link user recruitment in the entity cache if it is enabled.
	*
	* @param linkUserRecruitment the link user recruitment
	*/
	public static void cacheResult(
		com.portlets.action.model.LinkUserRecruitment linkUserRecruitment) {
		getPersistence().cacheResult(linkUserRecruitment);
	}

	/**
	* Caches the link user recruitments in the entity cache if it is enabled.
	*
	* @param linkUserRecruitments the link user recruitments
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.LinkUserRecruitment> linkUserRecruitments) {
		getPersistence().cacheResult(linkUserRecruitments);
	}

	/**
	* Creates a new link user recruitment with the primary key. Does not add the link user recruitment to the database.
	*
	* @param linkUserRecruitmentPK the primary key for the new link user recruitment
	* @return the new link user recruitment
	*/
	public static com.portlets.action.model.LinkUserRecruitment create(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK) {
		return getPersistence().create(linkUserRecruitmentPK);
	}

	/**
	* Removes the link user recruitment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param linkUserRecruitmentPK the primary key of the link user recruitment
	* @return the link user recruitment that was removed
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment remove(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence().remove(linkUserRecruitmentPK);
	}

	public static com.portlets.action.model.LinkUserRecruitment updateImpl(
		com.portlets.action.model.LinkUserRecruitment linkUserRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(linkUserRecruitment);
	}

	/**
	* Returns the link user recruitment with the primary key or throws a {@link com.portlets.action.NoSuchLinkUserRecruitmentException} if it could not be found.
	*
	* @param linkUserRecruitmentPK the primary key of the link user recruitment
	* @return the link user recruitment
	* @throws com.portlets.action.NoSuchLinkUserRecruitmentException if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment findByPrimaryKey(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUserRecruitmentException {
		return getPersistence().findByPrimaryKey(linkUserRecruitmentPK);
	}

	/**
	* Returns the link user recruitment with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param linkUserRecruitmentPK the primary key of the link user recruitment
	* @return the link user recruitment, or <code>null</code> if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.LinkUserRecruitment fetchByPrimaryKey(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(linkUserRecruitmentPK);
	}

	/**
	* Returns all the link user recruitments.
	*
	* @return the link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the link user recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @return the range of link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the link user recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.LinkUserRecruitment> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the link user recruitments from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of link user recruitments.
	*
	* @return the number of link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static LinkUserRecruitmentPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (LinkUserRecruitmentPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					LinkUserRecruitmentPersistence.class.getName());

			ReferenceRegistry.registerReference(LinkUserRecruitmentUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(LinkUserRecruitmentPersistence persistence) {
	}

	private static LinkUserRecruitmentPersistence _persistence;
}