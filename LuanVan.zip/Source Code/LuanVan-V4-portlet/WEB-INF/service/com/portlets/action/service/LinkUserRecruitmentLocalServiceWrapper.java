/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link LinkUserRecruitmentLocalService}.
 *
 * @author Computer
 * @see LinkUserRecruitmentLocalService
 * @generated
 */
public class LinkUserRecruitmentLocalServiceWrapper
	implements LinkUserRecruitmentLocalService,
		ServiceWrapper<LinkUserRecruitmentLocalService> {
	public LinkUserRecruitmentLocalServiceWrapper(
		LinkUserRecruitmentLocalService linkUserRecruitmentLocalService) {
		_linkUserRecruitmentLocalService = linkUserRecruitmentLocalService;
	}

	/**
	* Adds the link user recruitment to the database. Also notifies the appropriate model listeners.
	*
	* @param linkUserRecruitment the link user recruitment
	* @return the link user recruitment that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.LinkUserRecruitment addLinkUserRecruitment(
		com.portlets.action.model.LinkUserRecruitment linkUserRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.addLinkUserRecruitment(linkUserRecruitment);
	}

	/**
	* Creates a new link user recruitment with the primary key. Does not add the link user recruitment to the database.
	*
	* @param linkUserRecruitmentPK the primary key for the new link user recruitment
	* @return the new link user recruitment
	*/
	@Override
	public com.portlets.action.model.LinkUserRecruitment createLinkUserRecruitment(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK) {
		return _linkUserRecruitmentLocalService.createLinkUserRecruitment(linkUserRecruitmentPK);
	}

	/**
	* Deletes the link user recruitment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param linkUserRecruitmentPK the primary key of the link user recruitment
	* @return the link user recruitment that was removed
	* @throws PortalException if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.LinkUserRecruitment deleteLinkUserRecruitment(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.deleteLinkUserRecruitment(linkUserRecruitmentPK);
	}

	/**
	* Deletes the link user recruitment from the database. Also notifies the appropriate model listeners.
	*
	* @param linkUserRecruitment the link user recruitment
	* @return the link user recruitment that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.LinkUserRecruitment deleteLinkUserRecruitment(
		com.portlets.action.model.LinkUserRecruitment linkUserRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.deleteLinkUserRecruitment(linkUserRecruitment);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _linkUserRecruitmentLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.dynamicQuery(dynamicQuery,
			start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.dynamicQuery(dynamicQuery,
			start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.portlets.action.model.LinkUserRecruitment fetchLinkUserRecruitment(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.fetchLinkUserRecruitment(linkUserRecruitmentPK);
	}

	/**
	* Returns the link user recruitment with the primary key.
	*
	* @param linkUserRecruitmentPK the primary key of the link user recruitment
	* @return the link user recruitment
	* @throws PortalException if a link user recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.LinkUserRecruitment getLinkUserRecruitment(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK linkUserRecruitmentPK)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.getLinkUserRecruitment(linkUserRecruitmentPK);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the link user recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUserRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link user recruitments
	* @param end the upper bound of the range of link user recruitments (not inclusive)
	* @return the range of link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.LinkUserRecruitment> getLinkUserRecruitments(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.getLinkUserRecruitments(start,
			end);
	}

	/**
	* Returns the number of link user recruitments.
	*
	* @return the number of link user recruitments
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getLinkUserRecruitmentsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.getLinkUserRecruitmentsCount();
	}

	/**
	* Updates the link user recruitment in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param linkUserRecruitment the link user recruitment
	* @return the link user recruitment that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.LinkUserRecruitment updateLinkUserRecruitment(
		com.portlets.action.model.LinkUserRecruitment linkUserRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.updateLinkUserRecruitment(linkUserRecruitment);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _linkUserRecruitmentLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_linkUserRecruitmentLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _linkUserRecruitmentLocalService.invokeMethod(name,
			parameterTypes, arguments);
	}

	@Override
	public java.util.List<com.portlets.action.model.LinkUserRecruitment> getByUserId(
		java.lang.Long userId) {
		return _linkUserRecruitmentLocalService.getByUserId(userId);
	}

	@Override
	public java.util.List<com.portlets.action.model.LinkUserRecruitment> getLinkUserRecruitmentByRecruitmentId(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _linkUserRecruitmentLocalService.getLinkUserRecruitmentByRecruitmentId(recruitmentId);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public LinkUserRecruitmentLocalService getWrappedLinkUserRecruitmentLocalService() {
		return _linkUserRecruitmentLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedLinkUserRecruitmentLocalService(
		LinkUserRecruitmentLocalService linkUserRecruitmentLocalService) {
		_linkUserRecruitmentLocalService = linkUserRecruitmentLocalService;
	}

	@Override
	public LinkUserRecruitmentLocalService getWrappedService() {
		return _linkUserRecruitmentLocalService;
	}

	@Override
	public void setWrappedService(
		LinkUserRecruitmentLocalService linkUserRecruitmentLocalService) {
		_linkUserRecruitmentLocalService = linkUserRecruitmentLocalService;
	}

	private LinkUserRecruitmentLocalService _linkUserRecruitmentLocalService;
}