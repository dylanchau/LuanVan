/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.Recruitment;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Recruitment in entity cache.
 *
 * @author Computer
 * @see Recruitment
 * @generated
 */
public class RecruitmentCacheModel implements CacheModel<Recruitment>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(37);

		sb.append("{recruitmentId=");
		sb.append(recruitmentId);
		sb.append(", recruitmentName=");
		sb.append(recruitmentName);
		sb.append(", recruitmentPosition=");
		sb.append(recruitmentPosition);
		sb.append(", recruitmentDescription=");
		sb.append(recruitmentDescription);
		sb.append(", recruitmentBenefit=");
		sb.append(recruitmentBenefit);
		sb.append(", recruitmentJobType=");
		sb.append(recruitmentJobType);
		sb.append(", recruitmentFileReq=");
		sb.append(recruitmentFileReq);
		sb.append(", recruitmentFileDeadlineFrom=");
		sb.append(recruitmentFileDeadlineFrom);
		sb.append(", recruitmentFileDeadlineTo=");
		sb.append(recruitmentFileDeadlineTo);
		sb.append(", recruitmentSalary=");
		sb.append(recruitmentSalary);
		sb.append(", recruitmentNo=");
		sb.append(recruitmentNo);
		sb.append(", recruitmentGender=");
		sb.append(recruitmentGender);
		sb.append(", recruitmentQualification=");
		sb.append(recruitmentQualification);
		sb.append(", recruitmentAgeFrom=");
		sb.append(recruitmentAgeFrom);
		sb.append(", recruitmentAgeTo=");
		sb.append(recruitmentAgeTo);
		sb.append(", recruitmentExper=");
		sb.append(recruitmentExper);
		sb.append(", employerId=");
		sb.append(employerId);
		sb.append(", statesId=");
		sb.append(statesId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Recruitment toEntityModel() {
		RecruitmentImpl recruitmentImpl = new RecruitmentImpl();

		recruitmentImpl.setRecruitmentId(recruitmentId);

		if (recruitmentName == null) {
			recruitmentImpl.setRecruitmentName(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentName(recruitmentName);
		}

		if (recruitmentPosition == null) {
			recruitmentImpl.setRecruitmentPosition(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentPosition(recruitmentPosition);
		}

		if (recruitmentDescription == null) {
			recruitmentImpl.setRecruitmentDescription(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentDescription(recruitmentDescription);
		}

		if (recruitmentBenefit == null) {
			recruitmentImpl.setRecruitmentBenefit(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentBenefit(recruitmentBenefit);
		}

		if (recruitmentJobType == null) {
			recruitmentImpl.setRecruitmentJobType(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentJobType(recruitmentJobType);
		}

		if (recruitmentFileReq == null) {
			recruitmentImpl.setRecruitmentFileReq(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentFileReq(recruitmentFileReq);
		}

		if (recruitmentFileDeadlineFrom == Long.MIN_VALUE) {
			recruitmentImpl.setRecruitmentFileDeadlineFrom(null);
		}
		else {
			recruitmentImpl.setRecruitmentFileDeadlineFrom(new Date(
					recruitmentFileDeadlineFrom));
		}

		if (recruitmentFileDeadlineTo == Long.MIN_VALUE) {
			recruitmentImpl.setRecruitmentFileDeadlineTo(null);
		}
		else {
			recruitmentImpl.setRecruitmentFileDeadlineTo(new Date(
					recruitmentFileDeadlineTo));
		}

		if (recruitmentSalary == null) {
			recruitmentImpl.setRecruitmentSalary(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentSalary(recruitmentSalary);
		}

		recruitmentImpl.setRecruitmentNo(recruitmentNo);

		if (recruitmentGender == null) {
			recruitmentImpl.setRecruitmentGender(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentGender(recruitmentGender);
		}

		if (recruitmentQualification == null) {
			recruitmentImpl.setRecruitmentQualification(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentQualification(recruitmentQualification);
		}

		recruitmentImpl.setRecruitmentAgeFrom(recruitmentAgeFrom);
		recruitmentImpl.setRecruitmentAgeTo(recruitmentAgeTo);

		if (recruitmentExper == null) {
			recruitmentImpl.setRecruitmentExper(StringPool.BLANK);
		}
		else {
			recruitmentImpl.setRecruitmentExper(recruitmentExper);
		}

		recruitmentImpl.setEmployerId(employerId);
		recruitmentImpl.setStatesId(statesId);

		recruitmentImpl.resetOriginalValues();

		return recruitmentImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		recruitmentId = objectInput.readLong();
		recruitmentName = objectInput.readUTF();
		recruitmentPosition = objectInput.readUTF();
		recruitmentDescription = objectInput.readUTF();
		recruitmentBenefit = objectInput.readUTF();
		recruitmentJobType = objectInput.readUTF();
		recruitmentFileReq = objectInput.readUTF();
		recruitmentFileDeadlineFrom = objectInput.readLong();
		recruitmentFileDeadlineTo = objectInput.readLong();
		recruitmentSalary = objectInput.readUTF();
		recruitmentNo = objectInput.readInt();
		recruitmentGender = objectInput.readUTF();
		recruitmentQualification = objectInput.readUTF();
		recruitmentAgeFrom = objectInput.readInt();
		recruitmentAgeTo = objectInput.readInt();
		recruitmentExper = objectInput.readUTF();
		employerId = objectInput.readLong();
		statesId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(recruitmentId);

		if (recruitmentName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentName);
		}

		if (recruitmentPosition == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentPosition);
		}

		if (recruitmentDescription == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentDescription);
		}

		if (recruitmentBenefit == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentBenefit);
		}

		if (recruitmentJobType == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentJobType);
		}

		if (recruitmentFileReq == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentFileReq);
		}

		objectOutput.writeLong(recruitmentFileDeadlineFrom);
		objectOutput.writeLong(recruitmentFileDeadlineTo);

		if (recruitmentSalary == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentSalary);
		}

		objectOutput.writeInt(recruitmentNo);

		if (recruitmentGender == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentGender);
		}

		if (recruitmentQualification == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentQualification);
		}

		objectOutput.writeInt(recruitmentAgeFrom);
		objectOutput.writeInt(recruitmentAgeTo);

		if (recruitmentExper == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(recruitmentExper);
		}

		objectOutput.writeLong(employerId);
		objectOutput.writeLong(statesId);
	}

	public long recruitmentId;
	public String recruitmentName;
	public String recruitmentPosition;
	public String recruitmentDescription;
	public String recruitmentBenefit;
	public String recruitmentJobType;
	public String recruitmentFileReq;
	public long recruitmentFileDeadlineFrom;
	public long recruitmentFileDeadlineTo;
	public String recruitmentSalary;
	public int recruitmentNo;
	public String recruitmentGender;
	public String recruitmentQualification;
	public int recruitmentAgeFrom;
	public int recruitmentAgeTo;
	public String recruitmentExper;
	public long employerId;
	public long statesId;
}