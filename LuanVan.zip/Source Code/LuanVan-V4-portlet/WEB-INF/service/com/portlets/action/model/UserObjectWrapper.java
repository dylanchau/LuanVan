/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link UserObject}.
 * </p>
 *
 * @author Computer
 * @see UserObject
 * @generated
 */
public class UserObjectWrapper implements UserObject, ModelWrapper<UserObject> {
	public UserObjectWrapper(UserObject userObject) {
		_userObject = userObject;
	}

	@Override
	public Class<?> getModelClass() {
		return UserObject.class;
	}

	@Override
	public String getModelClassName() {
		return UserObject.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userObjectId", getUserObjectId());
		attributes.put("userObjectName", getUserObjectName());
		attributes.put("userObjectGender", getUserObjectGender());
		attributes.put("userObjectAddress", getUserObjectAddress());
		attributes.put("userObjectBirthday", getUserObjectBirthday());
		attributes.put("userObjectEmail", getUserObjectEmail());
		attributes.put("userObjectPhone", getUserObjectPhone());
		attributes.put("userObjectIntroduce", getUserObjectIntroduce());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		String userObjectName = (String)attributes.get("userObjectName");

		if (userObjectName != null) {
			setUserObjectName(userObjectName);
		}

		Boolean userObjectGender = (Boolean)attributes.get("userObjectGender");

		if (userObjectGender != null) {
			setUserObjectGender(userObjectGender);
		}

		String userObjectAddress = (String)attributes.get("userObjectAddress");

		if (userObjectAddress != null) {
			setUserObjectAddress(userObjectAddress);
		}

		Date userObjectBirthday = (Date)attributes.get("userObjectBirthday");

		if (userObjectBirthday != null) {
			setUserObjectBirthday(userObjectBirthday);
		}

		String userObjectEmail = (String)attributes.get("userObjectEmail");

		if (userObjectEmail != null) {
			setUserObjectEmail(userObjectEmail);
		}

		String userObjectPhone = (String)attributes.get("userObjectPhone");

		if (userObjectPhone != null) {
			setUserObjectPhone(userObjectPhone);
		}

		String userObjectIntroduce = (String)attributes.get(
				"userObjectIntroduce");

		if (userObjectIntroduce != null) {
			setUserObjectIntroduce(userObjectIntroduce);
		}
	}

	/**
	* Returns the primary key of this user object.
	*
	* @return the primary key of this user object
	*/
	@Override
	public long getPrimaryKey() {
		return _userObject.getPrimaryKey();
	}

	/**
	* Sets the primary key of this user object.
	*
	* @param primaryKey the primary key of this user object
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_userObject.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the user object ID of this user object.
	*
	* @return the user object ID of this user object
	*/
	@Override
	public long getUserObjectId() {
		return _userObject.getUserObjectId();
	}

	/**
	* Sets the user object ID of this user object.
	*
	* @param userObjectId the user object ID of this user object
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_userObject.setUserObjectId(userObjectId);
	}

	/**
	* Returns the user object name of this user object.
	*
	* @return the user object name of this user object
	*/
	@Override
	public java.lang.String getUserObjectName() {
		return _userObject.getUserObjectName();
	}

	/**
	* Sets the user object name of this user object.
	*
	* @param userObjectName the user object name of this user object
	*/
	@Override
	public void setUserObjectName(java.lang.String userObjectName) {
		_userObject.setUserObjectName(userObjectName);
	}

	/**
	* Returns the user object gender of this user object.
	*
	* @return the user object gender of this user object
	*/
	@Override
	public boolean getUserObjectGender() {
		return _userObject.getUserObjectGender();
	}

	/**
	* Returns <code>true</code> if this user object is user object gender.
	*
	* @return <code>true</code> if this user object is user object gender; <code>false</code> otherwise
	*/
	@Override
	public boolean isUserObjectGender() {
		return _userObject.isUserObjectGender();
	}

	/**
	* Sets whether this user object is user object gender.
	*
	* @param userObjectGender the user object gender of this user object
	*/
	@Override
	public void setUserObjectGender(boolean userObjectGender) {
		_userObject.setUserObjectGender(userObjectGender);
	}

	/**
	* Returns the user object address of this user object.
	*
	* @return the user object address of this user object
	*/
	@Override
	public java.lang.String getUserObjectAddress() {
		return _userObject.getUserObjectAddress();
	}

	/**
	* Sets the user object address of this user object.
	*
	* @param userObjectAddress the user object address of this user object
	*/
	@Override
	public void setUserObjectAddress(java.lang.String userObjectAddress) {
		_userObject.setUserObjectAddress(userObjectAddress);
	}

	/**
	* Returns the user object birthday of this user object.
	*
	* @return the user object birthday of this user object
	*/
	@Override
	public java.util.Date getUserObjectBirthday() {
		return _userObject.getUserObjectBirthday();
	}

	/**
	* Sets the user object birthday of this user object.
	*
	* @param userObjectBirthday the user object birthday of this user object
	*/
	@Override
	public void setUserObjectBirthday(java.util.Date userObjectBirthday) {
		_userObject.setUserObjectBirthday(userObjectBirthday);
	}

	/**
	* Returns the user object email of this user object.
	*
	* @return the user object email of this user object
	*/
	@Override
	public java.lang.String getUserObjectEmail() {
		return _userObject.getUserObjectEmail();
	}

	/**
	* Sets the user object email of this user object.
	*
	* @param userObjectEmail the user object email of this user object
	*/
	@Override
	public void setUserObjectEmail(java.lang.String userObjectEmail) {
		_userObject.setUserObjectEmail(userObjectEmail);
	}

	/**
	* Returns the user object phone of this user object.
	*
	* @return the user object phone of this user object
	*/
	@Override
	public java.lang.String getUserObjectPhone() {
		return _userObject.getUserObjectPhone();
	}

	/**
	* Sets the user object phone of this user object.
	*
	* @param userObjectPhone the user object phone of this user object
	*/
	@Override
	public void setUserObjectPhone(java.lang.String userObjectPhone) {
		_userObject.setUserObjectPhone(userObjectPhone);
	}

	/**
	* Returns the user object introduce of this user object.
	*
	* @return the user object introduce of this user object
	*/
	@Override
	public java.lang.String getUserObjectIntroduce() {
		return _userObject.getUserObjectIntroduce();
	}

	/**
	* Sets the user object introduce of this user object.
	*
	* @param userObjectIntroduce the user object introduce of this user object
	*/
	@Override
	public void setUserObjectIntroduce(java.lang.String userObjectIntroduce) {
		_userObject.setUserObjectIntroduce(userObjectIntroduce);
	}

	@Override
	public boolean isNew() {
		return _userObject.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_userObject.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _userObject.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_userObject.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _userObject.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _userObject.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_userObject.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _userObject.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_userObject.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_userObject.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_userObject.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new UserObjectWrapper((UserObject)_userObject.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.UserObject userObject) {
		return _userObject.compareTo(userObject);
	}

	@Override
	public int hashCode() {
		return _userObject.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.UserObject> toCacheModel() {
		return _userObject.toCacheModel();
	}

	@Override
	public com.portlets.action.model.UserObject toEscapedModel() {
		return new UserObjectWrapper(_userObject.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.UserObject toUnescapedModel() {
		return new UserObjectWrapper(_userObject.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _userObject.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _userObject.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_userObject.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserObjectWrapper)) {
			return false;
		}

		UserObjectWrapper userObjectWrapper = (UserObjectWrapper)obj;

		if (Validator.equals(_userObject, userObjectWrapper._userObject)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public UserObject getWrappedUserObject() {
		return _userObject;
	}

	@Override
	public UserObject getWrappedModel() {
		return _userObject;
	}

	@Override
	public void resetOriginalValues() {
		_userObject.resetOriginalValues();
	}

	private UserObject _userObject;
}