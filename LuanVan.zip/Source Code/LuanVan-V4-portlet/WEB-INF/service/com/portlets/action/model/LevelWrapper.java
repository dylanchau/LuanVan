/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Level}.
 * </p>
 *
 * @author Computer
 * @see Level
 * @generated
 */
public class LevelWrapper implements Level, ModelWrapper<Level> {
	public LevelWrapper(Level level) {
		_level = level;
	}

	@Override
	public Class<?> getModelClass() {
		return Level.class;
	}

	@Override
	public String getModelClassName() {
		return Level.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("levelId", getLevelId());
		attributes.put("levelName", getLevelName());
		attributes.put("levelExplain", getLevelExplain());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long levelId = (Long)attributes.get("levelId");

		if (levelId != null) {
			setLevelId(levelId);
		}

		String levelName = (String)attributes.get("levelName");

		if (levelName != null) {
			setLevelName(levelName);
		}

		String levelExplain = (String)attributes.get("levelExplain");

		if (levelExplain != null) {
			setLevelExplain(levelExplain);
		}
	}

	/**
	* Returns the primary key of this level.
	*
	* @return the primary key of this level
	*/
	@Override
	public long getPrimaryKey() {
		return _level.getPrimaryKey();
	}

	/**
	* Sets the primary key of this level.
	*
	* @param primaryKey the primary key of this level
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_level.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the level ID of this level.
	*
	* @return the level ID of this level
	*/
	@Override
	public long getLevelId() {
		return _level.getLevelId();
	}

	/**
	* Sets the level ID of this level.
	*
	* @param levelId the level ID of this level
	*/
	@Override
	public void setLevelId(long levelId) {
		_level.setLevelId(levelId);
	}

	/**
	* Returns the level name of this level.
	*
	* @return the level name of this level
	*/
	@Override
	public java.lang.String getLevelName() {
		return _level.getLevelName();
	}

	/**
	* Sets the level name of this level.
	*
	* @param levelName the level name of this level
	*/
	@Override
	public void setLevelName(java.lang.String levelName) {
		_level.setLevelName(levelName);
	}

	/**
	* Returns the level explain of this level.
	*
	* @return the level explain of this level
	*/
	@Override
	public java.lang.String getLevelExplain() {
		return _level.getLevelExplain();
	}

	/**
	* Sets the level explain of this level.
	*
	* @param levelExplain the level explain of this level
	*/
	@Override
	public void setLevelExplain(java.lang.String levelExplain) {
		_level.setLevelExplain(levelExplain);
	}

	@Override
	public boolean isNew() {
		return _level.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_level.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _level.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_level.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _level.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _level.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_level.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _level.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_level.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_level.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_level.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new LevelWrapper((Level)_level.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.Level level) {
		return _level.compareTo(level);
	}

	@Override
	public int hashCode() {
		return _level.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.Level> toCacheModel() {
		return _level.toCacheModel();
	}

	@Override
	public com.portlets.action.model.Level toEscapedModel() {
		return new LevelWrapper(_level.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.Level toUnescapedModel() {
		return new LevelWrapper(_level.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _level.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _level.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_level.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LevelWrapper)) {
			return false;
		}

		LevelWrapper levelWrapper = (LevelWrapper)obj;

		if (Validator.equals(_level, levelWrapper._level)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Level getWrappedLevel() {
		return _level;
	}

	@Override
	public Level getWrappedModel() {
		return _level;
	}

	@Override
	public void resetOriginalValues() {
		_level.resetOriginalValues();
	}

	private Level _level;
}