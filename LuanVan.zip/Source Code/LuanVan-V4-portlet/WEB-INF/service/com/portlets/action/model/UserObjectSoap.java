/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.UserObjectServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.UserObjectServiceSoap
 * @generated
 */
public class UserObjectSoap implements Serializable {
	public static UserObjectSoap toSoapModel(UserObject model) {
		UserObjectSoap soapModel = new UserObjectSoap();

		soapModel.setUserObjectId(model.getUserObjectId());
		soapModel.setUserObjectName(model.getUserObjectName());
		soapModel.setUserObjectGender(model.getUserObjectGender());
		soapModel.setUserObjectAddress(model.getUserObjectAddress());
		soapModel.setUserObjectBirthday(model.getUserObjectBirthday());
		soapModel.setUserObjectEmail(model.getUserObjectEmail());
		soapModel.setUserObjectPhone(model.getUserObjectPhone());
		soapModel.setUserObjectIntroduce(model.getUserObjectIntroduce());

		return soapModel;
	}

	public static UserObjectSoap[] toSoapModels(UserObject[] models) {
		UserObjectSoap[] soapModels = new UserObjectSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static UserObjectSoap[][] toSoapModels(UserObject[][] models) {
		UserObjectSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new UserObjectSoap[models.length][models[0].length];
		}
		else {
			soapModels = new UserObjectSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static UserObjectSoap[] toSoapModels(List<UserObject> models) {
		List<UserObjectSoap> soapModels = new ArrayList<UserObjectSoap>(models.size());

		for (UserObject model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new UserObjectSoap[soapModels.size()]);
	}

	public UserObjectSoap() {
	}

	public long getPrimaryKey() {
		return _userObjectId;
	}

	public void setPrimaryKey(long pk) {
		setUserObjectId(pk);
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	public String getUserObjectName() {
		return _userObjectName;
	}

	public void setUserObjectName(String userObjectName) {
		_userObjectName = userObjectName;
	}

	public boolean getUserObjectGender() {
		return _userObjectGender;
	}

	public boolean isUserObjectGender() {
		return _userObjectGender;
	}

	public void setUserObjectGender(boolean userObjectGender) {
		_userObjectGender = userObjectGender;
	}

	public String getUserObjectAddress() {
		return _userObjectAddress;
	}

	public void setUserObjectAddress(String userObjectAddress) {
		_userObjectAddress = userObjectAddress;
	}

	public Date getUserObjectBirthday() {
		return _userObjectBirthday;
	}

	public void setUserObjectBirthday(Date userObjectBirthday) {
		_userObjectBirthday = userObjectBirthday;
	}

	public String getUserObjectEmail() {
		return _userObjectEmail;
	}

	public void setUserObjectEmail(String userObjectEmail) {
		_userObjectEmail = userObjectEmail;
	}

	public String getUserObjectPhone() {
		return _userObjectPhone;
	}

	public void setUserObjectPhone(String userObjectPhone) {
		_userObjectPhone = userObjectPhone;
	}

	public String getUserObjectIntroduce() {
		return _userObjectIntroduce;
	}

	public void setUserObjectIntroduce(String userObjectIntroduce) {
		_userObjectIntroduce = userObjectIntroduce;
	}

	private long _userObjectId;
	private String _userObjectName;
	private boolean _userObjectGender;
	private String _userObjectAddress;
	private Date _userObjectBirthday;
	private String _userObjectEmail;
	private String _userObjectPhone;
	private String _userObjectIntroduce;
}