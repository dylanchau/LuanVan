package com.dylan.portlets.action.util;

import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.portlets.action.model.Skill;
import com.portlets.action.service.SkillLocalServiceUtil;

public class SkillActionUtil {

	@SuppressWarnings("unchecked")
	public static List<Skill> getSkillsByFieldId(long fieldId) 
			throws Exception {
		
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Skill.class);
		dq.add(PropertyFactoryUtil.forName("fieldId").eq(fieldId));
		
		try {
			return SkillLocalServiceUtil.dynamicQuery(dq); 
		} catch(SystemException e) {
			System.err.println("Loi"); 
			return null;
		}
	}
	
	
}
