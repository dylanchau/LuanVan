/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.EducationUsers;

import java.util.List;

/**
 * The persistence utility for the education users service. This utility wraps {@link EducationUsersPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see EducationUsersPersistence
 * @see EducationUsersPersistenceImpl
 * @generated
 */
public class EducationUsersUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(EducationUsers educationUsers) {
		getPersistence().clearCache(educationUsers);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<EducationUsers> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<EducationUsers> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<EducationUsers> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static EducationUsers update(EducationUsers educationUsers)
		throws SystemException {
		return getPersistence().update(educationUsers);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static EducationUsers update(EducationUsers educationUsers,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(educationUsers, serviceContext);
	}

	/**
	* Returns all the education userses where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @return the matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findByeducationUsersId(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByeducationUsersId(educationUsersId);
	}

	/**
	* Returns a range of all the education userses where educationUsersId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educationUsersId the education users ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @return the range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findByeducationUsersId(
		long educationUsersId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByeducationUsersId(educationUsersId, start, end);
	}

	/**
	* Returns an ordered range of all the education userses where educationUsersId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educationUsersId the education users ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findByeducationUsersId(
		long educationUsersId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByeducationUsersId(educationUsersId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers findByeducationUsersId_First(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException {
		return getPersistence()
				   .findByeducationUsersId_First(educationUsersId,
			orderByComparator);
	}

	/**
	* Returns the first education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers fetchByeducationUsersId_First(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByeducationUsersId_First(educationUsersId,
			orderByComparator);
	}

	/**
	* Returns the last education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers findByeducationUsersId_Last(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException {
		return getPersistence()
				   .findByeducationUsersId_Last(educationUsersId,
			orderByComparator);
	}

	/**
	* Returns the last education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers fetchByeducationUsersId_Last(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByeducationUsersId_Last(educationUsersId,
			orderByComparator);
	}

	/**
	* Removes all the education userses where educationUsersId = &#63; from the database.
	*
	* @param educationUsersId the education users ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByeducationUsersId(long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByeducationUsersId(educationUsersId);
	}

	/**
	* Returns the number of education userses where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @return the number of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByeducationUsersId(long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByeducationUsersId(educationUsersId);
	}

	/**
	* Returns all the education userses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findByuserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId);
	}

	/**
	* Returns a range of all the education userses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @return the range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findByuserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId, start, end);
	}

	/**
	* Returns an ordered range of all the education userses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findByuserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserObjectId(userObjectId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers findByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException {
		return getPersistence()
				   .findByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the first education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers fetchByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the last education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers findByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException {
		return getPersistence()
				   .findByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the last education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers fetchByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the education userses before and after the current education users in the ordered set where userObjectId = &#63;.
	*
	* @param educationUsersId the primary key of the current education users
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers[] findByuserObjectId_PrevAndNext(
		long educationUsersId, long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException {
		return getPersistence()
				   .findByuserObjectId_PrevAndNext(educationUsersId,
			userObjectId, orderByComparator);
	}

	/**
	* Removes all the education userses where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserObjectId(userObjectId);
	}

	/**
	* Returns the number of education userses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserObjectId(userObjectId);
	}

	/**
	* Caches the education users in the entity cache if it is enabled.
	*
	* @param educationUsers the education users
	*/
	public static void cacheResult(
		com.portlets.action.model.EducationUsers educationUsers) {
		getPersistence().cacheResult(educationUsers);
	}

	/**
	* Caches the education userses in the entity cache if it is enabled.
	*
	* @param educationUserses the education userses
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.EducationUsers> educationUserses) {
		getPersistence().cacheResult(educationUserses);
	}

	/**
	* Creates a new education users with the primary key. Does not add the education users to the database.
	*
	* @param educationUsersId the primary key for the new education users
	* @return the new education users
	*/
	public static com.portlets.action.model.EducationUsers create(
		long educationUsersId) {
		return getPersistence().create(educationUsersId);
	}

	/**
	* Removes the education users with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param educationUsersId the primary key of the education users
	* @return the education users that was removed
	* @throws com.portlets.action.NoSuchEducationUsersException if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers remove(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException {
		return getPersistence().remove(educationUsersId);
	}

	public static com.portlets.action.model.EducationUsers updateImpl(
		com.portlets.action.model.EducationUsers educationUsers)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(educationUsers);
	}

	/**
	* Returns the education users with the primary key or throws a {@link com.portlets.action.NoSuchEducationUsersException} if it could not be found.
	*
	* @param educationUsersId the primary key of the education users
	* @return the education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers findByPrimaryKey(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException {
		return getPersistence().findByPrimaryKey(educationUsersId);
	}

	/**
	* Returns the education users with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param educationUsersId the primary key of the education users
	* @return the education users, or <code>null</code> if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.EducationUsers fetchByPrimaryKey(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(educationUsersId);
	}

	/**
	* Returns all the education userses.
	*
	* @return the education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the education userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @return the range of education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the education userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of education userses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.EducationUsers> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the education userses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of education userses.
	*
	* @return the number of education userses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static EducationUsersPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (EducationUsersPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					EducationUsersPersistence.class.getName());

			ReferenceRegistry.registerReference(EducationUsersUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(EducationUsersPersistence persistence) {
	}

	private static EducationUsersPersistence _persistence;
}