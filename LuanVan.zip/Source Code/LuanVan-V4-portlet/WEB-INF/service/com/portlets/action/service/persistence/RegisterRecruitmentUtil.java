/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.RegisterRecruitment;

import java.util.List;

/**
 * The persistence utility for the register recruitment service. This utility wraps {@link RegisterRecruitmentPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see RegisterRecruitmentPersistence
 * @see RegisterRecruitmentPersistenceImpl
 * @generated
 */
public class RegisterRecruitmentUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(RegisterRecruitment registerRecruitment) {
		getPersistence().clearCache(registerRecruitment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<RegisterRecruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<RegisterRecruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<RegisterRecruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static RegisterRecruitment update(
		RegisterRecruitment registerRecruitment) throws SystemException {
		return getPersistence().update(registerRecruitment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static RegisterRecruitment update(
		RegisterRecruitment registerRecruitment, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(registerRecruitment, serviceContext);
	}

	/**
	* Returns all the register recruitments where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findBystatesId(
		long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId);
	}

	/**
	* Returns a range of all the register recruitments where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @return the range of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findBystatesId(
		long statesId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId, start, end);
	}

	/**
	* Returns an ordered range of all the register recruitments where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findBystatesId(
		long statesId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBystatesId(statesId, start, end, orderByComparator);
	}

	/**
	* Returns the first register recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence().findBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the first register recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the last register recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence().findBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the last register recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the register recruitments before and after the current register recruitment in the ordered set where statesId = &#63;.
	*
	* @param registerRecruitmentPK the primary key of the current register recruitment
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment[] findBystatesId_PrevAndNext(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK,
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findBystatesId_PrevAndNext(registerRecruitmentPK, statesId,
			orderByComparator);
	}

	/**
	* Removes all the register recruitments where statesId = &#63; from the database.
	*
	* @param statesId the states ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystatesId(statesId);
	}

	/**
	* Returns the number of register recruitments where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the number of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystatesId(statesId);
	}

	/**
	* Returns all the register recruitments where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @return the matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findByrecruitmentId(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByrecruitmentId(recruitmentId);
	}

	/**
	* Returns a range of all the register recruitments where recruitmentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param recruitmentId the recruitment ID
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @return the range of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findByrecruitmentId(
		long recruitmentId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByrecruitmentId(recruitmentId, start, end);
	}

	/**
	* Returns an ordered range of all the register recruitments where recruitmentId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param recruitmentId the recruitment ID
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findByrecruitmentId(
		long recruitmentId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByrecruitmentId(recruitmentId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first register recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findByrecruitmentId_First(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findByrecruitmentId_First(recruitmentId, orderByComparator);
	}

	/**
	* Returns the first register recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchByrecruitmentId_First(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByrecruitmentId_First(recruitmentId, orderByComparator);
	}

	/**
	* Returns the last register recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findByrecruitmentId_Last(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findByrecruitmentId_Last(recruitmentId, orderByComparator);
	}

	/**
	* Returns the last register recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchByrecruitmentId_Last(
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByrecruitmentId_Last(recruitmentId, orderByComparator);
	}

	/**
	* Returns the register recruitments before and after the current register recruitment in the ordered set where recruitmentId = &#63;.
	*
	* @param registerRecruitmentPK the primary key of the current register recruitment
	* @param recruitmentId the recruitment ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment[] findByrecruitmentId_PrevAndNext(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK,
		long recruitmentId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findByrecruitmentId_PrevAndNext(registerRecruitmentPK,
			recruitmentId, orderByComparator);
	}

	/**
	* Removes all the register recruitments where recruitmentId = &#63; from the database.
	*
	* @param recruitmentId the recruitment ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByrecruitmentId(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByrecruitmentId(recruitmentId);
	}

	/**
	* Returns the number of register recruitments where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @return the number of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByrecruitmentId(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByrecruitmentId(recruitmentId);
	}

	/**
	* Returns all the register recruitments where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findByuserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId);
	}

	/**
	* Returns a range of all the register recruitments where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @return the range of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findByuserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId, start, end);
	}

	/**
	* Returns an ordered range of all the register recruitments where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findByuserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserObjectId(userObjectId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first register recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the first register recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the last register recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the last register recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the register recruitments before and after the current register recruitment in the ordered set where userObjectId = &#63;.
	*
	* @param registerRecruitmentPK the primary key of the current register recruitment
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment[] findByuserObjectId_PrevAndNext(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK,
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findByuserObjectId_PrevAndNext(registerRecruitmentPK,
			userObjectId, orderByComparator);
	}

	/**
	* Removes all the register recruitments where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserObjectId(userObjectId);
	}

	/**
	* Returns the number of register recruitments where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserObjectId(userObjectId);
	}

	/**
	* Returns the register recruitment where recruitmentId = &#63; and userObjectId = &#63; or throws a {@link com.portlets.action.NoSuchRegisterRecruitmentException} if it could not be found.
	*
	* @param recruitmentId the recruitment ID
	* @param userObjectId the user object ID
	* @return the matching register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findByRecruitmentId_UserId(
		long recruitmentId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .findByRecruitmentId_UserId(recruitmentId, userObjectId);
	}

	/**
	* Returns the register recruitment where recruitmentId = &#63; and userObjectId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param recruitmentId the recruitment ID
	* @param userObjectId the user object ID
	* @return the matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchByRecruitmentId_UserId(
		long recruitmentId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByRecruitmentId_UserId(recruitmentId, userObjectId);
	}

	/**
	* Returns the register recruitment where recruitmentId = &#63; and userObjectId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param recruitmentId the recruitment ID
	* @param userObjectId the user object ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching register recruitment, or <code>null</code> if a matching register recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchByRecruitmentId_UserId(
		long recruitmentId, long userObjectId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByRecruitmentId_UserId(recruitmentId, userObjectId,
			retrieveFromCache);
	}

	/**
	* Removes the register recruitment where recruitmentId = &#63; and userObjectId = &#63; from the database.
	*
	* @param recruitmentId the recruitment ID
	* @param userObjectId the user object ID
	* @return the register recruitment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment removeByRecruitmentId_UserId(
		long recruitmentId, long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence()
				   .removeByRecruitmentId_UserId(recruitmentId, userObjectId);
	}

	/**
	* Returns the number of register recruitments where recruitmentId = &#63; and userObjectId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @param userObjectId the user object ID
	* @return the number of matching register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByRecruitmentId_UserId(long recruitmentId,
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .countByRecruitmentId_UserId(recruitmentId, userObjectId);
	}

	/**
	* Caches the register recruitment in the entity cache if it is enabled.
	*
	* @param registerRecruitment the register recruitment
	*/
	public static void cacheResult(
		com.portlets.action.model.RegisterRecruitment registerRecruitment) {
		getPersistence().cacheResult(registerRecruitment);
	}

	/**
	* Caches the register recruitments in the entity cache if it is enabled.
	*
	* @param registerRecruitments the register recruitments
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.RegisterRecruitment> registerRecruitments) {
		getPersistence().cacheResult(registerRecruitments);
	}

	/**
	* Creates a new register recruitment with the primary key. Does not add the register recruitment to the database.
	*
	* @param registerRecruitmentPK the primary key for the new register recruitment
	* @return the new register recruitment
	*/
	public static com.portlets.action.model.RegisterRecruitment create(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK) {
		return getPersistence().create(registerRecruitmentPK);
	}

	/**
	* Removes the register recruitment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param registerRecruitmentPK the primary key of the register recruitment
	* @return the register recruitment that was removed
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment remove(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence().remove(registerRecruitmentPK);
	}

	public static com.portlets.action.model.RegisterRecruitment updateImpl(
		com.portlets.action.model.RegisterRecruitment registerRecruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(registerRecruitment);
	}

	/**
	* Returns the register recruitment with the primary key or throws a {@link com.portlets.action.NoSuchRegisterRecruitmentException} if it could not be found.
	*
	* @param registerRecruitmentPK the primary key of the register recruitment
	* @return the register recruitment
	* @throws com.portlets.action.NoSuchRegisterRecruitmentException if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment findByPrimaryKey(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterRecruitmentException {
		return getPersistence().findByPrimaryKey(registerRecruitmentPK);
	}

	/**
	* Returns the register recruitment with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param registerRecruitmentPK the primary key of the register recruitment
	* @return the register recruitment, or <code>null</code> if a register recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterRecruitment fetchByPrimaryKey(
		com.portlets.action.service.persistence.RegisterRecruitmentPK registerRecruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(registerRecruitmentPK);
	}

	/**
	* Returns all the register recruitments.
	*
	* @return the register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the register recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @return the range of register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the register recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterRecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of register recruitments
	* @param end the upper bound of the range of register recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterRecruitment> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the register recruitments from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of register recruitments.
	*
	* @return the number of register recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static RegisterRecruitmentPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (RegisterRecruitmentPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					RegisterRecruitmentPersistence.class.getName());

			ReferenceRegistry.registerReference(RegisterRecruitmentUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(RegisterRecruitmentPersistence persistence) {
	}

	private static RegisterRecruitmentPersistence _persistence;
}