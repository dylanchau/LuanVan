/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.UserSkillLevel;

import java.util.List;

/**
 * The persistence utility for the user skill level service. This utility wraps {@link UserSkillLevelPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see UserSkillLevelPersistence
 * @see UserSkillLevelPersistenceImpl
 * @generated
 */
public class UserSkillLevelUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(UserSkillLevel userSkillLevel) {
		getPersistence().clearCache(userSkillLevel);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<UserSkillLevel> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<UserSkillLevel> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<UserSkillLevel> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static UserSkillLevel update(UserSkillLevel userSkillLevel)
		throws SystemException {
		return getPersistence().update(userSkillLevel);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static UserSkillLevel update(UserSkillLevel userSkillLevel,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(userSkillLevel, serviceContext);
	}

	/**
	* Returns all the user skill levels where levelId = &#63;.
	*
	* @param levelId the level ID
	* @return the matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findByLevelId(
		long levelId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByLevelId(levelId);
	}

	/**
	* Returns a range of all the user skill levels where levelId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param levelId the level ID
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @return the range of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findByLevelId(
		long levelId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByLevelId(levelId, start, end);
	}

	/**
	* Returns an ordered range of all the user skill levels where levelId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param levelId the level ID
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findByLevelId(
		long levelId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByLevelId(levelId, start, end, orderByComparator);
	}

	/**
	* Returns the first user skill level in the ordered set where levelId = &#63;.
	*
	* @param levelId the level ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel findByLevelId_First(
		long levelId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence().findByLevelId_First(levelId, orderByComparator);
	}

	/**
	* Returns the first user skill level in the ordered set where levelId = &#63;.
	*
	* @param levelId the level ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user skill level, or <code>null</code> if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel fetchByLevelId_First(
		long levelId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByLevelId_First(levelId, orderByComparator);
	}

	/**
	* Returns the last user skill level in the ordered set where levelId = &#63;.
	*
	* @param levelId the level ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel findByLevelId_Last(
		long levelId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence().findByLevelId_Last(levelId, orderByComparator);
	}

	/**
	* Returns the last user skill level in the ordered set where levelId = &#63;.
	*
	* @param levelId the level ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user skill level, or <code>null</code> if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel fetchByLevelId_Last(
		long levelId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByLevelId_Last(levelId, orderByComparator);
	}

	/**
	* Returns the user skill levels before and after the current user skill level in the ordered set where levelId = &#63;.
	*
	* @param userSkillLevelPK the primary key of the current user skill level
	* @param levelId the level ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a user skill level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel[] findByLevelId_PrevAndNext(
		com.portlets.action.service.persistence.UserSkillLevelPK userSkillLevelPK,
		long levelId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence()
				   .findByLevelId_PrevAndNext(userSkillLevelPK, levelId,
			orderByComparator);
	}

	/**
	* Removes all the user skill levels where levelId = &#63; from the database.
	*
	* @param levelId the level ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByLevelId(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByLevelId(levelId);
	}

	/**
	* Returns the number of user skill levels where levelId = &#63;.
	*
	* @param levelId the level ID
	* @return the number of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static int countByLevelId(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByLevelId(levelId);
	}

	/**
	* Returns all the user skill levels where skillId = &#63;.
	*
	* @param skillId the skill ID
	* @return the matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findBySkillId(
		long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBySkillId(skillId);
	}

	/**
	* Returns a range of all the user skill levels where skillId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param skillId the skill ID
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @return the range of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findBySkillId(
		long skillId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBySkillId(skillId, start, end);
	}

	/**
	* Returns an ordered range of all the user skill levels where skillId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param skillId the skill ID
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findBySkillId(
		long skillId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBySkillId(skillId, start, end, orderByComparator);
	}

	/**
	* Returns the first user skill level in the ordered set where skillId = &#63;.
	*
	* @param skillId the skill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel findBySkillId_First(
		long skillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence().findBySkillId_First(skillId, orderByComparator);
	}

	/**
	* Returns the first user skill level in the ordered set where skillId = &#63;.
	*
	* @param skillId the skill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user skill level, or <code>null</code> if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel fetchBySkillId_First(
		long skillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBySkillId_First(skillId, orderByComparator);
	}

	/**
	* Returns the last user skill level in the ordered set where skillId = &#63;.
	*
	* @param skillId the skill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel findBySkillId_Last(
		long skillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence().findBySkillId_Last(skillId, orderByComparator);
	}

	/**
	* Returns the last user skill level in the ordered set where skillId = &#63;.
	*
	* @param skillId the skill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user skill level, or <code>null</code> if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel fetchBySkillId_Last(
		long skillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBySkillId_Last(skillId, orderByComparator);
	}

	/**
	* Returns the user skill levels before and after the current user skill level in the ordered set where skillId = &#63;.
	*
	* @param userSkillLevelPK the primary key of the current user skill level
	* @param skillId the skill ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a user skill level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel[] findBySkillId_PrevAndNext(
		com.portlets.action.service.persistence.UserSkillLevelPK userSkillLevelPK,
		long skillId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence()
				   .findBySkillId_PrevAndNext(userSkillLevelPK, skillId,
			orderByComparator);
	}

	/**
	* Removes all the user skill levels where skillId = &#63; from the database.
	*
	* @param skillId the skill ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBySkillId(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBySkillId(skillId);
	}

	/**
	* Returns the number of user skill levels where skillId = &#63;.
	*
	* @param skillId the skill ID
	* @return the number of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static int countBySkillId(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBySkillId(skillId);
	}

	/**
	* Returns all the user skill levels where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findByUserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserObjectId(userObjectId);
	}

	/**
	* Returns a range of all the user skill levels where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @return the range of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findByUserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserObjectId(userObjectId, start, end);
	}

	/**
	* Returns an ordered range of all the user skill levels where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findByUserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUserObjectId(userObjectId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first user skill level in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel findByUserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence()
				   .findByUserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the first user skill level in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user skill level, or <code>null</code> if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel fetchByUserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the last user skill level in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel findByUserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence()
				   .findByUserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the last user skill level in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user skill level, or <code>null</code> if a matching user skill level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel fetchByUserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the user skill levels before and after the current user skill level in the ordered set where userObjectId = &#63;.
	*
	* @param userSkillLevelPK the primary key of the current user skill level
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a user skill level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel[] findByUserObjectId_PrevAndNext(
		com.portlets.action.service.persistence.UserSkillLevelPK userSkillLevelPK,
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence()
				   .findByUserObjectId_PrevAndNext(userSkillLevelPK,
			userObjectId, orderByComparator);
	}

	/**
	* Removes all the user skill levels where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUserObjectId(userObjectId);
	}

	/**
	* Returns the number of user skill levels where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUserObjectId(userObjectId);
	}

	/**
	* Caches the user skill level in the entity cache if it is enabled.
	*
	* @param userSkillLevel the user skill level
	*/
	public static void cacheResult(
		com.portlets.action.model.UserSkillLevel userSkillLevel) {
		getPersistence().cacheResult(userSkillLevel);
	}

	/**
	* Caches the user skill levels in the entity cache if it is enabled.
	*
	* @param userSkillLevels the user skill levels
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.UserSkillLevel> userSkillLevels) {
		getPersistence().cacheResult(userSkillLevels);
	}

	/**
	* Creates a new user skill level with the primary key. Does not add the user skill level to the database.
	*
	* @param userSkillLevelPK the primary key for the new user skill level
	* @return the new user skill level
	*/
	public static com.portlets.action.model.UserSkillLevel create(
		com.portlets.action.service.persistence.UserSkillLevelPK userSkillLevelPK) {
		return getPersistence().create(userSkillLevelPK);
	}

	/**
	* Removes the user skill level with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userSkillLevelPK the primary key of the user skill level
	* @return the user skill level that was removed
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a user skill level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel remove(
		com.portlets.action.service.persistence.UserSkillLevelPK userSkillLevelPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence().remove(userSkillLevelPK);
	}

	public static com.portlets.action.model.UserSkillLevel updateImpl(
		com.portlets.action.model.UserSkillLevel userSkillLevel)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(userSkillLevel);
	}

	/**
	* Returns the user skill level with the primary key or throws a {@link com.portlets.action.NoSuchUserSkillLevelException} if it could not be found.
	*
	* @param userSkillLevelPK the primary key of the user skill level
	* @return the user skill level
	* @throws com.portlets.action.NoSuchUserSkillLevelException if a user skill level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel findByPrimaryKey(
		com.portlets.action.service.persistence.UserSkillLevelPK userSkillLevelPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserSkillLevelException {
		return getPersistence().findByPrimaryKey(userSkillLevelPK);
	}

	/**
	* Returns the user skill level with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param userSkillLevelPK the primary key of the user skill level
	* @return the user skill level, or <code>null</code> if a user skill level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserSkillLevel fetchByPrimaryKey(
		com.portlets.action.service.persistence.UserSkillLevelPK userSkillLevelPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(userSkillLevelPK);
	}

	/**
	* Returns all the user skill levels.
	*
	* @return the user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the user skill levels.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @return the range of user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the user skill levels.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserSkillLevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user skill levels
	* @param end the upper bound of the range of user skill levels (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserSkillLevel> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the user skill levels from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of user skill levels.
	*
	* @return the number of user skill levels
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static UserSkillLevelPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (UserSkillLevelPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					UserSkillLevelPersistence.class.getName());

			ReferenceRegistry.registerReference(UserSkillLevelUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(UserSkillLevelPersistence persistence) {
	}

	private static UserSkillLevelPersistence _persistence;
}