/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.Level;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Level in entity cache.
 *
 * @author Computer
 * @see Level
 * @generated
 */
public class LevelCacheModel implements CacheModel<Level>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{levelId=");
		sb.append(levelId);
		sb.append(", levelName=");
		sb.append(levelName);
		sb.append(", levelExplain=");
		sb.append(levelExplain);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Level toEntityModel() {
		LevelImpl levelImpl = new LevelImpl();

		levelImpl.setLevelId(levelId);

		if (levelName == null) {
			levelImpl.setLevelName(StringPool.BLANK);
		}
		else {
			levelImpl.setLevelName(levelName);
		}

		if (levelExplain == null) {
			levelImpl.setLevelExplain(StringPool.BLANK);
		}
		else {
			levelImpl.setLevelExplain(levelExplain);
		}

		levelImpl.resetOriginalValues();

		return levelImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		levelId = objectInput.readLong();
		levelName = objectInput.readUTF();
		levelExplain = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(levelId);

		if (levelName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(levelName);
		}

		if (levelExplain == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(levelExplain);
		}
	}

	public long levelId;
	public String levelName;
	public String levelExplain;
}