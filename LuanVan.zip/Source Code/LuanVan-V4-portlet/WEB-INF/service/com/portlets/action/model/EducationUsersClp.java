/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.EducationUsersLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class EducationUsersClp extends BaseModelImpl<EducationUsers>
	implements EducationUsers {
	public EducationUsersClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return EducationUsers.class;
	}

	@Override
	public String getModelClassName() {
		return EducationUsers.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _educationUsersId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setEducationUsersId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _educationUsersId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("educationUsersId", getEducationUsersId());
		attributes.put("educationUsersSchool", getEducationUsersSchool());
		attributes.put("educationUsersMajor", getEducationUsersMajor());
		attributes.put("educationUsersDateStart", getEducationUsersDateStart());
		attributes.put("educationUsersDateFinish", getEducationUsersDateFinish());
		attributes.put("educationUsersDegree", getEducationUsersDegree());
		attributes.put("educationUsersDescription",
			getEducationUsersDescription());
		attributes.put("userObjectId", getUserObjectId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long educationUsersId = (Long)attributes.get("educationUsersId");

		if (educationUsersId != null) {
			setEducationUsersId(educationUsersId);
		}

		String educationUsersSchool = (String)attributes.get(
				"educationUsersSchool");

		if (educationUsersSchool != null) {
			setEducationUsersSchool(educationUsersSchool);
		}

		String educationUsersMajor = (String)attributes.get(
				"educationUsersMajor");

		if (educationUsersMajor != null) {
			setEducationUsersMajor(educationUsersMajor);
		}

		Date educationUsersDateStart = (Date)attributes.get(
				"educationUsersDateStart");

		if (educationUsersDateStart != null) {
			setEducationUsersDateStart(educationUsersDateStart);
		}

		Date educationUsersDateFinish = (Date)attributes.get(
				"educationUsersDateFinish");

		if (educationUsersDateFinish != null) {
			setEducationUsersDateFinish(educationUsersDateFinish);
		}

		String educationUsersDegree = (String)attributes.get(
				"educationUsersDegree");

		if (educationUsersDegree != null) {
			setEducationUsersDegree(educationUsersDegree);
		}

		String educationUsersDescription = (String)attributes.get(
				"educationUsersDescription");

		if (educationUsersDescription != null) {
			setEducationUsersDescription(educationUsersDescription);
		}

		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}
	}

	@Override
	public long getEducationUsersId() {
		return _educationUsersId;
	}

	@Override
	public void setEducationUsersId(long educationUsersId) {
		_educationUsersId = educationUsersId;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setEducationUsersId",
						long.class);

				method.invoke(_educationUsersRemoteModel, educationUsersId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducationUsersSchool() {
		return _educationUsersSchool;
	}

	@Override
	public void setEducationUsersSchool(String educationUsersSchool) {
		_educationUsersSchool = educationUsersSchool;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setEducationUsersSchool",
						String.class);

				method.invoke(_educationUsersRemoteModel, educationUsersSchool);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducationUsersMajor() {
		return _educationUsersMajor;
	}

	@Override
	public void setEducationUsersMajor(String educationUsersMajor) {
		_educationUsersMajor = educationUsersMajor;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setEducationUsersMajor",
						String.class);

				method.invoke(_educationUsersRemoteModel, educationUsersMajor);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getEducationUsersDateStart() {
		return _educationUsersDateStart;
	}

	@Override
	public void setEducationUsersDateStart(Date educationUsersDateStart) {
		_educationUsersDateStart = educationUsersDateStart;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setEducationUsersDateStart",
						Date.class);

				method.invoke(_educationUsersRemoteModel,
					educationUsersDateStart);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getEducationUsersDateFinish() {
		return _educationUsersDateFinish;
	}

	@Override
	public void setEducationUsersDateFinish(Date educationUsersDateFinish) {
		_educationUsersDateFinish = educationUsersDateFinish;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setEducationUsersDateFinish",
						Date.class);

				method.invoke(_educationUsersRemoteModel,
					educationUsersDateFinish);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducationUsersDegree() {
		return _educationUsersDegree;
	}

	@Override
	public void setEducationUsersDegree(String educationUsersDegree) {
		_educationUsersDegree = educationUsersDegree;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setEducationUsersDegree",
						String.class);

				method.invoke(_educationUsersRemoteModel, educationUsersDegree);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducationUsersDescription() {
		return _educationUsersDescription;
	}

	@Override
	public void setEducationUsersDescription(String educationUsersDescription) {
		_educationUsersDescription = educationUsersDescription;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setEducationUsersDescription",
						String.class);

				method.invoke(_educationUsersRemoteModel,
					educationUsersDescription);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserObjectId() {
		return _userObjectId;
	}

	@Override
	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;

		if (_educationUsersRemoteModel != null) {
			try {
				Class<?> clazz = _educationUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectId", long.class);

				method.invoke(_educationUsersRemoteModel, userObjectId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getEducationUsersRemoteModel() {
		return _educationUsersRemoteModel;
	}

	public void setEducationUsersRemoteModel(
		BaseModel<?> educationUsersRemoteModel) {
		_educationUsersRemoteModel = educationUsersRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _educationUsersRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_educationUsersRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			EducationUsersLocalServiceUtil.addEducationUsers(this);
		}
		else {
			EducationUsersLocalServiceUtil.updateEducationUsers(this);
		}
	}

	@Override
	public EducationUsers toEscapedModel() {
		return (EducationUsers)ProxyUtil.newProxyInstance(EducationUsers.class.getClassLoader(),
			new Class[] { EducationUsers.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		EducationUsersClp clone = new EducationUsersClp();

		clone.setEducationUsersId(getEducationUsersId());
		clone.setEducationUsersSchool(getEducationUsersSchool());
		clone.setEducationUsersMajor(getEducationUsersMajor());
		clone.setEducationUsersDateStart(getEducationUsersDateStart());
		clone.setEducationUsersDateFinish(getEducationUsersDateFinish());
		clone.setEducationUsersDegree(getEducationUsersDegree());
		clone.setEducationUsersDescription(getEducationUsersDescription());
		clone.setUserObjectId(getUserObjectId());

		return clone;
	}

	@Override
	public int compareTo(EducationUsers educationUsers) {
		long primaryKey = educationUsers.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EducationUsersClp)) {
			return false;
		}

		EducationUsersClp educationUsers = (EducationUsersClp)obj;

		long primaryKey = educationUsers.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{educationUsersId=");
		sb.append(getEducationUsersId());
		sb.append(", educationUsersSchool=");
		sb.append(getEducationUsersSchool());
		sb.append(", educationUsersMajor=");
		sb.append(getEducationUsersMajor());
		sb.append(", educationUsersDateStart=");
		sb.append(getEducationUsersDateStart());
		sb.append(", educationUsersDateFinish=");
		sb.append(getEducationUsersDateFinish());
		sb.append(", educationUsersDegree=");
		sb.append(getEducationUsersDegree());
		sb.append(", educationUsersDescription=");
		sb.append(getEducationUsersDescription());
		sb.append(", userObjectId=");
		sb.append(getUserObjectId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(28);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.EducationUsers");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>educationUsersId</column-name><column-value><![CDATA[");
		sb.append(getEducationUsersId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educationUsersSchool</column-name><column-value><![CDATA[");
		sb.append(getEducationUsersSchool());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educationUsersMajor</column-name><column-value><![CDATA[");
		sb.append(getEducationUsersMajor());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educationUsersDateStart</column-name><column-value><![CDATA[");
		sb.append(getEducationUsersDateStart());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educationUsersDateFinish</column-name><column-value><![CDATA[");
		sb.append(getEducationUsersDateFinish());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educationUsersDegree</column-name><column-value><![CDATA[");
		sb.append(getEducationUsersDegree());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educationUsersDescription</column-name><column-value><![CDATA[");
		sb.append(getEducationUsersDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectId</column-name><column-value><![CDATA[");
		sb.append(getUserObjectId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _educationUsersId;
	private String _educationUsersSchool;
	private String _educationUsersMajor;
	private Date _educationUsersDateStart;
	private Date _educationUsersDateFinish;
	private String _educationUsersDegree;
	private String _educationUsersDescription;
	private long _userObjectId;
	private BaseModel<?> _educationUsersRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}