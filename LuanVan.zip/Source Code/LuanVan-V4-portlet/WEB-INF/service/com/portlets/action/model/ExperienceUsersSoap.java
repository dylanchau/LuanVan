/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.ExperienceUsersServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.ExperienceUsersServiceSoap
 * @generated
 */
public class ExperienceUsersSoap implements Serializable {
	public static ExperienceUsersSoap toSoapModel(ExperienceUsers model) {
		ExperienceUsersSoap soapModel = new ExperienceUsersSoap();

		soapModel.setExperienceUsersId(model.getExperienceUsersId());
		soapModel.setExperienceUsersJob(model.getExperienceUsersJob());
		soapModel.setExperienceUsersCompany(model.getExperienceUsersCompany());
		soapModel.setExperienceUsersDateStart(model.getExperienceUsersDateStart());
		soapModel.setExperienceUsersDateFinish(model.getExperienceUsersDateFinish());
		soapModel.setExperienceUsersDescription(model.getExperienceUsersDescription());
		soapModel.setUserObjectId(model.getUserObjectId());

		return soapModel;
	}

	public static ExperienceUsersSoap[] toSoapModels(ExperienceUsers[] models) {
		ExperienceUsersSoap[] soapModels = new ExperienceUsersSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static ExperienceUsersSoap[][] toSoapModels(
		ExperienceUsers[][] models) {
		ExperienceUsersSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new ExperienceUsersSoap[models.length][models[0].length];
		}
		else {
			soapModels = new ExperienceUsersSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static ExperienceUsersSoap[] toSoapModels(
		List<ExperienceUsers> models) {
		List<ExperienceUsersSoap> soapModels = new ArrayList<ExperienceUsersSoap>(models.size());

		for (ExperienceUsers model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new ExperienceUsersSoap[soapModels.size()]);
	}

	public ExperienceUsersSoap() {
	}

	public long getPrimaryKey() {
		return _experienceUsersId;
	}

	public void setPrimaryKey(long pk) {
		setExperienceUsersId(pk);
	}

	public long getExperienceUsersId() {
		return _experienceUsersId;
	}

	public void setExperienceUsersId(long experienceUsersId) {
		_experienceUsersId = experienceUsersId;
	}

	public String getExperienceUsersJob() {
		return _experienceUsersJob;
	}

	public void setExperienceUsersJob(String experienceUsersJob) {
		_experienceUsersJob = experienceUsersJob;
	}

	public String getExperienceUsersCompany() {
		return _experienceUsersCompany;
	}

	public void setExperienceUsersCompany(String experienceUsersCompany) {
		_experienceUsersCompany = experienceUsersCompany;
	}

	public Date getExperienceUsersDateStart() {
		return _experienceUsersDateStart;
	}

	public void setExperienceUsersDateStart(Date experienceUsersDateStart) {
		_experienceUsersDateStart = experienceUsersDateStart;
	}

	public Date getExperienceUsersDateFinish() {
		return _experienceUsersDateFinish;
	}

	public void setExperienceUsersDateFinish(Date experienceUsersDateFinish) {
		_experienceUsersDateFinish = experienceUsersDateFinish;
	}

	public String getExperienceUsersDescription() {
		return _experienceUsersDescription;
	}

	public void setExperienceUsersDescription(String experienceUsersDescription) {
		_experienceUsersDescription = experienceUsersDescription;
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	private long _experienceUsersId;
	private String _experienceUsersJob;
	private String _experienceUsersCompany;
	private Date _experienceUsersDateStart;
	private Date _experienceUsersDateFinish;
	private String _experienceUsersDescription;
	private long _userObjectId;
}