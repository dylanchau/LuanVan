package com.dylan.messagebus.listenerImp;

import javax.mail.internet.InternetAddress;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.notifications.ChannelHubManagerUtil;
import com.liferay.portal.kernel.notifications.NotificationEvent;
import com.liferay.portal.kernel.notifications.NotificationEventFactoryUtil;
import com.portlets.action.service.EmployerLocalServiceUtil;
import com.portlets.action.service.RecruitmentLocalServiceUtil;
import com.portlets.action.service.UserObjectLocalServiceUtil;

public class RegistedUserListenerImpl implements MessageListener {

	@Override
	public void receive(Message arg0) throws MessageListenerException {
		// TODO Auto-generated method stub

		try {
			doReceive(arg0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
public void doReceive(Message message) throws Exception {
		
		String payLoad = (String) message.getPayload();
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject(payLoad);
		long id = jsonObject.getLong("RecruitmentId2");										
		long companyId = jsonObject.getLong("companyId");
		long employerId = jsonObject.getLong("employerId");
		long userId = jsonObject.getLong("userId");
		String tinNhan = jsonObject.getString("message");
		
		System.out.println(id + "\n" + companyId + "\n" + employerId);

		try {
				NotificationEvent notificationEvent = NotificationEventFactoryUtil
						.createNotificationEvent(System.currentTimeMillis(), UserNotificationHandler.PORTLET_ID, jsonObject);
				notificationEvent.setDeliveryRequired(0);
				ChannelHubManagerUtil.sendNotificationEvent(companyId,
							userId, notificationEvent);
				
				//send mail
				String From= "liferay.luanvan@gmail.com";
				String to = UserObjectLocalServiceUtil.getUserObject(userId).getUserObjectEmail();
				InternetAddress From1 = new InternetAddress(From);
				InternetAddress to1 = new InternetAddress(to);
				
				MailMessage mailMessage =new MailMessage(); 

                mailMessage.setFrom(From1);
                mailMessage.setTo(to1);
                
                String messageBody = "<span style=\"color: red; font-weight: bold;\">" + 
                						EmployerLocalServiceUtil.getEmployer(employerId).getEmployerName() + "</span>" + 
                						tinNhan + "<span style=\"color: red; font-weight: bold;\">" +
                						RecruitmentLocalServiceUtil.getRecruitment(id).getRecruitmentName() + "</span>";
                
                mailMessage.setSubject(tinNhan);
                mailMessage.setBody(messageBody);
                mailMessage.setHTMLFormat(true);
                
                
                MailServiceUtil.sendEmail(mailMessage);
		
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}

}
