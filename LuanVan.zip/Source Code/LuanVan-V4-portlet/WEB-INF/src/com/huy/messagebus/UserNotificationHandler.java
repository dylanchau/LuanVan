package com.huy.messagebus;

import javax.portlet.ActionRequest;
import javax.portlet.PortletURL;
import javax.portlet.WindowState;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.notifications.BaseUserNotificationHandler;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.model.UserNotificationEvent;
import com.liferay.portal.service.ServiceContext;


public class UserNotificationHandler extends 
			BaseUserNotificationHandler {

public static final String PORTLET_ID = "luanvanv4_WAR_LuanVanV4portlet";
	
	long id;
	
	public UserNotificationHandler() {
		 
		setPortletId(PORTLET_ID);
 
	}
	
	@Override
	protected String getBody(UserNotificationEvent userNotificationEvent,
			ServiceContext serviceContext) throws Exception {
 
		JSONObject jsonObject = JSONFactoryUtil
				.createJSONObject(userNotificationEvent.getPayload());
 
		id = jsonObject.getLong("id");
		long employerId = jsonObject.getLong("employerId");
 
		String title = "<strong>A new Job is Public with id:  " + employerId + "</strong>";
		
		String content = jsonObject.getString("companyId");
		
		String url = jsonObject.getString("url");
		
		String bodyText = "<a href=\"" + url + "\">" + content + "</a>";
 
		LiferayPortletResponse liferayPortletResponse = serviceContext
				.getLiferayPortletResponse();
 
		PortletURL confirmURL = liferayPortletResponse.createActionURL(PORTLET_ID);
		
 
		confirmURL.setParameter(ActionRequest.ACTION_NAME, "doSomethingGood");
		confirmURL.setParameter("redirect", serviceContext.getLayoutFullURL());
		confirmURL.setParameter("id", String.valueOf(id));
		confirmURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
		confirmURL.setWindowState(WindowState.NORMAL);
 
		PortletURL ignoreURL = liferayPortletResponse.createActionURL(PORTLET_ID);
		ignoreURL.setParameter(ActionRequest.ACTION_NAME, "deleteNotification");
		
		ignoreURL.setParameter("redirect", serviceContext.getLayoutFullURL());
		ignoreURL.setParameter("yourCustomEntityId", String.valueOf(id));
		ignoreURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
		ignoreURL.setWindowState(WindowState.NORMAL);
 
		String body = StringUtil.replace(getBodyTemplate(), 
				new String[] {"[$TITLE$]", "[$BODY_TEXT$]" }, 
				new String[] { title, bodyText});
		
		return body;
	}
 
	@Override
	protected String getLink(UserNotificationEvent userNotificationEvent,
			ServiceContext serviceContext) throws Exception {
 
		JSONObject jsonObject = JSONFactoryUtil
				.createJSONObject(userNotificationEvent.getPayload());
 
		long id = jsonObject
				.getLong("id");
		
		LiferayPortletResponse liferayPortletResponse = serviceContext
				.getLiferayPortletResponse();		
 
		PortletURL confirmURL = liferayPortletResponse.createActionURL(PORTLET_ID);
		confirmURL.setParameter(ActionRequest.ACTION_NAME, "showDetails");
		confirmURL.setParameter("redirect", serviceContext.getLayoutFullURL());
		confirmURL.setParameter("id", String.valueOf(id));
		confirmURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
		confirmURL.setWindowState(WindowState.NORMAL);
		
		return confirmURL.toString();
	}
 
	protected String getBodyTemplate() throws Exception {
		StringBundler sb = new StringBundler(5);
		sb.append("<div class=\"title\">[$TITLE$]</div>");
		sb.append("<div class=\"body\">[$BODY_TEXT$]</div>");

		return sb.toString();
	}
	

	Log _log = LogFactoryUtil.getLog(UserNotificationHandler.class);

}
