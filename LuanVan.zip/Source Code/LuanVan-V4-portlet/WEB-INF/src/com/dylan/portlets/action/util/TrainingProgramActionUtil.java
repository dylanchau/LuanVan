package com.dylan.portlets.action.util;

import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.portlets.action.model.TrainingProgram;
import com.portlets.action.service.TrainingProgramLocalServiceUtil;

public class TrainingProgramActionUtil {

	/**
	 * @param eduId
	 * @return null if exception
	 */
	@SuppressWarnings("unchecked")
	public static List<TrainingProgram> getTrainingProByEduId(long eduId) 
			throws Exception {
		
		try {
			DynamicQuery dq = DynamicQueryFactoryUtil.forClass(TrainingProgram.class);
			dq.add(PropertyFactoryUtil.forName("educatorId").eq(eduId));
			
			return TrainingProgramLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			_log.info("loi dq");
			_log.error(e.getClass() + "\n" + e.getMessage());
			return null;
		}
	}
	
	public static TrainingProgram updateTrainingPro(long proId, String name, double fee, String purpose,
			String period, String description, String diploma) throws Exception {
		
		try {
			
			TrainingProgram trainPro = TrainingProgramLocalServiceUtil.getTrainingProgram(proId);
			
			trainPro.setTrainingProgramName(name);
			trainPro.setTrainingProgramFee(fee);
			trainPro.setTrainingProgramPurpose(purpose);
			trainPro.setTrainingProgramPeriod(period);
			trainPro.setTrainingProgramDiploma(diploma);
			trainPro.setTrainingProgramDescription(description);
			
			TrainingProgram train = TrainingProgramLocalServiceUtil.updateTrainingProgram(trainPro);
			
			return train;
			
		}catch(Exception e) {
			_log.error(e);
			return null;
		}
	}
	
	private static Log _log = LogFactoryUtil.getLog(TrainingProgramActionUtil.class);
}
