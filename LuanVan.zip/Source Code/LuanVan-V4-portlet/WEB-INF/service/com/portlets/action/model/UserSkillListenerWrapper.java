/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link UserSkillListener}.
 * </p>
 *
 * @author Computer
 * @see UserSkillListener
 * @generated
 */
public class UserSkillListenerWrapper implements UserSkillListener,
	ModelWrapper<UserSkillListener> {
	public UserSkillListenerWrapper(UserSkillListener userSkillListener) {
		_userSkillListener = userSkillListener;
	}

	@Override
	public Class<?> getModelClass() {
		return UserSkillListener.class;
	}

	@Override
	public String getModelClassName() {
		return UserSkillListener.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userObjectId", getUserObjectId());
		attributes.put("skillId", getSkillId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		Long skillId = (Long)attributes.get("skillId");

		if (skillId != null) {
			setSkillId(skillId);
		}
	}

	/**
	* Returns the primary key of this user skill listener.
	*
	* @return the primary key of this user skill listener
	*/
	@Override
	public com.portlets.action.service.persistence.UserSkillListenerPK getPrimaryKey() {
		return _userSkillListener.getPrimaryKey();
	}

	/**
	* Sets the primary key of this user skill listener.
	*
	* @param primaryKey the primary key of this user skill listener
	*/
	@Override
	public void setPrimaryKey(
		com.portlets.action.service.persistence.UserSkillListenerPK primaryKey) {
		_userSkillListener.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the user object ID of this user skill listener.
	*
	* @return the user object ID of this user skill listener
	*/
	@Override
	public long getUserObjectId() {
		return _userSkillListener.getUserObjectId();
	}

	/**
	* Sets the user object ID of this user skill listener.
	*
	* @param userObjectId the user object ID of this user skill listener
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_userSkillListener.setUserObjectId(userObjectId);
	}

	/**
	* Returns the skill ID of this user skill listener.
	*
	* @return the skill ID of this user skill listener
	*/
	@Override
	public long getSkillId() {
		return _userSkillListener.getSkillId();
	}

	/**
	* Sets the skill ID of this user skill listener.
	*
	* @param skillId the skill ID of this user skill listener
	*/
	@Override
	public void setSkillId(long skillId) {
		_userSkillListener.setSkillId(skillId);
	}

	@Override
	public boolean isNew() {
		return _userSkillListener.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_userSkillListener.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _userSkillListener.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_userSkillListener.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _userSkillListener.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _userSkillListener.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_userSkillListener.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _userSkillListener.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_userSkillListener.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_userSkillListener.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_userSkillListener.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new UserSkillListenerWrapper((UserSkillListener)_userSkillListener.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.UserSkillListener userSkillListener) {
		return _userSkillListener.compareTo(userSkillListener);
	}

	@Override
	public int hashCode() {
		return _userSkillListener.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.UserSkillListener> toCacheModel() {
		return _userSkillListener.toCacheModel();
	}

	@Override
	public com.portlets.action.model.UserSkillListener toEscapedModel() {
		return new UserSkillListenerWrapper(_userSkillListener.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.UserSkillListener toUnescapedModel() {
		return new UserSkillListenerWrapper(_userSkillListener.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _userSkillListener.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _userSkillListener.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_userSkillListener.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserSkillListenerWrapper)) {
			return false;
		}

		UserSkillListenerWrapper userSkillListenerWrapper = (UserSkillListenerWrapper)obj;

		if (Validator.equals(_userSkillListener,
					userSkillListenerWrapper._userSkillListener)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public UserSkillListener getWrappedUserSkillListener() {
		return _userSkillListener;
	}

	@Override
	public UserSkillListener getWrappedModel() {
		return _userSkillListener;
	}

	@Override
	public void resetOriginalValues() {
		_userSkillListener.resetOriginalValues();
	}

	private UserSkillListener _userSkillListener;
}