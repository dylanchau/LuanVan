package com.kimtho.portlet.training;

import java.io.IOException;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.RegisterCourse;
import com.portlets.action.model.impl.RegisterCourseImpl;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.RegisterCourseLocalServiceUtil;


/**
 * 
 * @author Kim Tho
 *
 */

public class TrainingPortlet extends MVCPortlet{
	

	/**
	 * 
	 * This method will persist the data in database
	 * @throws SystemException 
	 * @throws IOException 
	 * @throws PortalException 
	 */
	@ProcessAction(name = "registerCourse")
	public void registerCourse(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException, PortalException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long courseId = ParamUtil.getLong(actionRequest, "courseId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		List<RegisterCourse> studentRegistered = RegisterCourseLocalServiceUtil.getByCourseId(courseId);
		int no = CourseLocalServiceUtil.getCourse(courseId).getCourseStudentNo();
		if(studentRegistered.size() >= no) {
			actionResponse.sendRedirect(redirect);
			SessionErrors.add(actionRequest.getPortletSession(), "fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		} else {
			RegisterCourse registerCourse = new RegisterCourseImpl();
			registerCourse.setUserObjectId(userId);
			registerCourse.setCourseId(courseId);
			registerCourse.setStatesId(new Long(10));
			RegisterCourseLocalServiceUtil.addRegisterCourse(registerCourse);
			SessionMessages.add(actionRequest, "added-registerCourse"); 
			actionResponse.sendRedirect(redirect);
			SessionMessages.add(actionRequest.getPortletSession(), "success");
		}
	   _log.info("#################Added Register Course Successfully#########################");
	}
	
	@ProcessAction(name = "unRegisterCourse")
	public void unRegisterCourse(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long courseId = ParamUtil.getLong(actionRequest, "courseId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterCourse registerCourse = new RegisterCourseImpl();
		registerCourse.setUserObjectId(userId);
		registerCourse.setCourseId(courseId);
		registerCourse.setStatesId(new Long(10));
		RegisterCourseLocalServiceUtil.deleteRegisterCourse(registerCourse);
		SessionMessages.add(actionRequest, "deleted-registerCourse"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Deleted Register Course Successfully#########################");
	}
	
	private Log _log = LogFactoryUtil.getLog(TrainingPortlet.class.getName());

}
