/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.portlets.action.model.LinkUsers;

/**
 * The persistence interface for the link users service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see LinkUsersPersistenceImpl
 * @see LinkUsersUtil
 * @generated
 */
public interface LinkUsersPersistence extends BasePersistence<LinkUsers> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link LinkUsersUtil} to access the link users persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the link userses where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @return the matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findByuserIdA(
		long userIdA)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the link userses where userIdA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdA the user ID a
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findByuserIdA(
		long userIdA, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the link userses where userIdA = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdA the user ID a
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findByuserIdA(
		long userIdA, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers findByuserIdA_First(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Returns the first link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers fetchByuserIdA_First(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers findByuserIdA_Last(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Returns the last link users in the ordered set where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers fetchByuserIdA_Last(
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the link userses before and after the current link users in the ordered set where userIdA = &#63;.
	*
	* @param linkUsersPK the primary key of the current link users
	* @param userIdA the user ID a
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers[] findByuserIdA_PrevAndNext(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK,
		long userIdA,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Removes all the link userses where userIdA = &#63; from the database.
	*
	* @param userIdA the user ID a
	* @throws SystemException if a system exception occurred
	*/
	public void removeByuserIdA(long userIdA)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of link userses where userIdA = &#63;.
	*
	* @param userIdA the user ID a
	* @return the number of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public int countByuserIdA(long userIdA)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the link userses where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @return the matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findByuserIdB(
		long userIdB)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the link userses where userIdB = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdB the user ID b
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findByuserIdB(
		long userIdB, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the link userses where userIdB = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userIdB the user ID b
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findByuserIdB(
		long userIdB, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers findByuserIdB_First(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Returns the first link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers fetchByuserIdB_First(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers findByuserIdB_Last(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Returns the last link users in the ordered set where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers fetchByuserIdB_Last(
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the link userses before and after the current link users in the ordered set where userIdB = &#63;.
	*
	* @param linkUsersPK the primary key of the current link users
	* @param userIdB the user ID b
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers[] findByuserIdB_PrevAndNext(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK,
		long userIdB,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Removes all the link userses where userIdB = &#63; from the database.
	*
	* @param userIdB the user ID b
	* @throws SystemException if a system exception occurred
	*/
	public void removeByuserIdB(long userIdB)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of link userses where userIdB = &#63;.
	*
	* @param userIdB the user ID b
	* @return the number of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public int countByuserIdB(long userIdB)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the link userses where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @return the matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findBylinkUsersNumber(
		int linkUsersNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the link userses where linkUsersNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUsersNumber the link users number
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findBylinkUsersNumber(
		int linkUsersNumber, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the link userses where linkUsersNumber = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param linkUsersNumber the link users number
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findBylinkUsersNumber(
		int linkUsersNumber, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers findBylinkUsersNumber_First(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Returns the first link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers fetchBylinkUsersNumber_First(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers findBylinkUsersNumber_Last(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Returns the last link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching link users, or <code>null</code> if a matching link users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers fetchBylinkUsersNumber_Last(
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the link userses before and after the current link users in the ordered set where linkUsersNumber = &#63;.
	*
	* @param linkUsersPK the primary key of the current link users
	* @param linkUsersNumber the link users number
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers[] findBylinkUsersNumber_PrevAndNext(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK,
		int linkUsersNumber,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Removes all the link userses where linkUsersNumber = &#63; from the database.
	*
	* @param linkUsersNumber the link users number
	* @throws SystemException if a system exception occurred
	*/
	public void removeBylinkUsersNumber(int linkUsersNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of link userses where linkUsersNumber = &#63;.
	*
	* @param linkUsersNumber the link users number
	* @return the number of matching link userses
	* @throws SystemException if a system exception occurred
	*/
	public int countBylinkUsersNumber(int linkUsersNumber)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the link users in the entity cache if it is enabled.
	*
	* @param linkUsers the link users
	*/
	public void cacheResult(com.portlets.action.model.LinkUsers linkUsers);

	/**
	* Caches the link userses in the entity cache if it is enabled.
	*
	* @param linkUserses the link userses
	*/
	public void cacheResult(
		java.util.List<com.portlets.action.model.LinkUsers> linkUserses);

	/**
	* Creates a new link users with the primary key. Does not add the link users to the database.
	*
	* @param linkUsersPK the primary key for the new link users
	* @return the new link users
	*/
	public com.portlets.action.model.LinkUsers create(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK);

	/**
	* Removes the link users with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param linkUsersPK the primary key of the link users
	* @return the link users that was removed
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers remove(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	public com.portlets.action.model.LinkUsers updateImpl(
		com.portlets.action.model.LinkUsers linkUsers)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the link users with the primary key or throws a {@link com.portlets.action.NoSuchLinkUsersException} if it could not be found.
	*
	* @param linkUsersPK the primary key of the link users
	* @return the link users
	* @throws com.portlets.action.NoSuchLinkUsersException if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers findByPrimaryKey(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLinkUsersException;

	/**
	* Returns the link users with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param linkUsersPK the primary key of the link users
	* @return the link users, or <code>null</code> if a link users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.LinkUsers fetchByPrimaryKey(
		com.portlets.action.service.persistence.LinkUsersPK linkUsersPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the link userses.
	*
	* @return the link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the link userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @return the range of link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the link userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LinkUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of link userses
	* @param end the upper bound of the range of link userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of link userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.LinkUsers> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the link userses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of link userses.
	*
	* @return the number of link userses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}