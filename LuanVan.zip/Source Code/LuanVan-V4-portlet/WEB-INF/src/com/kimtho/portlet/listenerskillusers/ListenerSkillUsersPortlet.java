package com.kimtho.portlet.listenerskillusers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.ProcessAction;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.kimtho.portlet.ActionUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.Skill;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.model.impl.UserSkillListenerImpl;
import com.portlets.action.service.SkillLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;

/**
 * Portlet implementation class ListenerSkillUsersPortlet
 */
public class ListenerSkillUsersPortlet extends MVCPortlet {
	/**
	 * 
	 * This method will persist the data in database
	 * @throws PortalException 
	 */
	@ProcessAction(name = "addUserSkillListener")
	public void addUserSkillListener(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		UserSkillListener userSkillListener = ActionUtil.userSkillListenerFromRequest(actionRequest);
		try {
			UserSkillListenerLocalServiceUtil.getUserSkillListener(userSkillListener.getPrimaryKey());
			SessionMessages.add(actionRequest, "noadded-listener-skills_users"); 
			_log.info("#################No Added Listener Skills Users#########################");
		} catch (Exception e){
			UserSkillListenerLocalServiceUtil.addUserSkillListener(userSkillListener);
			SessionMessages.add(actionRequest, "added-listener-skills_users"); 
		   _log.info("#################Added Listener Skills Users Successfully#########################");
		}
	}
	
	@ProcessAction(name = "addListUserSkillListener")
	public void addListUserSkillListener(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String skillIds_v2 = ParamUtil.getString(actionRequest, "skills");
		
		String[] stringArray = skillIds_v2.split(" "); 
		String skillsList = Arrays.toString(stringArray); 
		skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
		long[] skillIds = new long[stringArray.length];
		for(int i = 0; i < skillIds.length; i++) {
			skillIds[i] = Long.parseLong(stringArray[i]);
		}
		for(long s:skillIds){
			UserSkillListener userSkillListener = new UserSkillListenerImpl();
			userSkillListener.setSkillId(s);
			userSkillListener.setUserObjectId(userId);
			try {
				UserSkillListenerLocalServiceUtil.getUserSkillListener(userSkillListener.getPrimaryKey());
				SessionMessages.add(actionRequest, "noadded-listener-skills_users"); 
				_log.info("#################No Added Listener Skills Users#########################");
			} catch (Exception e){
				UserSkillListenerLocalServiceUtil.addUserSkillListener(userSkillListener);
				SessionMessages.add(actionRequest, "added-listener-skills_users"); 
			   _log.info("#################Added Listener Skills Users Successfully#########################");
			}
		}
	}
	
	@ProcessAction(name = "deleteUserSkillListener")
	public void deleteUserSkillListener(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long skillId = ParamUtil.getLong(actionRequest, "skillId");
		long userObjectId = ParamUtil.getLong(actionRequest, "userObjectId");
		UserSkillListener userSkillListener = new UserSkillListenerImpl();
		userSkillListener.setSkillId(skillId);
		userSkillListener.setUserObjectId(userObjectId);
		
		UserSkillListenerLocalServiceUtil.deleteUserSkillListener(userSkillListener);
		SessionMessages.add(actionRequest, "deleted-listener-skills_users"); 
		_log.info("#################Listener Skills Users Deleted Successfully#########################");
	}
	
	
	public void serveResource(ResourceRequest resourceRequest,
            ResourceResponse resourceResponse) throws IOException, PortletException {
		
		@SuppressWarnings("static-access")
		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
		String cmd = ParamUtil.getString(resourceRequest, "cmd", "");
		 if(cmd.equals("testabc")) {
			Skill skill = null;
			long[] skillIds = ParamUtil.getLongValues(resourceRequest, "skillIds");
			int skillIdslength = skillIds.length;
			_log.info(skillIdslength);
			if(skillIdslength > 0) {
				for(int i = 0; i < skillIds.length; i++) {
					_log.info(skillIds[i]);
					try {
						skill = SkillLocalServiceUtil.getSkill(skillIds[i]);
					} catch (PortalException e) {
						e.printStackTrace();
					} catch (SystemException e) {
						e.printStackTrace();
					}
					JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
					jsonObject.put("id", skillIds[i]);
					jsonObject.put("name", skill.getSkillName());
					jsonArray.put(jsonObject);
				}
			}
			
			PrintWriter writer = resourceResponse.getWriter();
			writer.print(jsonArray.toString());
			writer.flush(); writer.close();
		}
		super.serveResource(resourceRequest, resourceResponse);
	}
	
	private Log _log = LogFactoryUtil.getLog(ListenerSkillUsersPortlet.class.getName());

}

