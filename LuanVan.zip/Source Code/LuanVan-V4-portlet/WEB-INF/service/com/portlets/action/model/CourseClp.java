/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.CourseLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class CourseClp extends BaseModelImpl<Course> implements Course {
	public CourseClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Course.class;
	}

	@Override
	public String getModelClassName() {
		return Course.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _courseId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setCourseId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _courseId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("courseId", getCourseId());
		attributes.put("courseName", getCourseName());
		attributes.put("courseStudentNo", getCourseStudentNo());
		attributes.put("courseStartDate", getCourseStartDate());
		attributes.put("courseEnrollStartDate", getCourseEnrollStartDate());
		attributes.put("courseSchoolDay", getCourseSchoolDay());
		attributes.put("courseEnrollDeadLine", getCourseEnrollDeadLine());
		attributes.put("statesId", getStatesId());
		attributes.put("trainingProgramId", getTrainingProgramId());
		attributes.put("educatorId", getEducatorId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long courseId = (Long)attributes.get("courseId");

		if (courseId != null) {
			setCourseId(courseId);
		}

		String courseName = (String)attributes.get("courseName");

		if (courseName != null) {
			setCourseName(courseName);
		}

		Integer courseStudentNo = (Integer)attributes.get("courseStudentNo");

		if (courseStudentNo != null) {
			setCourseStudentNo(courseStudentNo);
		}

		Date courseStartDate = (Date)attributes.get("courseStartDate");

		if (courseStartDate != null) {
			setCourseStartDate(courseStartDate);
		}

		Date courseEnrollStartDate = (Date)attributes.get(
				"courseEnrollStartDate");

		if (courseEnrollStartDate != null) {
			setCourseEnrollStartDate(courseEnrollStartDate);
		}

		String courseSchoolDay = (String)attributes.get("courseSchoolDay");

		if (courseSchoolDay != null) {
			setCourseSchoolDay(courseSchoolDay);
		}

		Date courseEnrollDeadLine = (Date)attributes.get("courseEnrollDeadLine");

		if (courseEnrollDeadLine != null) {
			setCourseEnrollDeadLine(courseEnrollDeadLine);
		}

		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}

		Long trainingProgramId = (Long)attributes.get("trainingProgramId");

		if (trainingProgramId != null) {
			setTrainingProgramId(trainingProgramId);
		}

		Long educatorId = (Long)attributes.get("educatorId");

		if (educatorId != null) {
			setEducatorId(educatorId);
		}
	}

	@Override
	public long getCourseId() {
		return _courseId;
	}

	@Override
	public void setCourseId(long courseId) {
		_courseId = courseId;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setCourseId", long.class);

				method.invoke(_courseRemoteModel, courseId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCourseName() {
		return _courseName;
	}

	@Override
	public void setCourseName(String courseName) {
		_courseName = courseName;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setCourseName", String.class);

				method.invoke(_courseRemoteModel, courseName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getCourseStudentNo() {
		return _courseStudentNo;
	}

	@Override
	public void setCourseStudentNo(int courseStudentNo) {
		_courseStudentNo = courseStudentNo;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setCourseStudentNo", int.class);

				method.invoke(_courseRemoteModel, courseStudentNo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCourseStartDate() {
		return _courseStartDate;
	}

	@Override
	public void setCourseStartDate(Date courseStartDate) {
		_courseStartDate = courseStartDate;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setCourseStartDate", Date.class);

				method.invoke(_courseRemoteModel, courseStartDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCourseEnrollStartDate() {
		return _courseEnrollStartDate;
	}

	@Override
	public void setCourseEnrollStartDate(Date courseEnrollStartDate) {
		_courseEnrollStartDate = courseEnrollStartDate;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setCourseEnrollStartDate",
						Date.class);

				method.invoke(_courseRemoteModel, courseEnrollStartDate);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getCourseSchoolDay() {
		return _courseSchoolDay;
	}

	@Override
	public void setCourseSchoolDay(String courseSchoolDay) {
		_courseSchoolDay = courseSchoolDay;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setCourseSchoolDay",
						String.class);

				method.invoke(_courseRemoteModel, courseSchoolDay);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getCourseEnrollDeadLine() {
		return _courseEnrollDeadLine;
	}

	@Override
	public void setCourseEnrollDeadLine(Date courseEnrollDeadLine) {
		_courseEnrollDeadLine = courseEnrollDeadLine;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setCourseEnrollDeadLine",
						Date.class);

				method.invoke(_courseRemoteModel, courseEnrollDeadLine);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getStatesId() {
		return _statesId;
	}

	@Override
	public void setStatesId(long statesId) {
		_statesId = statesId;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setStatesId", long.class);

				method.invoke(_courseRemoteModel, statesId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getTrainingProgramId() {
		return _trainingProgramId;
	}

	@Override
	public void setTrainingProgramId(long trainingProgramId) {
		_trainingProgramId = trainingProgramId;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramId",
						long.class);

				method.invoke(_courseRemoteModel, trainingProgramId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getEducatorId() {
		return _educatorId;
	}

	@Override
	public void setEducatorId(long educatorId) {
		_educatorId = educatorId;

		if (_courseRemoteModel != null) {
			try {
				Class<?> clazz = _courseRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorId", long.class);

				method.invoke(_courseRemoteModel, educatorId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getCourseRemoteModel() {
		return _courseRemoteModel;
	}

	public void setCourseRemoteModel(BaseModel<?> courseRemoteModel) {
		_courseRemoteModel = courseRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _courseRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_courseRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			CourseLocalServiceUtil.addCourse(this);
		}
		else {
			CourseLocalServiceUtil.updateCourse(this);
		}
	}

	@Override
	public Course toEscapedModel() {
		return (Course)ProxyUtil.newProxyInstance(Course.class.getClassLoader(),
			new Class[] { Course.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		CourseClp clone = new CourseClp();

		clone.setCourseId(getCourseId());
		clone.setCourseName(getCourseName());
		clone.setCourseStudentNo(getCourseStudentNo());
		clone.setCourseStartDate(getCourseStartDate());
		clone.setCourseEnrollStartDate(getCourseEnrollStartDate());
		clone.setCourseSchoolDay(getCourseSchoolDay());
		clone.setCourseEnrollDeadLine(getCourseEnrollDeadLine());
		clone.setStatesId(getStatesId());
		clone.setTrainingProgramId(getTrainingProgramId());
		clone.setEducatorId(getEducatorId());

		return clone;
	}

	@Override
	public int compareTo(Course course) {
		long primaryKey = course.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CourseClp)) {
			return false;
		}

		CourseClp course = (CourseClp)obj;

		long primaryKey = course.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{courseId=");
		sb.append(getCourseId());
		sb.append(", courseName=");
		sb.append(getCourseName());
		sb.append(", courseStudentNo=");
		sb.append(getCourseStudentNo());
		sb.append(", courseStartDate=");
		sb.append(getCourseStartDate());
		sb.append(", courseEnrollStartDate=");
		sb.append(getCourseEnrollStartDate());
		sb.append(", courseSchoolDay=");
		sb.append(getCourseSchoolDay());
		sb.append(", courseEnrollDeadLine=");
		sb.append(getCourseEnrollDeadLine());
		sb.append(", statesId=");
		sb.append(getStatesId());
		sb.append(", trainingProgramId=");
		sb.append(getTrainingProgramId());
		sb.append(", educatorId=");
		sb.append(getEducatorId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(34);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.Course");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>courseId</column-name><column-value><![CDATA[");
		sb.append(getCourseId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>courseName</column-name><column-value><![CDATA[");
		sb.append(getCourseName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>courseStudentNo</column-name><column-value><![CDATA[");
		sb.append(getCourseStudentNo());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>courseStartDate</column-name><column-value><![CDATA[");
		sb.append(getCourseStartDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>courseEnrollStartDate</column-name><column-value><![CDATA[");
		sb.append(getCourseEnrollStartDate());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>courseSchoolDay</column-name><column-value><![CDATA[");
		sb.append(getCourseSchoolDay());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>courseEnrollDeadLine</column-name><column-value><![CDATA[");
		sb.append(getCourseEnrollDeadLine());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statesId</column-name><column-value><![CDATA[");
		sb.append(getStatesId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramId</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorId</column-name><column-value><![CDATA[");
		sb.append(getEducatorId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _courseId;
	private String _courseName;
	private int _courseStudentNo;
	private Date _courseStartDate;
	private Date _courseEnrollStartDate;
	private String _courseSchoolDay;
	private Date _courseEnrollDeadLine;
	private long _statesId;
	private long _trainingProgramId;
	private long _educatorId;
	private BaseModel<?> _courseRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}