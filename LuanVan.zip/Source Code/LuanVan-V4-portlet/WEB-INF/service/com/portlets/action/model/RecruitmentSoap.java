/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.RecruitmentServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.RecruitmentServiceSoap
 * @generated
 */
public class RecruitmentSoap implements Serializable {
	public static RecruitmentSoap toSoapModel(Recruitment model) {
		RecruitmentSoap soapModel = new RecruitmentSoap();

		soapModel.setRecruitmentId(model.getRecruitmentId());
		soapModel.setRecruitmentName(model.getRecruitmentName());
		soapModel.setRecruitmentPosition(model.getRecruitmentPosition());
		soapModel.setRecruitmentDescription(model.getRecruitmentDescription());
		soapModel.setRecruitmentBenefit(model.getRecruitmentBenefit());
		soapModel.setRecruitmentJobType(model.getRecruitmentJobType());
		soapModel.setRecruitmentFileReq(model.getRecruitmentFileReq());
		soapModel.setRecruitmentFileDeadlineFrom(model.getRecruitmentFileDeadlineFrom());
		soapModel.setRecruitmentFileDeadlineTo(model.getRecruitmentFileDeadlineTo());
		soapModel.setRecruitmentSalary(model.getRecruitmentSalary());
		soapModel.setRecruitmentNo(model.getRecruitmentNo());
		soapModel.setRecruitmentGender(model.getRecruitmentGender());
		soapModel.setRecruitmentQualification(model.getRecruitmentQualification());
		soapModel.setRecruitmentAgeFrom(model.getRecruitmentAgeFrom());
		soapModel.setRecruitmentAgeTo(model.getRecruitmentAgeTo());
		soapModel.setRecruitmentExper(model.getRecruitmentExper());
		soapModel.setEmployerId(model.getEmployerId());
		soapModel.setStatesId(model.getStatesId());

		return soapModel;
	}

	public static RecruitmentSoap[] toSoapModels(Recruitment[] models) {
		RecruitmentSoap[] soapModels = new RecruitmentSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static RecruitmentSoap[][] toSoapModels(Recruitment[][] models) {
		RecruitmentSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new RecruitmentSoap[models.length][models[0].length];
		}
		else {
			soapModels = new RecruitmentSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static RecruitmentSoap[] toSoapModels(List<Recruitment> models) {
		List<RecruitmentSoap> soapModels = new ArrayList<RecruitmentSoap>(models.size());

		for (Recruitment model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new RecruitmentSoap[soapModels.size()]);
	}

	public RecruitmentSoap() {
	}

	public long getPrimaryKey() {
		return _recruitmentId;
	}

	public void setPrimaryKey(long pk) {
		setRecruitmentId(pk);
	}

	public long getRecruitmentId() {
		return _recruitmentId;
	}

	public void setRecruitmentId(long recruitmentId) {
		_recruitmentId = recruitmentId;
	}

	public String getRecruitmentName() {
		return _recruitmentName;
	}

	public void setRecruitmentName(String recruitmentName) {
		_recruitmentName = recruitmentName;
	}

	public String getRecruitmentPosition() {
		return _recruitmentPosition;
	}

	public void setRecruitmentPosition(String recruitmentPosition) {
		_recruitmentPosition = recruitmentPosition;
	}

	public String getRecruitmentDescription() {
		return _recruitmentDescription;
	}

	public void setRecruitmentDescription(String recruitmentDescription) {
		_recruitmentDescription = recruitmentDescription;
	}

	public String getRecruitmentBenefit() {
		return _recruitmentBenefit;
	}

	public void setRecruitmentBenefit(String recruitmentBenefit) {
		_recruitmentBenefit = recruitmentBenefit;
	}

	public String getRecruitmentJobType() {
		return _recruitmentJobType;
	}

	public void setRecruitmentJobType(String recruitmentJobType) {
		_recruitmentJobType = recruitmentJobType;
	}

	public String getRecruitmentFileReq() {
		return _recruitmentFileReq;
	}

	public void setRecruitmentFileReq(String recruitmentFileReq) {
		_recruitmentFileReq = recruitmentFileReq;
	}

	public Date getRecruitmentFileDeadlineFrom() {
		return _recruitmentFileDeadlineFrom;
	}

	public void setRecruitmentFileDeadlineFrom(Date recruitmentFileDeadlineFrom) {
		_recruitmentFileDeadlineFrom = recruitmentFileDeadlineFrom;
	}

	public Date getRecruitmentFileDeadlineTo() {
		return _recruitmentFileDeadlineTo;
	}

	public void setRecruitmentFileDeadlineTo(Date recruitmentFileDeadlineTo) {
		_recruitmentFileDeadlineTo = recruitmentFileDeadlineTo;
	}

	public String getRecruitmentSalary() {
		return _recruitmentSalary;
	}

	public void setRecruitmentSalary(String recruitmentSalary) {
		_recruitmentSalary = recruitmentSalary;
	}

	public int getRecruitmentNo() {
		return _recruitmentNo;
	}

	public void setRecruitmentNo(int recruitmentNo) {
		_recruitmentNo = recruitmentNo;
	}

	public String getRecruitmentGender() {
		return _recruitmentGender;
	}

	public void setRecruitmentGender(String recruitmentGender) {
		_recruitmentGender = recruitmentGender;
	}

	public String getRecruitmentQualification() {
		return _recruitmentQualification;
	}

	public void setRecruitmentQualification(String recruitmentQualification) {
		_recruitmentQualification = recruitmentQualification;
	}

	public int getRecruitmentAgeFrom() {
		return _recruitmentAgeFrom;
	}

	public void setRecruitmentAgeFrom(int recruitmentAgeFrom) {
		_recruitmentAgeFrom = recruitmentAgeFrom;
	}

	public int getRecruitmentAgeTo() {
		return _recruitmentAgeTo;
	}

	public void setRecruitmentAgeTo(int recruitmentAgeTo) {
		_recruitmentAgeTo = recruitmentAgeTo;
	}

	public String getRecruitmentExper() {
		return _recruitmentExper;
	}

	public void setRecruitmentExper(String recruitmentExper) {
		_recruitmentExper = recruitmentExper;
	}

	public long getEmployerId() {
		return _employerId;
	}

	public void setEmployerId(long employerId) {
		_employerId = employerId;
	}

	public long getStatesId() {
		return _statesId;
	}

	public void setStatesId(long statesId) {
		_statesId = statesId;
	}

	private long _recruitmentId;
	private String _recruitmentName;
	private String _recruitmentPosition;
	private String _recruitmentDescription;
	private String _recruitmentBenefit;
	private String _recruitmentJobType;
	private String _recruitmentFileReq;
	private Date _recruitmentFileDeadlineFrom;
	private Date _recruitmentFileDeadlineTo;
	private String _recruitmentSalary;
	private int _recruitmentNo;
	private String _recruitmentGender;
	private String _recruitmentQualification;
	private int _recruitmentAgeFrom;
	private int _recruitmentAgeTo;
	private String _recruitmentExper;
	private long _employerId;
	private long _statesId;
}