/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link States}.
 * </p>
 *
 * @author Computer
 * @see States
 * @generated
 */
public class StatesWrapper implements States, ModelWrapper<States> {
	public StatesWrapper(States states) {
		_states = states;
	}

	@Override
	public Class<?> getModelClass() {
		return States.class;
	}

	@Override
	public String getModelClassName() {
		return States.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("statesId", getStatesId());
		attributes.put("statesName", getStatesName());
		attributes.put("statesExplain", getStatesExplain());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}

		String statesName = (String)attributes.get("statesName");

		if (statesName != null) {
			setStatesName(statesName);
		}

		String statesExplain = (String)attributes.get("statesExplain");

		if (statesExplain != null) {
			setStatesExplain(statesExplain);
		}
	}

	/**
	* Returns the primary key of this states.
	*
	* @return the primary key of this states
	*/
	@Override
	public long getPrimaryKey() {
		return _states.getPrimaryKey();
	}

	/**
	* Sets the primary key of this states.
	*
	* @param primaryKey the primary key of this states
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_states.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the states ID of this states.
	*
	* @return the states ID of this states
	*/
	@Override
	public long getStatesId() {
		return _states.getStatesId();
	}

	/**
	* Sets the states ID of this states.
	*
	* @param statesId the states ID of this states
	*/
	@Override
	public void setStatesId(long statesId) {
		_states.setStatesId(statesId);
	}

	/**
	* Returns the states name of this states.
	*
	* @return the states name of this states
	*/
	@Override
	public java.lang.String getStatesName() {
		return _states.getStatesName();
	}

	/**
	* Sets the states name of this states.
	*
	* @param statesName the states name of this states
	*/
	@Override
	public void setStatesName(java.lang.String statesName) {
		_states.setStatesName(statesName);
	}

	/**
	* Returns the states explain of this states.
	*
	* @return the states explain of this states
	*/
	@Override
	public java.lang.String getStatesExplain() {
		return _states.getStatesExplain();
	}

	/**
	* Sets the states explain of this states.
	*
	* @param statesExplain the states explain of this states
	*/
	@Override
	public void setStatesExplain(java.lang.String statesExplain) {
		_states.setStatesExplain(statesExplain);
	}

	@Override
	public boolean isNew() {
		return _states.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_states.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _states.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_states.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _states.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _states.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_states.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _states.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_states.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_states.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_states.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new StatesWrapper((States)_states.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.States states) {
		return _states.compareTo(states);
	}

	@Override
	public int hashCode() {
		return _states.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.States> toCacheModel() {
		return _states.toCacheModel();
	}

	@Override
	public com.portlets.action.model.States toEscapedModel() {
		return new StatesWrapper(_states.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.States toUnescapedModel() {
		return new StatesWrapper(_states.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _states.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _states.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_states.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof StatesWrapper)) {
			return false;
		}

		StatesWrapper statesWrapper = (StatesWrapper)obj;

		if (Validator.equals(_states, statesWrapper._states)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public States getWrappedStates() {
		return _states;
	}

	@Override
	public States getWrappedModel() {
		return _states;
	}

	@Override
	public void resetOriginalValues() {
		_states.resetOriginalValues();
	}

	private States _states;
}