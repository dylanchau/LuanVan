/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayInputStream;
import com.liferay.portal.kernel.io.unsync.UnsyncByteArrayOutputStream;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ClassLoaderObjectInputStream;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.BaseModel;

import com.portlets.action.model.CourseClp;
import com.portlets.action.model.EducationUsersClp;
import com.portlets.action.model.EducatorClp;
import com.portlets.action.model.EmployerClp;
import com.portlets.action.model.ExperienceUsersClp;
import com.portlets.action.model.LevelClp;
import com.portlets.action.model.LinkUserCourseClp;
import com.portlets.action.model.LinkUserRecruitmentClp;
import com.portlets.action.model.LinkUsersClp;
import com.portlets.action.model.RecruitmentClp;
import com.portlets.action.model.RegisterCourseClp;
import com.portlets.action.model.RegisterRecruitmentClp;
import com.portlets.action.model.SkillClp;
import com.portlets.action.model.StatesClp;
import com.portlets.action.model.TrainingProgramClp;
import com.portlets.action.model.UserObjectClp;
import com.portlets.action.model.UserSkillLevelClp;
import com.portlets.action.model.UserSkillListenerClp;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Computer
 */
public class ClpSerializer {
	public static String getServletContextName() {
		if (Validator.isNotNull(_servletContextName)) {
			return _servletContextName;
		}

		synchronized (ClpSerializer.class) {
			if (Validator.isNotNull(_servletContextName)) {
				return _servletContextName;
			}

			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Class<?> portletPropsClass = classLoader.loadClass(
						"com.liferay.util.portlet.PortletProps");

				Method getMethod = portletPropsClass.getMethod("get",
						new Class<?>[] { String.class });

				String portletPropsServletContextName = (String)getMethod.invoke(null,
						"LuanVan-V4-portlet-deployment-context");

				if (Validator.isNotNull(portletPropsServletContextName)) {
					_servletContextName = portletPropsServletContextName;
				}
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info(
						"Unable to locate deployment context from portlet properties");
				}
			}

			if (Validator.isNull(_servletContextName)) {
				try {
					String propsUtilServletContextName = PropsUtil.get(
							"LuanVan-V4-portlet-deployment-context");

					if (Validator.isNotNull(propsUtilServletContextName)) {
						_servletContextName = propsUtilServletContextName;
					}
				}
				catch (Throwable t) {
					if (_log.isInfoEnabled()) {
						_log.info(
							"Unable to locate deployment context from portal properties");
					}
				}
			}

			if (Validator.isNull(_servletContextName)) {
				_servletContextName = "LuanVan-V4-portlet";
			}

			return _servletContextName;
		}
	}

	public static Object translateInput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(CourseClp.class.getName())) {
			return translateInputCourse(oldModel);
		}

		if (oldModelClassName.equals(EducationUsersClp.class.getName())) {
			return translateInputEducationUsers(oldModel);
		}

		if (oldModelClassName.equals(EducatorClp.class.getName())) {
			return translateInputEducator(oldModel);
		}

		if (oldModelClassName.equals(EmployerClp.class.getName())) {
			return translateInputEmployer(oldModel);
		}

		if (oldModelClassName.equals(ExperienceUsersClp.class.getName())) {
			return translateInputExperienceUsers(oldModel);
		}

		if (oldModelClassName.equals(LevelClp.class.getName())) {
			return translateInputLevel(oldModel);
		}

		if (oldModelClassName.equals(LinkUserCourseClp.class.getName())) {
			return translateInputLinkUserCourse(oldModel);
		}

		if (oldModelClassName.equals(LinkUserRecruitmentClp.class.getName())) {
			return translateInputLinkUserRecruitment(oldModel);
		}

		if (oldModelClassName.equals(LinkUsersClp.class.getName())) {
			return translateInputLinkUsers(oldModel);
		}

		if (oldModelClassName.equals(RecruitmentClp.class.getName())) {
			return translateInputRecruitment(oldModel);
		}

		if (oldModelClassName.equals(RegisterCourseClp.class.getName())) {
			return translateInputRegisterCourse(oldModel);
		}

		if (oldModelClassName.equals(RegisterRecruitmentClp.class.getName())) {
			return translateInputRegisterRecruitment(oldModel);
		}

		if (oldModelClassName.equals(SkillClp.class.getName())) {
			return translateInputSkill(oldModel);
		}

		if (oldModelClassName.equals(StatesClp.class.getName())) {
			return translateInputStates(oldModel);
		}

		if (oldModelClassName.equals(TrainingProgramClp.class.getName())) {
			return translateInputTrainingProgram(oldModel);
		}

		if (oldModelClassName.equals(UserObjectClp.class.getName())) {
			return translateInputUserObject(oldModel);
		}

		if (oldModelClassName.equals(UserSkillLevelClp.class.getName())) {
			return translateInputUserSkillLevel(oldModel);
		}

		if (oldModelClassName.equals(UserSkillListenerClp.class.getName())) {
			return translateInputUserSkillListener(oldModel);
		}

		return oldModel;
	}

	public static Object translateInput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateInput(curObj));
		}

		return newList;
	}

	public static Object translateInputCourse(BaseModel<?> oldModel) {
		CourseClp oldClpModel = (CourseClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getCourseRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputEducationUsers(BaseModel<?> oldModel) {
		EducationUsersClp oldClpModel = (EducationUsersClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getEducationUsersRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputEducator(BaseModel<?> oldModel) {
		EducatorClp oldClpModel = (EducatorClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getEducatorRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputEmployer(BaseModel<?> oldModel) {
		EmployerClp oldClpModel = (EmployerClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getEmployerRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputExperienceUsers(BaseModel<?> oldModel) {
		ExperienceUsersClp oldClpModel = (ExperienceUsersClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getExperienceUsersRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputLevel(BaseModel<?> oldModel) {
		LevelClp oldClpModel = (LevelClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getLevelRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputLinkUserCourse(BaseModel<?> oldModel) {
		LinkUserCourseClp oldClpModel = (LinkUserCourseClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getLinkUserCourseRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputLinkUserRecruitment(
		BaseModel<?> oldModel) {
		LinkUserRecruitmentClp oldClpModel = (LinkUserRecruitmentClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getLinkUserRecruitmentRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputLinkUsers(BaseModel<?> oldModel) {
		LinkUsersClp oldClpModel = (LinkUsersClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getLinkUsersRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputRecruitment(BaseModel<?> oldModel) {
		RecruitmentClp oldClpModel = (RecruitmentClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getRecruitmentRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputRegisterCourse(BaseModel<?> oldModel) {
		RegisterCourseClp oldClpModel = (RegisterCourseClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getRegisterCourseRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputRegisterRecruitment(
		BaseModel<?> oldModel) {
		RegisterRecruitmentClp oldClpModel = (RegisterRecruitmentClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getRegisterRecruitmentRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputSkill(BaseModel<?> oldModel) {
		SkillClp oldClpModel = (SkillClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getSkillRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputStates(BaseModel<?> oldModel) {
		StatesClp oldClpModel = (StatesClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getStatesRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputTrainingProgram(BaseModel<?> oldModel) {
		TrainingProgramClp oldClpModel = (TrainingProgramClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getTrainingProgramRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputUserObject(BaseModel<?> oldModel) {
		UserObjectClp oldClpModel = (UserObjectClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getUserObjectRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputUserSkillLevel(BaseModel<?> oldModel) {
		UserSkillLevelClp oldClpModel = (UserSkillLevelClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getUserSkillLevelRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInputUserSkillListener(BaseModel<?> oldModel) {
		UserSkillListenerClp oldClpModel = (UserSkillListenerClp)oldModel;

		BaseModel<?> newModel = oldClpModel.getUserSkillListenerRemoteModel();

		newModel.setModelAttributes(oldClpModel.getModelAttributes());

		return newModel;
	}

	public static Object translateInput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateInput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateInput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Object translateOutput(BaseModel<?> oldModel) {
		Class<?> oldModelClass = oldModel.getClass();

		String oldModelClassName = oldModelClass.getName();

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.CourseImpl")) {
			return translateOutputCourse(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.EducationUsersImpl")) {
			return translateOutputEducationUsers(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.EducatorImpl")) {
			return translateOutputEducator(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.EmployerImpl")) {
			return translateOutputEmployer(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.ExperienceUsersImpl")) {
			return translateOutputExperienceUsers(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals("com.portlets.action.model.impl.LevelImpl")) {
			return translateOutputLevel(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.LinkUserCourseImpl")) {
			return translateOutputLinkUserCourse(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.LinkUserRecruitmentImpl")) {
			return translateOutputLinkUserRecruitment(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.LinkUsersImpl")) {
			return translateOutputLinkUsers(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.RecruitmentImpl")) {
			return translateOutputRecruitment(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.RegisterCourseImpl")) {
			return translateOutputRegisterCourse(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.RegisterRecruitmentImpl")) {
			return translateOutputRegisterRecruitment(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals("com.portlets.action.model.impl.SkillImpl")) {
			return translateOutputSkill(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.StatesImpl")) {
			return translateOutputStates(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.TrainingProgramImpl")) {
			return translateOutputTrainingProgram(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.UserObjectImpl")) {
			return translateOutputUserObject(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.UserSkillLevelImpl")) {
			return translateOutputUserSkillLevel(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		if (oldModelClassName.equals(
					"com.portlets.action.model.impl.UserSkillListenerImpl")) {
			return translateOutputUserSkillListener(oldModel);
		}
		else if (oldModelClassName.endsWith("Clp")) {
			try {
				ClassLoader classLoader = ClpSerializer.class.getClassLoader();

				Method getClpSerializerClassMethod = oldModelClass.getMethod(
						"getClpSerializerClass");

				Class<?> oldClpSerializerClass = (Class<?>)getClpSerializerClassMethod.invoke(oldModel);

				Class<?> newClpSerializerClass = classLoader.loadClass(oldClpSerializerClass.getName());

				Method translateOutputMethod = newClpSerializerClass.getMethod("translateOutput",
						BaseModel.class);

				Class<?> oldModelModelClass = oldModel.getModelClass();

				Method getRemoteModelMethod = oldModelClass.getMethod("get" +
						oldModelModelClass.getSimpleName() + "RemoteModel");

				Object oldRemoteModel = getRemoteModelMethod.invoke(oldModel);

				BaseModel<?> newModel = (BaseModel<?>)translateOutputMethod.invoke(null,
						oldRemoteModel);

				return newModel;
			}
			catch (Throwable t) {
				if (_log.isInfoEnabled()) {
					_log.info("Unable to translate " + oldModelClassName, t);
				}
			}
		}

		return oldModel;
	}

	public static Object translateOutput(List<Object> oldList) {
		List<Object> newList = new ArrayList<Object>(oldList.size());

		for (int i = 0; i < oldList.size(); i++) {
			Object curObj = oldList.get(i);

			newList.add(translateOutput(curObj));
		}

		return newList;
	}

	public static Object translateOutput(Object obj) {
		if (obj instanceof BaseModel<?>) {
			return translateOutput((BaseModel<?>)obj);
		}
		else if (obj instanceof List<?>) {
			return translateOutput((List<Object>)obj);
		}
		else {
			return obj;
		}
	}

	public static Throwable translateThrowable(Throwable throwable) {
		if (_useReflectionToTranslateThrowable) {
			try {
				UnsyncByteArrayOutputStream unsyncByteArrayOutputStream = new UnsyncByteArrayOutputStream();
				ObjectOutputStream objectOutputStream = new ObjectOutputStream(unsyncByteArrayOutputStream);

				objectOutputStream.writeObject(throwable);

				objectOutputStream.flush();
				objectOutputStream.close();

				UnsyncByteArrayInputStream unsyncByteArrayInputStream = new UnsyncByteArrayInputStream(unsyncByteArrayOutputStream.unsafeGetByteArray(),
						0, unsyncByteArrayOutputStream.size());

				Thread currentThread = Thread.currentThread();

				ClassLoader contextClassLoader = currentThread.getContextClassLoader();

				ObjectInputStream objectInputStream = new ClassLoaderObjectInputStream(unsyncByteArrayInputStream,
						contextClassLoader);

				throwable = (Throwable)objectInputStream.readObject();

				objectInputStream.close();

				return throwable;
			}
			catch (SecurityException se) {
				if (_log.isInfoEnabled()) {
					_log.info("Do not use reflection to translate throwable");
				}

				_useReflectionToTranslateThrowable = false;
			}
			catch (Throwable throwable2) {
				_log.error(throwable2, throwable2);

				return throwable2;
			}
		}

		Class<?> clazz = throwable.getClass();

		String className = clazz.getName();

		if (className.equals(PortalException.class.getName())) {
			return new PortalException();
		}

		if (className.equals(SystemException.class.getName())) {
			return new SystemException();
		}

		if (className.equals("com.portlets.action.NoSuchCourseException")) {
			return new com.portlets.action.NoSuchCourseException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchEducationUsersException")) {
			return new com.portlets.action.NoSuchEducationUsersException();
		}

		if (className.equals("com.portlets.action.NoSuchEducatorException")) {
			return new com.portlets.action.NoSuchEducatorException();
		}

		if (className.equals("com.portlets.action.NoSuchEmployerException")) {
			return new com.portlets.action.NoSuchEmployerException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchExperienceUsersException")) {
			return new com.portlets.action.NoSuchExperienceUsersException();
		}

		if (className.equals("com.portlets.action.NoSuchLevelException")) {
			return new com.portlets.action.NoSuchLevelException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchLinkUserCourseException")) {
			return new com.portlets.action.NoSuchLinkUserCourseException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchLinkUserRecruitmentException")) {
			return new com.portlets.action.NoSuchLinkUserRecruitmentException();
		}

		if (className.equals("com.portlets.action.NoSuchLinkUsersException")) {
			return new com.portlets.action.NoSuchLinkUsersException();
		}

		if (className.equals("com.portlets.action.NoSuchRecruitmentException")) {
			return new com.portlets.action.NoSuchRecruitmentException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchRegisterCourseException")) {
			return new com.portlets.action.NoSuchRegisterCourseException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchRegisterRecruitmentException")) {
			return new com.portlets.action.NoSuchRegisterRecruitmentException();
		}

		if (className.equals("com.portlets.action.NoSuchSkillException")) {
			return new com.portlets.action.NoSuchSkillException();
		}

		if (className.equals("com.portlets.action.NoSuchStatesException")) {
			return new com.portlets.action.NoSuchStatesException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchTrainingProgramException")) {
			return new com.portlets.action.NoSuchTrainingProgramException();
		}

		if (className.equals("com.portlets.action.NoSuchUserObjectException")) {
			return new com.portlets.action.NoSuchUserObjectException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchUserSkillLevelException")) {
			return new com.portlets.action.NoSuchUserSkillLevelException();
		}

		if (className.equals(
					"com.portlets.action.NoSuchUserSkillListenerException")) {
			return new com.portlets.action.NoSuchUserSkillListenerException();
		}

		return throwable;
	}

	public static Object translateOutputCourse(BaseModel<?> oldModel) {
		CourseClp newModel = new CourseClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setCourseRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputEducationUsers(BaseModel<?> oldModel) {
		EducationUsersClp newModel = new EducationUsersClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setEducationUsersRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputEducator(BaseModel<?> oldModel) {
		EducatorClp newModel = new EducatorClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setEducatorRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputEmployer(BaseModel<?> oldModel) {
		EmployerClp newModel = new EmployerClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setEmployerRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputExperienceUsers(BaseModel<?> oldModel) {
		ExperienceUsersClp newModel = new ExperienceUsersClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setExperienceUsersRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputLevel(BaseModel<?> oldModel) {
		LevelClp newModel = new LevelClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setLevelRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputLinkUserCourse(BaseModel<?> oldModel) {
		LinkUserCourseClp newModel = new LinkUserCourseClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setLinkUserCourseRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputLinkUserRecruitment(
		BaseModel<?> oldModel) {
		LinkUserRecruitmentClp newModel = new LinkUserRecruitmentClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setLinkUserRecruitmentRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputLinkUsers(BaseModel<?> oldModel) {
		LinkUsersClp newModel = new LinkUsersClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setLinkUsersRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputRecruitment(BaseModel<?> oldModel) {
		RecruitmentClp newModel = new RecruitmentClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setRecruitmentRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputRegisterCourse(BaseModel<?> oldModel) {
		RegisterCourseClp newModel = new RegisterCourseClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setRegisterCourseRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputRegisterRecruitment(
		BaseModel<?> oldModel) {
		RegisterRecruitmentClp newModel = new RegisterRecruitmentClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setRegisterRecruitmentRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputSkill(BaseModel<?> oldModel) {
		SkillClp newModel = new SkillClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setSkillRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputStates(BaseModel<?> oldModel) {
		StatesClp newModel = new StatesClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setStatesRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputTrainingProgram(BaseModel<?> oldModel) {
		TrainingProgramClp newModel = new TrainingProgramClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setTrainingProgramRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputUserObject(BaseModel<?> oldModel) {
		UserObjectClp newModel = new UserObjectClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setUserObjectRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputUserSkillLevel(BaseModel<?> oldModel) {
		UserSkillLevelClp newModel = new UserSkillLevelClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setUserSkillLevelRemoteModel(oldModel);

		return newModel;
	}

	public static Object translateOutputUserSkillListener(BaseModel<?> oldModel) {
		UserSkillListenerClp newModel = new UserSkillListenerClp();

		newModel.setModelAttributes(oldModel.getModelAttributes());

		newModel.setUserSkillListenerRemoteModel(oldModel);

		return newModel;
	}

	private static Log _log = LogFactoryUtil.getLog(ClpSerializer.class);
	private static String _servletContextName;
	private static boolean _useReflectionToTranslateThrowable = true;
}