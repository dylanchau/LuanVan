/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.UserObjectLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class UserObjectClp extends BaseModelImpl<UserObject>
	implements UserObject {
	public UserObjectClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return UserObject.class;
	}

	@Override
	public String getModelClassName() {
		return UserObject.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _userObjectId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setUserObjectId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _userObjectId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userObjectId", getUserObjectId());
		attributes.put("userObjectName", getUserObjectName());
		attributes.put("userObjectGender", getUserObjectGender());
		attributes.put("userObjectAddress", getUserObjectAddress());
		attributes.put("userObjectBirthday", getUserObjectBirthday());
		attributes.put("userObjectEmail", getUserObjectEmail());
		attributes.put("userObjectPhone", getUserObjectPhone());
		attributes.put("userObjectIntroduce", getUserObjectIntroduce());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		String userObjectName = (String)attributes.get("userObjectName");

		if (userObjectName != null) {
			setUserObjectName(userObjectName);
		}

		Boolean userObjectGender = (Boolean)attributes.get("userObjectGender");

		if (userObjectGender != null) {
			setUserObjectGender(userObjectGender);
		}

		String userObjectAddress = (String)attributes.get("userObjectAddress");

		if (userObjectAddress != null) {
			setUserObjectAddress(userObjectAddress);
		}

		Date userObjectBirthday = (Date)attributes.get("userObjectBirthday");

		if (userObjectBirthday != null) {
			setUserObjectBirthday(userObjectBirthday);
		}

		String userObjectEmail = (String)attributes.get("userObjectEmail");

		if (userObjectEmail != null) {
			setUserObjectEmail(userObjectEmail);
		}

		String userObjectPhone = (String)attributes.get("userObjectPhone");

		if (userObjectPhone != null) {
			setUserObjectPhone(userObjectPhone);
		}

		String userObjectIntroduce = (String)attributes.get(
				"userObjectIntroduce");

		if (userObjectIntroduce != null) {
			setUserObjectIntroduce(userObjectIntroduce);
		}
	}

	@Override
	public long getUserObjectId() {
		return _userObjectId;
	}

	@Override
	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectId", long.class);

				method.invoke(_userObjectRemoteModel, userObjectId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserObjectName() {
		return _userObjectName;
	}

	@Override
	public void setUserObjectName(String userObjectName) {
		_userObjectName = userObjectName;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectName",
						String.class);

				method.invoke(_userObjectRemoteModel, userObjectName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public boolean getUserObjectGender() {
		return _userObjectGender;
	}

	@Override
	public boolean isUserObjectGender() {
		return _userObjectGender;
	}

	@Override
	public void setUserObjectGender(boolean userObjectGender) {
		_userObjectGender = userObjectGender;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectGender",
						boolean.class);

				method.invoke(_userObjectRemoteModel, userObjectGender);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserObjectAddress() {
		return _userObjectAddress;
	}

	@Override
	public void setUserObjectAddress(String userObjectAddress) {
		_userObjectAddress = userObjectAddress;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectAddress",
						String.class);

				method.invoke(_userObjectRemoteModel, userObjectAddress);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Date getUserObjectBirthday() {
		return _userObjectBirthday;
	}

	@Override
	public void setUserObjectBirthday(Date userObjectBirthday) {
		_userObjectBirthday = userObjectBirthday;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectBirthday",
						Date.class);

				method.invoke(_userObjectRemoteModel, userObjectBirthday);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserObjectEmail() {
		return _userObjectEmail;
	}

	@Override
	public void setUserObjectEmail(String userObjectEmail) {
		_userObjectEmail = userObjectEmail;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectEmail",
						String.class);

				method.invoke(_userObjectRemoteModel, userObjectEmail);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserObjectPhone() {
		return _userObjectPhone;
	}

	@Override
	public void setUserObjectPhone(String userObjectPhone) {
		_userObjectPhone = userObjectPhone;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectPhone",
						String.class);

				method.invoke(_userObjectRemoteModel, userObjectPhone);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getUserObjectIntroduce() {
		return _userObjectIntroduce;
	}

	@Override
	public void setUserObjectIntroduce(String userObjectIntroduce) {
		_userObjectIntroduce = userObjectIntroduce;

		if (_userObjectRemoteModel != null) {
			try {
				Class<?> clazz = _userObjectRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectIntroduce",
						String.class);

				method.invoke(_userObjectRemoteModel, userObjectIntroduce);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getUserObjectRemoteModel() {
		return _userObjectRemoteModel;
	}

	public void setUserObjectRemoteModel(BaseModel<?> userObjectRemoteModel) {
		_userObjectRemoteModel = userObjectRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _userObjectRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_userObjectRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			UserObjectLocalServiceUtil.addUserObject(this);
		}
		else {
			UserObjectLocalServiceUtil.updateUserObject(this);
		}
	}

	@Override
	public UserObject toEscapedModel() {
		return (UserObject)ProxyUtil.newProxyInstance(UserObject.class.getClassLoader(),
			new Class[] { UserObject.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		UserObjectClp clone = new UserObjectClp();

		clone.setUserObjectId(getUserObjectId());
		clone.setUserObjectName(getUserObjectName());
		clone.setUserObjectGender(getUserObjectGender());
		clone.setUserObjectAddress(getUserObjectAddress());
		clone.setUserObjectBirthday(getUserObjectBirthday());
		clone.setUserObjectEmail(getUserObjectEmail());
		clone.setUserObjectPhone(getUserObjectPhone());
		clone.setUserObjectIntroduce(getUserObjectIntroduce());

		return clone;
	}

	@Override
	public int compareTo(UserObject userObject) {
		long primaryKey = userObject.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserObjectClp)) {
			return false;
		}

		UserObjectClp userObject = (UserObjectClp)obj;

		long primaryKey = userObject.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{userObjectId=");
		sb.append(getUserObjectId());
		sb.append(", userObjectName=");
		sb.append(getUserObjectName());
		sb.append(", userObjectGender=");
		sb.append(getUserObjectGender());
		sb.append(", userObjectAddress=");
		sb.append(getUserObjectAddress());
		sb.append(", userObjectBirthday=");
		sb.append(getUserObjectBirthday());
		sb.append(", userObjectEmail=");
		sb.append(getUserObjectEmail());
		sb.append(", userObjectPhone=");
		sb.append(getUserObjectPhone());
		sb.append(", userObjectIntroduce=");
		sb.append(getUserObjectIntroduce());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(28);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.UserObject");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>userObjectId</column-name><column-value><![CDATA[");
		sb.append(getUserObjectId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectName</column-name><column-value><![CDATA[");
		sb.append(getUserObjectName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectGender</column-name><column-value><![CDATA[");
		sb.append(getUserObjectGender());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectAddress</column-name><column-value><![CDATA[");
		sb.append(getUserObjectAddress());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectBirthday</column-name><column-value><![CDATA[");
		sb.append(getUserObjectBirthday());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectEmail</column-name><column-value><![CDATA[");
		sb.append(getUserObjectEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectPhone</column-name><column-value><![CDATA[");
		sb.append(getUserObjectPhone());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectIntroduce</column-name><column-value><![CDATA[");
		sb.append(getUserObjectIntroduce());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _userObjectId;
	private String _userObjectName;
	private boolean _userObjectGender;
	private String _userObjectAddress;
	private Date _userObjectBirthday;
	private String _userObjectEmail;
	private String _userObjectPhone;
	private String _userObjectIntroduce;
	private BaseModel<?> _userObjectRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}