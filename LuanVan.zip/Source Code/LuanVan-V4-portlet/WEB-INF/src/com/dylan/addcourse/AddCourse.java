package com.dylan.addcourse;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletURL;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.dylan.portlets.action.util.CourseActionUtil;
import com.kimtho.portlet.listener.ListenerUserCourse;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.Course;
import com.portlets.action.model.LinkUserCourse;
import com.portlets.action.model.RegisterCourse;
import com.portlets.action.model.Skill;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.LinkUserCourseLocalServiceUtil;
import com.portlets.action.service.RegisterCourseLocalServiceUtil;
import com.portlets.action.service.SkillLocalServiceUtil;

/**
 * Portlet implementation class AddCourse
 */
public class AddCourse extends MVCPortlet {

	public void saveCourse(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
		PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
		
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		
		String courseName = ParamUtil.getString(actionRequest, "courseName");
		int courseStudentNo = ParamUtil.getInteger(actionRequest, "courseStudentNo");
		long userId = ParamUtil.getLong(actionRequest, "userId");
		Date registerStartDate = df.parse(ParamUtil.getString(actionRequest, "registerStartDate", ""));
		Date registerEndDate = df.parse(ParamUtil.getString(actionRequest, "registerEndDate", ""));
		Date startCourseDate = df.parse(ParamUtil.getString(actionRequest, "startCourseDate"));
		long trainProId = ParamUtil.getLong(actionRequest, "trainProId");
		long defaultCourseStateId = 2;
		
		String[] skillClassSchoolDay = ParamUtil.getParameterValues(actionRequest, "skillClassSchoolDay", null);
		String skillClassSchoolDayList = Arrays.toString(skillClassSchoolDay);
		skillClassSchoolDayList = skillClassSchoolDayList.substring(1, skillClassSchoolDayList.length()-1).replaceAll(",", "");
		
		Course course = CourseActionUtil.addCourse(courseName, courseStudentNo, registerStartDate, 
				registerEndDate, startCourseDate, skillClassSchoolDayList, trainProId, userId, defaultCourseStateId);
		
		//Listener
		List<Skill> skills = SkillLocalServiceUtil.getTrainingProgramSkills(course.getTrainingProgramId());
		ListenerUserCourse listenerUserCourse = new ListenerUserCourse();
		for(Skill s:skills){
			listenerUserCourse.addLinkUserCourseId(course.getCourseId(), s.getSkillId());;
		}
		String[] skillIdsTemp = new String[skills.size()];
		for(int i=0; i<skills.size(); i++) {
			skillIdsTemp[i] = String.valueOf(skills.get(i).getSkillId());
		}
		
		String skillsList = Arrays.toString(skillIdsTemp);
		skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
		/*
		//Message bus
		String portletName2 = "p_p_id_training_WAR_LuanVanV4portlet";
		PortletURL testURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName2, 21118, PortletRequest.RENDER_PHASE);
		String destination = "messageListener/usesrObject_educator/destination";
		System.out.println("Send message method is calling...");
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		
		testURL.setParameter("mvcPath", "/html/training/detailcourse.jsp");
		testURL.setParameter("educatorId", String.valueOf(course.getEducatorId()));
		testURL.setParameter("id", String.valueOf(course.getCourseId()) );
		
		String message = "new class is open";
		jsonObject.put("message", message);
		jsonObject.put("educatorId", course.getEducatorId());
		jsonObject.put("id", course.getCourseId());
		jsonObject.put("skillIds", skillsList);
		jsonObject.put("testURL", testURL.toString());
		jsonObject.put("companyId", themeDisplay.getCompanyId());
		
		MessageBusUtil.sendMessage(destination, jsonObject.toString());
		*/
		redirectURL.setParameter("mvcPath", "/html/addcourse/view.jsp");
		actionResponse.sendRedirect(redirectURL.toString());
	}

	public void publishCourse(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
		PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
		PortletURL testURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
		
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		
		String courseName = ParamUtil.getString(actionRequest, "courseName");
		int courseStudentNo = ParamUtil.getInteger(actionRequest, "courseStudentNo");
		long educatorId = ParamUtil.getLong(actionRequest, "userId");
		Date registerStartDate = df.parse(ParamUtil.getString(actionRequest, "registerStartDate", ""));
		Date registerEndDate = df.parse(ParamUtil.getString(actionRequest, "registerEndDate", ""));
		Date startCourseDate = df.parse(ParamUtil.getString(actionRequest, "startCourseDate"));
		long trainProId = ParamUtil.getLong(actionRequest, "trainProId");
		long courseStateId = 0;
		
		String[] skillClassSchoolDay = ParamUtil.getParameterValues(actionRequest, "skillClassSchoolDay", null);
		String skillClassSchoolDayList = Arrays.toString(skillClassSchoolDay);
		skillClassSchoolDayList = skillClassSchoolDayList.substring(1, skillClassSchoolDayList.length()-1).replaceAll(",", "");
		
		Course course = CourseActionUtil.addCourse(courseName, courseStudentNo, registerStartDate, 
				registerEndDate, startCourseDate, skillClassSchoolDayList, trainProId, educatorId, courseStateId);
		
		
		
		redirectURL.setParameter("mvcPath", "/html/addcourse/view.jsp");
		actionResponse.sendRedirect(redirectURL.toString());
	}
	
	public void updateCourse(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long courseId = ParamUtil.getLong(actionRequest, "courseId");
		long educatorId = ParamUtil.getLong(actionRequest, "educatorId"); _log.info(educatorId);
		String courseName = ParamUtil.getString(actionRequest, "courseName"); _log.info(courseName);
		int courseStudentNo = ParamUtil.getInteger(actionRequest, "courseStudentNo"); _log.info(courseStudentNo);
		
		String[] skillClassSchoolDay = ParamUtil.getParameterValues(actionRequest, "skillClassSchoolDay", null);
		String skillClassSchoolDayList = Arrays.toString(skillClassSchoolDay);
		skillClassSchoolDayList = skillClassSchoolDayList.substring(1, 
				skillClassSchoolDayList.length()-1).replaceAll(",", "");
		_log.info(skillClassSchoolDayList);
		
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy", Locale.ENGLISH);
		Date registerStartDate = df.parse(ParamUtil.getString(actionRequest, "registerStartDate", "")); 
		Date registerEndDate = df.parse(ParamUtil.getString(actionRequest, "registerEndDate", ""));
		Date startCourseDate = df.parse(ParamUtil.getString(actionRequest, "startCourseDate", ""));
		
		_log.info(df.format(registerStartDate)); _log.info(df.format(registerEndDate)); _log.info(df.format(startCourseDate));
		
		try {
			
			Course course = CourseLocalServiceUtil.getCourse(courseId);
			course.setCourseName(courseName);
			course.setCourseStudentNo(courseStudentNo);
			course.setCourseSchoolDay(skillClassSchoolDayList);
			course.setCourseEnrollStartDate(registerStartDate);
			course.setCourseEnrollDeadLine(registerEndDate);
			course.setCourseStartDate(startCourseDate);
			CourseLocalServiceUtil.updateCourse(course);
			
			//message bus
			
		}catch(Exception e) {
			_log.error(e.getClass() + "\n" + e.getMessage());
		}
		
	}
	
	public void getCourseOfUserId(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws IOException, PortletException {
		
		
		_log.info("-------------------------------------------------------------");
		long state = ParamUtil.getLong(actionRequest, "states");
		_log.info(state);
		actionRequest.setAttribute("state", state);
		actionResponse.setRenderParameter("mvcPath", "/html/addcourse/view.jsp");
	}
	
	public void changeCourseState(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String portletName = "p_p_id_training_WAR_LuanVanV4portlet";
		PortletURL testURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName, 61677, PortletRequest.RENDER_PHASE);
		
		long stateId = ParamUtil.getLong(actionRequest, "states"); _log.info(stateId);
		long courseId = ParamUtil.getLong(actionRequest, "courseId"); _log.info(courseId);
		long educatorId = ParamUtil.getLong(actionRequest, "educatorId");
		long trainProId = ParamUtil.getLong(actionRequest, "trainProId");
		
		try {
			Course course = CourseLocalServiceUtil.getCourse(courseId);
			
			course.setStatesId(stateId);
			
			CourseLocalServiceUtil.updateCourse(course);
			
			//message bus
			if(stateId == 1) {
				String destination = "messageListener/educator_usesrObject/destination";
				System.out.println("Send message method is calling...");
				JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
				
				testURL.setParameter("mvcPath", "/html/training/detailcourse.jsp");
				testURL.setParameter("educatorId", String.valueOf(course.getEducatorId()));
				testURL.setParameter("id", String.valueOf(course.getCourseId()) );
				
				//get skills list
				List<Skill> skills = SkillLocalServiceUtil.getTrainingProgramSkills(trainProId);
				String[] skillIdsTemp = new String[skills.size()];
				for(int i=0; i<skills.size(); i++) {
					skillIdsTemp[i] = String.valueOf(skills.get(i).getSkillId());
				}
				
				String skillsList = Arrays.toString(skillIdsTemp);
				skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
				
				String message = "have just opened a new course";
				jsonObject.put("message", message);
				jsonObject.put("educatorId", educatorId);
				jsonObject.put("courseId", course.getCourseId());
				jsonObject.put("skillIds", skillsList);
				jsonObject.put("testURL", testURL.toString());
				jsonObject.put("companyId", themeDisplay.getCompanyId());
				
				MessageBusUtil.sendMessage(destination, jsonObject.toString());
			}
			//end message bus
			
			
			
			actionRequest.setAttribute("stateId", stateId);
			
			actionResponse.setRenderParameter("mvcPath", "/html/addcourse/view.jsp");
			
		}catch(Exception e) {
			_log.error(e); 
		}
		
	
	}
	
	public void editCourse(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long courseId = ParamUtil.getLong(actionRequest, "courseId"); _log.info(courseId);
		long educatorId = ParamUtil.getLong(actionRequest, "educatorId"); _log.info(educatorId);
		String backURL = ParamUtil.getString(actionRequest, "backURL"); _log.info(backURL);
		String updateURL = ParamUtil.getString(actionRequest, "updateURL"); _log.info(updateURL);
		
		try {
			Course course = CourseLocalServiceUtil.getCourse(courseId);
			course.setStatesId(2);
			CourseLocalServiceUtil.updateCourse(course);
			
			actionRequest.setAttribute("backURL", backURL);
			
			actionResponse.sendRedirect(updateURL);
			
		}catch(Exception e) {
			_log.error(e.getClass() + "\n" + e.getMessage());
		}
		
	}
	
	public void deleteCourse(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		_log.info("------------deleteCourse----------------");
		long courseId = ParamUtil.getLong(actionRequest, "courseId"); _log.info(courseId);
		List<RegisterCourse> studentsOfCourse = RegisterCourseLocalServiceUtil.getByCourseId(courseId);
		List<LinkUserCourse> userCourse = LinkUserCourseLocalServiceUtil.getByCourseId(courseId);
		_log.info(studentsOfCourse.size());
		
		if(studentsOfCourse.size() == 0) {
			CourseLocalServiceUtil.deleteCourse(courseId);
			for(LinkUserCourse linkUserCourse : userCourse) {
				LinkUserCourseLocalServiceUtil.deleteLinkUserCourse(linkUserCourse);
			}
			SessionMessages.add(actionRequest.getPortletSession(), "delete-course-success");
		} else {
			SessionErrors.add(actionRequest.getPortletSession(), "delete-course-fail");
		}
		
	}
	
	public void serveResource(ResourceRequest resourceRequest,
            ResourceResponse resourceResponse) throws IOException, PortletException {
		
	}
	
	Log _log = LogFactoryUtil.getLog(AddCourse.class);

}
