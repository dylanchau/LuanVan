/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.portlets.action.model.ExperienceUsers;

/**
 * The persistence interface for the experience users service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see ExperienceUsersPersistenceImpl
 * @see ExperienceUsersUtil
 * @generated
 */
public interface ExperienceUsersPersistence extends BasePersistence<ExperienceUsers> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link ExperienceUsersUtil} to access the experience users persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the experience userses where experienceUsersId = &#63;.
	*
	* @param experienceUsersId the experience users ID
	* @return the matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findByexperienceUsersId(
		long experienceUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the experience userses where experienceUsersId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.ExperienceUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param experienceUsersId the experience users ID
	* @param start the lower bound of the range of experience userses
	* @param end the upper bound of the range of experience userses (not inclusive)
	* @return the range of matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findByexperienceUsersId(
		long experienceUsersId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the experience userses where experienceUsersId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.ExperienceUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param experienceUsersId the experience users ID
	* @param start the lower bound of the range of experience userses
	* @param end the upper bound of the range of experience userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findByexperienceUsersId(
		long experienceUsersId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first experience users in the ordered set where experienceUsersId = &#63;.
	*
	* @param experienceUsersId the experience users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching experience users
	* @throws com.portlets.action.NoSuchExperienceUsersException if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers findByexperienceUsersId_First(
		long experienceUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchExperienceUsersException;

	/**
	* Returns the first experience users in the ordered set where experienceUsersId = &#63;.
	*
	* @param experienceUsersId the experience users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching experience users, or <code>null</code> if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers fetchByexperienceUsersId_First(
		long experienceUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last experience users in the ordered set where experienceUsersId = &#63;.
	*
	* @param experienceUsersId the experience users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching experience users
	* @throws com.portlets.action.NoSuchExperienceUsersException if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers findByexperienceUsersId_Last(
		long experienceUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchExperienceUsersException;

	/**
	* Returns the last experience users in the ordered set where experienceUsersId = &#63;.
	*
	* @param experienceUsersId the experience users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching experience users, or <code>null</code> if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers fetchByexperienceUsersId_Last(
		long experienceUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the experience userses where experienceUsersId = &#63; from the database.
	*
	* @param experienceUsersId the experience users ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByexperienceUsersId(long experienceUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of experience userses where experienceUsersId = &#63;.
	*
	* @param experienceUsersId the experience users ID
	* @return the number of matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public int countByexperienceUsersId(long experienceUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the experience userses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findByuserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the experience userses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.ExperienceUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of experience userses
	* @param end the upper bound of the range of experience userses (not inclusive)
	* @return the range of matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findByuserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the experience userses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.ExperienceUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of experience userses
	* @param end the upper bound of the range of experience userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findByuserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first experience users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching experience users
	* @throws com.portlets.action.NoSuchExperienceUsersException if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers findByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchExperienceUsersException;

	/**
	* Returns the first experience users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching experience users, or <code>null</code> if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers fetchByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last experience users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching experience users
	* @throws com.portlets.action.NoSuchExperienceUsersException if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers findByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchExperienceUsersException;

	/**
	* Returns the last experience users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching experience users, or <code>null</code> if a matching experience users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers fetchByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the experience userses before and after the current experience users in the ordered set where userObjectId = &#63;.
	*
	* @param experienceUsersId the primary key of the current experience users
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next experience users
	* @throws com.portlets.action.NoSuchExperienceUsersException if a experience users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers[] findByuserObjectId_PrevAndNext(
		long experienceUsersId, long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchExperienceUsersException;

	/**
	* Removes all the experience userses where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of experience userses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching experience userses
	* @throws SystemException if a system exception occurred
	*/
	public int countByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the experience users in the entity cache if it is enabled.
	*
	* @param experienceUsers the experience users
	*/
	public void cacheResult(
		com.portlets.action.model.ExperienceUsers experienceUsers);

	/**
	* Caches the experience userses in the entity cache if it is enabled.
	*
	* @param experienceUserses the experience userses
	*/
	public void cacheResult(
		java.util.List<com.portlets.action.model.ExperienceUsers> experienceUserses);

	/**
	* Creates a new experience users with the primary key. Does not add the experience users to the database.
	*
	* @param experienceUsersId the primary key for the new experience users
	* @return the new experience users
	*/
	public com.portlets.action.model.ExperienceUsers create(
		long experienceUsersId);

	/**
	* Removes the experience users with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param experienceUsersId the primary key of the experience users
	* @return the experience users that was removed
	* @throws com.portlets.action.NoSuchExperienceUsersException if a experience users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers remove(
		long experienceUsersId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchExperienceUsersException;

	public com.portlets.action.model.ExperienceUsers updateImpl(
		com.portlets.action.model.ExperienceUsers experienceUsers)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the experience users with the primary key or throws a {@link com.portlets.action.NoSuchExperienceUsersException} if it could not be found.
	*
	* @param experienceUsersId the primary key of the experience users
	* @return the experience users
	* @throws com.portlets.action.NoSuchExperienceUsersException if a experience users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers findByPrimaryKey(
		long experienceUsersId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchExperienceUsersException;

	/**
	* Returns the experience users with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param experienceUsersId the primary key of the experience users
	* @return the experience users, or <code>null</code> if a experience users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.ExperienceUsers fetchByPrimaryKey(
		long experienceUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the experience userses.
	*
	* @return the experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the experience userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.ExperienceUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of experience userses
	* @param end the upper bound of the range of experience userses (not inclusive)
	* @return the range of experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the experience userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.ExperienceUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of experience userses
	* @param end the upper bound of the range of experience userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of experience userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.ExperienceUsers> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the experience userses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of experience userses.
	*
	* @return the number of experience userses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}