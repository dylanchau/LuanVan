/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.Educator;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing Educator in entity cache.
 *
 * @author Computer
 * @see Educator
 * @generated
 */
public class EducatorCacheModel implements CacheModel<Educator>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{educatorId=");
		sb.append(educatorId);
		sb.append(", educatorName=");
		sb.append(educatorName);
		sb.append(", educatorAddress=");
		sb.append(educatorAddress);
		sb.append(", educatorEmail=");
		sb.append(educatorEmail);
		sb.append(", educatorPhone=");
		sb.append(educatorPhone);
		sb.append(", educatorIntroduce=");
		sb.append(educatorIntroduce);
		sb.append(", euducatorAchievements=");
		sb.append(euducatorAchievements);
		sb.append(", educatorLogoName=");
		sb.append(educatorLogoName);

		return sb.toString();
	}

	@Override
	public Educator toEntityModel() {
		EducatorImpl educatorImpl = new EducatorImpl();

		educatorImpl.setEducatorId(educatorId);

		if (educatorName == null) {
			educatorImpl.setEducatorName(StringPool.BLANK);
		}
		else {
			educatorImpl.setEducatorName(educatorName);
		}

		if (educatorAddress == null) {
			educatorImpl.setEducatorAddress(StringPool.BLANK);
		}
		else {
			educatorImpl.setEducatorAddress(educatorAddress);
		}

		if (educatorEmail == null) {
			educatorImpl.setEducatorEmail(StringPool.BLANK);
		}
		else {
			educatorImpl.setEducatorEmail(educatorEmail);
		}

		if (educatorPhone == null) {
			educatorImpl.setEducatorPhone(StringPool.BLANK);
		}
		else {
			educatorImpl.setEducatorPhone(educatorPhone);
		}

		if (educatorIntroduce == null) {
			educatorImpl.setEducatorIntroduce(StringPool.BLANK);
		}
		else {
			educatorImpl.setEducatorIntroduce(educatorIntroduce);
		}

		if (euducatorAchievements == null) {
			educatorImpl.setEuducatorAchievements(StringPool.BLANK);
		}
		else {
			educatorImpl.setEuducatorAchievements(euducatorAchievements);
		}

		if (educatorLogoName == null) {
			educatorImpl.setEducatorLogoName(StringPool.BLANK);
		}
		else {
			educatorImpl.setEducatorLogoName(educatorLogoName);
		}

		educatorImpl.resetOriginalValues();

		return educatorImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		educatorId = objectInput.readLong();
		educatorName = objectInput.readUTF();
		educatorAddress = objectInput.readUTF();
		educatorEmail = objectInput.readUTF();
		educatorPhone = objectInput.readUTF();
		educatorIntroduce = objectInput.readUTF();
		euducatorAchievements = objectInput.readUTF();
		educatorLogoName = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(educatorId);

		if (educatorName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educatorName);
		}

		if (educatorAddress == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educatorAddress);
		}

		if (educatorEmail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educatorEmail);
		}

		if (educatorPhone == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educatorPhone);
		}

		if (educatorIntroduce == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educatorIntroduce);
		}

		if (euducatorAchievements == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(euducatorAchievements);
		}

		if (educatorLogoName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(educatorLogoName);
		}
	}

	public long educatorId;
	public String educatorName;
	public String educatorAddress;
	public String educatorEmail;
	public String educatorPhone;
	public String educatorIntroduce;
	public String euducatorAchievements;
	public String educatorLogoName;
}