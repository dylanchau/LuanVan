/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.sql.Blob;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Educator}.
 * </p>
 *
 * @author Computer
 * @see Educator
 * @generated
 */
public class EducatorWrapper implements Educator, ModelWrapper<Educator> {
	public EducatorWrapper(Educator educator) {
		_educator = educator;
	}

	@Override
	public Class<?> getModelClass() {
		return Educator.class;
	}

	@Override
	public String getModelClassName() {
		return Educator.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("educatorId", getEducatorId());
		attributes.put("educatorName", getEducatorName());
		attributes.put("educatorAddress", getEducatorAddress());
		attributes.put("educatorEmail", getEducatorEmail());
		attributes.put("educatorPhone", getEducatorPhone());
		attributes.put("educatorIntroduce", getEducatorIntroduce());
		attributes.put("euducatorAchievements", getEuducatorAchievements());
		attributes.put("educatorLogoName", getEducatorLogoName());
		attributes.put("educatorLogo", getEducatorLogo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long educatorId = (Long)attributes.get("educatorId");

		if (educatorId != null) {
			setEducatorId(educatorId);
		}

		String educatorName = (String)attributes.get("educatorName");

		if (educatorName != null) {
			setEducatorName(educatorName);
		}

		String educatorAddress = (String)attributes.get("educatorAddress");

		if (educatorAddress != null) {
			setEducatorAddress(educatorAddress);
		}

		String educatorEmail = (String)attributes.get("educatorEmail");

		if (educatorEmail != null) {
			setEducatorEmail(educatorEmail);
		}

		String educatorPhone = (String)attributes.get("educatorPhone");

		if (educatorPhone != null) {
			setEducatorPhone(educatorPhone);
		}

		String educatorIntroduce = (String)attributes.get("educatorIntroduce");

		if (educatorIntroduce != null) {
			setEducatorIntroduce(educatorIntroduce);
		}

		String euducatorAchievements = (String)attributes.get(
				"euducatorAchievements");

		if (euducatorAchievements != null) {
			setEuducatorAchievements(euducatorAchievements);
		}

		String educatorLogoName = (String)attributes.get("educatorLogoName");

		if (educatorLogoName != null) {
			setEducatorLogoName(educatorLogoName);
		}

		Blob educatorLogo = (Blob)attributes.get("educatorLogo");

		if (educatorLogo != null) {
			setEducatorLogo(educatorLogo);
		}
	}

	/**
	* Returns the primary key of this educator.
	*
	* @return the primary key of this educator
	*/
	@Override
	public long getPrimaryKey() {
		return _educator.getPrimaryKey();
	}

	/**
	* Sets the primary key of this educator.
	*
	* @param primaryKey the primary key of this educator
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_educator.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the educator ID of this educator.
	*
	* @return the educator ID of this educator
	*/
	@Override
	public long getEducatorId() {
		return _educator.getEducatorId();
	}

	/**
	* Sets the educator ID of this educator.
	*
	* @param educatorId the educator ID of this educator
	*/
	@Override
	public void setEducatorId(long educatorId) {
		_educator.setEducatorId(educatorId);
	}

	/**
	* Returns the educator name of this educator.
	*
	* @return the educator name of this educator
	*/
	@Override
	public java.lang.String getEducatorName() {
		return _educator.getEducatorName();
	}

	/**
	* Sets the educator name of this educator.
	*
	* @param educatorName the educator name of this educator
	*/
	@Override
	public void setEducatorName(java.lang.String educatorName) {
		_educator.setEducatorName(educatorName);
	}

	/**
	* Returns the educator address of this educator.
	*
	* @return the educator address of this educator
	*/
	@Override
	public java.lang.String getEducatorAddress() {
		return _educator.getEducatorAddress();
	}

	/**
	* Sets the educator address of this educator.
	*
	* @param educatorAddress the educator address of this educator
	*/
	@Override
	public void setEducatorAddress(java.lang.String educatorAddress) {
		_educator.setEducatorAddress(educatorAddress);
	}

	/**
	* Returns the educator email of this educator.
	*
	* @return the educator email of this educator
	*/
	@Override
	public java.lang.String getEducatorEmail() {
		return _educator.getEducatorEmail();
	}

	/**
	* Sets the educator email of this educator.
	*
	* @param educatorEmail the educator email of this educator
	*/
	@Override
	public void setEducatorEmail(java.lang.String educatorEmail) {
		_educator.setEducatorEmail(educatorEmail);
	}

	/**
	* Returns the educator phone of this educator.
	*
	* @return the educator phone of this educator
	*/
	@Override
	public java.lang.String getEducatorPhone() {
		return _educator.getEducatorPhone();
	}

	/**
	* Sets the educator phone of this educator.
	*
	* @param educatorPhone the educator phone of this educator
	*/
	@Override
	public void setEducatorPhone(java.lang.String educatorPhone) {
		_educator.setEducatorPhone(educatorPhone);
	}

	/**
	* Returns the educator introduce of this educator.
	*
	* @return the educator introduce of this educator
	*/
	@Override
	public java.lang.String getEducatorIntroduce() {
		return _educator.getEducatorIntroduce();
	}

	/**
	* Sets the educator introduce of this educator.
	*
	* @param educatorIntroduce the educator introduce of this educator
	*/
	@Override
	public void setEducatorIntroduce(java.lang.String educatorIntroduce) {
		_educator.setEducatorIntroduce(educatorIntroduce);
	}

	/**
	* Returns the euducator achievements of this educator.
	*
	* @return the euducator achievements of this educator
	*/
	@Override
	public java.lang.String getEuducatorAchievements() {
		return _educator.getEuducatorAchievements();
	}

	/**
	* Sets the euducator achievements of this educator.
	*
	* @param euducatorAchievements the euducator achievements of this educator
	*/
	@Override
	public void setEuducatorAchievements(java.lang.String euducatorAchievements) {
		_educator.setEuducatorAchievements(euducatorAchievements);
	}

	/**
	* Returns the educator logo name of this educator.
	*
	* @return the educator logo name of this educator
	*/
	@Override
	public java.lang.String getEducatorLogoName() {
		return _educator.getEducatorLogoName();
	}

	/**
	* Sets the educator logo name of this educator.
	*
	* @param educatorLogoName the educator logo name of this educator
	*/
	@Override
	public void setEducatorLogoName(java.lang.String educatorLogoName) {
		_educator.setEducatorLogoName(educatorLogoName);
	}

	/**
	* Returns the educator logo of this educator.
	*
	* @return the educator logo of this educator
	*/
	@Override
	public java.sql.Blob getEducatorLogo() {
		return _educator.getEducatorLogo();
	}

	/**
	* Sets the educator logo of this educator.
	*
	* @param educatorLogo the educator logo of this educator
	*/
	@Override
	public void setEducatorLogo(java.sql.Blob educatorLogo) {
		_educator.setEducatorLogo(educatorLogo);
	}

	@Override
	public boolean isNew() {
		return _educator.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_educator.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _educator.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_educator.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _educator.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _educator.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_educator.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _educator.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_educator.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_educator.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_educator.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new EducatorWrapper((Educator)_educator.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.Educator educator) {
		return _educator.compareTo(educator);
	}

	@Override
	public int hashCode() {
		return _educator.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.Educator> toCacheModel() {
		return _educator.toCacheModel();
	}

	@Override
	public com.portlets.action.model.Educator toEscapedModel() {
		return new EducatorWrapper(_educator.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.Educator toUnescapedModel() {
		return new EducatorWrapper(_educator.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _educator.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _educator.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_educator.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EducatorWrapper)) {
			return false;
		}

		EducatorWrapper educatorWrapper = (EducatorWrapper)obj;

		if (Validator.equals(_educator, educatorWrapper._educator)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Educator getWrappedEducator() {
		return _educator;
	}

	@Override
	public Educator getWrappedModel() {
		return _educator;
	}

	@Override
	public void resetOriginalValues() {
		_educator.resetOriginalValues();
	}

	private Educator _educator;
}