package com.huy.recruitment.action;

import java.util.List;

import com.portlets.action.model.LinkUserRecruitment;
import com.portlets.action.model.Recruitment;
import com.portlets.action.model.RegisterRecruitment;
import com.portlets.action.model.UserObject;
import com.portlets.action.service.LinkUserRecruitmentLocalServiceUtil;
import com.portlets.action.service.RecruitmentLocalServiceUtil;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;

public class GetIdAll {

	@SuppressWarnings("unchecked")
	public static List<Recruitment> getRecruitmentByUserId(long maID) {
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Recruitment.class);
		dq.add(PropertyFactoryUtil.forName("employerId").eq(maID));
		try {
			return RecruitmentLocalServiceUtil.dynamicQuery(dq); 
			
		} catch (SystemException e) {
			System.out.println("Loi GetAllId By UserId!");
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<Recruitment> getRecruitmentByStateId(long maID) {
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Recruitment.class);
		dq.add(PropertyFactoryUtil.forName("statesId").eq(maID));
		try {
			return RecruitmentLocalServiceUtil.dynamicQuery(dq); 
			
		} catch (SystemException e) {
			System.out.println("Loi GetAllId! By StatesId");
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<Recruitment> getRecruitmentByUserId_StateId(long userId, long statesId) {
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Recruitment.class);
		dq.add(PropertyFactoryUtil.forName("employerId").eq(userId));
		dq.add(PropertyFactoryUtil.forName("statesId").eq(statesId));
		try {
			return RecruitmentLocalServiceUtil.dynamicQuery(dq); 
			
		} catch (SystemException e) {
			System.out.println("Loi GetAllId! By User_States");
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<RegisterRecruitment> getRegisterRecruitmentByUser_Recruitment(long userId, long recruitmentId) {
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(RegisterRecruitment.class);
		dq.add(PropertyFactoryUtil.forName("userObjectId").eq(userId));
		dq.add(PropertyFactoryUtil.forName("recruitmentId").eq(recruitmentId));
		try {
			return RegisterRecruitmentLocalServiceUtil.dynamicQuery(dq); 
			
		} catch (SystemException e) {
			System.out.println("Loi GetAllId! getRegisterRecruitmentBy User");
			return null;
		}
	}
	
	@SuppressWarnings("unchecked")
	public static List<UserObject> getUserObjectByRecruitmentId(long recruitmentId) {
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(RegisterRecruitment.class);
		dq.add(PropertyFactoryUtil.forName("recruitmentId").eq(recruitmentId));
		try {
			return RegisterRecruitmentLocalServiceUtil.dynamicQuery(dq); 
			
		} catch (SystemException e) {
			System.out.println("Loi GetAllId! List userObject getRegisterRecruitment");
			return null;
		}
	}
	@SuppressWarnings("unchecked")
	public static List<RegisterRecruitment> getRegisterRecruitmentByRecruitmentId(long recruitmentId) {
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(RegisterRecruitment.class);
		dq.add(PropertyFactoryUtil.forName("recruitmentId").eq(recruitmentId));
		try {
			return RegisterRecruitmentLocalServiceUtil.dynamicQuery(dq); 
			
		} catch (SystemException e) {
			System.out.println("Loi GetAllId! getRegisterRecruitment");
			return null;
		}
	}
	@SuppressWarnings("unchecked")
	public static List<LinkUserRecruitment> getLinkUserRecruitmentByRecruitmentId(long recruitmentId) {
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(LinkUserRecruitment.class);
		dq.add(PropertyFactoryUtil.forName("recruitmentId").eq(recruitmentId));
		try {
			return LinkUserRecruitmentLocalServiceUtil.dynamicQuery(dq); 
			
		} catch (SystemException e) {
			System.out.println("Loi GetAllId! getLinkUserRecruitmentByRecruitmentId");
			return null;
		}
	}
}
