package com.dylan.listenereducatoruser;

import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class ListenerEducatorUser
 */
public class ListenerEducatorUser extends MVCPortlet {
 

}
