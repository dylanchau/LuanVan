package com.dylan.studentmanagement;

import java.io.IOException;
import java.util.Enumeration;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletURL;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.dylan.portlets.action.util.UserSkillLevelActionUtil;
import com.dylan.portlets.action.util.AcceptUserRegisterRequestActionUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.model.User;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.Course;
import com.portlets.action.model.Skill;
import com.portlets.action.model.UserSkillLevel;
import com.portlets.action.model.impl.UserSkillLevelImpl;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.SkillLocalServiceUtil;
import com.portlets.action.service.UserSkillLevelLocalServiceUtil;

/**
 * Portlet implementation class StudentManagement
 */
public class StudentManagement extends MVCPortlet {

	public void getTrainProId(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws IOException, PortletException {
		
		
		_log.info("-------------------------------------------------------------");
		long trainProId = ParamUtil.getLong(actionRequest, "train");
		_log.info(trainProId);
		actionRequest.setAttribute("train", trainProId);
		actionResponse.setRenderParameter("mvcPath", "/html/studentmanagement/view.jsp");
	}

	public void updateSkill(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws IOException, PortletException {
		
		//JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
		//JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
		PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
		
		long userObjectId = ParamUtil.getLong(actionRequest, "userObjectId"); _log.info(userObjectId);
		long trainProId = ParamUtil.getLong(actionRequest, "trainProId"); _log.info(trainProId);
		
		Enumeration<String> strings = actionRequest.getParameterNames();
				
				while(strings.hasMoreElements()) {
					_log.info(strings.nextElement());
				}
		
		
		
		try {
			List<Skill> skills = SkillLocalServiceUtil.getTrainingProgramSkills(trainProId);
			for(int i=0; i<skills.size(); i++) {
				long skillLevel = ParamUtil.getLong(actionRequest, String.valueOf(skills.get(i).getSkillId()));
				_log.info(skillLevel);
				
				UserSkillLevelActionUtil.addUserSkills(userObjectId, skills.get(i).getSkillId(), skillLevel);
			}
		} catch (SystemException e) {
			e.printStackTrace();
		}
		
		actionResponse.sendRedirect(redirectURL.toString());
	}
	
	public void acceptStudentRequest(ActionRequest actionRequest, 
			ActionResponse actionResponse) throws Exception {
		
		_log.info("------------------------------------");
		
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long companyId = themeDisplay.getCompanyId();
		String[] studentIdRequested = ParamUtil.getParameterValues(actionRequest, "studentId");
		long courseId = ParamUtil.getLong(actionRequest, "courseId"); _log.info(courseId);
		
		for(String s : studentIdRequested) {
			_log.info(s);
			AcceptUserRegisterRequestActionUtil.approvalRequest(courseId, Long.parseLong(s), 1);
			
			//use message bus to message that student's request have been accepted
			String destination = "messageListener/educator_usesrObject/respone";
			System.out.println("Send message method is calling...");
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			
			long studentId = Long.parseLong(s);
			String message = " have accepted your register request";
			jsonObject.put("message", message);
			jsonObject.put("studentId", studentId);
			jsonObject.put("courseIdOfReq", courseId);
			jsonObject.put("companyId", companyId);
			
			MessageBusUtil.sendMessage(destination, jsonObject.toString());
		
		//end message bus
		}
	}
	
	public void updateUserSkill(ActionRequest actionRequest, 
			ActionResponse actionResponse) throws Exception {
		
		_log.info("***********************************");
		
		String[] studentIdRequested = ParamUtil.getParameterValues(actionRequest, "studentId");
		long courseId = ParamUtil.getLong(actionRequest, "courseId"); _log.info(courseId);
		Course course = CourseLocalServiceUtil.getCourse(courseId);
		List<Skill> skills = SkillLocalServiceUtil.getTrainingProgramSkills(course.getTrainingProgramId());
		
		for(String s : studentIdRequested) {
			_log.info(s); User u = UserLocalServiceUtil.getUser(Long.parseLong(s));
			for(int i=0; i<skills.size(); i++) {
				_log.info(u.getFullName() + "\t" +skills.get(i).getSkillName());
				
				UserSkillLevel userSkillLevel = new UserSkillLevelImpl();
				userSkillLevel.setUserObjectId(Long.parseLong(s));
				userSkillLevel.setSkillId(skills.get(i).getSkillId());
				UserSkillLevelLocalServiceUtil.addUserSkillLevel(userSkillLevel);
				
			}
		}
	}
	
	@SuppressWarnings("static-access")
	public void serveResource(ResourceRequest resourceRequest, 
			ResourceResponse resourceResponse) throws IOException, PortletException {
		
		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
		
		try {
			
			long userObjectId = ParamUtil.getLong(resourceRequest, "userObjectId"); _log.info(userObjectId);
			long trainProId = ParamUtil.getLong(resourceRequest, "trainProId"); _log.info(trainProId);
			
			List<Skill> skills = SkillLocalServiceUtil.getTrainingProgramSkills(trainProId);
			for(int i=0; i<skills.size(); i++) {
				long levelId = ParamUtil.getLong(resourceRequest, String.valueOf(skills.get(i).getSkillId()));
				_log.info(levelId);
				UserSkillLevelActionUtil.addUserSkills(userObjectId, skills.get(i).getSkillId(), levelId);
			}
			
		}catch(Exception e) {
			_log.error(e.getClass() + "\n" + e.getMessage());
		}
		//SessionMessages.add(resourceRequest.getPortletSession(), "success");
		/*
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		jsonObject.put("hello", "hello");
		jsonArray.put(jsonObject);
		PrintWriter writer = resourceResponse.getWriter();
		writer.print(jsonArray.toString());
		writer.flush(); writer.close();*/
		
		super.serveResource(resourceRequest, resourceResponse);
	}
	
	Log _log = LogFactoryUtil.getLog(StudentManagement.class);
}

