/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.UserObject;

import java.util.List;

/**
 * The persistence utility for the user object service. This utility wraps {@link UserObjectPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see UserObjectPersistence
 * @see UserObjectPersistenceImpl
 * @generated
 */
public class UserObjectUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(UserObject userObject) {
		getPersistence().clearCache(userObject);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<UserObject> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<UserObject> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<UserObject> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static UserObject update(UserObject userObject)
		throws SystemException {
		return getPersistence().update(userObject);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static UserObject update(UserObject userObject,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(userObject, serviceContext);
	}

	/**
	* Returns the user object where userObjectId = &#63; or throws a {@link com.portlets.action.NoSuchUserObjectException} if it could not be found.
	*
	* @param userObjectId the user object ID
	* @return the matching user object
	* @throws com.portlets.action.NoSuchUserObjectException if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject findByUserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException {
		return getPersistence().findByUserObjectId(userObjectId);
	}

	/**
	* Returns the user object where userObjectId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param userObjectId the user object ID
	* @return the matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject fetchByUserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByUserObjectId(userObjectId);
	}

	/**
	* Returns the user object where userObjectId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param userObjectId the user object ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject fetchByUserObjectId(
		long userObjectId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUserObjectId(userObjectId, retrieveFromCache);
	}

	/**
	* Removes the user object where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @return the user object that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject removeByUserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException {
		return getPersistence().removeByUserObjectId(userObjectId);
	}

	/**
	* Returns the number of user objects where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUserObjectId(userObjectId);
	}

	/**
	* Returns all the user objects where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @return the matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> findByUserObjectName(
		java.lang.String userObjectName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserObjectName(userObjectName);
	}

	/**
	* Returns a range of all the user objects where userObjectName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectName the user object name
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> findByUserObjectName(
		java.lang.String userObjectName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByUserObjectName(userObjectName, start, end);
	}

	/**
	* Returns an ordered range of all the user objects where userObjectName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectName the user object name
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> findByUserObjectName(
		java.lang.String userObjectName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByUserObjectName(userObjectName, start, end,
			orderByComparator);
	}

	/**
	* Returns the first user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user object
	* @throws com.portlets.action.NoSuchUserObjectException if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject findByUserObjectName_First(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException {
		return getPersistence()
				   .findByUserObjectName_First(userObjectName, orderByComparator);
	}

	/**
	* Returns the first user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject fetchByUserObjectName_First(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUserObjectName_First(userObjectName,
			orderByComparator);
	}

	/**
	* Returns the last user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user object
	* @throws com.portlets.action.NoSuchUserObjectException if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject findByUserObjectName_Last(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException {
		return getPersistence()
				   .findByUserObjectName_Last(userObjectName, orderByComparator);
	}

	/**
	* Returns the last user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching user object, or <code>null</code> if a matching user object could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject fetchByUserObjectName_Last(
		java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByUserObjectName_Last(userObjectName, orderByComparator);
	}

	/**
	* Returns the user objects before and after the current user object in the ordered set where userObjectName = &#63;.
	*
	* @param userObjectId the primary key of the current user object
	* @param userObjectName the user object name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next user object
	* @throws com.portlets.action.NoSuchUserObjectException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject[] findByUserObjectName_PrevAndNext(
		long userObjectId, java.lang.String userObjectName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException {
		return getPersistence()
				   .findByUserObjectName_PrevAndNext(userObjectId,
			userObjectName, orderByComparator);
	}

	/**
	* Removes all the user objects where userObjectName = &#63; from the database.
	*
	* @param userObjectName the user object name
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByUserObjectName(java.lang.String userObjectName)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByUserObjectName(userObjectName);
	}

	/**
	* Returns the number of user objects where userObjectName = &#63;.
	*
	* @param userObjectName the user object name
	* @return the number of matching user objects
	* @throws SystemException if a system exception occurred
	*/
	public static int countByUserObjectName(java.lang.String userObjectName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByUserObjectName(userObjectName);
	}

	/**
	* Caches the user object in the entity cache if it is enabled.
	*
	* @param userObject the user object
	*/
	public static void cacheResult(
		com.portlets.action.model.UserObject userObject) {
		getPersistence().cacheResult(userObject);
	}

	/**
	* Caches the user objects in the entity cache if it is enabled.
	*
	* @param userObjects the user objects
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.UserObject> userObjects) {
		getPersistence().cacheResult(userObjects);
	}

	/**
	* Creates a new user object with the primary key. Does not add the user object to the database.
	*
	* @param userObjectId the primary key for the new user object
	* @return the new user object
	*/
	public static com.portlets.action.model.UserObject create(long userObjectId) {
		return getPersistence().create(userObjectId);
	}

	/**
	* Removes the user object with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object that was removed
	* @throws com.portlets.action.NoSuchUserObjectException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject remove(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException {
		return getPersistence().remove(userObjectId);
	}

	public static com.portlets.action.model.UserObject updateImpl(
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(userObject);
	}

	/**
	* Returns the user object with the primary key or throws a {@link com.portlets.action.NoSuchUserObjectException} if it could not be found.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object
	* @throws com.portlets.action.NoSuchUserObjectException if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject findByPrimaryKey(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchUserObjectException {
		return getPersistence().findByPrimaryKey(userObjectId);
	}

	/**
	* Returns the user object with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param userObjectId the primary key of the user object
	* @return the user object, or <code>null</code> if a user object with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.UserObject fetchByPrimaryKey(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(userObjectId);
	}

	/**
	* Returns all the user objects.
	*
	* @return the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the user objects.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of user objects
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the user objects.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user objects
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the user objects from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of user objects.
	*
	* @return the number of user objects
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	/**
	* Returns all the educators associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Educator> getEducators(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEducators(pk);
	}

	/**
	* Returns a range of all the educators associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Educator> getEducators(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEducators(pk, start, end);
	}

	/**
	* Returns an ordered range of all the educators associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Educator> getEducators(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEducators(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of educators associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of educators associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static int getEducatorsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEducatorsSize(pk);
	}

	/**
	* Returns <code>true</code> if the educator is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param educatorPK the primary key of the educator
	* @return <code>true</code> if the educator is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsEducator(long pk, long educatorPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsEducator(pk, educatorPK);
	}

	/**
	* Returns <code>true</code> if the user object has any educators associated with it.
	*
	* @param pk the primary key of the user object to check for associations with educators
	* @return <code>true</code> if the user object has any educators associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsEducators(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsEducators(pk);
	}

	/**
	* Adds an association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPK the primary key of the educator
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducator(long pk, long educatorPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEducator(pk, educatorPK);
	}

	/**
	* Adds an association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educator the educator
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducator(long pk,
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEducator(pk, educator);
	}

	/**
	* Adds an association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPKs the primary keys of the educators
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducators(long pk, long[] educatorPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEducators(pk, educatorPKs);
	}

	/**
	* Adds an association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educators the educators
	* @throws SystemException if a system exception occurred
	*/
	public static void addEducators(long pk,
		java.util.List<com.portlets.action.model.Educator> educators)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEducators(pk, educators);
	}

	/**
	* Clears all associations between the user object and its educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated educators from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearEducators(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearEducators(pk);
	}

	/**
	* Removes the association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPK the primary key of the educator
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEducator(long pk, long educatorPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEducator(pk, educatorPK);
	}

	/**
	* Removes the association between the user object and the educator. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educator the educator
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEducator(long pk,
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEducator(pk, educator);
	}

	/**
	* Removes the association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPKs the primary keys of the educators
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEducators(long pk, long[] educatorPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEducators(pk, educatorPKs);
	}

	/**
	* Removes the association between the user object and the educators. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educators the educators
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEducators(long pk,
		java.util.List<com.portlets.action.model.Educator> educators)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEducators(pk, educators);
	}

	/**
	* Sets the educators associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educatorPKs the primary keys of the educators to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setEducators(long pk, long[] educatorPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setEducators(pk, educatorPKs);
	}

	/**
	* Sets the educators associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param educators the educators to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setEducators(long pk,
		java.util.List<com.portlets.action.model.Educator> educators)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setEducators(pk, educators);
	}

	/**
	* Returns all the courses associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> getCourses(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getCourses(pk);
	}

	/**
	* Returns a range of all the courses associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> getCourses(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getCourses(pk, start, end);
	}

	/**
	* Returns an ordered range of all the courses associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> getCourses(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getCourses(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of courses associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of courses associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static int getCoursesSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getCoursesSize(pk);
	}

	/**
	* Returns <code>true</code> if the course is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param coursePK the primary key of the course
	* @return <code>true</code> if the course is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsCourse(long pk, long coursePK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsCourse(pk, coursePK);
	}

	/**
	* Returns <code>true</code> if the user object has any courses associated with it.
	*
	* @param pk the primary key of the user object to check for associations with courses
	* @return <code>true</code> if the user object has any courses associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsCourses(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsCourses(pk);
	}

	/**
	* Adds an association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePK the primary key of the course
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourse(long pk, long coursePK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addCourse(pk, coursePK);
	}

	/**
	* Adds an association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param course the course
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourse(long pk,
		com.portlets.action.model.Course course)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addCourse(pk, course);
	}

	/**
	* Adds an association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePKs the primary keys of the courses
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourses(long pk, long[] coursePKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addCourses(pk, coursePKs);
	}

	/**
	* Adds an association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param courses the courses
	* @throws SystemException if a system exception occurred
	*/
	public static void addCourses(long pk,
		java.util.List<com.portlets.action.model.Course> courses)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addCourses(pk, courses);
	}

	/**
	* Clears all associations between the user object and its courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated courses from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearCourses(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearCourses(pk);
	}

	/**
	* Removes the association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePK the primary key of the course
	* @throws SystemException if a system exception occurred
	*/
	public static void removeCourse(long pk, long coursePK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeCourse(pk, coursePK);
	}

	/**
	* Removes the association between the user object and the course. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param course the course
	* @throws SystemException if a system exception occurred
	*/
	public static void removeCourse(long pk,
		com.portlets.action.model.Course course)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeCourse(pk, course);
	}

	/**
	* Removes the association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePKs the primary keys of the courses
	* @throws SystemException if a system exception occurred
	*/
	public static void removeCourses(long pk, long[] coursePKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeCourses(pk, coursePKs);
	}

	/**
	* Removes the association between the user object and the courses. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param courses the courses
	* @throws SystemException if a system exception occurred
	*/
	public static void removeCourses(long pk,
		java.util.List<com.portlets.action.model.Course> courses)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeCourses(pk, courses);
	}

	/**
	* Sets the courses associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param coursePKs the primary keys of the courses to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setCourses(long pk, long[] coursePKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setCourses(pk, coursePKs);
	}

	/**
	* Sets the courses associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param courses the courses to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setCourses(long pk,
		java.util.List<com.portlets.action.model.Course> courses)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setCourses(pk, courses);
	}

	/**
	* Returns all the employers associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Employer> getEmployers(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEmployers(pk);
	}

	/**
	* Returns a range of all the employers associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Employer> getEmployers(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEmployers(pk, start, end);
	}

	/**
	* Returns an ordered range of all the employers associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Employer> getEmployers(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEmployers(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of employers associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of employers associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static int getEmployersSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getEmployersSize(pk);
	}

	/**
	* Returns <code>true</code> if the employer is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param employerPK the primary key of the employer
	* @return <code>true</code> if the employer is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsEmployer(long pk, long employerPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsEmployer(pk, employerPK);
	}

	/**
	* Returns <code>true</code> if the user object has any employers associated with it.
	*
	* @param pk the primary key of the user object to check for associations with employers
	* @return <code>true</code> if the user object has any employers associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsEmployers(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsEmployers(pk);
	}

	/**
	* Adds an association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPK the primary key of the employer
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployer(long pk, long employerPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEmployer(pk, employerPK);
	}

	/**
	* Adds an association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employer the employer
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployer(long pk,
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEmployer(pk, employer);
	}

	/**
	* Adds an association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPKs the primary keys of the employers
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployers(long pk, long[] employerPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEmployers(pk, employerPKs);
	}

	/**
	* Adds an association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employers the employers
	* @throws SystemException if a system exception occurred
	*/
	public static void addEmployers(long pk,
		java.util.List<com.portlets.action.model.Employer> employers)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addEmployers(pk, employers);
	}

	/**
	* Clears all associations between the user object and its employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated employers from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearEmployers(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearEmployers(pk);
	}

	/**
	* Removes the association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPK the primary key of the employer
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEmployer(long pk, long employerPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEmployer(pk, employerPK);
	}

	/**
	* Removes the association between the user object and the employer. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employer the employer
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEmployer(long pk,
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEmployer(pk, employer);
	}

	/**
	* Removes the association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPKs the primary keys of the employers
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEmployers(long pk, long[] employerPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEmployers(pk, employerPKs);
	}

	/**
	* Removes the association between the user object and the employers. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employers the employers
	* @throws SystemException if a system exception occurred
	*/
	public static void removeEmployers(long pk,
		java.util.List<com.portlets.action.model.Employer> employers)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeEmployers(pk, employers);
	}

	/**
	* Sets the employers associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employerPKs the primary keys of the employers to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setEmployers(long pk, long[] employerPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setEmployers(pk, employerPKs);
	}

	/**
	* Sets the employers associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param employers the employers to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setEmployers(long pk,
		java.util.List<com.portlets.action.model.Employer> employers)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setEmployers(pk, employers);
	}

	/**
	* Returns all the recruitments associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getRecruitments(pk);
	}

	/**
	* Returns a range of all the recruitments associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @return the range of recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getRecruitments(pk, start, end);
	}

	/**
	* Returns an ordered range of all the recruitments associated with the user object.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.UserObjectModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the user object
	* @param start the lower bound of the range of user objects
	* @param end the upper bound of the range of user objects (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> getRecruitments(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .getRecruitments(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of recruitments associated with the user object.
	*
	* @param pk the primary key of the user object
	* @return the number of recruitments associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static int getRecruitmentsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getRecruitmentsSize(pk);
	}

	/**
	* Returns <code>true</code> if the recruitment is associated with the user object.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPK the primary key of the recruitment
	* @return <code>true</code> if the recruitment is associated with the user object; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsRecruitment(pk, recruitmentPK);
	}

	/**
	* Returns <code>true</code> if the user object has any recruitments associated with it.
	*
	* @param pk the primary key of the user object to check for associations with recruitments
	* @return <code>true</code> if the user object has any recruitments associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsRecruitments(pk);
	}

	/**
	* Adds an association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitment(pk, recruitmentPK);
	}

	/**
	* Adds an association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitment(pk, recruitment);
	}

	/**
	* Adds an association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitments(pk, recruitmentPKs);
	}

	/**
	* Adds an association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void addRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addRecruitments(pk, recruitments);
	}

	/**
	* Clears all associations between the user object and its recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object to clear the associated recruitments from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearRecruitments(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearRecruitments(pk);
	}

	/**
	* Removes the association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPK the primary key of the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitment(long pk, long recruitmentPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitment(pk, recruitmentPK);
	}

	/**
	* Removes the association between the user object and the recruitment. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitment the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitment(long pk,
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitment(pk, recruitment);
	}

	/**
	* Removes the association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPKs the primary keys of the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitments(pk, recruitmentPKs);
	}

	/**
	* Removes the association between the user object and the recruitments. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitments the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static void removeRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeRecruitments(pk, recruitments);
	}

	/**
	* Sets the recruitments associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitmentPKs the primary keys of the recruitments to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setRecruitments(long pk, long[] recruitmentPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setRecruitments(pk, recruitmentPKs);
	}

	/**
	* Sets the recruitments associated with the user object, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the user object
	* @param recruitments the recruitments to be associated with the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void setRecruitments(long pk,
		java.util.List<com.portlets.action.model.Recruitment> recruitments)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setRecruitments(pk, recruitments);
	}

	public static UserObjectPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (UserObjectPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					UserObjectPersistence.class.getName());

			ReferenceRegistry.registerReference(UserObjectUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(UserObjectPersistence persistence) {
	}

	private static UserObjectPersistence _persistence;
}