/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.TrainingProgramLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class TrainingProgramClp extends BaseModelImpl<TrainingProgram>
	implements TrainingProgram {
	public TrainingProgramClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return TrainingProgram.class;
	}

	@Override
	public String getModelClassName() {
		return TrainingProgram.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _trainingProgramId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setTrainingProgramId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _trainingProgramId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("trainingProgramId", getTrainingProgramId());
		attributes.put("trainingProgramName", getTrainingProgramName());
		attributes.put("trainingProgramPeriod", getTrainingProgramPeriod());
		attributes.put("trainingProgramPurpose", getTrainingProgramPurpose());
		attributes.put("trainingProgramDiploma", getTrainingProgramDiploma());
		attributes.put("trainingProgramFee", getTrainingProgramFee());
		attributes.put("trainingProgramItems", getTrainingProgramItems());
		attributes.put("trainingProgramContent", getTrainingProgramContent());
		attributes.put("trainingProgramDescription",
			getTrainingProgramDescription());
		attributes.put("educatorId", getEducatorId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long trainingProgramId = (Long)attributes.get("trainingProgramId");

		if (trainingProgramId != null) {
			setTrainingProgramId(trainingProgramId);
		}

		String trainingProgramName = (String)attributes.get(
				"trainingProgramName");

		if (trainingProgramName != null) {
			setTrainingProgramName(trainingProgramName);
		}

		String trainingProgramPeriod = (String)attributes.get(
				"trainingProgramPeriod");

		if (trainingProgramPeriod != null) {
			setTrainingProgramPeriod(trainingProgramPeriod);
		}

		String trainingProgramPurpose = (String)attributes.get(
				"trainingProgramPurpose");

		if (trainingProgramPurpose != null) {
			setTrainingProgramPurpose(trainingProgramPurpose);
		}

		String trainingProgramDiploma = (String)attributes.get(
				"trainingProgramDiploma");

		if (trainingProgramDiploma != null) {
			setTrainingProgramDiploma(trainingProgramDiploma);
		}

		Double trainingProgramFee = (Double)attributes.get("trainingProgramFee");

		if (trainingProgramFee != null) {
			setTrainingProgramFee(trainingProgramFee);
		}

		String trainingProgramItems = (String)attributes.get(
				"trainingProgramItems");

		if (trainingProgramItems != null) {
			setTrainingProgramItems(trainingProgramItems);
		}

		String trainingProgramContent = (String)attributes.get(
				"trainingProgramContent");

		if (trainingProgramContent != null) {
			setTrainingProgramContent(trainingProgramContent);
		}

		String trainingProgramDescription = (String)attributes.get(
				"trainingProgramDescription");

		if (trainingProgramDescription != null) {
			setTrainingProgramDescription(trainingProgramDescription);
		}

		Long educatorId = (Long)attributes.get("educatorId");

		if (educatorId != null) {
			setEducatorId(educatorId);
		}
	}

	@Override
	public long getTrainingProgramId() {
		return _trainingProgramId;
	}

	@Override
	public void setTrainingProgramId(long trainingProgramId) {
		_trainingProgramId = trainingProgramId;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramId",
						long.class);

				method.invoke(_trainingProgramRemoteModel, trainingProgramId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingProgramName() {
		return _trainingProgramName;
	}

	@Override
	public void setTrainingProgramName(String trainingProgramName) {
		_trainingProgramName = trainingProgramName;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramName",
						String.class);

				method.invoke(_trainingProgramRemoteModel, trainingProgramName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingProgramPeriod() {
		return _trainingProgramPeriod;
	}

	@Override
	public void setTrainingProgramPeriod(String trainingProgramPeriod) {
		_trainingProgramPeriod = trainingProgramPeriod;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramPeriod",
						String.class);

				method.invoke(_trainingProgramRemoteModel, trainingProgramPeriod);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingProgramPurpose() {
		return _trainingProgramPurpose;
	}

	@Override
	public void setTrainingProgramPurpose(String trainingProgramPurpose) {
		_trainingProgramPurpose = trainingProgramPurpose;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramPurpose",
						String.class);

				method.invoke(_trainingProgramRemoteModel,
					trainingProgramPurpose);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingProgramDiploma() {
		return _trainingProgramDiploma;
	}

	@Override
	public void setTrainingProgramDiploma(String trainingProgramDiploma) {
		_trainingProgramDiploma = trainingProgramDiploma;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramDiploma",
						String.class);

				method.invoke(_trainingProgramRemoteModel,
					trainingProgramDiploma);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public double getTrainingProgramFee() {
		return _trainingProgramFee;
	}

	@Override
	public void setTrainingProgramFee(double trainingProgramFee) {
		_trainingProgramFee = trainingProgramFee;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramFee",
						double.class);

				method.invoke(_trainingProgramRemoteModel, trainingProgramFee);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingProgramItems() {
		return _trainingProgramItems;
	}

	@Override
	public void setTrainingProgramItems(String trainingProgramItems) {
		_trainingProgramItems = trainingProgramItems;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramItems",
						String.class);

				method.invoke(_trainingProgramRemoteModel, trainingProgramItems);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingProgramContent() {
		return _trainingProgramContent;
	}

	@Override
	public void setTrainingProgramContent(String trainingProgramContent) {
		_trainingProgramContent = trainingProgramContent;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramContent",
						String.class);

				method.invoke(_trainingProgramRemoteModel,
					trainingProgramContent);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getTrainingProgramDescription() {
		return _trainingProgramDescription;
	}

	@Override
	public void setTrainingProgramDescription(String trainingProgramDescription) {
		_trainingProgramDescription = trainingProgramDescription;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setTrainingProgramDescription",
						String.class);

				method.invoke(_trainingProgramRemoteModel,
					trainingProgramDescription);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getEducatorId() {
		return _educatorId;
	}

	@Override
	public void setEducatorId(long educatorId) {
		_educatorId = educatorId;

		if (_trainingProgramRemoteModel != null) {
			try {
				Class<?> clazz = _trainingProgramRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorId", long.class);

				method.invoke(_trainingProgramRemoteModel, educatorId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getTrainingProgramRemoteModel() {
		return _trainingProgramRemoteModel;
	}

	public void setTrainingProgramRemoteModel(
		BaseModel<?> trainingProgramRemoteModel) {
		_trainingProgramRemoteModel = trainingProgramRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _trainingProgramRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_trainingProgramRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			TrainingProgramLocalServiceUtil.addTrainingProgram(this);
		}
		else {
			TrainingProgramLocalServiceUtil.updateTrainingProgram(this);
		}
	}

	@Override
	public TrainingProgram toEscapedModel() {
		return (TrainingProgram)ProxyUtil.newProxyInstance(TrainingProgram.class.getClassLoader(),
			new Class[] { TrainingProgram.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		TrainingProgramClp clone = new TrainingProgramClp();

		clone.setTrainingProgramId(getTrainingProgramId());
		clone.setTrainingProgramName(getTrainingProgramName());
		clone.setTrainingProgramPeriod(getTrainingProgramPeriod());
		clone.setTrainingProgramPurpose(getTrainingProgramPurpose());
		clone.setTrainingProgramDiploma(getTrainingProgramDiploma());
		clone.setTrainingProgramFee(getTrainingProgramFee());
		clone.setTrainingProgramItems(getTrainingProgramItems());
		clone.setTrainingProgramContent(getTrainingProgramContent());
		clone.setTrainingProgramDescription(getTrainingProgramDescription());
		clone.setEducatorId(getEducatorId());

		return clone;
	}

	@Override
	public int compareTo(TrainingProgram trainingProgram) {
		long primaryKey = trainingProgram.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof TrainingProgramClp)) {
			return false;
		}

		TrainingProgramClp trainingProgram = (TrainingProgramClp)obj;

		long primaryKey = trainingProgram.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{trainingProgramId=");
		sb.append(getTrainingProgramId());
		sb.append(", trainingProgramName=");
		sb.append(getTrainingProgramName());
		sb.append(", trainingProgramPeriod=");
		sb.append(getTrainingProgramPeriod());
		sb.append(", trainingProgramPurpose=");
		sb.append(getTrainingProgramPurpose());
		sb.append(", trainingProgramDiploma=");
		sb.append(getTrainingProgramDiploma());
		sb.append(", trainingProgramFee=");
		sb.append(getTrainingProgramFee());
		sb.append(", trainingProgramItems=");
		sb.append(getTrainingProgramItems());
		sb.append(", trainingProgramContent=");
		sb.append(getTrainingProgramContent());
		sb.append(", trainingProgramDescription=");
		sb.append(getTrainingProgramDescription());
		sb.append(", educatorId=");
		sb.append(getEducatorId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(34);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.TrainingProgram");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>trainingProgramId</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramName</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramPeriod</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramPeriod());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramPurpose</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramPurpose());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramDiploma</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramDiploma());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramFee</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramFee());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramItems</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramItems());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramContent</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramContent());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>trainingProgramDescription</column-name><column-value><![CDATA[");
		sb.append(getTrainingProgramDescription());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorId</column-name><column-value><![CDATA[");
		sb.append(getEducatorId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _trainingProgramId;
	private String _trainingProgramName;
	private String _trainingProgramPeriod;
	private String _trainingProgramPurpose;
	private String _trainingProgramDiploma;
	private double _trainingProgramFee;
	private String _trainingProgramItems;
	private String _trainingProgramContent;
	private String _trainingProgramDescription;
	private long _educatorId;
	private BaseModel<?> _trainingProgramRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}