package com.kimtho.portlet.course;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.kimtho.portlet.WebKeysU;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.RegisterCourse;
import com.portlets.action.model.impl.RegisterCourseImpl;
import com.portlets.action.service.RegisterCourseLocalServiceUtil;

/**
 * Portlet implementation class CoursePortlet
 */
public class CoursePortlet extends MVCPortlet {
	@ProcessAction(name = "registerCourse")
	public void registerCourse(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long courseId = ParamUtil.getLong(actionRequest, "courseId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterCourse registerCourse = new RegisterCourseImpl();
		registerCourse.setUserObjectId(userId);
		registerCourse.setCourseId(courseId);
		registerCourse.setStatesId(new Long(10));
		RegisterCourseLocalServiceUtil.addRegisterCourse(registerCourse);
		SessionMessages.add(actionRequest, "added-registerCourse"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Added Register Course Successfully#########################");
	}
	
	@ProcessAction(name = "unRegisterCourse")
	public void unRegisterCourse(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long courseId = ParamUtil.getLong(actionRequest, "courseId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterCourse registerCourse = new RegisterCourseImpl();
		registerCourse.setUserObjectId(userId);
		registerCourse.setCourseId(courseId);
		registerCourse.setStatesId(new Long(10));
		RegisterCourseLocalServiceUtil.deleteRegisterCourse(registerCourse);
		SessionMessages.add(actionRequest, "deleted-registerCourse"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Deleted Register Course Successfully#########################");
	}
	
	@ProcessAction(name = "loadListCourse")
	public void loadListCourse(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String select = ParamUtil.getString(actionRequest, "select","");
		System.out.println("------"+select);
		actionRequest.setAttribute(WebKeysU.LoadListCourse, select); 
		SessionMessages.add(actionRequest, "deleted-registerCourse"); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/course/view.jsp");
		
	   _log.info("#################Load List Course Successfully#########################");
	}
	
	private Log _log = LogFactoryUtil.getLog(CoursePortlet.class.getName());
}
