/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for Employer. This utility wraps
 * {@link com.portlets.action.service.impl.EmployerLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Computer
 * @see EmployerLocalService
 * @see com.portlets.action.service.base.EmployerLocalServiceBaseImpl
 * @see com.portlets.action.service.impl.EmployerLocalServiceImpl
 * @generated
 */
public class EmployerLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.portlets.action.service.impl.EmployerLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the employer to the database. Also notifies the appropriate model listeners.
	*
	* @param employer the employer
	* @return the employer that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Employer addEmployer(
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addEmployer(employer);
	}

	/**
	* Creates a new employer with the primary key. Does not add the employer to the database.
	*
	* @param employerId the primary key for the new employer
	* @return the new employer
	*/
	public static com.portlets.action.model.Employer createEmployer(
		long employerId) {
		return getService().createEmployer(employerId);
	}

	/**
	* Deletes the employer with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param employerId the primary key of the employer
	* @return the employer that was removed
	* @throws PortalException if a employer with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Employer deleteEmployer(
		long employerId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteEmployer(employerId);
	}

	/**
	* Deletes the employer from the database. Also notifies the appropriate model listeners.
	*
	* @param employer the employer
	* @return the employer that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Employer deleteEmployer(
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteEmployer(employer);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EmployerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EmployerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.portlets.action.model.Employer fetchEmployer(
		long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchEmployer(employerId);
	}

	/**
	* Returns the employer with the primary key.
	*
	* @param employerId the primary key of the employer
	* @return the employer
	* @throws PortalException if a employer with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Employer getEmployer(
		long employerId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployer(employerId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the employers.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EmployerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of employers
	* @param end the upper bound of the range of employers (not inclusive)
	* @return the range of employers
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Employer> getEmployers(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployers(start, end);
	}

	/**
	* Returns the number of employers.
	*
	* @return the number of employers
	* @throws SystemException if a system exception occurred
	*/
	public static int getEmployersCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployersCount();
	}

	/**
	* Updates the employer in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param employer the employer
	* @return the employer that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Employer updateEmployer(
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateEmployer(employer);
	}

	public static com.portlets.action.model.EmployerEmployerLogoBlobModel getEmployerLogoBlobModel(
		java.io.Serializable primaryKey)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployerLogoBlobModel(primaryKey);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjectEmployer(long userObjectId, long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addUserObjectEmployer(userObjectId, employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjectEmployer(long userObjectId,
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addUserObjectEmployer(userObjectId, employer);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjectEmployers(long userObjectId,
		long[] employerIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addUserObjectEmployers(userObjectId, employerIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjectEmployers(long userObjectId,
		java.util.List<com.portlets.action.model.Employer> Employers)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addUserObjectEmployers(userObjectId, Employers);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void clearUserObjectEmployers(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().clearUserObjectEmployers(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteUserObjectEmployer(long userObjectId,
		long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteUserObjectEmployer(userObjectId, employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteUserObjectEmployer(long userObjectId,
		com.portlets.action.model.Employer employer)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteUserObjectEmployer(userObjectId, employer);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteUserObjectEmployers(long userObjectId,
		long[] employerIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteUserObjectEmployers(userObjectId, employerIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteUserObjectEmployers(long userObjectId,
		java.util.List<com.portlets.action.model.Employer> Employers)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteUserObjectEmployers(userObjectId, Employers);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Employer> getUserObjectEmployers(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserObjectEmployers(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Employer> getUserObjectEmployers(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserObjectEmployers(userObjectId, start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Employer> getUserObjectEmployers(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getUserObjectEmployers(userObjectId, start, end,
			orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static int getUserObjectEmployersCount(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getUserObjectEmployersCount(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasUserObjectEmployer(long userObjectId,
		long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasUserObjectEmployer(userObjectId, employerId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasUserObjectEmployers(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasUserObjectEmployers(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void setUserObjectEmployers(long userObjectId,
		long[] employerIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().setUserObjectEmployers(userObjectId, employerIds);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static java.util.List<com.portlets.action.model.Employer> searchEmployerLikeOrProperties(
		java.lang.String query, int start, int end) {
		return getService().searchEmployerLikeOrProperties(query, start, end);
	}

	public static java.util.List<com.portlets.action.model.Employer> getEmployerByUserId(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployerByUserId(userId);
	}

	public static java.util.List<com.portlets.action.model.Employer> getEmployerByNoUserId(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getEmployerByNoUserId(userId);
	}

	public static java.util.List<com.portlets.action.model.Employer> searchEmployer(
		java.lang.String employerName, java.lang.String employerEmail,
		java.lang.String employerAddress, java.lang.String employerPhone) {
		return getService()
				   .searchEmployer(employerName, employerEmail,
			employerAddress, employerPhone);
	}

	public static void clearService() {
		_service = null;
	}

	public static EmployerLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					EmployerLocalService.class.getName());

			if (invokableLocalService instanceof EmployerLocalService) {
				_service = (EmployerLocalService)invokableLocalService;
			}
			else {
				_service = new EmployerLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(EmployerLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(EmployerLocalService service) {
	}

	private static EmployerLocalService _service;
}