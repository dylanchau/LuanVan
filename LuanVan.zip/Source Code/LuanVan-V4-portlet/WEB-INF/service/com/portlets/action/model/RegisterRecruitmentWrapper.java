/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link RegisterRecruitment}.
 * </p>
 *
 * @author Computer
 * @see RegisterRecruitment
 * @generated
 */
public class RegisterRecruitmentWrapper implements RegisterRecruitment,
	ModelWrapper<RegisterRecruitment> {
	public RegisterRecruitmentWrapper(RegisterRecruitment registerRecruitment) {
		_registerRecruitment = registerRecruitment;
	}

	@Override
	public Class<?> getModelClass() {
		return RegisterRecruitment.class;
	}

	@Override
	public String getModelClassName() {
		return RegisterRecruitment.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recruitmentId", getRecruitmentId());
		attributes.put("userObjectId", getUserObjectId());
		attributes.put("statesId", getStatesId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long recruitmentId = (Long)attributes.get("recruitmentId");

		if (recruitmentId != null) {
			setRecruitmentId(recruitmentId);
		}

		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}
	}

	/**
	* Returns the primary key of this register recruitment.
	*
	* @return the primary key of this register recruitment
	*/
	@Override
	public com.portlets.action.service.persistence.RegisterRecruitmentPK getPrimaryKey() {
		return _registerRecruitment.getPrimaryKey();
	}

	/**
	* Sets the primary key of this register recruitment.
	*
	* @param primaryKey the primary key of this register recruitment
	*/
	@Override
	public void setPrimaryKey(
		com.portlets.action.service.persistence.RegisterRecruitmentPK primaryKey) {
		_registerRecruitment.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the recruitment ID of this register recruitment.
	*
	* @return the recruitment ID of this register recruitment
	*/
	@Override
	public long getRecruitmentId() {
		return _registerRecruitment.getRecruitmentId();
	}

	/**
	* Sets the recruitment ID of this register recruitment.
	*
	* @param recruitmentId the recruitment ID of this register recruitment
	*/
	@Override
	public void setRecruitmentId(long recruitmentId) {
		_registerRecruitment.setRecruitmentId(recruitmentId);
	}

	/**
	* Returns the user object ID of this register recruitment.
	*
	* @return the user object ID of this register recruitment
	*/
	@Override
	public long getUserObjectId() {
		return _registerRecruitment.getUserObjectId();
	}

	/**
	* Sets the user object ID of this register recruitment.
	*
	* @param userObjectId the user object ID of this register recruitment
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_registerRecruitment.setUserObjectId(userObjectId);
	}

	/**
	* Returns the states ID of this register recruitment.
	*
	* @return the states ID of this register recruitment
	*/
	@Override
	public long getStatesId() {
		return _registerRecruitment.getStatesId();
	}

	/**
	* Sets the states ID of this register recruitment.
	*
	* @param statesId the states ID of this register recruitment
	*/
	@Override
	public void setStatesId(long statesId) {
		_registerRecruitment.setStatesId(statesId);
	}

	@Override
	public boolean isNew() {
		return _registerRecruitment.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_registerRecruitment.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _registerRecruitment.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_registerRecruitment.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _registerRecruitment.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _registerRecruitment.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_registerRecruitment.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _registerRecruitment.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_registerRecruitment.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_registerRecruitment.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_registerRecruitment.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new RegisterRecruitmentWrapper((RegisterRecruitment)_registerRecruitment.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.RegisterRecruitment registerRecruitment) {
		return _registerRecruitment.compareTo(registerRecruitment);
	}

	@Override
	public int hashCode() {
		return _registerRecruitment.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.RegisterRecruitment> toCacheModel() {
		return _registerRecruitment.toCacheModel();
	}

	@Override
	public com.portlets.action.model.RegisterRecruitment toEscapedModel() {
		return new RegisterRecruitmentWrapper(_registerRecruitment.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.RegisterRecruitment toUnescapedModel() {
		return new RegisterRecruitmentWrapper(_registerRecruitment.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _registerRecruitment.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _registerRecruitment.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_registerRecruitment.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RegisterRecruitmentWrapper)) {
			return false;
		}

		RegisterRecruitmentWrapper registerRecruitmentWrapper = (RegisterRecruitmentWrapper)obj;

		if (Validator.equals(_registerRecruitment,
					registerRecruitmentWrapper._registerRecruitment)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public RegisterRecruitment getWrappedRegisterRecruitment() {
		return _registerRecruitment;
	}

	@Override
	public RegisterRecruitment getWrappedModel() {
		return _registerRecruitment;
	}

	@Override
	public void resetOriginalValues() {
		_registerRecruitment.resetOriginalValues();
	}

	private RegisterRecruitment _registerRecruitment;
}