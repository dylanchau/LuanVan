/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.LevelLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class LevelClp extends BaseModelImpl<Level> implements Level {
	public LevelClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Level.class;
	}

	@Override
	public String getModelClassName() {
		return Level.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _levelId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setLevelId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _levelId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("levelId", getLevelId());
		attributes.put("levelName", getLevelName());
		attributes.put("levelExplain", getLevelExplain());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long levelId = (Long)attributes.get("levelId");

		if (levelId != null) {
			setLevelId(levelId);
		}

		String levelName = (String)attributes.get("levelName");

		if (levelName != null) {
			setLevelName(levelName);
		}

		String levelExplain = (String)attributes.get("levelExplain");

		if (levelExplain != null) {
			setLevelExplain(levelExplain);
		}
	}

	@Override
	public long getLevelId() {
		return _levelId;
	}

	@Override
	public void setLevelId(long levelId) {
		_levelId = levelId;

		if (_levelRemoteModel != null) {
			try {
				Class<?> clazz = _levelRemoteModel.getClass();

				Method method = clazz.getMethod("setLevelId", long.class);

				method.invoke(_levelRemoteModel, levelId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLevelName() {
		return _levelName;
	}

	@Override
	public void setLevelName(String levelName) {
		_levelName = levelName;

		if (_levelRemoteModel != null) {
			try {
				Class<?> clazz = _levelRemoteModel.getClass();

				Method method = clazz.getMethod("setLevelName", String.class);

				method.invoke(_levelRemoteModel, levelName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getLevelExplain() {
		return _levelExplain;
	}

	@Override
	public void setLevelExplain(String levelExplain) {
		_levelExplain = levelExplain;

		if (_levelRemoteModel != null) {
			try {
				Class<?> clazz = _levelRemoteModel.getClass();

				Method method = clazz.getMethod("setLevelExplain", String.class);

				method.invoke(_levelRemoteModel, levelExplain);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getLevelRemoteModel() {
		return _levelRemoteModel;
	}

	public void setLevelRemoteModel(BaseModel<?> levelRemoteModel) {
		_levelRemoteModel = levelRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _levelRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_levelRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			LevelLocalServiceUtil.addLevel(this);
		}
		else {
			LevelLocalServiceUtil.updateLevel(this);
		}
	}

	@Override
	public Level toEscapedModel() {
		return (Level)ProxyUtil.newProxyInstance(Level.class.getClassLoader(),
			new Class[] { Level.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		LevelClp clone = new LevelClp();

		clone.setLevelId(getLevelId());
		clone.setLevelName(getLevelName());
		clone.setLevelExplain(getLevelExplain());

		return clone;
	}

	@Override
	public int compareTo(Level level) {
		long primaryKey = level.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LevelClp)) {
			return false;
		}

		LevelClp level = (LevelClp)obj;

		long primaryKey = level.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{levelId=");
		sb.append(getLevelId());
		sb.append(", levelName=");
		sb.append(getLevelName());
		sb.append(", levelExplain=");
		sb.append(getLevelExplain());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(13);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.Level");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>levelId</column-name><column-value><![CDATA[");
		sb.append(getLevelId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>levelName</column-name><column-value><![CDATA[");
		sb.append(getLevelName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>levelExplain</column-name><column-value><![CDATA[");
		sb.append(getLevelExplain());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _levelId;
	private String _levelName;
	private String _levelExplain;
	private BaseModel<?> _levelRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}