/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.EducatorLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.sql.Blob;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class EducatorClp extends BaseModelImpl<Educator> implements Educator {
	public EducatorClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Educator.class;
	}

	@Override
	public String getModelClassName() {
		return Educator.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _educatorId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setEducatorId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _educatorId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("educatorId", getEducatorId());
		attributes.put("educatorName", getEducatorName());
		attributes.put("educatorAddress", getEducatorAddress());
		attributes.put("educatorEmail", getEducatorEmail());
		attributes.put("educatorPhone", getEducatorPhone());
		attributes.put("educatorIntroduce", getEducatorIntroduce());
		attributes.put("euducatorAchievements", getEuducatorAchievements());
		attributes.put("educatorLogoName", getEducatorLogoName());
		attributes.put("educatorLogo", getEducatorLogo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long educatorId = (Long)attributes.get("educatorId");

		if (educatorId != null) {
			setEducatorId(educatorId);
		}

		String educatorName = (String)attributes.get("educatorName");

		if (educatorName != null) {
			setEducatorName(educatorName);
		}

		String educatorAddress = (String)attributes.get("educatorAddress");

		if (educatorAddress != null) {
			setEducatorAddress(educatorAddress);
		}

		String educatorEmail = (String)attributes.get("educatorEmail");

		if (educatorEmail != null) {
			setEducatorEmail(educatorEmail);
		}

		String educatorPhone = (String)attributes.get("educatorPhone");

		if (educatorPhone != null) {
			setEducatorPhone(educatorPhone);
		}

		String educatorIntroduce = (String)attributes.get("educatorIntroduce");

		if (educatorIntroduce != null) {
			setEducatorIntroduce(educatorIntroduce);
		}

		String euducatorAchievements = (String)attributes.get(
				"euducatorAchievements");

		if (euducatorAchievements != null) {
			setEuducatorAchievements(euducatorAchievements);
		}

		String educatorLogoName = (String)attributes.get("educatorLogoName");

		if (educatorLogoName != null) {
			setEducatorLogoName(educatorLogoName);
		}

		Blob educatorLogo = (Blob)attributes.get("educatorLogo");

		if (educatorLogo != null) {
			setEducatorLogo(educatorLogo);
		}
	}

	@Override
	public long getEducatorId() {
		return _educatorId;
	}

	@Override
	public void setEducatorId(long educatorId) {
		_educatorId = educatorId;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorId", long.class);

				method.invoke(_educatorRemoteModel, educatorId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducatorName() {
		return _educatorName;
	}

	@Override
	public void setEducatorName(String educatorName) {
		_educatorName = educatorName;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorName", String.class);

				method.invoke(_educatorRemoteModel, educatorName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducatorAddress() {
		return _educatorAddress;
	}

	@Override
	public void setEducatorAddress(String educatorAddress) {
		_educatorAddress = educatorAddress;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorAddress",
						String.class);

				method.invoke(_educatorRemoteModel, educatorAddress);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducatorEmail() {
		return _educatorEmail;
	}

	@Override
	public void setEducatorEmail(String educatorEmail) {
		_educatorEmail = educatorEmail;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorEmail", String.class);

				method.invoke(_educatorRemoteModel, educatorEmail);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducatorPhone() {
		return _educatorPhone;
	}

	@Override
	public void setEducatorPhone(String educatorPhone) {
		_educatorPhone = educatorPhone;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorPhone", String.class);

				method.invoke(_educatorRemoteModel, educatorPhone);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducatorIntroduce() {
		return _educatorIntroduce;
	}

	@Override
	public void setEducatorIntroduce(String educatorIntroduce) {
		_educatorIntroduce = educatorIntroduce;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorIntroduce",
						String.class);

				method.invoke(_educatorRemoteModel, educatorIntroduce);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEuducatorAchievements() {
		return _euducatorAchievements;
	}

	@Override
	public void setEuducatorAchievements(String euducatorAchievements) {
		_euducatorAchievements = euducatorAchievements;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEuducatorAchievements",
						String.class);

				method.invoke(_educatorRemoteModel, euducatorAchievements);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getEducatorLogoName() {
		return _educatorLogoName;
	}

	@Override
	public void setEducatorLogoName(String educatorLogoName) {
		_educatorLogoName = educatorLogoName;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorLogoName",
						String.class);

				method.invoke(_educatorRemoteModel, educatorLogoName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public Blob getEducatorLogo() {
		return _educatorLogo;
	}

	@Override
	public void setEducatorLogo(Blob educatorLogo) {
		_educatorLogo = educatorLogo;

		if (_educatorRemoteModel != null) {
			try {
				Class<?> clazz = _educatorRemoteModel.getClass();

				Method method = clazz.getMethod("setEducatorLogo", Blob.class);

				method.invoke(_educatorRemoteModel, educatorLogo);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getEducatorRemoteModel() {
		return _educatorRemoteModel;
	}

	public void setEducatorRemoteModel(BaseModel<?> educatorRemoteModel) {
		_educatorRemoteModel = educatorRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _educatorRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_educatorRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			EducatorLocalServiceUtil.addEducator(this);
		}
		else {
			EducatorLocalServiceUtil.updateEducator(this);
		}
	}

	@Override
	public Educator toEscapedModel() {
		return (Educator)ProxyUtil.newProxyInstance(Educator.class.getClassLoader(),
			new Class[] { Educator.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		EducatorClp clone = new EducatorClp();

		clone.setEducatorId(getEducatorId());
		clone.setEducatorName(getEducatorName());
		clone.setEducatorAddress(getEducatorAddress());
		clone.setEducatorEmail(getEducatorEmail());
		clone.setEducatorPhone(getEducatorPhone());
		clone.setEducatorIntroduce(getEducatorIntroduce());
		clone.setEuducatorAchievements(getEuducatorAchievements());
		clone.setEducatorLogoName(getEducatorLogoName());
		clone.setEducatorLogo(getEducatorLogo());

		return clone;
	}

	@Override
	public int compareTo(Educator educator) {
		long primaryKey = educator.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EducatorClp)) {
			return false;
		}

		EducatorClp educator = (EducatorClp)obj;

		long primaryKey = educator.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(19);

		sb.append("{educatorId=");
		sb.append(getEducatorId());
		sb.append(", educatorName=");
		sb.append(getEducatorName());
		sb.append(", educatorAddress=");
		sb.append(getEducatorAddress());
		sb.append(", educatorEmail=");
		sb.append(getEducatorEmail());
		sb.append(", educatorPhone=");
		sb.append(getEducatorPhone());
		sb.append(", educatorIntroduce=");
		sb.append(getEducatorIntroduce());
		sb.append(", euducatorAchievements=");
		sb.append(getEuducatorAchievements());
		sb.append(", educatorLogoName=");
		sb.append(getEducatorLogoName());
		sb.append(", educatorLogo=");
		sb.append(getEducatorLogo());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(31);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.Educator");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>educatorId</column-name><column-value><![CDATA[");
		sb.append(getEducatorId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorName</column-name><column-value><![CDATA[");
		sb.append(getEducatorName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorAddress</column-name><column-value><![CDATA[");
		sb.append(getEducatorAddress());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorEmail</column-name><column-value><![CDATA[");
		sb.append(getEducatorEmail());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorPhone</column-name><column-value><![CDATA[");
		sb.append(getEducatorPhone());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorIntroduce</column-name><column-value><![CDATA[");
		sb.append(getEducatorIntroduce());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>euducatorAchievements</column-name><column-value><![CDATA[");
		sb.append(getEuducatorAchievements());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorLogoName</column-name><column-value><![CDATA[");
		sb.append(getEducatorLogoName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>educatorLogo</column-name><column-value><![CDATA[");
		sb.append(getEducatorLogo());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _educatorId;
	private String _educatorName;
	private String _educatorAddress;
	private String _educatorEmail;
	private String _educatorPhone;
	private String _educatorIntroduce;
	private String _euducatorAchievements;
	private String _educatorLogoName;
	private Blob _educatorLogo;
	private BaseModel<?> _educatorRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}