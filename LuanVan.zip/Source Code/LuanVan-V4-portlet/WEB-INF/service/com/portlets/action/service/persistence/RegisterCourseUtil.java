/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.RegisterCourse;

import java.util.List;

/**
 * The persistence utility for the register course service. This utility wraps {@link RegisterCoursePersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see RegisterCoursePersistence
 * @see RegisterCoursePersistenceImpl
 * @generated
 */
public class RegisterCourseUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(RegisterCourse registerCourse) {
		getPersistence().clearCache(registerCourse);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<RegisterCourse> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<RegisterCourse> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<RegisterCourse> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static RegisterCourse update(RegisterCourse registerCourse)
		throws SystemException {
		return getPersistence().update(registerCourse);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static RegisterCourse update(RegisterCourse registerCourse,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(registerCourse, serviceContext);
	}

	/**
	* Returns all the register courses where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findBystatesId(
		long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId);
	}

	/**
	* Returns a range of all the register courses where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @return the range of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findBystatesId(
		long statesId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId, start, end);
	}

	/**
	* Returns an ordered range of all the register courses where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findBystatesId(
		long statesId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBystatesId(statesId, start, end, orderByComparator);
	}

	/**
	* Returns the first register course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse findBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence().findBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the first register course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register course, or <code>null</code> if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse fetchBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the last register course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse findBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence().findBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the last register course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register course, or <code>null</code> if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse fetchBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the register courses before and after the current register course in the ordered set where statesId = &#63;.
	*
	* @param registerCoursePK the primary key of the current register course
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a register course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse[] findBystatesId_PrevAndNext(
		com.portlets.action.service.persistence.RegisterCoursePK registerCoursePK,
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence()
				   .findBystatesId_PrevAndNext(registerCoursePK, statesId,
			orderByComparator);
	}

	/**
	* Removes all the register courses where statesId = &#63; from the database.
	*
	* @param statesId the states ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystatesId(statesId);
	}

	/**
	* Returns the number of register courses where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the number of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystatesId(statesId);
	}

	/**
	* Returns all the register courses where courseId = &#63;.
	*
	* @param courseId the course ID
	* @return the matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findBycourseId(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycourseId(courseId);
	}

	/**
	* Returns a range of all the register courses where courseId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param courseId the course ID
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @return the range of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findBycourseId(
		long courseId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBycourseId(courseId, start, end);
	}

	/**
	* Returns an ordered range of all the register courses where courseId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param courseId the course ID
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findBycourseId(
		long courseId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBycourseId(courseId, start, end, orderByComparator);
	}

	/**
	* Returns the first register course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse findBycourseId_First(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence().findBycourseId_First(courseId, orderByComparator);
	}

	/**
	* Returns the first register course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register course, or <code>null</code> if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse fetchBycourseId_First(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBycourseId_First(courseId, orderByComparator);
	}

	/**
	* Returns the last register course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse findBycourseId_Last(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence().findBycourseId_Last(courseId, orderByComparator);
	}

	/**
	* Returns the last register course in the ordered set where courseId = &#63;.
	*
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register course, or <code>null</code> if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse fetchBycourseId_Last(
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBycourseId_Last(courseId, orderByComparator);
	}

	/**
	* Returns the register courses before and after the current register course in the ordered set where courseId = &#63;.
	*
	* @param registerCoursePK the primary key of the current register course
	* @param courseId the course ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a register course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse[] findBycourseId_PrevAndNext(
		com.portlets.action.service.persistence.RegisterCoursePK registerCoursePK,
		long courseId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence()
				   .findBycourseId_PrevAndNext(registerCoursePK, courseId,
			orderByComparator);
	}

	/**
	* Removes all the register courses where courseId = &#63; from the database.
	*
	* @param courseId the course ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBycourseId(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBycourseId(courseId);
	}

	/**
	* Returns the number of register courses where courseId = &#63;.
	*
	* @param courseId the course ID
	* @return the number of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countBycourseId(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBycourseId(courseId);
	}

	/**
	* Returns all the register courses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findByuserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId);
	}

	/**
	* Returns a range of all the register courses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @return the range of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findByuserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByuserObjectId(userObjectId, start, end);
	}

	/**
	* Returns an ordered range of all the register courses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findByuserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByuserObjectId(userObjectId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first register course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse findByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence()
				   .findByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the first register course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching register course, or <code>null</code> if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse fetchByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_First(userObjectId, orderByComparator);
	}

	/**
	* Returns the last register course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse findByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence()
				   .findByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the last register course in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching register course, or <code>null</code> if a matching register course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse fetchByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByuserObjectId_Last(userObjectId, orderByComparator);
	}

	/**
	* Returns the register courses before and after the current register course in the ordered set where userObjectId = &#63;.
	*
	* @param registerCoursePK the primary key of the current register course
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a register course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse[] findByuserObjectId_PrevAndNext(
		com.portlets.action.service.persistence.RegisterCoursePK registerCoursePK,
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence()
				   .findByuserObjectId_PrevAndNext(registerCoursePK,
			userObjectId, orderByComparator);
	}

	/**
	* Removes all the register courses where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByuserObjectId(userObjectId);
	}

	/**
	* Returns the number of register courses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching register courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByuserObjectId(userObjectId);
	}

	/**
	* Caches the register course in the entity cache if it is enabled.
	*
	* @param registerCourse the register course
	*/
	public static void cacheResult(
		com.portlets.action.model.RegisterCourse registerCourse) {
		getPersistence().cacheResult(registerCourse);
	}

	/**
	* Caches the register courses in the entity cache if it is enabled.
	*
	* @param registerCourses the register courses
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.RegisterCourse> registerCourses) {
		getPersistence().cacheResult(registerCourses);
	}

	/**
	* Creates a new register course with the primary key. Does not add the register course to the database.
	*
	* @param registerCoursePK the primary key for the new register course
	* @return the new register course
	*/
	public static com.portlets.action.model.RegisterCourse create(
		com.portlets.action.service.persistence.RegisterCoursePK registerCoursePK) {
		return getPersistence().create(registerCoursePK);
	}

	/**
	* Removes the register course with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param registerCoursePK the primary key of the register course
	* @return the register course that was removed
	* @throws com.portlets.action.NoSuchRegisterCourseException if a register course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse remove(
		com.portlets.action.service.persistence.RegisterCoursePK registerCoursePK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence().remove(registerCoursePK);
	}

	public static com.portlets.action.model.RegisterCourse updateImpl(
		com.portlets.action.model.RegisterCourse registerCourse)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(registerCourse);
	}

	/**
	* Returns the register course with the primary key or throws a {@link com.portlets.action.NoSuchRegisterCourseException} if it could not be found.
	*
	* @param registerCoursePK the primary key of the register course
	* @return the register course
	* @throws com.portlets.action.NoSuchRegisterCourseException if a register course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse findByPrimaryKey(
		com.portlets.action.service.persistence.RegisterCoursePK registerCoursePK)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRegisterCourseException {
		return getPersistence().findByPrimaryKey(registerCoursePK);
	}

	/**
	* Returns the register course with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param registerCoursePK the primary key of the register course
	* @return the register course, or <code>null</code> if a register course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.RegisterCourse fetchByPrimaryKey(
		com.portlets.action.service.persistence.RegisterCoursePK registerCoursePK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(registerCoursePK);
	}

	/**
	* Returns all the register courses.
	*
	* @return the register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the register courses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @return the range of register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the register courses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RegisterCourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of register courses
	* @param end the upper bound of the range of register courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of register courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.RegisterCourse> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the register courses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of register courses.
	*
	* @return the number of register courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static RegisterCoursePersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (RegisterCoursePersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					RegisterCoursePersistence.class.getName());

			ReferenceRegistry.registerReference(RegisterCourseUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(RegisterCoursePersistence persistence) {
	}

	private static RegisterCoursePersistence _persistence;
}