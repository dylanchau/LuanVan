/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.portlets.action.service.persistence.LinkUserRecruitmentPK;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.LinkUserRecruitmentServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.LinkUserRecruitmentServiceSoap
 * @generated
 */
public class LinkUserRecruitmentSoap implements Serializable {
	public static LinkUserRecruitmentSoap toSoapModel(LinkUserRecruitment model) {
		LinkUserRecruitmentSoap soapModel = new LinkUserRecruitmentSoap();

		soapModel.setRecruitmentId(model.getRecruitmentId());
		soapModel.setUserObjectId(model.getUserObjectId());
		soapModel.setLinkUserRecruitmentNo(model.getLinkUserRecruitmentNo());

		return soapModel;
	}

	public static LinkUserRecruitmentSoap[] toSoapModels(
		LinkUserRecruitment[] models) {
		LinkUserRecruitmentSoap[] soapModels = new LinkUserRecruitmentSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static LinkUserRecruitmentSoap[][] toSoapModels(
		LinkUserRecruitment[][] models) {
		LinkUserRecruitmentSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new LinkUserRecruitmentSoap[models.length][models[0].length];
		}
		else {
			soapModels = new LinkUserRecruitmentSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static LinkUserRecruitmentSoap[] toSoapModels(
		List<LinkUserRecruitment> models) {
		List<LinkUserRecruitmentSoap> soapModels = new ArrayList<LinkUserRecruitmentSoap>(models.size());

		for (LinkUserRecruitment model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new LinkUserRecruitmentSoap[soapModels.size()]);
	}

	public LinkUserRecruitmentSoap() {
	}

	public LinkUserRecruitmentPK getPrimaryKey() {
		return new LinkUserRecruitmentPK(_recruitmentId, _userObjectId);
	}

	public void setPrimaryKey(LinkUserRecruitmentPK pk) {
		setRecruitmentId(pk.recruitmentId);
		setUserObjectId(pk.userObjectId);
	}

	public long getRecruitmentId() {
		return _recruitmentId;
	}

	public void setRecruitmentId(long recruitmentId) {
		_recruitmentId = recruitmentId;
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	public int getLinkUserRecruitmentNo() {
		return _linkUserRecruitmentNo;
	}

	public void setLinkUserRecruitmentNo(int linkUserRecruitmentNo) {
		_linkUserRecruitmentNo = linkUserRecruitmentNo;
	}

	private long _recruitmentId;
	private long _userObjectId;
	private int _linkUserRecruitmentNo;
}