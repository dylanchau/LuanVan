/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.TrainingProgram;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing TrainingProgram in entity cache.
 *
 * @author Computer
 * @see TrainingProgram
 * @generated
 */
public class TrainingProgramCacheModel implements CacheModel<TrainingProgram>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{trainingProgramId=");
		sb.append(trainingProgramId);
		sb.append(", trainingProgramName=");
		sb.append(trainingProgramName);
		sb.append(", trainingProgramPeriod=");
		sb.append(trainingProgramPeriod);
		sb.append(", trainingProgramPurpose=");
		sb.append(trainingProgramPurpose);
		sb.append(", trainingProgramDiploma=");
		sb.append(trainingProgramDiploma);
		sb.append(", trainingProgramFee=");
		sb.append(trainingProgramFee);
		sb.append(", trainingProgramItems=");
		sb.append(trainingProgramItems);
		sb.append(", trainingProgramContent=");
		sb.append(trainingProgramContent);
		sb.append(", trainingProgramDescription=");
		sb.append(trainingProgramDescription);
		sb.append(", educatorId=");
		sb.append(educatorId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public TrainingProgram toEntityModel() {
		TrainingProgramImpl trainingProgramImpl = new TrainingProgramImpl();

		trainingProgramImpl.setTrainingProgramId(trainingProgramId);

		if (trainingProgramName == null) {
			trainingProgramImpl.setTrainingProgramName(StringPool.BLANK);
		}
		else {
			trainingProgramImpl.setTrainingProgramName(trainingProgramName);
		}

		if (trainingProgramPeriod == null) {
			trainingProgramImpl.setTrainingProgramPeriod(StringPool.BLANK);
		}
		else {
			trainingProgramImpl.setTrainingProgramPeriod(trainingProgramPeriod);
		}

		if (trainingProgramPurpose == null) {
			trainingProgramImpl.setTrainingProgramPurpose(StringPool.BLANK);
		}
		else {
			trainingProgramImpl.setTrainingProgramPurpose(trainingProgramPurpose);
		}

		if (trainingProgramDiploma == null) {
			trainingProgramImpl.setTrainingProgramDiploma(StringPool.BLANK);
		}
		else {
			trainingProgramImpl.setTrainingProgramDiploma(trainingProgramDiploma);
		}

		trainingProgramImpl.setTrainingProgramFee(trainingProgramFee);

		if (trainingProgramItems == null) {
			trainingProgramImpl.setTrainingProgramItems(StringPool.BLANK);
		}
		else {
			trainingProgramImpl.setTrainingProgramItems(trainingProgramItems);
		}

		if (trainingProgramContent == null) {
			trainingProgramImpl.setTrainingProgramContent(StringPool.BLANK);
		}
		else {
			trainingProgramImpl.setTrainingProgramContent(trainingProgramContent);
		}

		if (trainingProgramDescription == null) {
			trainingProgramImpl.setTrainingProgramDescription(StringPool.BLANK);
		}
		else {
			trainingProgramImpl.setTrainingProgramDescription(trainingProgramDescription);
		}

		trainingProgramImpl.setEducatorId(educatorId);

		trainingProgramImpl.resetOriginalValues();

		return trainingProgramImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		trainingProgramId = objectInput.readLong();
		trainingProgramName = objectInput.readUTF();
		trainingProgramPeriod = objectInput.readUTF();
		trainingProgramPurpose = objectInput.readUTF();
		trainingProgramDiploma = objectInput.readUTF();
		trainingProgramFee = objectInput.readDouble();
		trainingProgramItems = objectInput.readUTF();
		trainingProgramContent = objectInput.readUTF();
		trainingProgramDescription = objectInput.readUTF();
		educatorId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(trainingProgramId);

		if (trainingProgramName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingProgramName);
		}

		if (trainingProgramPeriod == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingProgramPeriod);
		}

		if (trainingProgramPurpose == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingProgramPurpose);
		}

		if (trainingProgramDiploma == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingProgramDiploma);
		}

		objectOutput.writeDouble(trainingProgramFee);

		if (trainingProgramItems == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingProgramItems);
		}

		if (trainingProgramContent == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingProgramContent);
		}

		if (trainingProgramDescription == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(trainingProgramDescription);
		}

		objectOutput.writeLong(educatorId);
	}

	public long trainingProgramId;
	public String trainingProgramName;
	public String trainingProgramPeriod;
	public String trainingProgramPurpose;
	public String trainingProgramDiploma;
	public double trainingProgramFee;
	public String trainingProgramItems;
	public String trainingProgramContent;
	public String trainingProgramDescription;
	public long educatorId;
}