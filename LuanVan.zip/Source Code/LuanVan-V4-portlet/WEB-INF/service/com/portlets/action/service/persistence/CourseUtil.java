/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.Course;

import java.util.List;

/**
 * The persistence utility for the course service. This utility wraps {@link CoursePersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see CoursePersistence
 * @see CoursePersistenceImpl
 * @generated
 */
public class CourseUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Course course) {
		getPersistence().clearCache(course);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Course> findWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Course> findWithDynamicQuery(DynamicQuery dynamicQuery,
		int start, int end) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Course> findWithDynamicQuery(DynamicQuery dynamicQuery,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Course update(Course course) throws SystemException {
		return getPersistence().update(course);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Course update(Course course, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(course, serviceContext);
	}

	/**
	* Returns the course where courseId = &#63; or throws a {@link com.portlets.action.NoSuchCourseException} if it could not be found.
	*
	* @param courseId the course ID
	* @return the matching course
	* @throws com.portlets.action.NoSuchCourseException if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findByCourseId(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence().findByCourseId(courseId);
	}

	/**
	* Returns the course where courseId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param courseId the course ID
	* @return the matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchByCourseId(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByCourseId(courseId);
	}

	/**
	* Returns the course where courseId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param courseId the course ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchByCourseId(
		long courseId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByCourseId(courseId, retrieveFromCache);
	}

	/**
	* Removes the course where courseId = &#63; from the database.
	*
	* @param courseId the course ID
	* @return the course that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course removeByCourseId(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence().removeByCourseId(courseId);
	}

	/**
	* Returns the number of courses where courseId = &#63;.
	*
	* @param courseId the course ID
	* @return the number of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByCourseId(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByCourseId(courseId);
	}

	/**
	* Returns all the courses where courseName = &#63;.
	*
	* @param courseName the course name
	* @return the matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findByCourseName(
		java.lang.String courseName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByCourseName(courseName);
	}

	/**
	* Returns a range of all the courses where courseName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param courseName the course name
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @return the range of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findByCourseName(
		java.lang.String courseName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByCourseName(courseName, start, end);
	}

	/**
	* Returns an ordered range of all the courses where courseName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param courseName the course name
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findByCourseName(
		java.lang.String courseName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByCourseName(courseName, start, end, orderByComparator);
	}

	/**
	* Returns the first course in the ordered set where courseName = &#63;.
	*
	* @param courseName the course name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching course
	* @throws com.portlets.action.NoSuchCourseException if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findByCourseName_First(
		java.lang.String courseName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence()
				   .findByCourseName_First(courseName, orderByComparator);
	}

	/**
	* Returns the first course in the ordered set where courseName = &#63;.
	*
	* @param courseName the course name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchByCourseName_First(
		java.lang.String courseName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCourseName_First(courseName, orderByComparator);
	}

	/**
	* Returns the last course in the ordered set where courseName = &#63;.
	*
	* @param courseName the course name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching course
	* @throws com.portlets.action.NoSuchCourseException if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findByCourseName_Last(
		java.lang.String courseName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence()
				   .findByCourseName_Last(courseName, orderByComparator);
	}

	/**
	* Returns the last course in the ordered set where courseName = &#63;.
	*
	* @param courseName the course name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchByCourseName_Last(
		java.lang.String courseName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByCourseName_Last(courseName, orderByComparator);
	}

	/**
	* Returns the courses before and after the current course in the ordered set where courseName = &#63;.
	*
	* @param courseId the primary key of the current course
	* @param courseName the course name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next course
	* @throws com.portlets.action.NoSuchCourseException if a course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course[] findByCourseName_PrevAndNext(
		long courseId, java.lang.String courseName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence()
				   .findByCourseName_PrevAndNext(courseId, courseName,
			orderByComparator);
	}

	/**
	* Removes all the courses where courseName = &#63; from the database.
	*
	* @param courseName the course name
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByCourseName(java.lang.String courseName)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByCourseName(courseName);
	}

	/**
	* Returns the number of courses where courseName = &#63;.
	*
	* @param courseName the course name
	* @return the number of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countByCourseName(java.lang.String courseName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByCourseName(courseName);
	}

	/**
	* Returns all the courses where trainingProgramId = &#63;.
	*
	* @param trainingProgramId the training program ID
	* @return the matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findBytrainingProgramId(
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBytrainingProgramId(trainingProgramId);
	}

	/**
	* Returns a range of all the courses where trainingProgramId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param trainingProgramId the training program ID
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @return the range of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findBytrainingProgramId(
		long trainingProgramId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBytrainingProgramId(trainingProgramId, start, end);
	}

	/**
	* Returns an ordered range of all the courses where trainingProgramId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param trainingProgramId the training program ID
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findBytrainingProgramId(
		long trainingProgramId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBytrainingProgramId(trainingProgramId, start, end,
			orderByComparator);
	}

	/**
	* Returns the first course in the ordered set where trainingProgramId = &#63;.
	*
	* @param trainingProgramId the training program ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching course
	* @throws com.portlets.action.NoSuchCourseException if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findBytrainingProgramId_First(
		long trainingProgramId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence()
				   .findBytrainingProgramId_First(trainingProgramId,
			orderByComparator);
	}

	/**
	* Returns the first course in the ordered set where trainingProgramId = &#63;.
	*
	* @param trainingProgramId the training program ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchBytrainingProgramId_First(
		long trainingProgramId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBytrainingProgramId_First(trainingProgramId,
			orderByComparator);
	}

	/**
	* Returns the last course in the ordered set where trainingProgramId = &#63;.
	*
	* @param trainingProgramId the training program ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching course
	* @throws com.portlets.action.NoSuchCourseException if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findBytrainingProgramId_Last(
		long trainingProgramId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence()
				   .findBytrainingProgramId_Last(trainingProgramId,
			orderByComparator);
	}

	/**
	* Returns the last course in the ordered set where trainingProgramId = &#63;.
	*
	* @param trainingProgramId the training program ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchBytrainingProgramId_Last(
		long trainingProgramId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBytrainingProgramId_Last(trainingProgramId,
			orderByComparator);
	}

	/**
	* Returns the courses before and after the current course in the ordered set where trainingProgramId = &#63;.
	*
	* @param courseId the primary key of the current course
	* @param trainingProgramId the training program ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next course
	* @throws com.portlets.action.NoSuchCourseException if a course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course[] findBytrainingProgramId_PrevAndNext(
		long courseId, long trainingProgramId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence()
				   .findBytrainingProgramId_PrevAndNext(courseId,
			trainingProgramId, orderByComparator);
	}

	/**
	* Removes all the courses where trainingProgramId = &#63; from the database.
	*
	* @param trainingProgramId the training program ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBytrainingProgramId(long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBytrainingProgramId(trainingProgramId);
	}

	/**
	* Returns the number of courses where trainingProgramId = &#63;.
	*
	* @param trainingProgramId the training program ID
	* @return the number of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countBytrainingProgramId(long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBytrainingProgramId(trainingProgramId);
	}

	/**
	* Returns all the courses where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findBystatesId(
		long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId);
	}

	/**
	* Returns a range of all the courses where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @return the range of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findBystatesId(
		long statesId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId, start, end);
	}

	/**
	* Returns an ordered range of all the courses where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findBystatesId(
		long statesId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBystatesId(statesId, start, end, orderByComparator);
	}

	/**
	* Returns the first course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching course
	* @throws com.portlets.action.NoSuchCourseException if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence().findBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the first course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the last course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching course
	* @throws com.portlets.action.NoSuchCourseException if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence().findBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the last course in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching course, or <code>null</code> if a matching course could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the courses before and after the current course in the ordered set where statesId = &#63;.
	*
	* @param courseId the primary key of the current course
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next course
	* @throws com.portlets.action.NoSuchCourseException if a course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course[] findBystatesId_PrevAndNext(
		long courseId, long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence()
				   .findBystatesId_PrevAndNext(courseId, statesId,
			orderByComparator);
	}

	/**
	* Removes all the courses where statesId = &#63; from the database.
	*
	* @param statesId the states ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystatesId(statesId);
	}

	/**
	* Returns the number of courses where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the number of matching courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystatesId(statesId);
	}

	/**
	* Caches the course in the entity cache if it is enabled.
	*
	* @param course the course
	*/
	public static void cacheResult(com.portlets.action.model.Course course) {
		getPersistence().cacheResult(course);
	}

	/**
	* Caches the courses in the entity cache if it is enabled.
	*
	* @param courses the courses
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.Course> courses) {
		getPersistence().cacheResult(courses);
	}

	/**
	* Creates a new course with the primary key. Does not add the course to the database.
	*
	* @param courseId the primary key for the new course
	* @return the new course
	*/
	public static com.portlets.action.model.Course create(long courseId) {
		return getPersistence().create(courseId);
	}

	/**
	* Removes the course with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param courseId the primary key of the course
	* @return the course that was removed
	* @throws com.portlets.action.NoSuchCourseException if a course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course remove(long courseId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence().remove(courseId);
	}

	public static com.portlets.action.model.Course updateImpl(
		com.portlets.action.model.Course course)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(course);
	}

	/**
	* Returns the course with the primary key or throws a {@link com.portlets.action.NoSuchCourseException} if it could not be found.
	*
	* @param courseId the primary key of the course
	* @return the course
	* @throws com.portlets.action.NoSuchCourseException if a course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course findByPrimaryKey(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchCourseException {
		return getPersistence().findByPrimaryKey(courseId);
	}

	/**
	* Returns the course with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param courseId the primary key of the course
	* @return the course, or <code>null</code> if a course with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Course fetchByPrimaryKey(
		long courseId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(courseId);
	}

	/**
	* Returns all the courses.
	*
	* @return the courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the courses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @return the range of courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the courses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of courses
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Course> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the courses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of courses.
	*
	* @return the number of courses
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	/**
	* Returns all the user objects associated with the course.
	*
	* @param pk the primary key of the course
	* @return the user objects associated with the course
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjects(pk);
	}

	/**
	* Returns a range of all the user objects associated with the course.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the course
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @return the range of user objects associated with the course
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjects(pk, start, end);
	}

	/**
	* Returns an ordered range of all the user objects associated with the course.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.CourseModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the course
	* @param start the lower bound of the range of courses
	* @param end the upper bound of the range of courses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user objects associated with the course
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjects(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of user objects associated with the course.
	*
	* @param pk the primary key of the course
	* @return the number of user objects associated with the course
	* @throws SystemException if a system exception occurred
	*/
	public static int getUserObjectsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjectsSize(pk);
	}

	/**
	* Returns <code>true</code> if the user object is associated with the course.
	*
	* @param pk the primary key of the course
	* @param userObjectPK the primary key of the user object
	* @return <code>true</code> if the user object is associated with the course; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsUserObject(pk, userObjectPK);
	}

	/**
	* Returns <code>true</code> if the course has any user objects associated with it.
	*
	* @param pk the primary key of the course to check for associations with user objects
	* @return <code>true</code> if the course has any user objects associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsUserObjects(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsUserObjects(pk);
	}

	/**
	* Adds an association between the course and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjectPK the primary key of the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObject(pk, userObjectPK);
	}

	/**
	* Adds an association between the course and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObject the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObject(long pk,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObject(pk, userObject);
	}

	/**
	* Adds an association between the course and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjectPKs the primary keys of the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObjects(pk, userObjectPKs);
	}

	/**
	* Adds an association between the course and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjects the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObjects(pk, userObjects);
	}

	/**
	* Clears all associations between the course and its user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course to clear the associated user objects from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearUserObjects(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearUserObjects(pk);
	}

	/**
	* Removes the association between the course and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjectPK the primary key of the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObject(pk, userObjectPK);
	}

	/**
	* Removes the association between the course and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObject the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObject(long pk,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObject(pk, userObject);
	}

	/**
	* Removes the association between the course and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjectPKs the primary keys of the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObjects(pk, userObjectPKs);
	}

	/**
	* Removes the association between the course and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjects the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObjects(pk, userObjects);
	}

	/**
	* Sets the user objects associated with the course, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjectPKs the primary keys of the user objects to be associated with the course
	* @throws SystemException if a system exception occurred
	*/
	public static void setUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setUserObjects(pk, userObjectPKs);
	}

	/**
	* Sets the user objects associated with the course, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the course
	* @param userObjects the user objects to be associated with the course
	* @throws SystemException if a system exception occurred
	*/
	public static void setUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setUserObjects(pk, userObjects);
	}

	public static CoursePersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (CoursePersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					CoursePersistence.class.getName());

			ReferenceRegistry.registerReference(CourseUtil.class, "_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(CoursePersistence persistence) {
	}

	private static CoursePersistence _persistence;
}