/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;

import java.io.Serializable;

/**
 * @author Computer
 * @generated
 */
public class UserSkillLevelPK implements Comparable<UserSkillLevelPK>,
	Serializable {
	public long userObjectId;
	public long skillId;

	public UserSkillLevelPK() {
	}

	public UserSkillLevelPK(long userObjectId, long skillId) {
		this.userObjectId = userObjectId;
		this.skillId = skillId;
	}

	public long getUserObjectId() {
		return userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		this.userObjectId = userObjectId;
	}

	public long getSkillId() {
		return skillId;
	}

	public void setSkillId(long skillId) {
		this.skillId = skillId;
	}

	@Override
	public int compareTo(UserSkillLevelPK pk) {
		if (pk == null) {
			return -1;
		}

		int value = 0;

		if (userObjectId < pk.userObjectId) {
			value = -1;
		}
		else if (userObjectId > pk.userObjectId) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		if (skillId < pk.skillId) {
			value = -1;
		}
		else if (skillId > pk.skillId) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof UserSkillLevelPK)) {
			return false;
		}

		UserSkillLevelPK pk = (UserSkillLevelPK)obj;

		if ((userObjectId == pk.userObjectId) && (skillId == pk.skillId)) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (String.valueOf(userObjectId) + String.valueOf(skillId)).hashCode();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(10);

		sb.append(StringPool.OPEN_CURLY_BRACE);

		sb.append("userObjectId");
		sb.append(StringPool.EQUAL);
		sb.append(userObjectId);

		sb.append(StringPool.COMMA);
		sb.append(StringPool.SPACE);
		sb.append("skillId");
		sb.append(StringPool.EQUAL);
		sb.append(skillId);

		sb.append(StringPool.CLOSE_CURLY_BRACE);

		return sb.toString();
	}
}