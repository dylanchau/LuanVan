package com.kimtho.portlet.listener;

import java.util.ArrayList;
import java.util.List;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.portlets.action.model.LinkUserRecruitment;
import com.portlets.action.model.UserSkillLevel;
import com.portlets.action.model.impl.LinkUserRecruitmentImpl;
import com.portlets.action.service.LinkUserRecruitmentLocalServiceUtil;
import com.portlets.action.service.UserSkillLevelLocalServiceUtil;


public class ListenerUserRecruitment {
	
	public ListenerUserRecruitment() {
		// TODO Auto-generated constructor stub
	}
	
	public void addLinkUserEmployerInfoId(Long recruitmentId, Long skillId) throws SystemException, PortalException {
		System.out.println("-------------------------addLinkUserEmployerInfoId is calling---------------------------------" + skillId);
		List<UserSkillLevel> userSkillLevel = new ArrayList<UserSkillLevel>();
		userSkillLevel = UserSkillLevelLocalServiceUtil.getBySkillId(skillId);
		System.out.println("size: " + userSkillLevel.size());
		for(UserSkillLevel a : userSkillLevel)
			System.out.println("userId: " + a.getUserObjectId());
		
		LinkUserRecruitment linkUserRecruitment1 = new LinkUserRecruitmentImpl();
		linkUserRecruitment1.setRecruitmentId(recruitmentId);
		linkUserRecruitment1.setLinkUserRecruitmentNo(1);
		for(UserSkillLevel su:userSkillLevel){
			System.out.println("#################"+su.getUserObjectId()+"################"+recruitmentId+"##############");
			linkUserRecruitment1.setUserObjectId(su.getUserObjectId());
			try {
				LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
				
				linkUserRecruitment1=LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
				linkUserRecruitment1.setLinkUserRecruitmentNo(linkUserRecruitment1.getLinkUserRecruitmentNo()+1);
				LinkUserRecruitmentLocalServiceUtil.updateLinkUserRecruitment(linkUserRecruitment1);
			} catch(Exception e){
				LinkUserRecruitmentLocalServiceUtil.addLinkUserRecruitment(linkUserRecruitment1);
			}
		}
	}
	
	public void deleteLinkUserEmployerInfoId(Long employerInfoId, Long skillId) throws SystemException, PortalException {
		List<UserSkillLevel> userSkillLevel = new ArrayList<UserSkillLevel>();
		userSkillLevel =UserSkillLevelLocalServiceUtil.getBySkillId(skillId);
		
		LinkUserRecruitment linkUserRecruitment1 = new LinkUserRecruitmentImpl();
		linkUserRecruitment1.setRecruitmentId(employerInfoId);
		linkUserRecruitment1.setLinkUserRecruitmentNo(1);
		for(UserSkillLevel su:userSkillLevel){
			System.out.println("#################"+su.getUserObjectId()+"################"+employerInfoId+"##############");
			linkUserRecruitment1.setUserObjectId(su.getUserObjectId());
			try {
				LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
				
				linkUserRecruitment1=LinkUserRecruitmentLocalServiceUtil.getLinkUserRecruitment(linkUserRecruitment1.getPrimaryKey());
				if(linkUserRecruitment1.getLinkUserRecruitmentNo()==1){
					LinkUserRecruitmentLocalServiceUtil.deleteLinkUserRecruitment(linkUserRecruitment1);
				} else {
					linkUserRecruitment1.setLinkUserRecruitmentNo(linkUserRecruitment1.getLinkUserRecruitmentNo()-1);
					LinkUserRecruitmentLocalServiceUtil.updateLinkUserRecruitment(linkUserRecruitment1);
				}
			} catch(Exception e){
				LinkUserRecruitmentLocalServiceUtil.addLinkUserRecruitment(linkUserRecruitment1);
			}
		}
	}
}
