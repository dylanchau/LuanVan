/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Course}.
 * </p>
 *
 * @author Computer
 * @see Course
 * @generated
 */
public class CourseWrapper implements Course, ModelWrapper<Course> {
	public CourseWrapper(Course course) {
		_course = course;
	}

	@Override
	public Class<?> getModelClass() {
		return Course.class;
	}

	@Override
	public String getModelClassName() {
		return Course.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("courseId", getCourseId());
		attributes.put("courseName", getCourseName());
		attributes.put("courseStudentNo", getCourseStudentNo());
		attributes.put("courseStartDate", getCourseStartDate());
		attributes.put("courseEnrollStartDate", getCourseEnrollStartDate());
		attributes.put("courseSchoolDay", getCourseSchoolDay());
		attributes.put("courseEnrollDeadLine", getCourseEnrollDeadLine());
		attributes.put("statesId", getStatesId());
		attributes.put("trainingProgramId", getTrainingProgramId());
		attributes.put("educatorId", getEducatorId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long courseId = (Long)attributes.get("courseId");

		if (courseId != null) {
			setCourseId(courseId);
		}

		String courseName = (String)attributes.get("courseName");

		if (courseName != null) {
			setCourseName(courseName);
		}

		Integer courseStudentNo = (Integer)attributes.get("courseStudentNo");

		if (courseStudentNo != null) {
			setCourseStudentNo(courseStudentNo);
		}

		Date courseStartDate = (Date)attributes.get("courseStartDate");

		if (courseStartDate != null) {
			setCourseStartDate(courseStartDate);
		}

		Date courseEnrollStartDate = (Date)attributes.get(
				"courseEnrollStartDate");

		if (courseEnrollStartDate != null) {
			setCourseEnrollStartDate(courseEnrollStartDate);
		}

		String courseSchoolDay = (String)attributes.get("courseSchoolDay");

		if (courseSchoolDay != null) {
			setCourseSchoolDay(courseSchoolDay);
		}

		Date courseEnrollDeadLine = (Date)attributes.get("courseEnrollDeadLine");

		if (courseEnrollDeadLine != null) {
			setCourseEnrollDeadLine(courseEnrollDeadLine);
		}

		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}

		Long trainingProgramId = (Long)attributes.get("trainingProgramId");

		if (trainingProgramId != null) {
			setTrainingProgramId(trainingProgramId);
		}

		Long educatorId = (Long)attributes.get("educatorId");

		if (educatorId != null) {
			setEducatorId(educatorId);
		}
	}

	/**
	* Returns the primary key of this course.
	*
	* @return the primary key of this course
	*/
	@Override
	public long getPrimaryKey() {
		return _course.getPrimaryKey();
	}

	/**
	* Sets the primary key of this course.
	*
	* @param primaryKey the primary key of this course
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_course.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the course ID of this course.
	*
	* @return the course ID of this course
	*/
	@Override
	public long getCourseId() {
		return _course.getCourseId();
	}

	/**
	* Sets the course ID of this course.
	*
	* @param courseId the course ID of this course
	*/
	@Override
	public void setCourseId(long courseId) {
		_course.setCourseId(courseId);
	}

	/**
	* Returns the course name of this course.
	*
	* @return the course name of this course
	*/
	@Override
	public java.lang.String getCourseName() {
		return _course.getCourseName();
	}

	/**
	* Sets the course name of this course.
	*
	* @param courseName the course name of this course
	*/
	@Override
	public void setCourseName(java.lang.String courseName) {
		_course.setCourseName(courseName);
	}

	/**
	* Returns the course student no of this course.
	*
	* @return the course student no of this course
	*/
	@Override
	public int getCourseStudentNo() {
		return _course.getCourseStudentNo();
	}

	/**
	* Sets the course student no of this course.
	*
	* @param courseStudentNo the course student no of this course
	*/
	@Override
	public void setCourseStudentNo(int courseStudentNo) {
		_course.setCourseStudentNo(courseStudentNo);
	}

	/**
	* Returns the course start date of this course.
	*
	* @return the course start date of this course
	*/
	@Override
	public java.util.Date getCourseStartDate() {
		return _course.getCourseStartDate();
	}

	/**
	* Sets the course start date of this course.
	*
	* @param courseStartDate the course start date of this course
	*/
	@Override
	public void setCourseStartDate(java.util.Date courseStartDate) {
		_course.setCourseStartDate(courseStartDate);
	}

	/**
	* Returns the course enroll start date of this course.
	*
	* @return the course enroll start date of this course
	*/
	@Override
	public java.util.Date getCourseEnrollStartDate() {
		return _course.getCourseEnrollStartDate();
	}

	/**
	* Sets the course enroll start date of this course.
	*
	* @param courseEnrollStartDate the course enroll start date of this course
	*/
	@Override
	public void setCourseEnrollStartDate(java.util.Date courseEnrollStartDate) {
		_course.setCourseEnrollStartDate(courseEnrollStartDate);
	}

	/**
	* Returns the course school day of this course.
	*
	* @return the course school day of this course
	*/
	@Override
	public java.lang.String getCourseSchoolDay() {
		return _course.getCourseSchoolDay();
	}

	/**
	* Sets the course school day of this course.
	*
	* @param courseSchoolDay the course school day of this course
	*/
	@Override
	public void setCourseSchoolDay(java.lang.String courseSchoolDay) {
		_course.setCourseSchoolDay(courseSchoolDay);
	}

	/**
	* Returns the course enroll dead line of this course.
	*
	* @return the course enroll dead line of this course
	*/
	@Override
	public java.util.Date getCourseEnrollDeadLine() {
		return _course.getCourseEnrollDeadLine();
	}

	/**
	* Sets the course enroll dead line of this course.
	*
	* @param courseEnrollDeadLine the course enroll dead line of this course
	*/
	@Override
	public void setCourseEnrollDeadLine(java.util.Date courseEnrollDeadLine) {
		_course.setCourseEnrollDeadLine(courseEnrollDeadLine);
	}

	/**
	* Returns the states ID of this course.
	*
	* @return the states ID of this course
	*/
	@Override
	public long getStatesId() {
		return _course.getStatesId();
	}

	/**
	* Sets the states ID of this course.
	*
	* @param statesId the states ID of this course
	*/
	@Override
	public void setStatesId(long statesId) {
		_course.setStatesId(statesId);
	}

	/**
	* Returns the training program ID of this course.
	*
	* @return the training program ID of this course
	*/
	@Override
	public long getTrainingProgramId() {
		return _course.getTrainingProgramId();
	}

	/**
	* Sets the training program ID of this course.
	*
	* @param trainingProgramId the training program ID of this course
	*/
	@Override
	public void setTrainingProgramId(long trainingProgramId) {
		_course.setTrainingProgramId(trainingProgramId);
	}

	/**
	* Returns the educator ID of this course.
	*
	* @return the educator ID of this course
	*/
	@Override
	public long getEducatorId() {
		return _course.getEducatorId();
	}

	/**
	* Sets the educator ID of this course.
	*
	* @param educatorId the educator ID of this course
	*/
	@Override
	public void setEducatorId(long educatorId) {
		_course.setEducatorId(educatorId);
	}

	@Override
	public boolean isNew() {
		return _course.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_course.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _course.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_course.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _course.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _course.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_course.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _course.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_course.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_course.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_course.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new CourseWrapper((Course)_course.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.Course course) {
		return _course.compareTo(course);
	}

	@Override
	public int hashCode() {
		return _course.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.Course> toCacheModel() {
		return _course.toCacheModel();
	}

	@Override
	public com.portlets.action.model.Course toEscapedModel() {
		return new CourseWrapper(_course.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.Course toUnescapedModel() {
		return new CourseWrapper(_course.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _course.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _course.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_course.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof CourseWrapper)) {
			return false;
		}

		CourseWrapper courseWrapper = (CourseWrapper)obj;

		if (Validator.equals(_course, courseWrapper._course)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Course getWrappedCourse() {
		return _course;
	}

	@Override
	public Course getWrappedModel() {
		return _course;
	}

	@Override
	public void resetOriginalValues() {
		_course.resetOriginalValues();
	}

	private Course _course;
}