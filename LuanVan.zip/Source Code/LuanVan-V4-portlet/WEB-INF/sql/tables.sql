create table NewSocial_Course (
	courseId LONG not null primary key,
	courseName VARCHAR(75) null,
	courseStudentNo INTEGER,
	courseStartDate DATE null,
	courseEnrollStartDate DATE null,
	courseSchoolDay VARCHAR(75) null,
	courseEnrollDeadLine DATE null,
	statesId LONG,
	trainingProgramId LONG,
	educatorId LONG
);

create table NewSocial_EducationUsers (
	educationUsersId LONG not null primary key,
	educationUsersSchool VARCHAR(75) null,
	educationUsersMajor VARCHAR(75) null,
	educationUsersDateStart DATE null,
	educationUsersDateFinish DATE null,
	educationUsersDegree VARCHAR(75) null,
	educationUsersDescription VARCHAR(75) null,
	userObjectId LONG
);

create table NewSocial_Educator (
	educatorId LONG not null primary key,
	educatorName VARCHAR(75) null,
	educatorAddress VARCHAR(75) null,
	educatorEmail VARCHAR(75) null,
	educatorPhone VARCHAR(75) null,
	educatorIntroduce VARCHAR(75) null,
	euducatorAchievements VARCHAR(75) null,
	educatorLogoName VARCHAR(75) null,
	educatorLogo BLOB
);

create table NewSocial_Employer (
	employerId LONG not null primary key,
	employerName VARCHAR(75) null,
	employerAddress VARCHAR(75) null,
	employerEmail VARCHAR(75) null,
	employerPhone VARCHAR(75) null,
	employerIntroduce VARCHAR(75) null,
	employerAchievements VARCHAR(75) null,
	employerLogoName VARCHAR(75) null,
	employerLogo BLOB
);

create table NewSocial_ExperienceUsers (
	experienceUsersId LONG not null primary key,
	experienceUsersJob VARCHAR(75) null,
	experienceUsersCompany VARCHAR(75) null,
	experienceUsersDateStart DATE null,
	experienceUsersDateFinish DATE null,
	experienceUsersDescription VARCHAR(75) null,
	userObjectId LONG
);

create table NewSocial_Level (
	levelId LONG not null primary key,
	levelName VARCHAR(75) null,
	levelExplain VARCHAR(75) null
);

create table NewSocial_LinkUserCourse (
	userObjectId LONG not null,
	courseId LONG not null,
	linkUserCourseNo INTEGER,
	primary key (userObjectId, courseId)
);

create table NewSocial_LinkUserRecruitment (
	recruitmentId LONG not null,
	userObjectId LONG not null,
	linkUserRecruitmentNo INTEGER,
	primary key (recruitmentId, userObjectId)
);

create table NewSocial_LinkUsers (
	userIdA LONG not null,
	userIdB LONG not null,
	linkUsersNumber INTEGER,
	primary key (userIdA, userIdB)
);

create table NewSocial_Recruitment (
	recruitmentId LONG not null primary key,
	recruitmentName VARCHAR(75) null,
	recruitmentPosition VARCHAR(75) null,
	recruitmentDescription VARCHAR(75) null,
	recruitmentBenefit VARCHAR(75) null,
	recruitmentJobType VARCHAR(75) null,
	recruitmentFileReq VARCHAR(75) null,
	recruitmentFileDeadlineFrom DATE null,
	recruitmentFileDeadlineTo DATE null,
	recruitmentSalary VARCHAR(75) null,
	recruitmentNo INTEGER,
	recruitmentGender VARCHAR(75) null,
	recruitmentQualification VARCHAR(75) null,
	recruitmentAgeFrom INTEGER,
	recruitmentAgeTo INTEGER,
	recruitmentExper VARCHAR(75) null,
	employerId LONG,
	statesId LONG
);

create table NewSocial_Recruitment_Skill (
	recruitmentId LONG not null,
	skillId LONG not null,
	primary key (recruitmentId, skillId)
);

create table NewSocial_RegisterCourse (
	courseId LONG not null,
	userObjectId LONG not null,
	statesId LONG,
	primary key (courseId, userObjectId)
);

create table NewSocial_RegisterRecruitment (
	recruitmentId LONG not null,
	userObjectId LONG not null,
	statesId LONG,
	primary key (recruitmentId, userObjectId)
);

create table NewSocial_Skill (
	skillId LONG not null primary key,
	skillName VARCHAR(75) null,
	skillExplain VARCHAR(75) null,
	skillAncestor LONG
);

create table NewSocial_States (
	statesId LONG not null primary key,
	statesName VARCHAR(75) null,
	statesExplain VARCHAR(75) null
);

create table NewSocial_TrainingProgram (
	trainingProgramId LONG not null primary key,
	trainingProgramName VARCHAR(75) null,
	trainingProgramPeriod VARCHAR(75) null,
	trainingProgramPurpose VARCHAR(75) null,
	trainingProgramDiploma VARCHAR(75) null,
	trainingProgramFee DOUBLE,
	trainingProgramItems VARCHAR(75) null,
	trainingProgramContent VARCHAR(75) null,
	trainingProgramDescription VARCHAR(75) null,
	educatorId LONG
);

create table NewSocial_TrainingProgram_Skill (
	skillId LONG not null,
	trainingProgramId LONG not null,
	primary key (skillId, trainingProgramId)
);

create table NewSocial_UserObject (
	userObjectId LONG not null primary key,
	userObjectName VARCHAR(75) null,
	userObjectGender BOOLEAN,
	userObjectAddress VARCHAR(75) null,
	userObjectBirthday DATE null,
	userObjectEmail VARCHAR(75) null,
	userObjectPhone VARCHAR(75) null,
	userObjectIntroduce VARCHAR(75) null
);

create table NewSocial_UserObject_Course (
	courseId LONG not null,
	userObjectId LONG not null,
	primary key (courseId, userObjectId)
);

create table NewSocial_UserObject_Educator (
	educatorId LONG not null,
	userObjectId LONG not null,
	primary key (educatorId, userObjectId)
);

create table NewSocial_UserObject_Employer (
	employerId LONG not null,
	userObjectId LONG not null,
	primary key (employerId, userObjectId)
);

create table NewSocial_UserObject_Recruitment (
	recruitmentId LONG not null,
	userObjectId LONG not null,
	primary key (recruitmentId, userObjectId)
);

create table NewSocial_UserSkillLevel (
	userObjectId LONG not null,
	skillId LONG not null,
	levelId LONG,
	primary key (userObjectId, skillId)
);

create table NewSocial_UserSkillListener (
	userObjectId LONG not null,
	skillId LONG not null,
	primary key (userObjectId, skillId)
);