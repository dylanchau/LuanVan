/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link LinkUserRecruitment}.
 * </p>
 *
 * @author Computer
 * @see LinkUserRecruitment
 * @generated
 */
public class LinkUserRecruitmentWrapper implements LinkUserRecruitment,
	ModelWrapper<LinkUserRecruitment> {
	public LinkUserRecruitmentWrapper(LinkUserRecruitment linkUserRecruitment) {
		_linkUserRecruitment = linkUserRecruitment;
	}

	@Override
	public Class<?> getModelClass() {
		return LinkUserRecruitment.class;
	}

	@Override
	public String getModelClassName() {
		return LinkUserRecruitment.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recruitmentId", getRecruitmentId());
		attributes.put("userObjectId", getUserObjectId());
		attributes.put("linkUserRecruitmentNo", getLinkUserRecruitmentNo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long recruitmentId = (Long)attributes.get("recruitmentId");

		if (recruitmentId != null) {
			setRecruitmentId(recruitmentId);
		}

		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		Integer linkUserRecruitmentNo = (Integer)attributes.get(
				"linkUserRecruitmentNo");

		if (linkUserRecruitmentNo != null) {
			setLinkUserRecruitmentNo(linkUserRecruitmentNo);
		}
	}

	/**
	* Returns the primary key of this link user recruitment.
	*
	* @return the primary key of this link user recruitment
	*/
	@Override
	public com.portlets.action.service.persistence.LinkUserRecruitmentPK getPrimaryKey() {
		return _linkUserRecruitment.getPrimaryKey();
	}

	/**
	* Sets the primary key of this link user recruitment.
	*
	* @param primaryKey the primary key of this link user recruitment
	*/
	@Override
	public void setPrimaryKey(
		com.portlets.action.service.persistence.LinkUserRecruitmentPK primaryKey) {
		_linkUserRecruitment.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the recruitment ID of this link user recruitment.
	*
	* @return the recruitment ID of this link user recruitment
	*/
	@Override
	public long getRecruitmentId() {
		return _linkUserRecruitment.getRecruitmentId();
	}

	/**
	* Sets the recruitment ID of this link user recruitment.
	*
	* @param recruitmentId the recruitment ID of this link user recruitment
	*/
	@Override
	public void setRecruitmentId(long recruitmentId) {
		_linkUserRecruitment.setRecruitmentId(recruitmentId);
	}

	/**
	* Returns the user object ID of this link user recruitment.
	*
	* @return the user object ID of this link user recruitment
	*/
	@Override
	public long getUserObjectId() {
		return _linkUserRecruitment.getUserObjectId();
	}

	/**
	* Sets the user object ID of this link user recruitment.
	*
	* @param userObjectId the user object ID of this link user recruitment
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_linkUserRecruitment.setUserObjectId(userObjectId);
	}

	/**
	* Returns the link user recruitment no of this link user recruitment.
	*
	* @return the link user recruitment no of this link user recruitment
	*/
	@Override
	public int getLinkUserRecruitmentNo() {
		return _linkUserRecruitment.getLinkUserRecruitmentNo();
	}

	/**
	* Sets the link user recruitment no of this link user recruitment.
	*
	* @param linkUserRecruitmentNo the link user recruitment no of this link user recruitment
	*/
	@Override
	public void setLinkUserRecruitmentNo(int linkUserRecruitmentNo) {
		_linkUserRecruitment.setLinkUserRecruitmentNo(linkUserRecruitmentNo);
	}

	@Override
	public boolean isNew() {
		return _linkUserRecruitment.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_linkUserRecruitment.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _linkUserRecruitment.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_linkUserRecruitment.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _linkUserRecruitment.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _linkUserRecruitment.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_linkUserRecruitment.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _linkUserRecruitment.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_linkUserRecruitment.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_linkUserRecruitment.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_linkUserRecruitment.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new LinkUserRecruitmentWrapper((LinkUserRecruitment)_linkUserRecruitment.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.LinkUserRecruitment linkUserRecruitment) {
		return _linkUserRecruitment.compareTo(linkUserRecruitment);
	}

	@Override
	public int hashCode() {
		return _linkUserRecruitment.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.LinkUserRecruitment> toCacheModel() {
		return _linkUserRecruitment.toCacheModel();
	}

	@Override
	public com.portlets.action.model.LinkUserRecruitment toEscapedModel() {
		return new LinkUserRecruitmentWrapper(_linkUserRecruitment.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.LinkUserRecruitment toUnescapedModel() {
		return new LinkUserRecruitmentWrapper(_linkUserRecruitment.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _linkUserRecruitment.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _linkUserRecruitment.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_linkUserRecruitment.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LinkUserRecruitmentWrapper)) {
			return false;
		}

		LinkUserRecruitmentWrapper linkUserRecruitmentWrapper = (LinkUserRecruitmentWrapper)obj;

		if (Validator.equals(_linkUserRecruitment,
					linkUserRecruitmentWrapper._linkUserRecruitment)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public LinkUserRecruitment getWrappedLinkUserRecruitment() {
		return _linkUserRecruitment;
	}

	@Override
	public LinkUserRecruitment getWrappedModel() {
		return _linkUserRecruitment;
	}

	@Override
	public void resetOriginalValues() {
		_linkUserRecruitment.resetOriginalValues();
	}

	private LinkUserRecruitment _linkUserRecruitment;
}