/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link EducationUsers}.
 * </p>
 *
 * @author Computer
 * @see EducationUsers
 * @generated
 */
public class EducationUsersWrapper implements EducationUsers,
	ModelWrapper<EducationUsers> {
	public EducationUsersWrapper(EducationUsers educationUsers) {
		_educationUsers = educationUsers;
	}

	@Override
	public Class<?> getModelClass() {
		return EducationUsers.class;
	}

	@Override
	public String getModelClassName() {
		return EducationUsers.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("educationUsersId", getEducationUsersId());
		attributes.put("educationUsersSchool", getEducationUsersSchool());
		attributes.put("educationUsersMajor", getEducationUsersMajor());
		attributes.put("educationUsersDateStart", getEducationUsersDateStart());
		attributes.put("educationUsersDateFinish", getEducationUsersDateFinish());
		attributes.put("educationUsersDegree", getEducationUsersDegree());
		attributes.put("educationUsersDescription",
			getEducationUsersDescription());
		attributes.put("userObjectId", getUserObjectId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long educationUsersId = (Long)attributes.get("educationUsersId");

		if (educationUsersId != null) {
			setEducationUsersId(educationUsersId);
		}

		String educationUsersSchool = (String)attributes.get(
				"educationUsersSchool");

		if (educationUsersSchool != null) {
			setEducationUsersSchool(educationUsersSchool);
		}

		String educationUsersMajor = (String)attributes.get(
				"educationUsersMajor");

		if (educationUsersMajor != null) {
			setEducationUsersMajor(educationUsersMajor);
		}

		Date educationUsersDateStart = (Date)attributes.get(
				"educationUsersDateStart");

		if (educationUsersDateStart != null) {
			setEducationUsersDateStart(educationUsersDateStart);
		}

		Date educationUsersDateFinish = (Date)attributes.get(
				"educationUsersDateFinish");

		if (educationUsersDateFinish != null) {
			setEducationUsersDateFinish(educationUsersDateFinish);
		}

		String educationUsersDegree = (String)attributes.get(
				"educationUsersDegree");

		if (educationUsersDegree != null) {
			setEducationUsersDegree(educationUsersDegree);
		}

		String educationUsersDescription = (String)attributes.get(
				"educationUsersDescription");

		if (educationUsersDescription != null) {
			setEducationUsersDescription(educationUsersDescription);
		}

		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}
	}

	/**
	* Returns the primary key of this education users.
	*
	* @return the primary key of this education users
	*/
	@Override
	public long getPrimaryKey() {
		return _educationUsers.getPrimaryKey();
	}

	/**
	* Sets the primary key of this education users.
	*
	* @param primaryKey the primary key of this education users
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_educationUsers.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the education users ID of this education users.
	*
	* @return the education users ID of this education users
	*/
	@Override
	public long getEducationUsersId() {
		return _educationUsers.getEducationUsersId();
	}

	/**
	* Sets the education users ID of this education users.
	*
	* @param educationUsersId the education users ID of this education users
	*/
	@Override
	public void setEducationUsersId(long educationUsersId) {
		_educationUsers.setEducationUsersId(educationUsersId);
	}

	/**
	* Returns the education users school of this education users.
	*
	* @return the education users school of this education users
	*/
	@Override
	public java.lang.String getEducationUsersSchool() {
		return _educationUsers.getEducationUsersSchool();
	}

	/**
	* Sets the education users school of this education users.
	*
	* @param educationUsersSchool the education users school of this education users
	*/
	@Override
	public void setEducationUsersSchool(java.lang.String educationUsersSchool) {
		_educationUsers.setEducationUsersSchool(educationUsersSchool);
	}

	/**
	* Returns the education users major of this education users.
	*
	* @return the education users major of this education users
	*/
	@Override
	public java.lang.String getEducationUsersMajor() {
		return _educationUsers.getEducationUsersMajor();
	}

	/**
	* Sets the education users major of this education users.
	*
	* @param educationUsersMajor the education users major of this education users
	*/
	@Override
	public void setEducationUsersMajor(java.lang.String educationUsersMajor) {
		_educationUsers.setEducationUsersMajor(educationUsersMajor);
	}

	/**
	* Returns the education users date start of this education users.
	*
	* @return the education users date start of this education users
	*/
	@Override
	public java.util.Date getEducationUsersDateStart() {
		return _educationUsers.getEducationUsersDateStart();
	}

	/**
	* Sets the education users date start of this education users.
	*
	* @param educationUsersDateStart the education users date start of this education users
	*/
	@Override
	public void setEducationUsersDateStart(
		java.util.Date educationUsersDateStart) {
		_educationUsers.setEducationUsersDateStart(educationUsersDateStart);
	}

	/**
	* Returns the education users date finish of this education users.
	*
	* @return the education users date finish of this education users
	*/
	@Override
	public java.util.Date getEducationUsersDateFinish() {
		return _educationUsers.getEducationUsersDateFinish();
	}

	/**
	* Sets the education users date finish of this education users.
	*
	* @param educationUsersDateFinish the education users date finish of this education users
	*/
	@Override
	public void setEducationUsersDateFinish(
		java.util.Date educationUsersDateFinish) {
		_educationUsers.setEducationUsersDateFinish(educationUsersDateFinish);
	}

	/**
	* Returns the education users degree of this education users.
	*
	* @return the education users degree of this education users
	*/
	@Override
	public java.lang.String getEducationUsersDegree() {
		return _educationUsers.getEducationUsersDegree();
	}

	/**
	* Sets the education users degree of this education users.
	*
	* @param educationUsersDegree the education users degree of this education users
	*/
	@Override
	public void setEducationUsersDegree(java.lang.String educationUsersDegree) {
		_educationUsers.setEducationUsersDegree(educationUsersDegree);
	}

	/**
	* Returns the education users description of this education users.
	*
	* @return the education users description of this education users
	*/
	@Override
	public java.lang.String getEducationUsersDescription() {
		return _educationUsers.getEducationUsersDescription();
	}

	/**
	* Sets the education users description of this education users.
	*
	* @param educationUsersDescription the education users description of this education users
	*/
	@Override
	public void setEducationUsersDescription(
		java.lang.String educationUsersDescription) {
		_educationUsers.setEducationUsersDescription(educationUsersDescription);
	}

	/**
	* Returns the user object ID of this education users.
	*
	* @return the user object ID of this education users
	*/
	@Override
	public long getUserObjectId() {
		return _educationUsers.getUserObjectId();
	}

	/**
	* Sets the user object ID of this education users.
	*
	* @param userObjectId the user object ID of this education users
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_educationUsers.setUserObjectId(userObjectId);
	}

	@Override
	public boolean isNew() {
		return _educationUsers.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_educationUsers.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _educationUsers.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_educationUsers.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _educationUsers.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _educationUsers.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_educationUsers.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _educationUsers.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_educationUsers.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_educationUsers.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_educationUsers.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new EducationUsersWrapper((EducationUsers)_educationUsers.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.EducationUsers educationUsers) {
		return _educationUsers.compareTo(educationUsers);
	}

	@Override
	public int hashCode() {
		return _educationUsers.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.EducationUsers> toCacheModel() {
		return _educationUsers.toCacheModel();
	}

	@Override
	public com.portlets.action.model.EducationUsers toEscapedModel() {
		return new EducationUsersWrapper(_educationUsers.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.EducationUsers toUnescapedModel() {
		return new EducationUsersWrapper(_educationUsers.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _educationUsers.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _educationUsers.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_educationUsers.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EducationUsersWrapper)) {
			return false;
		}

		EducationUsersWrapper educationUsersWrapper = (EducationUsersWrapper)obj;

		if (Validator.equals(_educationUsers,
					educationUsersWrapper._educationUsers)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public EducationUsers getWrappedEducationUsers() {
		return _educationUsers;
	}

	@Override
	public EducationUsers getWrappedModel() {
		return _educationUsers;
	}

	@Override
	public void resetOriginalValues() {
		_educationUsers.resetOriginalValues();
	}

	private EducationUsers _educationUsers;
}