/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.Level;

import java.util.List;

/**
 * The persistence utility for the level service. This utility wraps {@link LevelPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see LevelPersistence
 * @see LevelPersistenceImpl
 * @generated
 */
public class LevelUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Level level) {
		getPersistence().clearCache(level);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Level> findWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Level> findWithDynamicQuery(DynamicQuery dynamicQuery,
		int start, int end) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Level> findWithDynamicQuery(DynamicQuery dynamicQuery,
		int start, int end, OrderByComparator orderByComparator)
		throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Level update(Level level) throws SystemException {
		return getPersistence().update(level);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Level update(Level level, ServiceContext serviceContext)
		throws SystemException {
		return getPersistence().update(level, serviceContext);
	}

	/**
	* Returns the level where levelId = &#63; or throws a {@link com.portlets.action.NoSuchLevelException} if it could not be found.
	*
	* @param levelId the level ID
	* @return the matching level
	* @throws com.portlets.action.NoSuchLevelException if a matching level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level findBylevelId(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLevelException {
		return getPersistence().findBylevelId(levelId);
	}

	/**
	* Returns the level where levelId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param levelId the level ID
	* @return the matching level, or <code>null</code> if a matching level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level fetchBylevelId(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBylevelId(levelId);
	}

	/**
	* Returns the level where levelId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param levelId the level ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching level, or <code>null</code> if a matching level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level fetchBylevelId(long levelId,
		boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBylevelId(levelId, retrieveFromCache);
	}

	/**
	* Removes the level where levelId = &#63; from the database.
	*
	* @param levelId the level ID
	* @return the level that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level removeBylevelId(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLevelException {
		return getPersistence().removeBylevelId(levelId);
	}

	/**
	* Returns the number of levels where levelId = &#63;.
	*
	* @param levelId the level ID
	* @return the number of matching levels
	* @throws SystemException if a system exception occurred
	*/
	public static int countBylevelId(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBylevelId(levelId);
	}

	/**
	* Returns all the levels where levelName = &#63;.
	*
	* @param levelName the level name
	* @return the matching levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Level> findBylevelName(
		java.lang.String levelName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBylevelName(levelName);
	}

	/**
	* Returns a range of all the levels where levelName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param levelName the level name
	* @param start the lower bound of the range of levels
	* @param end the upper bound of the range of levels (not inclusive)
	* @return the range of matching levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Level> findBylevelName(
		java.lang.String levelName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBylevelName(levelName, start, end);
	}

	/**
	* Returns an ordered range of all the levels where levelName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param levelName the level name
	* @param start the lower bound of the range of levels
	* @param end the upper bound of the range of levels (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Level> findBylevelName(
		java.lang.String levelName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBylevelName(levelName, start, end, orderByComparator);
	}

	/**
	* Returns the first level in the ordered set where levelName = &#63;.
	*
	* @param levelName the level name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching level
	* @throws com.portlets.action.NoSuchLevelException if a matching level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level findBylevelName_First(
		java.lang.String levelName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLevelException {
		return getPersistence()
				   .findBylevelName_First(levelName, orderByComparator);
	}

	/**
	* Returns the first level in the ordered set where levelName = &#63;.
	*
	* @param levelName the level name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching level, or <code>null</code> if a matching level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level fetchBylevelName_First(
		java.lang.String levelName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylevelName_First(levelName, orderByComparator);
	}

	/**
	* Returns the last level in the ordered set where levelName = &#63;.
	*
	* @param levelName the level name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching level
	* @throws com.portlets.action.NoSuchLevelException if a matching level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level findBylevelName_Last(
		java.lang.String levelName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLevelException {
		return getPersistence()
				   .findBylevelName_Last(levelName, orderByComparator);
	}

	/**
	* Returns the last level in the ordered set where levelName = &#63;.
	*
	* @param levelName the level name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching level, or <code>null</code> if a matching level could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level fetchBylevelName_Last(
		java.lang.String levelName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBylevelName_Last(levelName, orderByComparator);
	}

	/**
	* Returns the levels before and after the current level in the ordered set where levelName = &#63;.
	*
	* @param levelId the primary key of the current level
	* @param levelName the level name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next level
	* @throws com.portlets.action.NoSuchLevelException if a level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level[] findBylevelName_PrevAndNext(
		long levelId, java.lang.String levelName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLevelException {
		return getPersistence()
				   .findBylevelName_PrevAndNext(levelId, levelName,
			orderByComparator);
	}

	/**
	* Removes all the levels where levelName = &#63; from the database.
	*
	* @param levelName the level name
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBylevelName(java.lang.String levelName)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBylevelName(levelName);
	}

	/**
	* Returns the number of levels where levelName = &#63;.
	*
	* @param levelName the level name
	* @return the number of matching levels
	* @throws SystemException if a system exception occurred
	*/
	public static int countBylevelName(java.lang.String levelName)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBylevelName(levelName);
	}

	/**
	* Caches the level in the entity cache if it is enabled.
	*
	* @param level the level
	*/
	public static void cacheResult(com.portlets.action.model.Level level) {
		getPersistence().cacheResult(level);
	}

	/**
	* Caches the levels in the entity cache if it is enabled.
	*
	* @param levels the levels
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.Level> levels) {
		getPersistence().cacheResult(levels);
	}

	/**
	* Creates a new level with the primary key. Does not add the level to the database.
	*
	* @param levelId the primary key for the new level
	* @return the new level
	*/
	public static com.portlets.action.model.Level create(long levelId) {
		return getPersistence().create(levelId);
	}

	/**
	* Removes the level with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param levelId the primary key of the level
	* @return the level that was removed
	* @throws com.portlets.action.NoSuchLevelException if a level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level remove(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLevelException {
		return getPersistence().remove(levelId);
	}

	public static com.portlets.action.model.Level updateImpl(
		com.portlets.action.model.Level level)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(level);
	}

	/**
	* Returns the level with the primary key or throws a {@link com.portlets.action.NoSuchLevelException} if it could not be found.
	*
	* @param levelId the primary key of the level
	* @return the level
	* @throws com.portlets.action.NoSuchLevelException if a level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level findByPrimaryKey(long levelId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchLevelException {
		return getPersistence().findByPrimaryKey(levelId);
	}

	/**
	* Returns the level with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param levelId the primary key of the level
	* @return the level, or <code>null</code> if a level with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Level fetchByPrimaryKey(
		long levelId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(levelId);
	}

	/**
	* Returns all the levels.
	*
	* @return the levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Level> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the levels.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of levels
	* @param end the upper bound of the range of levels (not inclusive)
	* @return the range of levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Level> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the levels.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.LevelModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of levels
	* @param end the upper bound of the range of levels (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of levels
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Level> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the levels from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of levels.
	*
	* @return the number of levels
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	public static LevelPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (LevelPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					LevelPersistence.class.getName());

			ReferenceRegistry.registerReference(LevelUtil.class, "_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(LevelPersistence persistence) {
	}

	private static LevelPersistence _persistence;
}