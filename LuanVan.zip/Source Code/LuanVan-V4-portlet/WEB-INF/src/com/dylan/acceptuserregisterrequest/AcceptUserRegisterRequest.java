package com.dylan.acceptuserregisterrequest;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;

import com.dylan.portlets.action.util.AcceptUserRegisterRequestActionUtil;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class AcceptUserRegisterRequest
 */
public class AcceptUserRegisterRequest extends MVCPortlet {

	public void acceptStudentRequest(ActionRequest actionRequest, 
			ActionResponse actionResponse) throws Exception {
		
		_log.info("------------------------------------");
		
		String[] studentIdRequested = ParamUtil.getParameterValues(actionRequest, "studentId");
		long courseId = ParamUtil.getLong(actionRequest, "courseId"); _log.info(courseId);
		
		for(String s : studentIdRequested) {
			_log.info(s);
			AcceptUserRegisterRequestActionUtil.approvalRequest(courseId, Long.parseLong(s), 3);
		}
	}
	
	Log _log = LogFactoryUtil.getLog(AcceptUserRegisterRequest.class);
}

