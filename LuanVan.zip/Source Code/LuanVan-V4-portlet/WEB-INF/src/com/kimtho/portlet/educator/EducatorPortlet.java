package com.kimtho.portlet.educator;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.kimtho.portlet.WebKeysU;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.RegisterCourse;
import com.portlets.action.model.impl.RegisterCourseImpl;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.EducatorLocalServiceUtil;
import com.portlets.action.service.RegisterCourseLocalServiceUtil;


/**
 * 
 * @author Kim Tho
 *
 */

public class EducatorPortlet extends MVCPortlet{
	

	/**
	 * 
	 * This method will persist the data in database
	 * @throws SystemException 
	 * @throws IOException 
	 */
	@ProcessAction(name = "followEducator")
	public void followEducator(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long educatorId = ParamUtil.getLong(actionRequest, "educatorId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		EducatorLocalServiceUtil.addUserObjectEducator(userId, educatorId);
		SessionMessages.add(actionRequest, "added-followEducator"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Added Follow Educator Successfully#########################");
	}
	
	@ProcessAction(name = "unFollowEducator")
	public void unFollowEducator(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long educatorId = ParamUtil.getLong(actionRequest, "educatorId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		EducatorLocalServiceUtil.deleteUserObjectEducator(userId, educatorId);
		SessionMessages.add(actionRequest, "deleted-followEducator"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################deleted Follow Educator Successfully#########################");
	}
	
	@ProcessAction(name = "loadListEducator")
	public void loadListEducator(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String select = ParamUtil.getString(actionRequest, "select","");
		System.out.println("------"+select);
		actionRequest.setAttribute(WebKeysU.LoadListEducator, select); 
		SessionMessages.add(actionRequest, "deleted-followEducator"); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/educator/view.jsp");
		
	   _log.info("#################Load List Educator Successfully#########################");
	}
	
	@ProcessAction(name = "registerCourse")
	public void registerCourse(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long courseId = ParamUtil.getLong(actionRequest, "courseId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		CourseLocalServiceUtil.addUserObjectCourse(userId, courseId);
		//
		RegisterCourse registerCourse = new RegisterCourseImpl();
		registerCourse.setUserObjectId(userId);
		registerCourse.setCourseId(courseId);
		registerCourse.setStatesId(new Long(10));
		RegisterCourseLocalServiceUtil.addRegisterCourse(registerCourse);
		SessionMessages.add(actionRequest, "added-registerCourse"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Added Register Course Successfully#########################");
	}
	
	@ProcessAction(name = "unRegisterCourse")
	public void unRegisterCourse(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long courseId = ParamUtil.getLong(actionRequest, "courseId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		CourseLocalServiceUtil.deleteUserObjectCourse(userId, courseId);
		//
		RegisterCourse registerCourse = new RegisterCourseImpl();
		registerCourse.setUserObjectId(userId);
		registerCourse.setCourseId(courseId);
		registerCourse.setStatesId(new Long(10));
		RegisterCourseLocalServiceUtil.deleteRegisterCourse(registerCourse);
		SessionMessages.add(actionRequest, "deleted-registerCourse"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Deleted Register Course Successfully#########################");
	}
	
	@ProcessAction(name = "searchEducator")
	public void searchEducator(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		//String redirect = ParamUtil.getString(actionRequest, "redirect","");
		String educatorName = ParamUtil.getString(actionRequest, "educatorName","");
		System.out.println(educatorName);
		String educatorAddress = ParamUtil.getString(actionRequest, "educatorAddress","");
		String educatorEmail = ParamUtil.getString(actionRequest, "educatorEmail","");
		String educatorPhone = ParamUtil.getString(actionRequest, "educatorPhone","");
		actionRequest.setAttribute("educatorName", educatorName);
		actionRequest.setAttribute("educatorAddress", educatorAddress);
		actionRequest.setAttribute("educatorEmail", educatorEmail);
		actionRequest.setAttribute("educatorPhone", educatorPhone);
		SessionMessages.add(actionRequest, "load-search-educator"); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/educator/advancesearch.jsp");
	   _log.info("#################Search Educator Successfully#########################");
	}
	
	private Log _log = LogFactoryUtil.getLog(EducatorPortlet.class.getName());

}
