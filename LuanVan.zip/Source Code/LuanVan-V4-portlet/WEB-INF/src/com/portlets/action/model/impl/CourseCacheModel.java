/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.Course;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing Course in entity cache.
 *
 * @author Computer
 * @see Course
 * @generated
 */
public class CourseCacheModel implements CacheModel<Course>, Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(21);

		sb.append("{courseId=");
		sb.append(courseId);
		sb.append(", courseName=");
		sb.append(courseName);
		sb.append(", courseStudentNo=");
		sb.append(courseStudentNo);
		sb.append(", courseStartDate=");
		sb.append(courseStartDate);
		sb.append(", courseEnrollStartDate=");
		sb.append(courseEnrollStartDate);
		sb.append(", courseSchoolDay=");
		sb.append(courseSchoolDay);
		sb.append(", courseEnrollDeadLine=");
		sb.append(courseEnrollDeadLine);
		sb.append(", statesId=");
		sb.append(statesId);
		sb.append(", trainingProgramId=");
		sb.append(trainingProgramId);
		sb.append(", educatorId=");
		sb.append(educatorId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public Course toEntityModel() {
		CourseImpl courseImpl = new CourseImpl();

		courseImpl.setCourseId(courseId);

		if (courseName == null) {
			courseImpl.setCourseName(StringPool.BLANK);
		}
		else {
			courseImpl.setCourseName(courseName);
		}

		courseImpl.setCourseStudentNo(courseStudentNo);

		if (courseStartDate == Long.MIN_VALUE) {
			courseImpl.setCourseStartDate(null);
		}
		else {
			courseImpl.setCourseStartDate(new Date(courseStartDate));
		}

		if (courseEnrollStartDate == Long.MIN_VALUE) {
			courseImpl.setCourseEnrollStartDate(null);
		}
		else {
			courseImpl.setCourseEnrollStartDate(new Date(courseEnrollStartDate));
		}

		if (courseSchoolDay == null) {
			courseImpl.setCourseSchoolDay(StringPool.BLANK);
		}
		else {
			courseImpl.setCourseSchoolDay(courseSchoolDay);
		}

		if (courseEnrollDeadLine == Long.MIN_VALUE) {
			courseImpl.setCourseEnrollDeadLine(null);
		}
		else {
			courseImpl.setCourseEnrollDeadLine(new Date(courseEnrollDeadLine));
		}

		courseImpl.setStatesId(statesId);
		courseImpl.setTrainingProgramId(trainingProgramId);
		courseImpl.setEducatorId(educatorId);

		courseImpl.resetOriginalValues();

		return courseImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		courseId = objectInput.readLong();
		courseName = objectInput.readUTF();
		courseStudentNo = objectInput.readInt();
		courseStartDate = objectInput.readLong();
		courseEnrollStartDate = objectInput.readLong();
		courseSchoolDay = objectInput.readUTF();
		courseEnrollDeadLine = objectInput.readLong();
		statesId = objectInput.readLong();
		trainingProgramId = objectInput.readLong();
		educatorId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(courseId);

		if (courseName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(courseName);
		}

		objectOutput.writeInt(courseStudentNo);
		objectOutput.writeLong(courseStartDate);
		objectOutput.writeLong(courseEnrollStartDate);

		if (courseSchoolDay == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(courseSchoolDay);
		}

		objectOutput.writeLong(courseEnrollDeadLine);
		objectOutput.writeLong(statesId);
		objectOutput.writeLong(trainingProgramId);
		objectOutput.writeLong(educatorId);
	}

	public long courseId;
	public String courseName;
	public int courseStudentNo;
	public long courseStartDate;
	public long courseEnrollStartDate;
	public String courseSchoolDay;
	public long courseEnrollDeadLine;
	public long statesId;
	public long trainingProgramId;
	public long educatorId;
}