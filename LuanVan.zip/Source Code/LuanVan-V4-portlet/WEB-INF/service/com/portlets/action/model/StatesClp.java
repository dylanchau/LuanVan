/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.StatesLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class StatesClp extends BaseModelImpl<States> implements States {
	public StatesClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return States.class;
	}

	@Override
	public String getModelClassName() {
		return States.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _statesId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setStatesId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _statesId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("statesId", getStatesId());
		attributes.put("statesName", getStatesName());
		attributes.put("statesExplain", getStatesExplain());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}

		String statesName = (String)attributes.get("statesName");

		if (statesName != null) {
			setStatesName(statesName);
		}

		String statesExplain = (String)attributes.get("statesExplain");

		if (statesExplain != null) {
			setStatesExplain(statesExplain);
		}
	}

	@Override
	public long getStatesId() {
		return _statesId;
	}

	@Override
	public void setStatesId(long statesId) {
		_statesId = statesId;

		if (_statesRemoteModel != null) {
			try {
				Class<?> clazz = _statesRemoteModel.getClass();

				Method method = clazz.getMethod("setStatesId", long.class);

				method.invoke(_statesRemoteModel, statesId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatesName() {
		return _statesName;
	}

	@Override
	public void setStatesName(String statesName) {
		_statesName = statesName;

		if (_statesRemoteModel != null) {
			try {
				Class<?> clazz = _statesRemoteModel.getClass();

				Method method = clazz.getMethod("setStatesName", String.class);

				method.invoke(_statesRemoteModel, statesName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getStatesExplain() {
		return _statesExplain;
	}

	@Override
	public void setStatesExplain(String statesExplain) {
		_statesExplain = statesExplain;

		if (_statesRemoteModel != null) {
			try {
				Class<?> clazz = _statesRemoteModel.getClass();

				Method method = clazz.getMethod("setStatesExplain", String.class);

				method.invoke(_statesRemoteModel, statesExplain);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getStatesRemoteModel() {
		return _statesRemoteModel;
	}

	public void setStatesRemoteModel(BaseModel<?> statesRemoteModel) {
		_statesRemoteModel = statesRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _statesRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_statesRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			StatesLocalServiceUtil.addStates(this);
		}
		else {
			StatesLocalServiceUtil.updateStates(this);
		}
	}

	@Override
	public States toEscapedModel() {
		return (States)ProxyUtil.newProxyInstance(States.class.getClassLoader(),
			new Class[] { States.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		StatesClp clone = new StatesClp();

		clone.setStatesId(getStatesId());
		clone.setStatesName(getStatesName());
		clone.setStatesExplain(getStatesExplain());

		return clone;
	}

	@Override
	public int compareTo(States states) {
		long primaryKey = states.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof StatesClp)) {
			return false;
		}

		StatesClp states = (StatesClp)obj;

		long primaryKey = states.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{statesId=");
		sb.append(getStatesId());
		sb.append(", statesName=");
		sb.append(getStatesName());
		sb.append(", statesExplain=");
		sb.append(getStatesExplain());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(13);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.States");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>statesId</column-name><column-value><![CDATA[");
		sb.append(getStatesId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statesName</column-name><column-value><![CDATA[");
		sb.append(getStatesName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statesExplain</column-name><column-value><![CDATA[");
		sb.append(getStatesExplain());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _statesId;
	private String _statesName;
	private String _statesExplain;
	private BaseModel<?> _statesRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}