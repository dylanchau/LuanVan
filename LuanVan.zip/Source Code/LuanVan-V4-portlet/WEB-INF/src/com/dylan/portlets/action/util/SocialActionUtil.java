package com.dylan.portlets.action.util;

import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.model.Contact;
import com.liferay.portal.service.ContactLocalServiceUtil;

public class SocialActionUtil {

	@SuppressWarnings("unchecked")
	public static List<Contact> getSocialByUserId(long userId) 
			throws Exception {
		
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(Contact.class);
		dq.add(PropertyFactoryUtil.forName("userId").eq(userId));
		
		try {
			
			return ContactLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			System.err.println(e.getMessage()); return null;
		}
	}
}
