package com.dylan.messagebus.listenerImp;

import javax.portlet.ActionRequest;
import javax.portlet.PortletURL;
import javax.portlet.WindowState;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.notifications.BaseUserNotificationHandler;
import com.liferay.portal.kernel.portlet.LiferayPortletResponse;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringUtil;
import com.liferay.portal.model.UserNotificationEvent;
import com.liferay.portal.service.ServiceContext;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.EducatorLocalServiceUtil;
import com.portlets.action.service.EmployerLocalServiceUtil;
import com.portlets.action.service.RecruitmentLocalServiceUtil;

public class UserNotificationHandler extends 
					BaseUserNotificationHandler {

public static final String PORTLET_ID = "luanvanv4_WAR_LuanVanV4portlet";
	
	long courseId;
	
	public UserNotificationHandler() {
		 
		setPortletId(com.dylan.messagebus.listenerImp.UserNotificationHandler.PORTLET_ID);
 
	}
	
	@Override
	protected String getBody(UserNotificationEvent userNotificationEvent,
			ServiceContext serviceContext) throws Exception {
 
		JSONObject jsonObject = JSONFactoryUtil
				.createJSONObject(userNotificationEvent.getPayload());
 
		courseId = jsonObject.getLong("courseId"); _log.info(courseId);
		long recruitmentId = jsonObject.getLong("id"); _log.info(recruitmentId);
		long courseIdOfReq = jsonObject.getLong("courseIdOfReq"); _log.info(courseIdOfReq);
		long RecruitmentId = jsonObject.getLong("RecruitmentId2"); _log.info(RecruitmentId);
		
		String body = "";
		if(courseId != 0) {
		
			long educatorId = jsonObject.getLong("educatorId"); _log.info(educatorId);
			String testURL = jsonObject.getString("testURL"); _log.info(testURL);
			long companyId = jsonObject.getLong("companyId"); _log.info(companyId);
			
			String title = "<strong>" + EducatorLocalServiceUtil.getEducator(educatorId).getEducatorName() +
					" have just open a new course </strong>";
			
			
			
			String bodyText = "<a href=\"" + testURL + "\">Link"  + "</a>";
	 /*
			LiferayPortletResponse liferayPortletResponse = serviceContext
					.getLiferayPortletResponse();
	 
			PortletURL confirmURL = liferayPortletResponse
					.createActionURL(com.dylan.messagebus.listenerImp.UserNotificationHandler.PORTLET_ID);
			
	 
			confirmURL.setParameter(ActionRequest.ACTION_NAME, "doSomethingGood");
			confirmURL.setParameter("redirect", serviceContext.getLayoutFullURL());
			confirmURL.setParameter("id", String.valueOf(courseId));
			confirmURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
			confirmURL.setWindowState(WindowState.NORMAL);
	 
			PortletURL ignoreURL = liferayPortletResponse.createActionURL(com.dylan.messagebus.listenerImp.UserNotificationHandler.PORTLET_ID);
			ignoreURL.setParameter(ActionRequest.ACTION_NAME, "deleteNotification");
			
			ignoreURL.setParameter("redirect", serviceContext.getLayoutFullURL());
			ignoreURL.setParameter("yourCustomEntityId", String.valueOf(courseId));
			ignoreURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
			ignoreURL.setWindowState(WindowState.NORMAL);
	 */
			body = StringUtil.replace(getBodyTemplate(), 
					new String[] {"[$TITLE$]", "[$BODY_TEXT$]" }, 
					new String[] { title, bodyText});
			
		} else if(recruitmentId != 0) {
			long id = jsonObject.getLong("id");
			long employerId = jsonObject.getLong("employerId");
			String title = "<strong>" + 
					EmployerLocalServiceUtil.getEmployer(employerId).getEmployerName() +
					" just publish a new Job </strong>";
			
			String companyId = jsonObject.getString("companyId");
			
			String url = jsonObject.getString("testURL");
			
			String bodyText = "<a style='text-align: center;' href=\"" + url + "\">Link" + "</a>";
	 /*
			LiferayPortletResponse liferayPortletResponse = serviceContext
					.getLiferayPortletResponse();
	 
			PortletURL confirmURL = liferayPortletResponse.createActionURL(PORTLET_ID);
			
	 
			confirmURL.setParameter(ActionRequest.ACTION_NAME, "doSomethingGood");
			confirmURL.setParameter("redirect", serviceContext.getLayoutFullURL());
			confirmURL.setParameter("id", String.valueOf(id));
			confirmURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
			confirmURL.setWindowState(WindowState.NORMAL);
	 
			PortletURL ignoreURL = liferayPortletResponse.createActionURL(PORTLET_ID);
			ignoreURL.setParameter(ActionRequest.ACTION_NAME, "deleteNotification");
			
			ignoreURL.setParameter("redirect", serviceContext.getLayoutFullURL());
			ignoreURL.setParameter("yourCustomEntityId", String.valueOf(id));
			ignoreURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
			ignoreURL.setWindowState(WindowState.NORMAL);
	 */
			body = StringUtil.replace(getBodyTemplate(), 
					new String[] {"[$TITLE$]", "[$BODY_TEXT$]" }, 
					new String[] { title, bodyText});
		} else if(courseIdOfReq != 0) {
			
			long studentId = jsonObject.getLong("studentId"); _log.info(studentId);
			long eduId = CourseLocalServiceUtil.getCourse(courseIdOfReq).getEducatorId();
			String title = "<div style=\"text-align: center;\">" + 
							"Notice" + "</div>";
			
			String bodyText = "<strong>" + EducatorLocalServiceUtil.getEducator(eduId).getEducatorName() +
			" have accepted your register request to course " + 
					CourseLocalServiceUtil.getCourse(courseIdOfReq).getCourseName() + "</strong>";
			
			body = StringUtil.replace(getBodyTemplate(), 
					new String[] {"[$TITLE$]", "[$BODY_TEXT$]" }, 
					new String[] { title, bodyText});
			
		} else if(RecruitmentId != 0) {
			long employerId = jsonObject.getLong("employerId"); _log.info(employerId);
			long userId = jsonObject.getLong("userId"); _log.info(userId);
			String message = jsonObject.getString("message"); _log.info(message);
			
			String title = "<div style=\"text-align: center;\">" + 
					"Notice" + "</div>";
	
			String bodyText = "<strong>" + EmployerLocalServiceUtil.getEmployer(employerId).getEmployerName() +
			message + 
					RecruitmentLocalServiceUtil.getRecruitment(RecruitmentId).getRecruitmentName() + "</strong>";
			
			body = StringUtil.replace(getBodyTemplate(), 
					new String[] {"[$TITLE$]", "[$BODY_TEXT$]" }, 
					new String[] { title, bodyText});
		}
		
		return body; 
	}
 
	@Override
	protected String getLink(UserNotificationEvent userNotificationEvent,
			ServiceContext serviceContext) throws Exception {
 
		JSONObject jsonObject = JSONFactoryUtil
				.createJSONObject(userNotificationEvent.getPayload());
 
		long id = jsonObject
				.getLong("id");
		
		LiferayPortletResponse liferayPortletResponse = serviceContext
				.getLiferayPortletResponse();		
 
		PortletURL confirmURL = liferayPortletResponse.createActionURL(com.dylan.messagebus.listenerImp.UserNotificationHandler.PORTLET_ID);
		confirmURL.setParameter(ActionRequest.ACTION_NAME, "showDetails");
		confirmURL.setParameter("redirect", serviceContext.getLayoutFullURL());
		confirmURL.setParameter("id", String.valueOf(id));
		confirmURL.setParameter("userNotificationEventId", String.valueOf(userNotificationEvent.getUserNotificationEventId()));
		confirmURL.setWindowState(WindowState.NORMAL);
		
		return confirmURL.toString();
	}
 
	protected String getBodyTemplate() throws Exception {
		StringBundler sb = new StringBundler(5);
		sb.append("<div class=\"title\">[$TITLE$]</div>");
		sb.append("<div class=\"body\">[$BODY_TEXT$]</div>");

		return sb.toString();
	}
	
	Log _log = LogFactoryUtil.getLog(UserNotificationHandler.class);
}
