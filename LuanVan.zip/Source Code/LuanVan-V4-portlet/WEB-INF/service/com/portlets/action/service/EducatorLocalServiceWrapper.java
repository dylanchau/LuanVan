/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link EducatorLocalService}.
 *
 * @author Computer
 * @see EducatorLocalService
 * @generated
 */
public class EducatorLocalServiceWrapper implements EducatorLocalService,
	ServiceWrapper<EducatorLocalService> {
	public EducatorLocalServiceWrapper(
		EducatorLocalService educatorLocalService) {
		_educatorLocalService = educatorLocalService;
	}

	/**
	* Adds the educator to the database. Also notifies the appropriate model listeners.
	*
	* @param educator the educator
	* @return the educator that was added
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.Educator addEducator(
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.addEducator(educator);
	}

	/**
	* Creates a new educator with the primary key. Does not add the educator to the database.
	*
	* @param educatorId the primary key for the new educator
	* @return the new educator
	*/
	@Override
	public com.portlets.action.model.Educator createEducator(long educatorId) {
		return _educatorLocalService.createEducator(educatorId);
	}

	/**
	* Deletes the educator with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param educatorId the primary key of the educator
	* @return the educator that was removed
	* @throws PortalException if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.Educator deleteEducator(long educatorId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.deleteEducator(educatorId);
	}

	/**
	* Deletes the educator from the database. Also notifies the appropriate model listeners.
	*
	* @param educator the educator
	* @return the educator that was removed
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.Educator deleteEducator(
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.deleteEducator(educator);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _educatorLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@Override
	@SuppressWarnings("rawtypes")
	public java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.dynamicQueryCount(dynamicQuery, projection);
	}

	@Override
	public com.portlets.action.model.Educator fetchEducator(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.fetchEducator(educatorId);
	}

	/**
	* Returns the educator with the primary key.
	*
	* @param educatorId the primary key of the educator
	* @return the educator
	* @throws PortalException if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.Educator getEducator(long educatorId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getEducator(educatorId);
	}

	@Override
	public com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the educators.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @return the range of educators
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.Educator> getEducators(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getEducators(start, end);
	}

	/**
	* Returns the number of educators.
	*
	* @return the number of educators
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getEducatorsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getEducatorsCount();
	}

	/**
	* Updates the educator in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param educator the educator
	* @return the educator that was updated
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public com.portlets.action.model.Educator updateEducator(
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.updateEducator(educator);
	}

	@Override
	public com.portlets.action.model.EducatorEducatorLogoBlobModel getEducatorLogoBlobModel(
		java.io.Serializable primaryKey)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getEducatorLogoBlobModel(primaryKey);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addUserObjectEducator(long userObjectId, long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.addUserObjectEducator(userObjectId, educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addUserObjectEducator(long userObjectId,
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.addUserObjectEducator(userObjectId, educator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addUserObjectEducators(long userObjectId, long[] educatorIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.addUserObjectEducators(userObjectId, educatorIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void addUserObjectEducators(long userObjectId,
		java.util.List<com.portlets.action.model.Educator> Educators)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.addUserObjectEducators(userObjectId, Educators);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void clearUserObjectEducators(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.clearUserObjectEducators(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteUserObjectEducator(long userObjectId, long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.deleteUserObjectEducator(userObjectId, educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteUserObjectEducator(long userObjectId,
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.deleteUserObjectEducator(userObjectId, educator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteUserObjectEducators(long userObjectId, long[] educatorIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.deleteUserObjectEducators(userObjectId,
			educatorIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void deleteUserObjectEducators(long userObjectId,
		java.util.List<com.portlets.action.model.Educator> Educators)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.deleteUserObjectEducators(userObjectId, Educators);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.Educator> getUserObjectEducators(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getUserObjectEducators(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.Educator> getUserObjectEducators(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getUserObjectEducators(userObjectId,
			start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public java.util.List<com.portlets.action.model.Educator> getUserObjectEducators(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getUserObjectEducators(userObjectId,
			start, end, orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public int getUserObjectEducatorsCount(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getUserObjectEducatorsCount(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasUserObjectEducator(long userObjectId, long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.hasUserObjectEducator(userObjectId,
			educatorId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public boolean hasUserObjectEducators(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.hasUserObjectEducators(userObjectId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	@Override
	public void setUserObjectEducators(long userObjectId, long[] educatorIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		_educatorLocalService.setUserObjectEducators(userObjectId, educatorIds);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	@Override
	public java.lang.String getBeanIdentifier() {
		return _educatorLocalService.getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	@Override
	public void setBeanIdentifier(java.lang.String beanIdentifier) {
		_educatorLocalService.setBeanIdentifier(beanIdentifier);
	}

	@Override
	public java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return _educatorLocalService.invokeMethod(name, parameterTypes,
			arguments);
	}

	/**
	* @param query
	* @param start
	* @param end
	* @return list rong neu exception
	*/
	@Override
	public java.util.List<com.portlets.action.model.Educator> searchEducatorLikeOrProperties(
		java.lang.String query, int start, int end) {
		return _educatorLocalService.searchEducatorLikeOrProperties(query,
			start, end);
	}

	@Override
	public java.util.List<com.portlets.action.model.Educator> getEducatorByUserId(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getEducatorByUserId(userId);
	}

	@Override
	public java.util.List<com.portlets.action.model.Educator> getEducatorByNoUserId(
		long userId) throws com.liferay.portal.kernel.exception.SystemException {
		return _educatorLocalService.getEducatorByNoUserId(userId);
	}

	@Override
	public java.util.List<com.portlets.action.model.Educator> searchEducator(
		java.lang.String educatorName, java.lang.String educatorEmail,
		java.lang.String educatorAddress, java.lang.String educatorPhone) {
		return _educatorLocalService.searchEducator(educatorName,
			educatorEmail, educatorAddress, educatorPhone);
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedService}
	 */
	public EducatorLocalService getWrappedEducatorLocalService() {
		return _educatorLocalService;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #setWrappedService}
	 */
	public void setWrappedEducatorLocalService(
		EducatorLocalService educatorLocalService) {
		_educatorLocalService = educatorLocalService;
	}

	@Override
	public EducatorLocalService getWrappedService() {
		return _educatorLocalService;
	}

	@Override
	public void setWrappedService(EducatorLocalService educatorLocalService) {
		_educatorLocalService = educatorLocalService;
	}

	private EducatorLocalService _educatorLocalService;
}