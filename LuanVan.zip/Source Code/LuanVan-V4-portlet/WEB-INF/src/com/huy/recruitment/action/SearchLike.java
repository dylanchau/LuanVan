package com.huy.recruitment.action;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.RecruitmentLocalServiceClp;
import com.portlets.action.service.RecruitmentLocalServiceUtil;
import com.portlets.action.service.RecruitmentService;
import com.portlets.action.service.RecruitmentLocalService;
import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

public class SearchLike {
	private static RecruitmentLocalService _service;
	public static java.util.List<com.portlets.action.model.Recruitment> searchRecruitmentLikeOrProperties(
			java.lang.String query, int start, int end) {
			return SearchLike.searchRecruitmentLikeOrProperties(query, start, end);
		}
	
	public static RecruitmentService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					RecruitmentLocalService.class.getName());

			if (invokableLocalService instanceof RecruitmentLocalService) {
				_service = (RecruitmentLocalService)invokableLocalService;
			}
			else {
				_service = new RecruitmentLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(RecruitmentLocalServiceUtil.class,
				"_service");
		}

		return (RecruitmentService) _service;
	}
}
