/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.sql.Blob;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.EmployerServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.EmployerServiceSoap
 * @generated
 */
public class EmployerSoap implements Serializable {
	public static EmployerSoap toSoapModel(Employer model) {
		EmployerSoap soapModel = new EmployerSoap();

		soapModel.setEmployerId(model.getEmployerId());
		soapModel.setEmployerName(model.getEmployerName());
		soapModel.setEmployerAddress(model.getEmployerAddress());
		soapModel.setEmployerEmail(model.getEmployerEmail());
		soapModel.setEmployerPhone(model.getEmployerPhone());
		soapModel.setEmployerIntroduce(model.getEmployerIntroduce());
		soapModel.setEmployerAchievements(model.getEmployerAchievements());
		soapModel.setEmployerLogoName(model.getEmployerLogoName());
		soapModel.setEmployerLogo(model.getEmployerLogo());

		return soapModel;
	}

	public static EmployerSoap[] toSoapModels(Employer[] models) {
		EmployerSoap[] soapModels = new EmployerSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static EmployerSoap[][] toSoapModels(Employer[][] models) {
		EmployerSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new EmployerSoap[models.length][models[0].length];
		}
		else {
			soapModels = new EmployerSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static EmployerSoap[] toSoapModels(List<Employer> models) {
		List<EmployerSoap> soapModels = new ArrayList<EmployerSoap>(models.size());

		for (Employer model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new EmployerSoap[soapModels.size()]);
	}

	public EmployerSoap() {
	}

	public long getPrimaryKey() {
		return _employerId;
	}

	public void setPrimaryKey(long pk) {
		setEmployerId(pk);
	}

	public long getEmployerId() {
		return _employerId;
	}

	public void setEmployerId(long employerId) {
		_employerId = employerId;
	}

	public String getEmployerName() {
		return _employerName;
	}

	public void setEmployerName(String employerName) {
		_employerName = employerName;
	}

	public String getEmployerAddress() {
		return _employerAddress;
	}

	public void setEmployerAddress(String employerAddress) {
		_employerAddress = employerAddress;
	}

	public String getEmployerEmail() {
		return _employerEmail;
	}

	public void setEmployerEmail(String employerEmail) {
		_employerEmail = employerEmail;
	}

	public String getEmployerPhone() {
		return _employerPhone;
	}

	public void setEmployerPhone(String employerPhone) {
		_employerPhone = employerPhone;
	}

	public String getEmployerIntroduce() {
		return _employerIntroduce;
	}

	public void setEmployerIntroduce(String employerIntroduce) {
		_employerIntroduce = employerIntroduce;
	}

	public String getEmployerAchievements() {
		return _employerAchievements;
	}

	public void setEmployerAchievements(String employerAchievements) {
		_employerAchievements = employerAchievements;
	}

	public String getEmployerLogoName() {
		return _employerLogoName;
	}

	public void setEmployerLogoName(String employerLogoName) {
		_employerLogoName = employerLogoName;
	}

	public Blob getEmployerLogo() {
		return _employerLogo;
	}

	public void setEmployerLogo(Blob employerLogo) {
		_employerLogo = employerLogo;
	}

	private long _employerId;
	private String _employerName;
	private String _employerAddress;
	private String _employerEmail;
	private String _employerPhone;
	private String _employerIntroduce;
	private String _employerAchievements;
	private String _employerLogoName;
	private Blob _employerLogo;
}