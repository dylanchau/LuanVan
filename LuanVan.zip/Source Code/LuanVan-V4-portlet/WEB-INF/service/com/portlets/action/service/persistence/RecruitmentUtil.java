/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.ServiceContext;

import com.portlets.action.model.Recruitment;

import java.util.List;

/**
 * The persistence utility for the recruitment service. This utility wraps {@link RecruitmentPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see RecruitmentPersistence
 * @see RecruitmentPersistenceImpl
 * @generated
 */
public class RecruitmentUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#clearCache(com.liferay.portal.model.BaseModel)
	 */
	public static void clearCache(Recruitment recruitment) {
		getPersistence().clearCache(recruitment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery)
		throws SystemException {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<Recruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery) throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<Recruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end)
		throws SystemException {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<Recruitment> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator orderByComparator) throws SystemException {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel)
	 */
	public static Recruitment update(Recruitment recruitment)
		throws SystemException {
		return getPersistence().update(recruitment);
	}

	/**
	 * @see com.liferay.portal.service.persistence.BasePersistence#update(com.liferay.portal.model.BaseModel, ServiceContext)
	 */
	public static Recruitment update(Recruitment recruitment,
		ServiceContext serviceContext) throws SystemException {
		return getPersistence().update(recruitment, serviceContext);
	}

	/**
	* Returns all the recruitments where employerId = &#63;.
	*
	* @param employerId the employer ID
	* @return the matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findByEmployerId(
		long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmployerId(employerId);
	}

	/**
	* Returns a range of all the recruitments where employerId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param employerId the employer ID
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @return the range of matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findByEmployerId(
		long employerId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findByEmployerId(employerId, start, end);
	}

	/**
	* Returns an ordered range of all the recruitments where employerId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param employerId the employer ID
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findByEmployerId(
		long employerId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findByEmployerId(employerId, start, end, orderByComparator);
	}

	/**
	* Returns the first recruitment in the ordered set where employerId = &#63;.
	*
	* @param employerId the employer ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment findByEmployerId_First(
		long employerId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence()
				   .findByEmployerId_First(employerId, orderByComparator);
	}

	/**
	* Returns the first recruitment in the ordered set where employerId = &#63;.
	*
	* @param employerId the employer ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching recruitment, or <code>null</code> if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment fetchByEmployerId_First(
		long employerId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByEmployerId_First(employerId, orderByComparator);
	}

	/**
	* Returns the last recruitment in the ordered set where employerId = &#63;.
	*
	* @param employerId the employer ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment findByEmployerId_Last(
		long employerId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence()
				   .findByEmployerId_Last(employerId, orderByComparator);
	}

	/**
	* Returns the last recruitment in the ordered set where employerId = &#63;.
	*
	* @param employerId the employer ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching recruitment, or <code>null</code> if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment fetchByEmployerId_Last(
		long employerId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByEmployerId_Last(employerId, orderByComparator);
	}

	/**
	* Returns the recruitments before and after the current recruitment in the ordered set where employerId = &#63;.
	*
	* @param recruitmentId the primary key of the current recruitment
	* @param employerId the employer ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment[] findByEmployerId_PrevAndNext(
		long recruitmentId, long employerId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence()
				   .findByEmployerId_PrevAndNext(recruitmentId, employerId,
			orderByComparator);
	}

	/**
	* Removes all the recruitments where employerId = &#63; from the database.
	*
	* @param employerId the employer ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeByEmployerId(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeByEmployerId(employerId);
	}

	/**
	* Returns the number of recruitments where employerId = &#63;.
	*
	* @param employerId the employer ID
	* @return the number of matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByEmployerId(long employerId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByEmployerId(employerId);
	}

	/**
	* Returns the recruitment where recruitmentId = &#63; or throws a {@link com.portlets.action.NoSuchRecruitmentException} if it could not be found.
	*
	* @param recruitmentId the recruitment ID
	* @return the matching recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment findByrecruitmentId(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence().findByrecruitmentId(recruitmentId);
	}

	/**
	* Returns the recruitment where recruitmentId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param recruitmentId the recruitment ID
	* @return the matching recruitment, or <code>null</code> if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment fetchByrecruitmentId(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByrecruitmentId(recruitmentId);
	}

	/**
	* Returns the recruitment where recruitmentId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param recruitmentId the recruitment ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching recruitment, or <code>null</code> if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment fetchByrecruitmentId(
		long recruitmentId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchByrecruitmentId(recruitmentId, retrieveFromCache);
	}

	/**
	* Removes the recruitment where recruitmentId = &#63; from the database.
	*
	* @param recruitmentId the recruitment ID
	* @return the recruitment that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment removeByrecruitmentId(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence().removeByrecruitmentId(recruitmentId);
	}

	/**
	* Returns the number of recruitments where recruitmentId = &#63;.
	*
	* @param recruitmentId the recruitment ID
	* @return the number of matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countByrecruitmentId(long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countByrecruitmentId(recruitmentId);
	}

	/**
	* Returns all the recruitments where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findBystatesId(
		long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId);
	}

	/**
	* Returns a range of all the recruitments where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @return the range of matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findBystatesId(
		long statesId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findBystatesId(statesId, start, end);
	}

	/**
	* Returns an ordered range of all the recruitments where statesId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param statesId the states ID
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findBystatesId(
		long statesId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .findBystatesId(statesId, start, end, orderByComparator);
	}

	/**
	* Returns the first recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment findBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence().findBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the first recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching recruitment, or <code>null</code> if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment fetchBystatesId_First(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence()
				   .fetchBystatesId_First(statesId, orderByComparator);
	}

	/**
	* Returns the last recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment findBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence().findBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the last recruitment in the ordered set where statesId = &#63;.
	*
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching recruitment, or <code>null</code> if a matching recruitment could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment fetchBystatesId_Last(
		long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchBystatesId_Last(statesId, orderByComparator);
	}

	/**
	* Returns the recruitments before and after the current recruitment in the ordered set where statesId = &#63;.
	*
	* @param recruitmentId the primary key of the current recruitment
	* @param statesId the states ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment[] findBystatesId_PrevAndNext(
		long recruitmentId, long statesId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence()
				   .findBystatesId_PrevAndNext(recruitmentId, statesId,
			orderByComparator);
	}

	/**
	* Removes all the recruitments where statesId = &#63; from the database.
	*
	* @param statesId the states ID
	* @throws SystemException if a system exception occurred
	*/
	public static void removeBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeBystatesId(statesId);
	}

	/**
	* Returns the number of recruitments where statesId = &#63;.
	*
	* @param statesId the states ID
	* @return the number of matching recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countBystatesId(long statesId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countBystatesId(statesId);
	}

	/**
	* Caches the recruitment in the entity cache if it is enabled.
	*
	* @param recruitment the recruitment
	*/
	public static void cacheResult(
		com.portlets.action.model.Recruitment recruitment) {
		getPersistence().cacheResult(recruitment);
	}

	/**
	* Caches the recruitments in the entity cache if it is enabled.
	*
	* @param recruitments the recruitments
	*/
	public static void cacheResult(
		java.util.List<com.portlets.action.model.Recruitment> recruitments) {
		getPersistence().cacheResult(recruitments);
	}

	/**
	* Creates a new recruitment with the primary key. Does not add the recruitment to the database.
	*
	* @param recruitmentId the primary key for the new recruitment
	* @return the new recruitment
	*/
	public static com.portlets.action.model.Recruitment create(
		long recruitmentId) {
		return getPersistence().create(recruitmentId);
	}

	/**
	* Removes the recruitment with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param recruitmentId the primary key of the recruitment
	* @return the recruitment that was removed
	* @throws com.portlets.action.NoSuchRecruitmentException if a recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment remove(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence().remove(recruitmentId);
	}

	public static com.portlets.action.model.Recruitment updateImpl(
		com.portlets.action.model.Recruitment recruitment)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().updateImpl(recruitment);
	}

	/**
	* Returns the recruitment with the primary key or throws a {@link com.portlets.action.NoSuchRecruitmentException} if it could not be found.
	*
	* @param recruitmentId the primary key of the recruitment
	* @return the recruitment
	* @throws com.portlets.action.NoSuchRecruitmentException if a recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment findByPrimaryKey(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchRecruitmentException {
		return getPersistence().findByPrimaryKey(recruitmentId);
	}

	/**
	* Returns the recruitment with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param recruitmentId the primary key of the recruitment
	* @return the recruitment, or <code>null</code> if a recruitment with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.Recruitment fetchByPrimaryKey(
		long recruitmentId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().fetchByPrimaryKey(recruitmentId);
	}

	/**
	* Returns all the recruitments.
	*
	* @return the recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @return the range of recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the recruitments.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Recruitment> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Removes all the recruitments from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public static void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of recruitments.
	*
	* @return the number of recruitments
	* @throws SystemException if a system exception occurred
	*/
	public static int countAll()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().countAll();
	}

	/**
	* Returns all the user objects associated with the recruitment.
	*
	* @param pk the primary key of the recruitment
	* @return the user objects associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjects(pk);
	}

	/**
	* Returns a range of all the user objects associated with the recruitment.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the recruitment
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @return the range of user objects associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjects(pk, start, end);
	}

	/**
	* Returns an ordered range of all the user objects associated with the recruitment.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the recruitment
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user objects associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjects(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of user objects associated with the recruitment.
	*
	* @param pk the primary key of the recruitment
	* @return the number of user objects associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static int getUserObjectsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getUserObjectsSize(pk);
	}

	/**
	* Returns <code>true</code> if the user object is associated with the recruitment.
	*
	* @param pk the primary key of the recruitment
	* @param userObjectPK the primary key of the user object
	* @return <code>true</code> if the user object is associated with the recruitment; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsUserObject(pk, userObjectPK);
	}

	/**
	* Returns <code>true</code> if the recruitment has any user objects associated with it.
	*
	* @param pk the primary key of the recruitment to check for associations with user objects
	* @return <code>true</code> if the recruitment has any user objects associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsUserObjects(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsUserObjects(pk);
	}

	/**
	* Adds an association between the recruitment and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjectPK the primary key of the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObject(pk, userObjectPK);
	}

	/**
	* Adds an association between the recruitment and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObject the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObject(long pk,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObject(pk, userObject);
	}

	/**
	* Adds an association between the recruitment and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjectPKs the primary keys of the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObjects(pk, userObjectPKs);
	}

	/**
	* Adds an association between the recruitment and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjects the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void addUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addUserObjects(pk, userObjects);
	}

	/**
	* Clears all associations between the recruitment and its user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment to clear the associated user objects from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearUserObjects(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearUserObjects(pk);
	}

	/**
	* Removes the association between the recruitment and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjectPK the primary key of the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObject(pk, userObjectPK);
	}

	/**
	* Removes the association between the recruitment and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObject the user object
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObject(long pk,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObject(pk, userObject);
	}

	/**
	* Removes the association between the recruitment and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjectPKs the primary keys of the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObjects(pk, userObjectPKs);
	}

	/**
	* Removes the association between the recruitment and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjects the user objects
	* @throws SystemException if a system exception occurred
	*/
	public static void removeUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeUserObjects(pk, userObjects);
	}

	/**
	* Sets the user objects associated with the recruitment, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjectPKs the primary keys of the user objects to be associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void setUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setUserObjects(pk, userObjectPKs);
	}

	/**
	* Sets the user objects associated with the recruitment, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param userObjects the user objects to be associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void setUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setUserObjects(pk, userObjects);
	}

	/**
	* Returns all the skills associated with the recruitment.
	*
	* @param pk the primary key of the recruitment
	* @return the skills associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> getSkills(
		long pk) throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getSkills(pk);
	}

	/**
	* Returns a range of all the skills associated with the recruitment.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the recruitment
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @return the range of skills associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> getSkills(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getSkills(pk, start, end);
	}

	/**
	* Returns an ordered range of all the skills associated with the recruitment.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.RecruitmentModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the recruitment
	* @param start the lower bound of the range of recruitments
	* @param end the upper bound of the range of recruitments (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of skills associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.Skill> getSkills(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getSkills(pk, start, end, orderByComparator);
	}

	/**
	* Returns the number of skills associated with the recruitment.
	*
	* @param pk the primary key of the recruitment
	* @return the number of skills associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static int getSkillsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().getSkillsSize(pk);
	}

	/**
	* Returns <code>true</code> if the skill is associated with the recruitment.
	*
	* @param pk the primary key of the recruitment
	* @param skillPK the primary key of the skill
	* @return <code>true</code> if the skill is associated with the recruitment; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsSkill(long pk, long skillPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsSkill(pk, skillPK);
	}

	/**
	* Returns <code>true</code> if the recruitment has any skills associated with it.
	*
	* @param pk the primary key of the recruitment to check for associations with skills
	* @return <code>true</code> if the recruitment has any skills associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public static boolean containsSkills(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getPersistence().containsSkills(pk);
	}

	/**
	* Adds an association between the recruitment and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skillPK the primary key of the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkill(long pk, long skillPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addSkill(pk, skillPK);
	}

	/**
	* Adds an association between the recruitment and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skill the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkill(long pk, com.portlets.action.model.Skill skill)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addSkill(pk, skill);
	}

	/**
	* Adds an association between the recruitment and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skillPKs the primary keys of the skills
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkills(long pk, long[] skillPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addSkills(pk, skillPKs);
	}

	/**
	* Adds an association between the recruitment and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skills the skills
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkills(long pk,
		java.util.List<com.portlets.action.model.Skill> skills)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().addSkills(pk, skills);
	}

	/**
	* Clears all associations between the recruitment and its skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment to clear the associated skills from
	* @throws SystemException if a system exception occurred
	*/
	public static void clearSkills(long pk)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().clearSkills(pk);
	}

	/**
	* Removes the association between the recruitment and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skillPK the primary key of the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void removeSkill(long pk, long skillPK)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeSkill(pk, skillPK);
	}

	/**
	* Removes the association between the recruitment and the skill. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skill the skill
	* @throws SystemException if a system exception occurred
	*/
	public static void removeSkill(long pk,
		com.portlets.action.model.Skill skill)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeSkill(pk, skill);
	}

	/**
	* Removes the association between the recruitment and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skillPKs the primary keys of the skills
	* @throws SystemException if a system exception occurred
	*/
	public static void removeSkills(long pk, long[] skillPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeSkills(pk, skillPKs);
	}

	/**
	* Removes the association between the recruitment and the skills. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skills the skills
	* @throws SystemException if a system exception occurred
	*/
	public static void removeSkills(long pk,
		java.util.List<com.portlets.action.model.Skill> skills)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().removeSkills(pk, skills);
	}

	/**
	* Sets the skills associated with the recruitment, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skillPKs the primary keys of the skills to be associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void setSkills(long pk, long[] skillPKs)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setSkills(pk, skillPKs);
	}

	/**
	* Sets the skills associated with the recruitment, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the recruitment
	* @param skills the skills to be associated with the recruitment
	* @throws SystemException if a system exception occurred
	*/
	public static void setSkills(long pk,
		java.util.List<com.portlets.action.model.Skill> skills)
		throws com.liferay.portal.kernel.exception.SystemException {
		getPersistence().setSkills(pk, skills);
	}

	public static RecruitmentPersistence getPersistence() {
		if (_persistence == null) {
			_persistence = (RecruitmentPersistence)PortletBeanLocatorUtil.locate(com.portlets.action.service.ClpSerializer.getServletContextName(),
					RecruitmentPersistence.class.getName());

			ReferenceRegistry.registerReference(RecruitmentUtil.class,
				"_persistence");
		}

		return _persistence;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setPersistence(RecruitmentPersistence persistence) {
	}

	private static RecruitmentPersistence _persistence;
}