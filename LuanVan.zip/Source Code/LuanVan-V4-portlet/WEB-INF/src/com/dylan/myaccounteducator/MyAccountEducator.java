package com.dylan.myaccounteducator;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.Contact;
import com.liferay.portal.model.EmailAddress;
import com.liferay.portal.model.Phone;
import com.liferay.portal.model.User;
import com.liferay.portal.service.AddressLocalServiceUtil;
import com.liferay.portal.service.ContactLocalServiceUtil;
import com.liferay.portal.service.CountryServiceUtil;
import com.liferay.portal.service.EmailAddressLocalServiceUtil;
import com.liferay.portal.service.PhoneLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.Educator;
import com.portlets.action.service.EducatorLocalServiceUtil;

/**
 * Portlet implementation class MyAccountEducator
 */
public class MyAccountEducator extends MVCPortlet {
	public void updateDetail(ActionRequest actionRequest,
			ActionResponse actionResponse) throws Exception {
		
		//UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String emailAddress = ParamUtil.getString(actionRequest, "emailAddress");
		String name = ParamUtil.getString(actionRequest, "firstName");
		String screenName = ParamUtil.getString(actionRequest, "screenName");
		
		//File userPortrait = uploadRequest.getFile("fileName");
		//InputStream fis = new FileInputStream(userPortrait);
		//InputStream inputStram = uploadRequest.getFileAsStream("fileName"); 
		//OutputBlob dataOutputBlob = new OutputBlob(fis, userPortrait.length());
		
		 User s = null;
		 
		 _log.info(name + "\t" + userId + "\t" + emailAddress);
		
		try{
			Educator e = EducatorLocalServiceUtil.getEducator(userId); _log.info(e.getEducatorId());
			 e.setEducatorEmail(emailAddress);
			 e.setEducatorName(name);
			 //e.setEducatorLogo(dataOutputBlob);
			 EducatorLocalServiceUtil.updateEducator(e);
			 
			 try {
				 
				 //InputStream inputStram = uploadRequest.getFileAsStream("fileName"); 
				 //byte[] bytes = FileUtil.getBytes(userPortrait);

				 s = UserLocalServiceUtil.getUser(userId); _log.info(s.getUserId());
				 s.setEmailAddress(emailAddress);
				 s.setFirstName(name);
				 s.setScreenName(screenName);
				 
				 s = UserLocalServiceUtil.updateUser(s);
				 if(s != null)
					 _log.info("success");
				 else 
					 _log.error("fail");
				 
				_log.info(s.getFirstName() + "\t" + s.getScreenName()); 
				 //UserLocalServiceUtil.updatePortrait(userId, bytes);
					
			 }catch(SystemException e1) {
				 _log.error(e1.getMessage());
			 } catch(PortalException e2) {
				 _log.error(e2.getMessage());
			 }
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-detail-success");
			 
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-detail-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
	}
	
	public void updatePassword(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		
		
		String password1 = ParamUtil.getString(actionRequest, "password1");
		String reminderQueryQuestion = ParamUtil.getString(actionRequest, "reminderQueryQuestion");
		String reminderQueryAnswer = ParamUtil.getString(actionRequest, "reminderQueryAnswer");
		
		User user = null;
		
		user = UserLocalServiceUtil.updatePassword(userId, password1, password1, false);
		user = UserLocalServiceUtil.updateReminderQuery(userId, reminderQueryQuestion, reminderQueryAnswer);
		
		if(user != null) {
			SessionMessages.add(actionRequest.getPortletSession(), "update-pass-success");
		} else {
			SessionErrors.add(actionRequest.getPortletSession(), "update-pass-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/password.jsp");
		
	}
	
	public void addAddress(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String street = ParamUtil.getString(actionRequest, "street");
		String city = ParamUtil.getString(actionRequest, "city");
		long countryId = ParamUtil.getLong(actionRequest, "countryId");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		String zip = ParamUtil.getString(actionRequest, "zip");
		long educatorId = ParamUtil.getLong(actionRequest, "educatorId");
		
		try {
			Address address = null;
			address = AddressLocalServiceUtil.createAddress(CounterLocalServiceUtil.increment());
			
			Educator e = EducatorLocalServiceUtil.getEducator(educatorId);
			e.setEducatorAddress(street + ", " + city + ", " + CountryServiceUtil.getCountry(countryId).getName());
			EducatorLocalServiceUtil.updateEducator(e);
			
			address.setUserId(userId);
			address.setCity(city);
			address.setCountryId(countryId);
			address.setStreet1(street);
			address.setTypeId(typeId);
			address.setZip(zip);
			
			AddressLocalServiceUtil.addAddress(address);
			SessionMessages.add(actionRequest.getPortletSession(), "add-address-success");
			
		} catch(Exception e) {
			e.printStackTrace();
			SessionErrors.add(actionRequest.getPortletSession(), "add-address-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/addresses.jsp");
		_log.info(userId + "\n" + street + "\n" + city + "\n" + countryId + typeId);
	}
	
	public void updateAddress(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		long addressId = ParamUtil.getLong(actionRequest, "addressId");
		String street1 = ParamUtil.getString(actionRequest, "street1");
		String city = ParamUtil.getString(actionRequest, "city");
		long countryId = ParamUtil.getLong(actionRequest, "countryId");
		String zip = ParamUtil.getString(actionRequest, "zip");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		long educatorId = ParamUtil.getLong(actionRequest, "educatorId");
		
		_log.info(userId + "\n" + addressId + "\n" + street1 + "\n" + 
					city + "\n" + countryId + "\n" + zip + "\n" + typeId);
		
		try {
			
			Address address = AddressLocalServiceUtil.getAddress(addressId); 
			address.setStreet1(street1);
			address.setCity(city);
			address.setCountryId(countryId);
			address.setZip(zip);
			address.setTypeId(typeId);
			AddressLocalServiceUtil.updateAddress(address);
			
			Educator e = EducatorLocalServiceUtil.getEducator(educatorId);
			e.setEducatorAddress(street1 + ", " + city + ", " + CountryServiceUtil.getCountry(countryId).getName());
			EducatorLocalServiceUtil.updateEducator(e);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-address-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-address-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/addresses.jsp");
	}
	
	public void updatePhoneNumber(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long educatorId = ParamUtil.getLong(actionRequest, "userId");
		long phoneId = ParamUtil.getLong(actionRequest, "phoneId");
		String number_ = ParamUtil.getString(actionRequest, "number");
		String extension = ParamUtil.getString(actionRequest, "extension");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		try {
			
			Phone phone = PhoneLocalServiceUtil.getPhone(phoneId);
			
			phone.setNumber(number_);
			phone.setExtension(extension);
			phone.setTypeId(typeId);
			
			PhoneLocalServiceUtil.updatePhone(phone);
			
			Educator e = EducatorLocalServiceUtil.getEducator(educatorId);
			e.setEducatorPhone(number_);
			EducatorLocalServiceUtil.updateEducator(e);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-phone-success");
		} catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-phone-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/phonenumbers.jsp");
	}
	
	public void addPhoneNumber(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String number_ = ParamUtil.getString(actionRequest, "number_");
		String extension = ParamUtil.getString(actionRequest, "extension");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		try {
			
			Phone phone = PhoneLocalServiceUtil.createPhone(CounterLocalServiceUtil.increment());
			
			phone.setNumber(number_);
			phone.setExtension(extension);
			phone.setTypeId(typeId);
			phone.setUserId(userId);
			
			PhoneLocalServiceUtil.addPhone(phone);
			
			Educator e = EducatorLocalServiceUtil.getEducator(userId);
			e.setEducatorPhone(number_);
			EducatorLocalServiceUtil.updateEducator(e);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-phone-success");
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "add-phone-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/phonenumbers.jsp");
		_log.info(userId + "\n" + number_ + "\n" + extension +  "\n" + typeId);
	}
	
	public void addUserEmail(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String address = ParamUtil.getString(actionRequest, "address");
		
		try {
			
			EmailAddress emailAddress = EmailAddressLocalServiceUtil
					.createEmailAddress(CounterLocalServiceUtil.increment());
			
			emailAddress.setUserId(userId);
			emailAddress.setAddress(address);
			
			EmailAddressLocalServiceUtil.addEmailAddress(emailAddress);
			SessionMessages.add(actionRequest.getPortletSession(), "add-email-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "add-email-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/emailaddresses.jsp");
		_log.info(address + "\n" +userId);
	}
	
	public void updateUserEmail(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String address = ParamUtil.getString(actionRequest, "address");
		long emailAddressId = ParamUtil.getLong(actionRequest, "emailAddressId");
		
		try {
			
			EmailAddress emailAddress = EmailAddressLocalServiceUtil.getEmailAddress(emailAddressId);
			
			emailAddress.setAddress(address);
			
			EmailAddressLocalServiceUtil.addEmailAddress(emailAddress);
			SessionMessages.add(actionRequest.getPortletSession(), "update-email-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-email-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/emailaddresses.jsp");
		_log.info(address + "\n" +userId);
	}
	
	public void updateSocial(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long contactId = ParamUtil.getLong(actionRequest, "contactId");
		String facebookSn = ParamUtil.getString(actionRequest, "facebookSn");
		String twitterSn = ParamUtil.getString(actionRequest, "twitterSn");
		
		try {
			
			Contact con = ContactLocalServiceUtil.getContact(contactId);
			con.setFacebookSn(facebookSn);
			con.setTwitterSn(twitterSn);
			
			ContactLocalServiceUtil.updateContact(con);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-social-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-social-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/socialnetwork.jsp");
		_log.info(contactId + "\n" +contactId + "\n" + twitterSn);
	}
	
	public void addSocial(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		String facebookSn = ParamUtil.getString(actionRequest, "facebookSn");
		String twitterSn = ParamUtil.getString(actionRequest, "twitterSn");
		long userId = ParamUtil.getLong(actionRequest, "userId");
		
		try {
			
			Contact con = ContactLocalServiceUtil.createContact(CounterLocalServiceUtil.increment());
			
			con.setFacebookSn(facebookSn);
			con.setTwitterSn(twitterSn);
			con.setUserId(userId);
			
			ContactLocalServiceUtil.addContact(con);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-social-success");
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "add-social-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/myaccounteducator/socialnetwork.jsp");
	}
	
	public void serverResourse(ResourceRequest resourceRequest,
            ResourceResponse resourceResponse) throws IOException, PortletException {
		
		
	}
	Log _log = LogFactoryUtil.getLog(MyAccountEducator.class);
}
