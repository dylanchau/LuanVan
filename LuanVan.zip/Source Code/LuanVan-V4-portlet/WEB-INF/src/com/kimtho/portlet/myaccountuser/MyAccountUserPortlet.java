package com.kimtho.portlet.myaccountuser;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletSession;
import javax.portlet.ProcessAction;

import com.kimtho.portlet.ActionUtil;
import com.kimtho.portlet.WebKeysU;
import com.kimtho.portlet.listenerskillusers.ListenerSkillsUsers;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.Contact;
import com.liferay.portal.model.Phone;
import com.liferay.portal.model.User;
import com.liferay.portal.service.AddressLocalServiceUtil;
import com.liferay.portal.service.ContactLocalServiceUtil;
import com.liferay.portal.service.CountryServiceUtil;
import com.liferay.portal.service.PhoneLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.expando.model.ExpandoColumnConstants;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.EducationUsers;
import com.portlets.action.model.ExperienceUsers;
import com.portlets.action.model.UserObject;
import com.portlets.action.model.UserSkillLevel;
import com.portlets.action.model.impl.UserSkillLevelImpl;
import com.portlets.action.service.EducationUsersLocalServiceUtil;
import com.portlets.action.service.ExperienceUsersLocalServiceUtil;
import com.portlets.action.service.UserObjectLocalServiceUtil;
import com.portlets.action.service.UserSkillLevelLocalServiceUtil;

/**
 * Portlet implementation class MyAccountUserPortlet
 */
public class MyAccountUserPortlet extends MVCPortlet {
	@ProcessAction(name = "addEducationUsers")
	public void addEducationUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException {
		EducationUsers educationUsers = ActionUtil.educationUsersFromRequest(actionRequest);
		EducationUsersLocalServiceUtil.addEducationUsers(educationUsers);
		SessionMessages.add(actionRequest, "added-education-users"); 
	   _log.info("#################Added Education Users Successfully#########################");
	   actionResponse.setRenderParameter("jspPage", "/html/portlet/educationusers/view.jsp");
	}
	
	@ProcessAction(name = "deleteEducationUsers")
	public void deleteEducationUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long educationUsersId = ParamUtil.getLong(actionRequest, "educationUsersId");
		EducationUsersLocalServiceUtil.deleteEducationUsers(educationUsersId);
		SessionMessages.add(actionRequest, "deleted-education-users"); 
		_log.info("#################Education Users Deleted Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/educationusers/view.jsp");
	}
	
	@ProcessAction(name = "viewEducationUsers")
	public void viewEducationUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long educationUsersId = ParamUtil.getLong(actionRequest, "educationUsersId");
		EducationUsers educationUsers = EducationUsersLocalServiceUtil.getEducationUsers(educationUsersId);
		actionRequest.setAttribute(WebKeysU.EducationUsers_ENTRY, educationUsers);
		actionResponse.setRenderParameter("jspPage", "/html/portlet/educationusers/view_education_users.jsp");
	}
	
	@ProcessAction(name = "updateEducationUsers")
	public void updateEducationUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long educationUsersId = (Long) actionRequest.getPortletSession().getAttribute(WebKeysU.EducationUsersID,PortletSession.PORTLET_SCOPE);
		EducationUsers educationUsers = ActionUtil.educationUsersFromRequest(actionRequest);
		educationUsers.setEducationUsersId(educationUsersId);
		EducationUsersLocalServiceUtil.updateEducationUsers(educationUsers);
		SessionMessages.add(actionRequest, "updated-education-users"); 
		_log.info("#################Updated Education Users Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/educationusers/view.jsp");
		
	}
	
	@ProcessAction(name = "editEducationUsers")
	public void editEducationUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long educationUsersId = ParamUtil.getLong(actionRequest, "educationUsersId");
		EducationUsers educationUsers = EducationUsersLocalServiceUtil.getEducationUsers(educationUsersId);
		actionRequest.setAttribute(WebKeysU.EducationUsers, educationUsers); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/educationusers/edit_education_users.jsp");
		actionRequest.getPortletSession().setAttribute(WebKeysU.EducationUsersID, educationUsers.getEducationUsersId(),PortletSession.PORTLET_SCOPE);
			
	}
	@ProcessAction(name = "addExperienceUsers")
	public void addExperienceUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException {
		ExperienceUsers experienceUsers = ActionUtil.experienceUsersFromRequest(actionRequest);
		ExperienceUsersLocalServiceUtil.addExperienceUsers(experienceUsers);
		SessionMessages.add(actionRequest, "added-experience-users"); 
	   _log.info("#################Added Experience Users Successfully#########################");
	   actionResponse.setRenderParameter("jspPage", "/html/portlet/experienceusers/view.jsp");
	}
	
	@ProcessAction(name = "deleteExperienceUsers")
	public void deleteExperienceUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long experienceUsersId = ParamUtil.getLong(actionRequest, "experienceUsersId");
		ExperienceUsersLocalServiceUtil.deleteExperienceUsers(experienceUsersId);
		SessionMessages.add(actionRequest, "deleted-experience-users"); 
		_log.info("#################Experience Users Deleted Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/experienceusers/view.jsp");
	}
	
	@ProcessAction(name = "viewExperienceUsers")
	public void viewExperienceUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long experienceUsersId = ParamUtil.getLong(actionRequest, "experienceUsersId");
		ExperienceUsers experienceUsers = ExperienceUsersLocalServiceUtil.getExperienceUsers(experienceUsersId);
		actionRequest.setAttribute(WebKeysU.ExperienceUsers_ENTRY, experienceUsers);
		actionResponse.setRenderParameter("jspPage", "/html/portlet/experienceusers/view_experience_users.jsp");
	}
	
	@ProcessAction(name = "updateExperienceUsers")
	public void updateExperienceUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long experienceUsersId = (Long) actionRequest.getPortletSession().getAttribute(WebKeysU.ExperienceUsersID,PortletSession.PORTLET_SCOPE);
		ExperienceUsers experienceUsers = ActionUtil.experienceUsersFromRequest(actionRequest);
		experienceUsers.setExperienceUsersId(experienceUsersId);
		ExperienceUsersLocalServiceUtil.updateExperienceUsers(experienceUsers);
		SessionMessages.add(actionRequest, "updated-experience-users"); 
		_log.info("#################Updated Experience Users Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/experienceusers/view.jsp");		
	}	
	
	@ProcessAction(name = "editExperienceUsers")
	public void editExperienceUsers(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long experienceUsersId = ParamUtil.getLong(actionRequest, "experienceUsersId");
		ExperienceUsers experienceUsers = ExperienceUsersLocalServiceUtil.getExperienceUsers(experienceUsersId);
		actionRequest.setAttribute(WebKeysU.ExperienceUsers, experienceUsers); 
		actionResponse.setRenderParameter("jspPage", "/html/portlet/experienceusers/edit_experience_users.jsp");
		actionRequest.getPortletSession().setAttribute(WebKeysU.ExperienceUsersID, experienceUsers.getExperienceUsersId(),PortletSession.PORTLET_SCOPE);		
	}
	
	@ProcessAction(name = "addUserSkillLevel")
	public void addUserSkillLevel(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		UserSkillLevel userSkillLevel = ActionUtil.userSkillLevelFromRequest(actionRequest);
		List<UserSkillLevel> userSkillLevels = UserSkillLevelLocalServiceUtil.getUserSkillLevels(0, UserSkillLevelLocalServiceUtil.getUserSkillLevelsCount());
		int temp=0;
		for(UserSkillLevel us : userSkillLevels){
			if(us.getSkillId()==userSkillLevel.getSkillId() && us.getUserObjectId()==userSkillLevel.getUserObjectId()){
				temp=1;
			}
		}
		if(temp==0){
			UserSkillLevelLocalServiceUtil.addUserSkillLevel(userSkillLevel);
			//listener user
			ListenerSkillsUsers lku = new ListenerSkillsUsers();
			lku.addLinkUsers(userSkillLevel.getUserObjectId(), userSkillLevel.getSkillId());
			}
		SessionMessages.add(actionRequest, "added-skills_users"); 
	   _log.info("#################Added Skills Users Successfully#########################");
	   actionResponse.setRenderParameter("jspPage", "/html/portlet/skillusers/view.jsp");
	}

	@ProcessAction(name = "deleteUserSkillLevel")
	public void deleteUserSkillLevel(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long skillId = ParamUtil.getLong(actionRequest, "skillId");
		long usersObjectId = ParamUtil.getLong(actionRequest, "userObjectId");
		UserSkillLevel userSkillLevel = new UserSkillLevelImpl();
		userSkillLevel.setSkillId(skillId);
		userSkillLevel.setUserObjectId(usersObjectId);
		UserSkillLevelLocalServiceUtil.deleteUserSkillLevel(userSkillLevel.getPrimaryKey());
		
		//listener user
		ListenerSkillsUsers lku = new ListenerSkillsUsers();
		lku.deleteLinkUsers(userSkillLevel.getUserObjectId(), userSkillLevel.getSkillId());
		
		SessionMessages.add(actionRequest, "deleted-skills_Users"); 
		_log.info("#################Skills Users Deleted Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/skillusers/view.jsp");
	}
	
	@ProcessAction(name = "viewUserSkillLevel")
	public void viewUserSkillLevel(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long skillId = ParamUtil.getLong(actionRequest, "skillId");
		long userObjectId = ParamUtil.getLong(actionRequest, "userObjectId");
		UserSkillLevel userSkillLevel = new UserSkillLevelImpl();
		userSkillLevel.setSkillId(skillId);
		userSkillLevel.setUserObjectId(userObjectId);
		userSkillLevel = UserSkillLevelLocalServiceUtil.getUserSkillLevel(userSkillLevel.getPrimaryKey());	
		actionRequest.setAttribute(WebKeysU.UserSkillLevel_ENTRY, userSkillLevel);
		actionResponse.setRenderParameter("jspPage", "/html/portlet/skillusers/view_skills_users.jsp");
	}
	
	@ProcessAction(name = "updateDetail")
	public void updateDetail(ActionRequest actionRequest,ActionResponse actionResponse) 
			throws SystemException, PortalException {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		System.out.println(userId);
		User user = UserLocalServiceUtil.getUser(userId);
		user.setScreenName(ParamUtil.getString(actionRequest, "screenName"));
		user.setEmailAddress(ParamUtil.getString(actionRequest, "emailAddress"));
		user.setFirstName(ParamUtil.getString(actionRequest, "firstName"));
		user.setMiddleName(ParamUtil.getString(actionRequest, "middleName"));
		user.setLastName(ParamUtil.getString(actionRequest, "lastName"));
		user.setModifiedDate(new Date());
		UserLocalServiceUtil.updateUser(user);
		Contact contact = ContactLocalServiceUtil.getContact(user.getContactId());
		contact.setEmailAddress(ParamUtil.getString(actionRequest, "emailAddress"));
		contact.setFirstName(ParamUtil.getString(actionRequest, "firstName"));
		contact.setMiddleName(ParamUtil.getString(actionRequest, "middleName"));
		contact.setLastName(ParamUtil.getString(actionRequest, "lastName"));
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
		contact.setBirthday(ParamUtil.getDate(actionRequest, "birthday", df));
		contact.setMale(ParamUtil.getBoolean(actionRequest, "male"));
		contact.setModifiedDate(new Date());
		contact.setPrefixId(ParamUtil.getInteger(actionRequest, "prefixId"));
		contact.setSuffixId(ParamUtil.getInteger(actionRequest, "suffixId"));
		ContactLocalServiceUtil.updateContact(contact);
		
		//update userObject table
		UserObject userObject = UserObjectLocalServiceUtil.getUserObject(userId);
		userObject.setUserObjectName(ParamUtil.getString(actionRequest, "firstName"));
		userObject.setUserObjectGender(ParamUtil.getBoolean(actionRequest, "male"));
		userObject.setUserObjectBirthday(ParamUtil.getDate(actionRequest, "birthday", df));
		userObject.setUserObjectEmail(ParamUtil.getString(actionRequest, "emailAddress"));
		UserObjectLocalServiceUtil.updateUserObject(userObject);
	
		SessionMessages.add(actionRequest, "updated-user"); 
		_log.info("#################Updated User Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/myaccountuser/view.jsp");		
	}
	
	@ProcessAction(name = "updatePass")
	public void updatePass(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String password0 = ParamUtil.getString(actionRequest, "password0");
		String password1 = ParamUtil.getString(actionRequest, "password1");
		String reminderQueryQuestion = ParamUtil.getString(actionRequest, "reminderQueryQuestion");
		String reminderQueryAnswer = ParamUtil.getString(actionRequest, "reminderQueryAnswer");
		User user = UserLocalServiceUtil.getUser(userId);
		System.out.println(userId+"----"+password0+"----"+password1+"----"+user.getPassword());
		if(password0.equals(password1)){
			SessionMessages.add(actionRequest, "updated-same"); 
		} else {
			UserLocalServiceUtil.updatePassword(userId, password1, password1, false);
			UserLocalServiceUtil.updateReminderQuery(userId, reminderQueryQuestion, reminderQueryAnswer);
			SessionMessages.add(actionRequest, "updated-pass"); 
			
			_log.info("#################Updated Pass Successfully#########################");
			}	
		actionResponse.setRenderParameter("jspPage", "/html/portlet/myaccountuser/password.jsp");		
	}
	
	@ProcessAction(name = "updateSocial")
	public void updateSocial(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long contactId = ParamUtil.getLong(actionRequest, "contactId");
		String facebookSn = ParamUtil.getString(actionRequest, "facebookSn");
		String twitterSn = ParamUtil.getString(actionRequest, "twitterSn");
		Contact contact = ContactLocalServiceUtil.getContact(contactId);
		contact.setFacebookSn(facebookSn);
		contact.setTwitterSn(twitterSn);
		ContactLocalServiceUtil.updateContact(contact);
		SessionMessages.add(actionRequest, "updated-pass"); 		
		_log.info("#################Updated Pass Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/myaccountuser/socialnetwork.jsp");		
	}
	
	@ProcessAction(name = "updateInterest")
	public void updateInterest(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String interest = (String) PortalUtil.getExpandoValue(actionRequest, "ExpandoAttribute--" + "interest" + "--", 
				ExpandoColumnConstants.STRING, ExpandoColumnConstants.PROPERTY_DISPLAY_TYPE_TEXT_BOX);
		User user = UserLocalServiceUtil.getUser(userId);
		System.out.println(interest);
		user.getExpandoBridge().setAttribute("interest", interest);
		SessionMessages.add(actionRequest, "updated-pass"); 
		_log.info("#################Updated Pass Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/myaccountuser/interest.jsp");		
	}
	@ProcessAction(name = "updateThongtin")
	public void updateThongtin(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String thongtin = (String) PortalUtil.getExpandoValue(actionRequest, "ExpandoAttribute--" + "thongtin" + "--", 
				ExpandoColumnConstants.STRING, ExpandoColumnConstants.PROPERTY_DISPLAY_TYPE_TEXT_BOX);
		User user = UserLocalServiceUtil.getUser(userId);
		System.out.println(thongtin);
		user.getExpandoBridge().setAttribute("thongtin", thongtin);
		SessionMessages.add(actionRequest, "updated-pass"); 
		_log.info("#################Updated Infomation Successfully#########################");
		actionResponse.setRenderParameter("jspPage", "/html/portlet/myaccountuser/thongtin.jsp");		
	}
	
	@ProcessAction(name = "addAddress")
	public void addaddress(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String street = ParamUtil.getString(actionRequest, "street");
		String city = ParamUtil.getString(actionRequest, "city");
		long countryId = ParamUtil.getLong(actionRequest, "countryId");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		String zip = ParamUtil.getString(actionRequest, "zip");
		
		try {
			Address address = null;
			address = AddressLocalServiceUtil.createAddress(CounterLocalServiceUtil.increment());
			
			address.setUserId(userId);
			address.setCity(city);
			address.setCountryId(countryId);
			address.setStreet1(street);
			address.setTypeId(typeId);
			address.setZip(zip);
			
			AddressLocalServiceUtil.addAddress(address);
			
			UserObject userObject = UserObjectLocalServiceUtil.getUserObject(userId);
			userObject.setUserObjectAddress(street + ", " + city + ", " + CountryServiceUtil.getCountry(countryId).getName());
			UserObjectLocalServiceUtil.updateUserObject(userObject);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-address-success");
			
		} catch(Exception e) {
			e.printStackTrace();
			SessionErrors.add(actionRequest.getPortletSession(), "add-address-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		actionResponse.setRenderParameter("jspPage", "/html/portlet/myaccountuser/addresses.jsp");		
	}
	@ProcessAction(name = "updateAddress")
	public void updateAddress(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		long addressId = ParamUtil.getLong(actionRequest, "addressId");
		String street1 = ParamUtil.getString(actionRequest, "street1");
		String city = ParamUtil.getString(actionRequest, "city");
		long countryId = ParamUtil.getLong(actionRequest, "countryId");
		String zip = ParamUtil.getString(actionRequest, "zip");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		try {
			
			Address address = AddressLocalServiceUtil.getAddress(addressId); 
			address.setStreet1(street1);
			address.setCity(city);
			address.setCountryId(countryId);
			address.setZip(zip);
			address.setTypeId(typeId);
			AddressLocalServiceUtil.updateAddress(address);
			
			UserObject userObject = UserObjectLocalServiceUtil.getUserObject(userId);
			userObject.setUserObjectAddress(street1 + ", " + city + ", " + CountryServiceUtil.getCountry(countryId).getName());
			UserObjectLocalServiceUtil.updateUserObject(userObject);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-address-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-address-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		actionResponse.setRenderParameter("jspPage", "/html/portlet/myaccountuser/addresses.jsp");
	}
	public void updatePhoneNumber(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long phoneId = ParamUtil.getLong(actionRequest, "phoneId");
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String number_ = ParamUtil.getString(actionRequest, "number");
		String extension = ParamUtil.getString(actionRequest, "extension");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		try {
			
			Phone phone = PhoneLocalServiceUtil.getPhone(phoneId);
			
			phone.setNumber(number_);
			phone.setExtension(extension);
			phone.setTypeId(typeId);
			
			PhoneLocalServiceUtil.updatePhone(phone);
			
			UserObject userObject = UserObjectLocalServiceUtil.getUserObject(userId);
			userObject.setUserObjectPhone(number_);
			UserObjectLocalServiceUtil.updateUserObject(userObject);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-phone-success");
		} catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-phone-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/portlet/myaccountuser/phonenumbers.jsp");
	}
	
	public void addPhoneNumber(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String number_ = ParamUtil.getString(actionRequest, "number_");
		String extension = ParamUtil.getString(actionRequest, "extension");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		try {
			
			Phone phone = PhoneLocalServiceUtil.createPhone(CounterLocalServiceUtil.increment());
			
			phone.setNumber(number_);
			phone.setExtension(extension);
			phone.setTypeId(typeId);
			phone.setUserId(userId);
			
			PhoneLocalServiceUtil.addPhone(phone);
			
			//update userObject table
			UserObject userObject = UserObjectLocalServiceUtil.getUserObject(userId);
			userObject.setUserObjectPhone(number_);
			UserObjectLocalServiceUtil.updateUserObject(userObject);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-phone-success");
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "add-phone-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		actionResponse.setRenderParameter("mvcPath", "/html/portlet/myaccountuser/phonenumbers.jsp");
	}
	
	private Log _log = LogFactoryUtil.getLog(MyAccountUserPortlet.class.getName());

}
