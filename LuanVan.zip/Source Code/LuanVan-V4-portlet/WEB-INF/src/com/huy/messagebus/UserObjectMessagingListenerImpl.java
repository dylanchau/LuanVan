package com.huy.messagebus;

import java.util.List;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.notifications.ChannelHubManagerUtil;
import com.liferay.portal.kernel.notifications.NotificationEvent;
import com.liferay.portal.kernel.notifications.NotificationEventFactoryUtil;
import com.portlets.action.model.UserObject;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.service.UserObjectLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;




public class UserObjectMessagingListenerImpl implements MessageListener {

	public void receive(Message message) 
			throws MessageListenerException {
		
		try {
			doReceive(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void doReceive(Message message) throws Exception {
		
		String payLoad = (String) message.getPayload();
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject(payLoad);
		long id = jsonObject.getLong("id");										
		String url = jsonObject.getString("url");
		String skillsList = jsonObject.getString("skillIds"); 
		long companyId = jsonObject.getLong("companyId");
		long employerId = jsonObject.getLong("employerId");
		
		System.out.println(id + "\n" + companyId + "\n" + employerId);
		
		String[] skillList = skillsList.split(" ");
		
		System.out.println(url + skillList);
		
		long[] ids = new long[skillList.length];
		for(int i = 0; i < skillList.length; i++) {
			ids[i] = Long.parseLong(skillList[i]);
			System.out.println(ids[i]);
		}
		
		try {
			
			//get users whose skills match with the skills of class that employer public
			int userCount = UserObjectLocalServiceUtil.getUserObjectsCount();
			List<UserObject> users = UserObjectLocalServiceUtil.getUserObjects(0, userCount);
			for(UserObject user : users) {
				boolean flag = compare(user.getUserObjectId(), ids);
				System.out.println(flag);
				if(flag) {
					
					NotificationEvent notificationEvent = NotificationEventFactoryUtil
							.createNotificationEvent(System.currentTimeMillis(), UserNotificationHandler.PORTLET_ID, jsonObject);
					
					notificationEvent.setDeliveryRequired(0);
					
					ChannelHubManagerUtil.sendNotificationEvent(companyId,
							user.getUserObjectId(), notificationEvent);
					
				}
			}
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}
	
	private boolean compare(long userId, long[] skills) {
		
		boolean flag = false;
		boolean breakLoop = false;
		
		try {
			
			List<UserSkillListener> userSkills = UserSkillListenerLocalServiceUtil.getByUserId(userId);
			
			for(int i = 0; i < userSkills.size(); i++) {
				for(int j = 0; j < skills.length; j++) {
					_log.info(userSkills.get(i).getUserObjectId());
					if(userSkills.get(i).getSkillId() == skills[j]) {
						flag = breakLoop = true; 
						break;
					} else {
						j++;
					}
				}
				if(breakLoop) 
					break;
			}
			
			
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
		
		return flag;
	}

	Log _log = LogFactoryUtil.getLog(UserObjectMessagingListenerImpl.class);
}
