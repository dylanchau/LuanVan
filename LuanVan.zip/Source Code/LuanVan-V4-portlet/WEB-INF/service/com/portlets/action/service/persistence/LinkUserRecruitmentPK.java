/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;

import java.io.Serializable;

/**
 * @author Computer
 * @generated
 */
public class LinkUserRecruitmentPK implements Comparable<LinkUserRecruitmentPK>,
	Serializable {
	public long recruitmentId;
	public long userObjectId;

	public LinkUserRecruitmentPK() {
	}

	public LinkUserRecruitmentPK(long recruitmentId, long userObjectId) {
		this.recruitmentId = recruitmentId;
		this.userObjectId = userObjectId;
	}

	public long getRecruitmentId() {
		return recruitmentId;
	}

	public void setRecruitmentId(long recruitmentId) {
		this.recruitmentId = recruitmentId;
	}

	public long getUserObjectId() {
		return userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		this.userObjectId = userObjectId;
	}

	@Override
	public int compareTo(LinkUserRecruitmentPK pk) {
		if (pk == null) {
			return -1;
		}

		int value = 0;

		if (recruitmentId < pk.recruitmentId) {
			value = -1;
		}
		else if (recruitmentId > pk.recruitmentId) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		if (userObjectId < pk.userObjectId) {
			value = -1;
		}
		else if (userObjectId > pk.userObjectId) {
			value = 1;
		}
		else {
			value = 0;
		}

		if (value != 0) {
			return value;
		}

		return 0;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LinkUserRecruitmentPK)) {
			return false;
		}

		LinkUserRecruitmentPK pk = (LinkUserRecruitmentPK)obj;

		if ((recruitmentId == pk.recruitmentId) &&
				(userObjectId == pk.userObjectId)) {
			return true;
		}
		else {
			return false;
		}
	}

	@Override
	public int hashCode() {
		return (String.valueOf(recruitmentId) + String.valueOf(userObjectId)).hashCode();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(10);

		sb.append(StringPool.OPEN_CURLY_BRACE);

		sb.append("recruitmentId");
		sb.append(StringPool.EQUAL);
		sb.append(recruitmentId);

		sb.append(StringPool.COMMA);
		sb.append(StringPool.SPACE);
		sb.append("userObjectId");
		sb.append(StringPool.EQUAL);
		sb.append(userObjectId);

		sb.append(StringPool.CLOSE_CURLY_BRACE);

		return sb.toString();
	}
}