/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.CourseServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.CourseServiceSoap
 * @generated
 */
public class CourseSoap implements Serializable {
	public static CourseSoap toSoapModel(Course model) {
		CourseSoap soapModel = new CourseSoap();

		soapModel.setCourseId(model.getCourseId());
		soapModel.setCourseName(model.getCourseName());
		soapModel.setCourseStudentNo(model.getCourseStudentNo());
		soapModel.setCourseStartDate(model.getCourseStartDate());
		soapModel.setCourseEnrollStartDate(model.getCourseEnrollStartDate());
		soapModel.setCourseSchoolDay(model.getCourseSchoolDay());
		soapModel.setCourseEnrollDeadLine(model.getCourseEnrollDeadLine());
		soapModel.setStatesId(model.getStatesId());
		soapModel.setTrainingProgramId(model.getTrainingProgramId());
		soapModel.setEducatorId(model.getEducatorId());

		return soapModel;
	}

	public static CourseSoap[] toSoapModels(Course[] models) {
		CourseSoap[] soapModels = new CourseSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static CourseSoap[][] toSoapModels(Course[][] models) {
		CourseSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new CourseSoap[models.length][models[0].length];
		}
		else {
			soapModels = new CourseSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static CourseSoap[] toSoapModels(List<Course> models) {
		List<CourseSoap> soapModels = new ArrayList<CourseSoap>(models.size());

		for (Course model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new CourseSoap[soapModels.size()]);
	}

	public CourseSoap() {
	}

	public long getPrimaryKey() {
		return _courseId;
	}

	public void setPrimaryKey(long pk) {
		setCourseId(pk);
	}

	public long getCourseId() {
		return _courseId;
	}

	public void setCourseId(long courseId) {
		_courseId = courseId;
	}

	public String getCourseName() {
		return _courseName;
	}

	public void setCourseName(String courseName) {
		_courseName = courseName;
	}

	public int getCourseStudentNo() {
		return _courseStudentNo;
	}

	public void setCourseStudentNo(int courseStudentNo) {
		_courseStudentNo = courseStudentNo;
	}

	public Date getCourseStartDate() {
		return _courseStartDate;
	}

	public void setCourseStartDate(Date courseStartDate) {
		_courseStartDate = courseStartDate;
	}

	public Date getCourseEnrollStartDate() {
		return _courseEnrollStartDate;
	}

	public void setCourseEnrollStartDate(Date courseEnrollStartDate) {
		_courseEnrollStartDate = courseEnrollStartDate;
	}

	public String getCourseSchoolDay() {
		return _courseSchoolDay;
	}

	public void setCourseSchoolDay(String courseSchoolDay) {
		_courseSchoolDay = courseSchoolDay;
	}

	public Date getCourseEnrollDeadLine() {
		return _courseEnrollDeadLine;
	}

	public void setCourseEnrollDeadLine(Date courseEnrollDeadLine) {
		_courseEnrollDeadLine = courseEnrollDeadLine;
	}

	public long getStatesId() {
		return _statesId;
	}

	public void setStatesId(long statesId) {
		_statesId = statesId;
	}

	public long getTrainingProgramId() {
		return _trainingProgramId;
	}

	public void setTrainingProgramId(long trainingProgramId) {
		_trainingProgramId = trainingProgramId;
	}

	public long getEducatorId() {
		return _educatorId;
	}

	public void setEducatorId(long educatorId) {
		_educatorId = educatorId;
	}

	private long _courseId;
	private String _courseName;
	private int _courseStudentNo;
	private Date _courseStartDate;
	private Date _courseEnrollStartDate;
	private String _courseSchoolDay;
	private Date _courseEnrollDeadLine;
	private long _statesId;
	private long _trainingProgramId;
	private long _educatorId;
}