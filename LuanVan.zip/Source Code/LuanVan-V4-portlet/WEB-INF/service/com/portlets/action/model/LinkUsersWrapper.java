/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link LinkUsers}.
 * </p>
 *
 * @author Computer
 * @see LinkUsers
 * @generated
 */
public class LinkUsersWrapper implements LinkUsers, ModelWrapper<LinkUsers> {
	public LinkUsersWrapper(LinkUsers linkUsers) {
		_linkUsers = linkUsers;
	}

	@Override
	public Class<?> getModelClass() {
		return LinkUsers.class;
	}

	@Override
	public String getModelClassName() {
		return LinkUsers.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userIdA", getUserIdA());
		attributes.put("userIdB", getUserIdB());
		attributes.put("linkUsersNumber", getLinkUsersNumber());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userIdA = (Long)attributes.get("userIdA");

		if (userIdA != null) {
			setUserIdA(userIdA);
		}

		Long userIdB = (Long)attributes.get("userIdB");

		if (userIdB != null) {
			setUserIdB(userIdB);
		}

		Integer linkUsersNumber = (Integer)attributes.get("linkUsersNumber");

		if (linkUsersNumber != null) {
			setLinkUsersNumber(linkUsersNumber);
		}
	}

	/**
	* Returns the primary key of this link users.
	*
	* @return the primary key of this link users
	*/
	@Override
	public com.portlets.action.service.persistence.LinkUsersPK getPrimaryKey() {
		return _linkUsers.getPrimaryKey();
	}

	/**
	* Sets the primary key of this link users.
	*
	* @param primaryKey the primary key of this link users
	*/
	@Override
	public void setPrimaryKey(
		com.portlets.action.service.persistence.LinkUsersPK primaryKey) {
		_linkUsers.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the user ID a of this link users.
	*
	* @return the user ID a of this link users
	*/
	@Override
	public long getUserIdA() {
		return _linkUsers.getUserIdA();
	}

	/**
	* Sets the user ID a of this link users.
	*
	* @param userIdA the user ID a of this link users
	*/
	@Override
	public void setUserIdA(long userIdA) {
		_linkUsers.setUserIdA(userIdA);
	}

	/**
	* Returns the user ID b of this link users.
	*
	* @return the user ID b of this link users
	*/
	@Override
	public long getUserIdB() {
		return _linkUsers.getUserIdB();
	}

	/**
	* Sets the user ID b of this link users.
	*
	* @param userIdB the user ID b of this link users
	*/
	@Override
	public void setUserIdB(long userIdB) {
		_linkUsers.setUserIdB(userIdB);
	}

	/**
	* Returns the link users number of this link users.
	*
	* @return the link users number of this link users
	*/
	@Override
	public int getLinkUsersNumber() {
		return _linkUsers.getLinkUsersNumber();
	}

	/**
	* Sets the link users number of this link users.
	*
	* @param linkUsersNumber the link users number of this link users
	*/
	@Override
	public void setLinkUsersNumber(int linkUsersNumber) {
		_linkUsers.setLinkUsersNumber(linkUsersNumber);
	}

	@Override
	public boolean isNew() {
		return _linkUsers.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_linkUsers.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _linkUsers.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_linkUsers.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _linkUsers.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _linkUsers.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_linkUsers.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _linkUsers.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_linkUsers.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_linkUsers.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_linkUsers.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new LinkUsersWrapper((LinkUsers)_linkUsers.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.LinkUsers linkUsers) {
		return _linkUsers.compareTo(linkUsers);
	}

	@Override
	public int hashCode() {
		return _linkUsers.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.LinkUsers> toCacheModel() {
		return _linkUsers.toCacheModel();
	}

	@Override
	public com.portlets.action.model.LinkUsers toEscapedModel() {
		return new LinkUsersWrapper(_linkUsers.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.LinkUsers toUnescapedModel() {
		return new LinkUsersWrapper(_linkUsers.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _linkUsers.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _linkUsers.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_linkUsers.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LinkUsersWrapper)) {
			return false;
		}

		LinkUsersWrapper linkUsersWrapper = (LinkUsersWrapper)obj;

		if (Validator.equals(_linkUsers, linkUsersWrapper._linkUsers)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public LinkUsers getWrappedLinkUsers() {
		return _linkUsers;
	}

	@Override
	public LinkUsers getWrappedModel() {
		return _linkUsers;
	}

	@Override
	public void resetOriginalValues() {
		_linkUsers.resetOriginalValues();
	}

	private LinkUsers _linkUsers;
}