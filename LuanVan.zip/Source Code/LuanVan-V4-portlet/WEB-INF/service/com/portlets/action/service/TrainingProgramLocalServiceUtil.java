/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service;

import com.liferay.portal.kernel.bean.PortletBeanLocatorUtil;
import com.liferay.portal.kernel.util.ReferenceRegistry;
import com.liferay.portal.service.InvokableLocalService;

/**
 * Provides the local service utility for TrainingProgram. This utility wraps
 * {@link com.portlets.action.service.impl.TrainingProgramLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Computer
 * @see TrainingProgramLocalService
 * @see com.portlets.action.service.base.TrainingProgramLocalServiceBaseImpl
 * @see com.portlets.action.service.impl.TrainingProgramLocalServiceImpl
 * @generated
 */
public class TrainingProgramLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link com.portlets.action.service.impl.TrainingProgramLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the training program to the database. Also notifies the appropriate model listeners.
	*
	* @param trainingProgram the training program
	* @return the training program that was added
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.TrainingProgram addTrainingProgram(
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().addTrainingProgram(trainingProgram);
	}

	/**
	* Creates a new training program with the primary key. Does not add the training program to the database.
	*
	* @param trainingProgramId the primary key for the new training program
	* @return the new training program
	*/
	public static com.portlets.action.model.TrainingProgram createTrainingProgram(
		long trainingProgramId) {
		return getService().createTrainingProgram(trainingProgramId);
	}

	/**
	* Deletes the training program with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param trainingProgramId the primary key of the training program
	* @return the training program that was removed
	* @throws PortalException if a training program with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.TrainingProgram deleteTrainingProgram(
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteTrainingProgram(trainingProgramId);
	}

	/**
	* Deletes the training program from the database. Also notifies the appropriate model listeners.
	*
	* @param trainingProgram the training program
	* @return the training program that was removed
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.TrainingProgram deleteTrainingProgram(
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().deleteTrainingProgram(trainingProgram);
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	* @throws SystemException if a system exception occurred
	*/
	@SuppressWarnings("rawtypes")
	public static java.util.List dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows that match the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows that match the dynamic query
	* @throws SystemException if a system exception occurred
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static com.portlets.action.model.TrainingProgram fetchTrainingProgram(
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().fetchTrainingProgram(trainingProgramId);
	}

	/**
	* Returns the training program with the primary key.
	*
	* @param trainingProgramId the primary key of the training program
	* @return the training program
	* @throws PortalException if a training program with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.TrainingProgram getTrainingProgram(
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getTrainingProgram(trainingProgramId);
	}

	public static com.liferay.portal.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException,
			com.liferay.portal.kernel.exception.SystemException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns a range of all the training programs.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.TrainingProgramModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of training programs
	* @param end the upper bound of the range of training programs (not inclusive)
	* @return the range of training programs
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.TrainingProgram> getTrainingPrograms(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getTrainingPrograms(start, end);
	}

	/**
	* Returns the number of training programs.
	*
	* @return the number of training programs
	* @throws SystemException if a system exception occurred
	*/
	public static int getTrainingProgramsCount()
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getTrainingProgramsCount();
	}

	/**
	* Updates the training program in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param trainingProgram the training program
	* @return the training program that was updated
	* @throws SystemException if a system exception occurred
	*/
	public static com.portlets.action.model.TrainingProgram updateTrainingProgram(
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().updateTrainingProgram(trainingProgram);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkillTrainingProgram(long skillId,
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addSkillTrainingProgram(skillId, trainingProgramId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkillTrainingProgram(long skillId,
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addSkillTrainingProgram(skillId, trainingProgram);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkillTrainingPrograms(long skillId,
		long[] trainingProgramIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addSkillTrainingPrograms(skillId, trainingProgramIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void addSkillTrainingPrograms(long skillId,
		java.util.List<com.portlets.action.model.TrainingProgram> TrainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().addSkillTrainingPrograms(skillId, TrainingPrograms);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void clearSkillTrainingPrograms(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().clearSkillTrainingPrograms(skillId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteSkillTrainingProgram(long skillId,
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteSkillTrainingProgram(skillId, trainingProgramId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteSkillTrainingProgram(long skillId,
		com.portlets.action.model.TrainingProgram trainingProgram)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteSkillTrainingProgram(skillId, trainingProgram);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteSkillTrainingPrograms(long skillId,
		long[] trainingProgramIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteSkillTrainingPrograms(skillId, trainingProgramIds);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void deleteSkillTrainingPrograms(long skillId,
		java.util.List<com.portlets.action.model.TrainingProgram> TrainingPrograms)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().deleteSkillTrainingPrograms(skillId, TrainingPrograms);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.TrainingProgram> getSkillTrainingPrograms(
		long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSkillTrainingPrograms(skillId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.TrainingProgram> getSkillTrainingPrograms(
		long skillId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSkillTrainingPrograms(skillId, start, end);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static java.util.List<com.portlets.action.model.TrainingProgram> getSkillTrainingPrograms(
		long skillId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService()
				   .getSkillTrainingPrograms(skillId, start, end,
			orderByComparator);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static int getSkillTrainingProgramsCount(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().getSkillTrainingProgramsCount(skillId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasSkillTrainingProgram(long skillId,
		long trainingProgramId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasSkillTrainingProgram(skillId, trainingProgramId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static boolean hasSkillTrainingPrograms(long skillId)
		throws com.liferay.portal.kernel.exception.SystemException {
		return getService().hasSkillTrainingPrograms(skillId);
	}

	/**
	* @throws SystemException if a system exception occurred
	*/
	public static void setSkillTrainingPrograms(long skillId,
		long[] trainingProgramIds)
		throws com.liferay.portal.kernel.exception.SystemException {
		getService().setSkillTrainingPrograms(skillId, trainingProgramIds);
	}

	/**
	* Returns the Spring bean ID for this bean.
	*
	* @return the Spring bean ID for this bean
	*/
	public static java.lang.String getBeanIdentifier() {
		return getService().getBeanIdentifier();
	}

	/**
	* Sets the Spring bean ID for this bean.
	*
	* @param beanIdentifier the Spring bean ID for this bean
	*/
	public static void setBeanIdentifier(java.lang.String beanIdentifier) {
		getService().setBeanIdentifier(beanIdentifier);
	}

	public static java.lang.Object invokeMethod(java.lang.String name,
		java.lang.String[] parameterTypes, java.lang.Object[] arguments)
		throws java.lang.Throwable {
		return getService().invokeMethod(name, parameterTypes, arguments);
	}

	public static java.util.List<com.portlets.action.model.TrainingProgram> getByEducatorId(
		java.lang.Long educatorId) {
		return getService().getByEducatorId(educatorId);
	}

	public static com.portlets.action.model.TrainingProgram addTrainingPro(
		java.lang.String name, java.lang.String period,
		java.lang.String purpose, double fee, java.lang.String items,
		java.lang.String description, java.lang.String diploma, long userId)
		throws com.liferay.portal.kernel.exception.SystemException,
			javax.portlet.PortletException {
		return getService()
				   .addTrainingPro(name, period, purpose, fee, items,
			description, diploma, userId);
	}

	public static void clearService() {
		_service = null;
	}

	public static TrainingProgramLocalService getService() {
		if (_service == null) {
			InvokableLocalService invokableLocalService = (InvokableLocalService)PortletBeanLocatorUtil.locate(ClpSerializer.getServletContextName(),
					TrainingProgramLocalService.class.getName());

			if (invokableLocalService instanceof TrainingProgramLocalService) {
				_service = (TrainingProgramLocalService)invokableLocalService;
			}
			else {
				_service = new TrainingProgramLocalServiceClp(invokableLocalService);
			}

			ReferenceRegistry.registerReference(TrainingProgramLocalServiceUtil.class,
				"_service");
		}

		return _service;
	}

	/**
	 * @deprecated As of 6.2.0
	 */
	public void setService(TrainingProgramLocalService service) {
	}

	private static TrainingProgramLocalService _service;
}