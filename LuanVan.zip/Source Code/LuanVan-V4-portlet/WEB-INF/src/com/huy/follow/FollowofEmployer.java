package com.huy.follow;

import java.io.File;
import java.io.IOException;

import javax.mail.internet.InternetAddress;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadRequest;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class FollowofEmployer
 */
public class FollowofEmployer extends MVCPortlet {
	public void sendMail(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			
	             
	             String From= "liferay.luanvan@gmail.com";
	             long userId = ParamUtil.getLong(actionRequest,"To");
	             String To = UserLocalServiceUtil.getUser(userId).getEmailAddress();
	             String Subject = ParamUtil.getString(actionRequest, "Subject");
	             String body = ParamUtil.getString(actionRequest, "body");
	             
	             InternetAddress From1 = new InternetAddress(From);
	             InternetAddress To1 = new InternetAddress(To);
	             
	             
	             //UploadRequest uploadRequest = PortalUtil.getUploadPortletRequest(actionRequest);
	             //File file = uploadRequest.getFile("file");
	             //String fileName = file.getName();
	             
	             try {
	            	 	MailMessage mailMessage =new MailMessage(); 

	                    mailMessage.setFrom(From1);
	                    mailMessage.setTo(To1);
	               
	                    mailMessage.setSubject(Subject);
	                    mailMessage.setBody(body);
	                    mailMessage.setHTMLFormat(true);
	                    
	                    //mailMessage.addFileAttachment(file, fileName); 
	                    
	                    MailServiceUtil.sendEmail(mailMessage);
	                    System.out.println("mail is sent");
	                    SessionMessages.add(actionRequest.getPortletSession(),"mail-send-success");
	                    
	             } catch (Exception e) {
						e.printStackTrace();
					}
	             
			} catch (Exception e) {
					e.printStackTrace();
				}
			}

}
