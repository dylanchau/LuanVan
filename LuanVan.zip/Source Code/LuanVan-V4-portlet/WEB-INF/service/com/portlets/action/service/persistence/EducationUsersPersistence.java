/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.portlets.action.model.EducationUsers;

/**
 * The persistence interface for the education users service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see EducationUsersPersistenceImpl
 * @see EducationUsersUtil
 * @generated
 */
public interface EducationUsersPersistence extends BasePersistence<EducationUsers> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EducationUsersUtil} to access the education users persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns all the education userses where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @return the matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findByeducationUsersId(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the education userses where educationUsersId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educationUsersId the education users ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @return the range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findByeducationUsersId(
		long educationUsersId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the education userses where educationUsersId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educationUsersId the education users ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findByeducationUsersId(
		long educationUsersId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers findByeducationUsersId_First(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException;

	/**
	* Returns the first education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers fetchByeducationUsersId_First(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers findByeducationUsersId_Last(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException;

	/**
	* Returns the last education users in the ordered set where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers fetchByeducationUsersId_Last(
		long educationUsersId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the education userses where educationUsersId = &#63; from the database.
	*
	* @param educationUsersId the education users ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByeducationUsersId(long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of education userses where educationUsersId = &#63;.
	*
	* @param educationUsersId the education users ID
	* @return the number of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public int countByeducationUsersId(long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the education userses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findByuserObjectId(
		long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the education userses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @return the range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findByuserObjectId(
		long userObjectId, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the education userses where userObjectId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param userObjectId the user object ID
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findByuserObjectId(
		long userObjectId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers findByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException;

	/**
	* Returns the first education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers fetchByuserObjectId_First(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers findByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException;

	/**
	* Returns the last education users in the ordered set where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching education users, or <code>null</code> if a matching education users could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers fetchByuserObjectId_Last(
		long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the education userses before and after the current education users in the ordered set where userObjectId = &#63;.
	*
	* @param educationUsersId the primary key of the current education users
	* @param userObjectId the user object ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers[] findByuserObjectId_PrevAndNext(
		long educationUsersId, long userObjectId,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException;

	/**
	* Removes all the education userses where userObjectId = &#63; from the database.
	*
	* @param userObjectId the user object ID
	* @throws SystemException if a system exception occurred
	*/
	public void removeByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of education userses where userObjectId = &#63;.
	*
	* @param userObjectId the user object ID
	* @return the number of matching education userses
	* @throws SystemException if a system exception occurred
	*/
	public int countByuserObjectId(long userObjectId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the education users in the entity cache if it is enabled.
	*
	* @param educationUsers the education users
	*/
	public void cacheResult(
		com.portlets.action.model.EducationUsers educationUsers);

	/**
	* Caches the education userses in the entity cache if it is enabled.
	*
	* @param educationUserses the education userses
	*/
	public void cacheResult(
		java.util.List<com.portlets.action.model.EducationUsers> educationUserses);

	/**
	* Creates a new education users with the primary key. Does not add the education users to the database.
	*
	* @param educationUsersId the primary key for the new education users
	* @return the new education users
	*/
	public com.portlets.action.model.EducationUsers create(
		long educationUsersId);

	/**
	* Removes the education users with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param educationUsersId the primary key of the education users
	* @return the education users that was removed
	* @throws com.portlets.action.NoSuchEducationUsersException if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers remove(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException;

	public com.portlets.action.model.EducationUsers updateImpl(
		com.portlets.action.model.EducationUsers educationUsers)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the education users with the primary key or throws a {@link com.portlets.action.NoSuchEducationUsersException} if it could not be found.
	*
	* @param educationUsersId the primary key of the education users
	* @return the education users
	* @throws com.portlets.action.NoSuchEducationUsersException if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers findByPrimaryKey(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducationUsersException;

	/**
	* Returns the education users with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param educationUsersId the primary key of the education users
	* @return the education users, or <code>null</code> if a education users with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.EducationUsers fetchByPrimaryKey(
		long educationUsersId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the education userses.
	*
	* @return the education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the education userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @return the range of education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the education userses.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducationUsersModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of education userses
	* @param end the upper bound of the range of education userses (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of education userses
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.EducationUsers> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the education userses from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of education userses.
	*
	* @return the number of education userses
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;
}