/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.TrainingProgramServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.TrainingProgramServiceSoap
 * @generated
 */
public class TrainingProgramSoap implements Serializable {
	public static TrainingProgramSoap toSoapModel(TrainingProgram model) {
		TrainingProgramSoap soapModel = new TrainingProgramSoap();

		soapModel.setTrainingProgramId(model.getTrainingProgramId());
		soapModel.setTrainingProgramName(model.getTrainingProgramName());
		soapModel.setTrainingProgramPeriod(model.getTrainingProgramPeriod());
		soapModel.setTrainingProgramPurpose(model.getTrainingProgramPurpose());
		soapModel.setTrainingProgramDiploma(model.getTrainingProgramDiploma());
		soapModel.setTrainingProgramFee(model.getTrainingProgramFee());
		soapModel.setTrainingProgramItems(model.getTrainingProgramItems());
		soapModel.setTrainingProgramContent(model.getTrainingProgramContent());
		soapModel.setTrainingProgramDescription(model.getTrainingProgramDescription());
		soapModel.setEducatorId(model.getEducatorId());

		return soapModel;
	}

	public static TrainingProgramSoap[] toSoapModels(TrainingProgram[] models) {
		TrainingProgramSoap[] soapModels = new TrainingProgramSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static TrainingProgramSoap[][] toSoapModels(
		TrainingProgram[][] models) {
		TrainingProgramSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new TrainingProgramSoap[models.length][models[0].length];
		}
		else {
			soapModels = new TrainingProgramSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static TrainingProgramSoap[] toSoapModels(
		List<TrainingProgram> models) {
		List<TrainingProgramSoap> soapModels = new ArrayList<TrainingProgramSoap>(models.size());

		for (TrainingProgram model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new TrainingProgramSoap[soapModels.size()]);
	}

	public TrainingProgramSoap() {
	}

	public long getPrimaryKey() {
		return _trainingProgramId;
	}

	public void setPrimaryKey(long pk) {
		setTrainingProgramId(pk);
	}

	public long getTrainingProgramId() {
		return _trainingProgramId;
	}

	public void setTrainingProgramId(long trainingProgramId) {
		_trainingProgramId = trainingProgramId;
	}

	public String getTrainingProgramName() {
		return _trainingProgramName;
	}

	public void setTrainingProgramName(String trainingProgramName) {
		_trainingProgramName = trainingProgramName;
	}

	public String getTrainingProgramPeriod() {
		return _trainingProgramPeriod;
	}

	public void setTrainingProgramPeriod(String trainingProgramPeriod) {
		_trainingProgramPeriod = trainingProgramPeriod;
	}

	public String getTrainingProgramPurpose() {
		return _trainingProgramPurpose;
	}

	public void setTrainingProgramPurpose(String trainingProgramPurpose) {
		_trainingProgramPurpose = trainingProgramPurpose;
	}

	public String getTrainingProgramDiploma() {
		return _trainingProgramDiploma;
	}

	public void setTrainingProgramDiploma(String trainingProgramDiploma) {
		_trainingProgramDiploma = trainingProgramDiploma;
	}

	public double getTrainingProgramFee() {
		return _trainingProgramFee;
	}

	public void setTrainingProgramFee(double trainingProgramFee) {
		_trainingProgramFee = trainingProgramFee;
	}

	public String getTrainingProgramItems() {
		return _trainingProgramItems;
	}

	public void setTrainingProgramItems(String trainingProgramItems) {
		_trainingProgramItems = trainingProgramItems;
	}

	public String getTrainingProgramContent() {
		return _trainingProgramContent;
	}

	public void setTrainingProgramContent(String trainingProgramContent) {
		_trainingProgramContent = trainingProgramContent;
	}

	public String getTrainingProgramDescription() {
		return _trainingProgramDescription;
	}

	public void setTrainingProgramDescription(String trainingProgramDescription) {
		_trainingProgramDescription = trainingProgramDescription;
	}

	public long getEducatorId() {
		return _educatorId;
	}

	public void setEducatorId(long educatorId) {
		_educatorId = educatorId;
	}

	private long _trainingProgramId;
	private String _trainingProgramName;
	private String _trainingProgramPeriod;
	private String _trainingProgramPurpose;
	private String _trainingProgramDiploma;
	private double _trainingProgramFee;
	private String _trainingProgramItems;
	private String _trainingProgramContent;
	private String _trainingProgramDescription;
	private long _educatorId;
}