/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;
import com.portlets.action.service.persistence.RegisterRecruitmentPK;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class RegisterRecruitmentClp extends BaseModelImpl<RegisterRecruitment>
	implements RegisterRecruitment {
	public RegisterRecruitmentClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return RegisterRecruitment.class;
	}

	@Override
	public String getModelClassName() {
		return RegisterRecruitment.class.getName();
	}

	@Override
	public RegisterRecruitmentPK getPrimaryKey() {
		return new RegisterRecruitmentPK(_recruitmentId, _userObjectId);
	}

	@Override
	public void setPrimaryKey(RegisterRecruitmentPK primaryKey) {
		setRecruitmentId(primaryKey.recruitmentId);
		setUserObjectId(primaryKey.userObjectId);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return new RegisterRecruitmentPK(_recruitmentId, _userObjectId);
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey((RegisterRecruitmentPK)primaryKeyObj);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("recruitmentId", getRecruitmentId());
		attributes.put("userObjectId", getUserObjectId());
		attributes.put("statesId", getStatesId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long recruitmentId = (Long)attributes.get("recruitmentId");

		if (recruitmentId != null) {
			setRecruitmentId(recruitmentId);
		}

		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}

		Long statesId = (Long)attributes.get("statesId");

		if (statesId != null) {
			setStatesId(statesId);
		}
	}

	@Override
	public long getRecruitmentId() {
		return _recruitmentId;
	}

	@Override
	public void setRecruitmentId(long recruitmentId) {
		_recruitmentId = recruitmentId;

		if (_registerRecruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _registerRecruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setRecruitmentId", long.class);

				method.invoke(_registerRecruitmentRemoteModel, recruitmentId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserObjectId() {
		return _userObjectId;
	}

	@Override
	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;

		if (_registerRecruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _registerRecruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setUserObjectId", long.class);

				method.invoke(_registerRecruitmentRemoteModel, userObjectId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getStatesId() {
		return _statesId;
	}

	@Override
	public void setStatesId(long statesId) {
		_statesId = statesId;

		if (_registerRecruitmentRemoteModel != null) {
			try {
				Class<?> clazz = _registerRecruitmentRemoteModel.getClass();

				Method method = clazz.getMethod("setStatesId", long.class);

				method.invoke(_registerRecruitmentRemoteModel, statesId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getRegisterRecruitmentRemoteModel() {
		return _registerRecruitmentRemoteModel;
	}

	public void setRegisterRecruitmentRemoteModel(
		BaseModel<?> registerRecruitmentRemoteModel) {
		_registerRecruitmentRemoteModel = registerRecruitmentRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _registerRecruitmentRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_registerRecruitmentRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			RegisterRecruitmentLocalServiceUtil.addRegisterRecruitment(this);
		}
		else {
			RegisterRecruitmentLocalServiceUtil.updateRegisterRecruitment(this);
		}
	}

	@Override
	public RegisterRecruitment toEscapedModel() {
		return (RegisterRecruitment)ProxyUtil.newProxyInstance(RegisterRecruitment.class.getClassLoader(),
			new Class[] { RegisterRecruitment.class },
			new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		RegisterRecruitmentClp clone = new RegisterRecruitmentClp();

		clone.setRecruitmentId(getRecruitmentId());
		clone.setUserObjectId(getUserObjectId());
		clone.setStatesId(getStatesId());

		return clone;
	}

	@Override
	public int compareTo(RegisterRecruitment registerRecruitment) {
		RegisterRecruitmentPK primaryKey = registerRecruitment.getPrimaryKey();

		return getPrimaryKey().compareTo(primaryKey);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof RegisterRecruitmentClp)) {
			return false;
		}

		RegisterRecruitmentClp registerRecruitment = (RegisterRecruitmentClp)obj;

		RegisterRecruitmentPK primaryKey = registerRecruitment.getPrimaryKey();

		if (getPrimaryKey().equals(primaryKey)) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return getPrimaryKey().hashCode();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{recruitmentId=");
		sb.append(getRecruitmentId());
		sb.append(", userObjectId=");
		sb.append(getUserObjectId());
		sb.append(", statesId=");
		sb.append(getStatesId());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(13);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.RegisterRecruitment");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>recruitmentId</column-name><column-value><![CDATA[");
		sb.append(getRecruitmentId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userObjectId</column-name><column-value><![CDATA[");
		sb.append(getUserObjectId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>statesId</column-name><column-value><![CDATA[");
		sb.append(getStatesId());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _recruitmentId;
	private long _userObjectId;
	private long _statesId;
	private BaseModel<?> _registerRecruitmentRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}