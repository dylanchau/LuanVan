package com.huy.accRecruitment;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.portlets.action.model.Employer;
import com.portlets.action.service.EmployerLocalServiceUtil;
import com.liferay.counter.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.model.Address;
import com.liferay.portal.model.Contact;
import com.liferay.portal.model.EmailAddress;
import com.liferay.portal.model.Phone;
import com.liferay.portal.model.User;
import com.liferay.portal.service.AddressLocalServiceUtil;
import com.liferay.portal.service.ContactLocalServiceUtil;
import com.liferay.portal.service.CountryServiceUtil;
import com.liferay.portal.service.EmailAddressLocalServiceUtil;
import com.liferay.portal.service.PhoneLocalServiceUtil;
import com.liferay.portal.service.UserLocalServiceUtil;
import com.liferay.portal.util.PortalUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

/**
 * Portlet implementation class AccRecruitment
 */
public class AccRecruitment extends MVCPortlet {

	public void updateDetail(ActionRequest actionRequest,
			ActionResponse actionResponse) throws Exception {

		long userId = ParamUtil.getLong(actionRequest, "userId");
		String emailAddress = ParamUtil.getString(actionRequest, "emailAddress");
		String name = ParamUtil.getString(actionRequest, "firstName");
		String screenName = ParamUtil.getString(actionRequest, "screenName");
		User user = null;
		
		try{
			Employer employer = EmployerLocalServiceUtil.getEmployer(userId); 
			employer.setEmployerEmail(emailAddress);
			employer.setEmployerName(name);
			 
			EmployerLocalServiceUtil.updateEmployer(employer);
			 
			 	try {
				 user= UserLocalServiceUtil.getUser(userId);
				 user.setEmailAddress(emailAddress);
				 user.setFirstName(name);
				 user.setScreenName(screenName);
				 user= UserLocalServiceUtil.updateUser(user);
				 if(user != null)
					 _log.info("Update is success");
				 else 
					 _log.error("Error");			
			 	}catch(SystemException e1) {
				 _log.error(e1.getMessage());
			 } catch(PortalException e2) {
				 _log.error(e2.getMessage());
		}
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-detail-success");
			 
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-detail-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
	}
	
	public void updatePassword(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		
		
		String password1 = ParamUtil.getString(actionRequest, "password1");
		String reminderQueryQuestion = ParamUtil.getString(actionRequest, "reminderQueryQuestion");
		String reminderQueryAnswer = ParamUtil.getString(actionRequest, "reminderQueryAnswer");
		
		User user = null;
		
		user = UserLocalServiceUtil.updatePassword(userId, password1, password1, false);
		user = UserLocalServiceUtil.updateReminderQuery(userId, reminderQueryQuestion, reminderQueryAnswer);
		
		if(user != null) {
			SessionMessages.add(actionRequest.getPortletSession(), "update-pass-success");
		} else {
			SessionErrors.add(actionRequest.getPortletSession(), "update-pass-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/password.jsp");
		
	}
	
	public void addAddress(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String street = ParamUtil.getString(actionRequest, "street");
		String city = ParamUtil.getString(actionRequest, "city");
		long countryId = ParamUtil.getLong(actionRequest, "countryId");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		String zip = ParamUtil.getString(actionRequest, "zip");
		
		try {
			Address address = null;
			address = AddressLocalServiceUtil.createAddress(CounterLocalServiceUtil.increment());
			
			address.setUserId(userId);
			address.setCity(city);
			address.setCountryId(countryId);
			address.setStreet1(street);
			address.setTypeId(typeId);
			address.setZip(zip);
			
			AddressLocalServiceUtil.addAddress(address);
			
			Employer e = EmployerLocalServiceUtil.getEmployer(userId);
			e.setEmployerAddress(street + ", " + city + ", " + CountryServiceUtil.getCountry(countryId).getName());
			EmployerLocalServiceUtil.updateEmployer(e);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-address-success");
			
		} catch(Exception e) {
			e.printStackTrace();
			SessionErrors.add(actionRequest.getPortletSession(), "add-address-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/addresses.jsp");
		_log.info(userId + "\n" + street + "\n" + city + "\n" + countryId + typeId);
	}
	
	public void updateAddress(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		long addressId = ParamUtil.getLong(actionRequest, "addressId");
		String street1 = ParamUtil.getString(actionRequest, "street1");
		String city = ParamUtil.getString(actionRequest, "city");
		long countryId = ParamUtil.getLong(actionRequest, "countryId");
		String zip = ParamUtil.getString(actionRequest, "zip");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		_log.info(userId + "\n" + addressId + "\n" + street1 + "\n" + 
					city + "\n" + countryId + "\n" + zip + "\n" + typeId);
		
		try {
			
			Address address = AddressLocalServiceUtil.getAddress(addressId); 
			address.setStreet1(street1);
			address.setCity(city);
			address.setCountryId(countryId);
			address.setZip(zip);
			address.setTypeId(typeId);
			AddressLocalServiceUtil.updateAddress(address);
			
			Employer e = EmployerLocalServiceUtil.getEmployer(userId);
			e.setEmployerAddress(street1 + ", " + city + ", " + CountryServiceUtil.getCountry(countryId).getName());
			EmployerLocalServiceUtil.updateEmployer(e);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-address-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-address-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/addresses.jsp");
	}
	
	public void updatePhoneNumber(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long employerId = ParamUtil.getLong(actionRequest, "userId");
		long phoneId = ParamUtil.getLong(actionRequest, "phoneId");
		String number_ = ParamUtil.getString(actionRequest, "number");
		String extension = ParamUtil.getString(actionRequest, "extension");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		try {
			
			Phone phone = PhoneLocalServiceUtil.getPhone(phoneId);
			
			phone.setNumber(number_);
			phone.setExtension(extension);
			phone.setTypeId(typeId);
			
			PhoneLocalServiceUtil.updatePhone(phone);
			
			Employer e = EmployerLocalServiceUtil.getEmployer(employerId);
			e.setEmployerPhone(number_);
			EmployerLocalServiceUtil.updateEmployer(e);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-phone-success");
		} catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-phone-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/phonenumbers.jsp");
	}
	
	public void addPhoneNumber(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String number_ = ParamUtil.getString(actionRequest, "number_");
		String extension = ParamUtil.getString(actionRequest, "extension");
		int typeId = ParamUtil.getInteger(actionRequest, "typeId");
		
		try {
			
			Phone phone = PhoneLocalServiceUtil.createPhone(CounterLocalServiceUtil.increment());
			
			phone.setNumber(number_);
			phone.setExtension(extension);
			phone.setTypeId(typeId);
			phone.setUserId(userId);
			
			PhoneLocalServiceUtil.addPhone(phone);
			
			Employer e = EmployerLocalServiceUtil.getEmployer(userId);
			e.setEmployerAddress(number_);
			EmployerLocalServiceUtil.updateEmployer(e);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-phone-success");
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "add-phone-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/phonenumbers.jsp");
		_log.info(userId + "\n" + number_ + "\n" + extension +  "\n" + typeId);
	}
	
	public void addUserEmail(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String address = ParamUtil.getString(actionRequest, "address");
		
		try {
			
			EmailAddress emailAddress = EmailAddressLocalServiceUtil
					.createEmailAddress(CounterLocalServiceUtil.increment());
			
			emailAddress.setUserId(userId);
			emailAddress.setAddress(address);
			
			EmailAddressLocalServiceUtil.addEmailAddress(emailAddress);
			SessionMessages.add(actionRequest.getPortletSession(), "add-email-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "add-email-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/emailaddresses.jsp");
		_log.info(address + "\n" +userId);
	}
	
	public void updateUserEmail(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long userId = ParamUtil.getLong(actionRequest, "userId");
		String address = ParamUtil.getString(actionRequest, "address");
		long emailAddressId = ParamUtil.getLong(actionRequest, "emailAddressId");
		
		try {
			
			EmailAddress emailAddress = EmailAddressLocalServiceUtil.getEmailAddress(emailAddressId);
			
			emailAddress.setAddress(address);
			
			EmailAddressLocalServiceUtil.addEmailAddress(emailAddress);
			SessionMessages.add(actionRequest.getPortletSession(), "update-email-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-email-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/emailaddresses.jsp");
		_log.info(address + "\n" +userId);
	}
	
	public void updateSocial(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		long contactId = ParamUtil.getLong(actionRequest, "contactId");
		String facebookSn = ParamUtil.getString(actionRequest, "facebookSn");
		String twitterSn = ParamUtil.getString(actionRequest, "twitterSn");
		
		try {
			
			Contact con = ContactLocalServiceUtil.getContact(contactId);
			con.setFacebookSn(facebookSn);
			con.setTwitterSn(twitterSn);
			
			ContactLocalServiceUtil.updateContact(con);
			
			SessionMessages.add(actionRequest.getPortletSession(), "update-social-success");
			
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "update-social-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/socialnetwork.jsp");
		_log.info(contactId + "\n" +contactId + "\n" + twitterSn);
	}
	
	public void addSocial(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		
		String facebookSn = ParamUtil.getString(actionRequest, "facebookSn");
		String twitterSn = ParamUtil.getString(actionRequest, "twitterSn");
		long userId = ParamUtil.getLong(actionRequest, "userId");
		
		try {
			
			Contact con = ContactLocalServiceUtil.createContact(CounterLocalServiceUtil.increment());
			
			con.setFacebookSn(facebookSn);
			con.setTwitterSn(twitterSn);
			con.setUserId(userId);
			
			ContactLocalServiceUtil.addContact(con);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-social-success");
		}catch(Exception e) {
			_log.error(e);
			SessionErrors.add(actionRequest.getPortletSession(), "add-social-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
		
		actionResponse.setRenderParameter("mvcPath", "/html/accrecruitment/socialnetwork.jsp");
	}
	
	public void serverResourse(ResourceRequest resourceRequest,
            ResourceResponse resourceResponse) throws IOException, PortletException {
		
		
	}
	
	Log _log = LogFactoryUtil.getLog(AccRecruitment.class);


}
