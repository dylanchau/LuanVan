package com.dylan.messagebus.listenerImp;

import javax.mail.internet.InternetAddress;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.messaging.Message;
import com.liferay.portal.kernel.messaging.MessageListener;
import com.liferay.portal.kernel.messaging.MessageListenerException;
import com.liferay.portal.kernel.notifications.ChannelHubManagerUtil;
import com.liferay.portal.kernel.notifications.NotificationEvent;
import com.liferay.portal.kernel.notifications.NotificationEventFactoryUtil;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.EducatorLocalServiceUtil;
import com.portlets.action.service.EmployerLocalServiceUtil;
import com.portlets.action.service.RecruitmentLocalServiceUtil;
import com.portlets.action.service.UserObjectLocalServiceUtil;

public class EducatorAcceptResponeImpl implements MessageListener {

	@Override
	public void receive(Message message) 
			throws MessageListenerException {
		try {
			doReceive(message);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void doReceive(Message message) throws Exception {
		
		String payLoad = (String) message.getPayload();
		JSONObject jsonObject = JSONFactoryUtil.createJSONObject(payLoad);
		
		long studentId = jsonObject.getLong("studentId");
		long courseId = jsonObject.getLong("courseIdOfReq");
		long companyId = jsonObject.getLong("companyId");
		String messages = jsonObject.getString("message");
		long educatorId = CourseLocalServiceUtil.getCourse(courseId).getEducatorId();
		
		_log.info(educatorId);
		_log.info(studentId);
		_log.info(courseId);
		_log.info(messages);
		
		try {
			
			NotificationEvent notificationEvent = NotificationEventFactoryUtil
					.createNotificationEvent(System.currentTimeMillis(), UserNotificationHandler.PORTLET_ID, jsonObject);
			
			notificationEvent.setDeliveryRequired(0);
			
			ChannelHubManagerUtil.sendNotificationEvent(companyId,
					studentId, notificationEvent);
			
			//send mail
			String From= "liferay.luanvan@gmail.com";
			String to = UserObjectLocalServiceUtil.getUserObject(studentId).getUserObjectEmail();
			InternetAddress From1 = new InternetAddress(From);
			InternetAddress to1 = new InternetAddress(to);
			
			MailMessage mailMessage =new MailMessage(); 

            mailMessage.setFrom(From1);
            mailMessage.setTo(to1);
            
            String subject = "Register request response";
            String messageBody = "<span style=\"color: red; font-weight: bold;\">" + 
            						EducatorLocalServiceUtil.getEducator(educatorId).getEducatorName() + "</span>" + 
            						" accepted your registered to course " + "<span style=\"color: red; font-weight: bold;\">" +
            						CourseLocalServiceUtil.getCourse(courseId).getCourseName() + "</span>";
            
            mailMessage.setSubject(subject);
            mailMessage.setBody(messageBody);
            mailMessage.setHTMLFormat(true);
            
            
            MailServiceUtil.sendEmail(mailMessage);
			
		}catch(Exception e) {
			
		}
	}

	Log _log = LogFactoryUtil.getLog(EducatorAcceptResponeImpl.class);
}
