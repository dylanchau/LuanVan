package com.dylan.addtraining;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletURL;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import com.dylan.portlets.action.util.CourseActionUtil;
import com.dylan.portlets.action.util.TrainingProgramActionUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionErrors;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.Course;
import com.portlets.action.model.Skill;
import com.portlets.action.model.TrainingProgram;
import com.portlets.action.service.SkillLocalServiceUtil;
import com.portlets.action.service.TrainingProgramLocalServiceUtil;

/**
 * Portlet implementation class AddTraining
 */
public class AddTraining extends MVCPortlet {
	public void addTrainingProgram(ActionRequest actionRequest, 
			ActionResponse actionResponse) throws Exception {
		
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
		PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
		
		//get value of parameters
		String trainingProgramName = ParamUtil.getString(actionRequest, "trainingProgramName");
		double trainingProgramFee = ParamUtil.getDouble(actionRequest, "trainingProgramFee");
		String trainingProgramPurpose = ParamUtil.getString(actionRequest, "trainingProgramPurpose");
		String trainingProgramPeriod = ParamUtil.getString(actionRequest, "trainingProgramPeriod");
		String trainingProgramDescription = ParamUtil.getString(actionRequest, "trainingProgramDescription");
		String trainingProgramDiploma = ParamUtil.getString(actionRequest, "trainingProgramDiploma");
		long userId = ParamUtil.getLong(actionRequest, "userId");
		
		//get skills
		String skillIds_v2 = ParamUtil.getString(actionRequest, "skills");
		
		String[] stringArray = skillIds_v2.split(" "); 
		String skillsList = Arrays.toString(stringArray); 
		skillsList = skillsList.substring(1, skillsList.length()-1).replaceAll(",", "");
		
		long[] skillIds = new long[stringArray.length];
		for(int i = 0; i < skillIds.length; i++) {
			skillIds[i] = Long.parseLong(stringArray[i]);
			System.out.println(skillIds[i]);
		}
		
		_log.info(trainingProgramName + "\n" +
				trainingProgramFee + "\n" +
				trainingProgramPurpose + "\n" +
				trainingProgramPeriod + "\n" +
				trainingProgramDescription);
		
		TrainingProgram training = null;
		try {
			
			training = TrainingProgramLocalServiceUtil.addTrainingPro(trainingProgramName, trainingProgramPeriod, 
					trainingProgramPurpose, trainingProgramFee, 
					StringPool.BLANK, trainingProgramDescription, trainingProgramDiploma, userId);
			
			SkillLocalServiceUtil.addTrainingProgramSkills(training.getTrainingProgramId(), skillIds);
			
			SessionMessages.add(actionRequest.getPortletSession(), "add-training-success");
			
			//message bus
			
			
			redirectURL.setParameter("mvcPath", "/html/addtraining/view.jsp");
			
			actionResponse.sendRedirect(redirectURL.toString());
		}catch(Exception e) {
			_log.error(e.getMessage());
			SessionErrors.add(actionRequest.getPortletSession(), "add-training-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
	}

	public void updateTrainingProgram(ActionRequest actionRequest, 
			ActionResponse actionResponse) throws Exception {
		
		long educatorId = ParamUtil.getLong(actionRequest, "educatorId"); _log.info(educatorId);
		
		long proId = ParamUtil.getLong(actionRequest, "proId"); _log.info(proId);
		
		List<Course> courses = CourseActionUtil.getCourseByProId(proId);
		
		String trainingProgramName = ParamUtil.getString(actionRequest, "trainingProgramName"); _log.info(trainingProgramName);
		double trainingProgramFee = ParamUtil.getDouble(actionRequest, "trainingProgramFee"); _log.info(trainingProgramFee);
		String trainingProgramPurpose = ParamUtil.getString(actionRequest, "trainingProgramPurpose"); _log.info(trainingProgramPurpose);
		String trainingProgramPeriod = ParamUtil.getString(actionRequest, "trainingProgramPeriod"); _log.info(trainingProgramPeriod);
		String trainingProgramDescription = ParamUtil.getString(actionRequest, "trainingProgramDescription"); _log.info(trainingProgramDescription);
		String trainingProgramDiploma = ParamUtil.getString(actionRequest, "trainingProgramDiploma"); _log.info(trainingProgramDiploma);
		
		//get and delete old skills of pro
		List<Skill> oldSkills = SkillLocalServiceUtil.getTrainingProgramSkills(proId);
		long[] skillListIds = new long[oldSkills.size()]; 
		for(int i=0; i < oldSkills.size(); i++) {
			skillListIds[i] = oldSkills.get(i).getSkillId();
			_log.info("old skill: " + oldSkills.get(i).getSkillId() + "\t skillIds: " + skillListIds[i]);
		}
		SkillLocalServiceUtil.deleteTrainingProgramSkills(proId, skillListIds);
				
		//update new skills
		String skills = ParamUtil.getString(actionRequest, "skills"); _log.info(skills);
		String[] skillIds = skills.split(" "); long[] skillIds2 = new long[skillIds.length];
		for(int i=0; i<skillIds.length; i++) {
			skillIds2[i] = Long.parseLong(skillIds[i]);
			_log.info(skillIds2[i]);
		}
		
		TrainingProgram trainPro = TrainingProgramActionUtil.updateTrainingPro(proId, trainingProgramName, 
				trainingProgramFee, trainingProgramPurpose, 
				trainingProgramPeriod, trainingProgramDescription, trainingProgramDiploma);
		
		SkillLocalServiceUtil.addTrainingProgramSkills(proId, skillIds2);
		
	}
	
	public void deleteTrain(ActionRequest actionRequest, 
			ActionResponse actionResponse) throws Exception {
		
		long trainProId = ParamUtil.getLong(actionRequest, "trainProId"); _log.info(trainProId);
		try {
			TrainingProgramLocalServiceUtil.deleteTrainingProgram(trainProId);
			
			SessionMessages.add(actionRequest.getPortletSession(), "delete-success");
		}catch(Exception e) {
			_log.error(e.getClass() + "\n" + e.getMessage());
			SessionErrors.add(actionRequest.getPortletSession(), "delete-fail");
			SessionMessages.add(actionRequest, PortalUtil.getPortletId(actionRequest) + 
					SessionMessages.KEY_SUFFIX_HIDE_DEFAULT_ERROR_MESSAGE);
		}
	}
	
	@SuppressWarnings("static-access")
	public void serveResource(ResourceRequest resourceRequest,
            ResourceResponse resourceResponse) throws IOException, PortletException {
		
		JSONArray jsonArray = new JSONFactoryUtil().createJSONArray();
		String cmd = ParamUtil.getString(resourceRequest, "cmd", "");
		
		if(cmd.equals("testabc")) {
			Skill skill = null;
			long[] skillIds = ParamUtil.getLongValues(resourceRequest, "skillIds");
			int skillIdslength = skillIds.length;
			_log.info(skillIdslength);
			if(skillIdslength > 0) {
				for(int i = 0; i < skillIds.length; i++) {
					_log.info(skillIds[i]);
					try {
						skill = SkillLocalServiceUtil.getSkill(skillIds[i]);
					} catch (PortalException e) {
						e.printStackTrace();
					} catch (SystemException e) {
						e.printStackTrace();
					}
					JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
					jsonObject.put("id", skillIds[i]);
					jsonObject.put("name", skill.getSkillName());
					jsonArray.put(jsonObject);
				}
			}
			
			PrintWriter writer = resourceResponse.getWriter();
			writer.print(jsonArray.toString());
			writer.flush(); writer.close();
		}
		super.serveResource(resourceRequest, resourceResponse);
	}
	Log _log = LogFactoryUtil.getLog(AddTraining.class);
}
