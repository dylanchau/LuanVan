/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.SkillLocalServiceUtil;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class SkillClp extends BaseModelImpl<Skill> implements Skill {
	public SkillClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return Skill.class;
	}

	@Override
	public String getModelClassName() {
		return Skill.class.getName();
	}

	@Override
	public long getPrimaryKey() {
		return _skillId;
	}

	@Override
	public void setPrimaryKey(long primaryKey) {
		setSkillId(primaryKey);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _skillId;
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey(((Long)primaryKeyObj).longValue());
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("skillId", getSkillId());
		attributes.put("skillName", getSkillName());
		attributes.put("skillExplain", getSkillExplain());
		attributes.put("skillAncestor", getSkillAncestor());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long skillId = (Long)attributes.get("skillId");

		if (skillId != null) {
			setSkillId(skillId);
		}

		String skillName = (String)attributes.get("skillName");

		if (skillName != null) {
			setSkillName(skillName);
		}

		String skillExplain = (String)attributes.get("skillExplain");

		if (skillExplain != null) {
			setSkillExplain(skillExplain);
		}

		Long skillAncestor = (Long)attributes.get("skillAncestor");

		if (skillAncestor != null) {
			setSkillAncestor(skillAncestor);
		}
	}

	@Override
	public long getSkillId() {
		return _skillId;
	}

	@Override
	public void setSkillId(long skillId) {
		_skillId = skillId;

		if (_skillRemoteModel != null) {
			try {
				Class<?> clazz = _skillRemoteModel.getClass();

				Method method = clazz.getMethod("setSkillId", long.class);

				method.invoke(_skillRemoteModel, skillId);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSkillName() {
		return _skillName;
	}

	@Override
	public void setSkillName(String skillName) {
		_skillName = skillName;

		if (_skillRemoteModel != null) {
			try {
				Class<?> clazz = _skillRemoteModel.getClass();

				Method method = clazz.getMethod("setSkillName", String.class);

				method.invoke(_skillRemoteModel, skillName);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public String getSkillExplain() {
		return _skillExplain;
	}

	@Override
	public void setSkillExplain(String skillExplain) {
		_skillExplain = skillExplain;

		if (_skillRemoteModel != null) {
			try {
				Class<?> clazz = _skillRemoteModel.getClass();

				Method method = clazz.getMethod("setSkillExplain", String.class);

				method.invoke(_skillRemoteModel, skillExplain);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getSkillAncestor() {
		return _skillAncestor;
	}

	@Override
	public void setSkillAncestor(long skillAncestor) {
		_skillAncestor = skillAncestor;

		if (_skillRemoteModel != null) {
			try {
				Class<?> clazz = _skillRemoteModel.getClass();

				Method method = clazz.getMethod("setSkillAncestor", long.class);

				method.invoke(_skillRemoteModel, skillAncestor);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getSkillRemoteModel() {
		return _skillRemoteModel;
	}

	public void setSkillRemoteModel(BaseModel<?> skillRemoteModel) {
		_skillRemoteModel = skillRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _skillRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_skillRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			SkillLocalServiceUtil.addSkill(this);
		}
		else {
			SkillLocalServiceUtil.updateSkill(this);
		}
	}

	@Override
	public Skill toEscapedModel() {
		return (Skill)ProxyUtil.newProxyInstance(Skill.class.getClassLoader(),
			new Class[] { Skill.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		SkillClp clone = new SkillClp();

		clone.setSkillId(getSkillId());
		clone.setSkillName(getSkillName());
		clone.setSkillExplain(getSkillExplain());
		clone.setSkillAncestor(getSkillAncestor());

		return clone;
	}

	@Override
	public int compareTo(Skill skill) {
		long primaryKey = skill.getPrimaryKey();

		if (getPrimaryKey() < primaryKey) {
			return -1;
		}
		else if (getPrimaryKey() > primaryKey) {
			return 1;
		}
		else {
			return 0;
		}
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof SkillClp)) {
			return false;
		}

		SkillClp skill = (SkillClp)obj;

		long primaryKey = skill.getPrimaryKey();

		if (getPrimaryKey() == primaryKey) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return (int)getPrimaryKey();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(9);

		sb.append("{skillId=");
		sb.append(getSkillId());
		sb.append(", skillName=");
		sb.append(getSkillName());
		sb.append(", skillExplain=");
		sb.append(getSkillExplain());
		sb.append(", skillAncestor=");
		sb.append(getSkillAncestor());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(16);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.Skill");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>skillId</column-name><column-value><![CDATA[");
		sb.append(getSkillId());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>skillName</column-name><column-value><![CDATA[");
		sb.append(getSkillName());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>skillExplain</column-name><column-value><![CDATA[");
		sb.append(getSkillExplain());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>skillAncestor</column-name><column-value><![CDATA[");
		sb.append(getSkillAncestor());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _skillId;
	private String _skillName;
	private String _skillExplain;
	private long _skillAncestor;
	private BaseModel<?> _skillRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}