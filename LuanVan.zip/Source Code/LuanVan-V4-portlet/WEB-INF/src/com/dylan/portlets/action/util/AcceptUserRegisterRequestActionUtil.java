package com.dylan.portlets.action.util;

import java.util.List;

import com.portlets.action.model.RegisterCourse;
import com.portlets.action.service.RegisterCourseLocalServiceUtil;


public class AcceptUserRegisterRequestActionUtil {

	public static void approvalRequest(long courseId, long userId,
			long statedId) throws Exception {
		
		List<RegisterCourse> registerCourses = RegisterCourseLocalServiceUtil
				.getByCourseId(courseId);
		
		for(RegisterCourse a : registerCourses) {
			try {
				a.setStatesId(statedId);
				RegisterCourseLocalServiceUtil.updateRegisterCourse(a); 
			} catch(Exception e) {
				System.err.println(e.getClass() + "\n" + e.getMessage());
			}
		}
	}
}
