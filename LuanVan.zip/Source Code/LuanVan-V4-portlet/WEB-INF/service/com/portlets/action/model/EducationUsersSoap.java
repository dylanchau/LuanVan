/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.EducationUsersServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.EducationUsersServiceSoap
 * @generated
 */
public class EducationUsersSoap implements Serializable {
	public static EducationUsersSoap toSoapModel(EducationUsers model) {
		EducationUsersSoap soapModel = new EducationUsersSoap();

		soapModel.setEducationUsersId(model.getEducationUsersId());
		soapModel.setEducationUsersSchool(model.getEducationUsersSchool());
		soapModel.setEducationUsersMajor(model.getEducationUsersMajor());
		soapModel.setEducationUsersDateStart(model.getEducationUsersDateStart());
		soapModel.setEducationUsersDateFinish(model.getEducationUsersDateFinish());
		soapModel.setEducationUsersDegree(model.getEducationUsersDegree());
		soapModel.setEducationUsersDescription(model.getEducationUsersDescription());
		soapModel.setUserObjectId(model.getUserObjectId());

		return soapModel;
	}

	public static EducationUsersSoap[] toSoapModels(EducationUsers[] models) {
		EducationUsersSoap[] soapModels = new EducationUsersSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static EducationUsersSoap[][] toSoapModels(EducationUsers[][] models) {
		EducationUsersSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new EducationUsersSoap[models.length][models[0].length];
		}
		else {
			soapModels = new EducationUsersSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static EducationUsersSoap[] toSoapModels(List<EducationUsers> models) {
		List<EducationUsersSoap> soapModels = new ArrayList<EducationUsersSoap>(models.size());

		for (EducationUsers model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new EducationUsersSoap[soapModels.size()]);
	}

	public EducationUsersSoap() {
	}

	public long getPrimaryKey() {
		return _educationUsersId;
	}

	public void setPrimaryKey(long pk) {
		setEducationUsersId(pk);
	}

	public long getEducationUsersId() {
		return _educationUsersId;
	}

	public void setEducationUsersId(long educationUsersId) {
		_educationUsersId = educationUsersId;
	}

	public String getEducationUsersSchool() {
		return _educationUsersSchool;
	}

	public void setEducationUsersSchool(String educationUsersSchool) {
		_educationUsersSchool = educationUsersSchool;
	}

	public String getEducationUsersMajor() {
		return _educationUsersMajor;
	}

	public void setEducationUsersMajor(String educationUsersMajor) {
		_educationUsersMajor = educationUsersMajor;
	}

	public Date getEducationUsersDateStart() {
		return _educationUsersDateStart;
	}

	public void setEducationUsersDateStart(Date educationUsersDateStart) {
		_educationUsersDateStart = educationUsersDateStart;
	}

	public Date getEducationUsersDateFinish() {
		return _educationUsersDateFinish;
	}

	public void setEducationUsersDateFinish(Date educationUsersDateFinish) {
		_educationUsersDateFinish = educationUsersDateFinish;
	}

	public String getEducationUsersDegree() {
		return _educationUsersDegree;
	}

	public void setEducationUsersDegree(String educationUsersDegree) {
		_educationUsersDegree = educationUsersDegree;
	}

	public String getEducationUsersDescription() {
		return _educationUsersDescription;
	}

	public void setEducationUsersDescription(String educationUsersDescription) {
		_educationUsersDescription = educationUsersDescription;
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	private long _educationUsersId;
	private String _educationUsersSchool;
	private String _educationUsersMajor;
	private Date _educationUsersDateStart;
	private Date _educationUsersDateFinish;
	private String _educationUsersDegree;
	private String _educationUsersDescription;
	private long _userObjectId;
}