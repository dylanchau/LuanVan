/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.sql.Blob;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link Employer}.
 * </p>
 *
 * @author Computer
 * @see Employer
 * @generated
 */
public class EmployerWrapper implements Employer, ModelWrapper<Employer> {
	public EmployerWrapper(Employer employer) {
		_employer = employer;
	}

	@Override
	public Class<?> getModelClass() {
		return Employer.class;
	}

	@Override
	public String getModelClassName() {
		return Employer.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("employerId", getEmployerId());
		attributes.put("employerName", getEmployerName());
		attributes.put("employerAddress", getEmployerAddress());
		attributes.put("employerEmail", getEmployerEmail());
		attributes.put("employerPhone", getEmployerPhone());
		attributes.put("employerIntroduce", getEmployerIntroduce());
		attributes.put("employerAchievements", getEmployerAchievements());
		attributes.put("employerLogoName", getEmployerLogoName());
		attributes.put("employerLogo", getEmployerLogo());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long employerId = (Long)attributes.get("employerId");

		if (employerId != null) {
			setEmployerId(employerId);
		}

		String employerName = (String)attributes.get("employerName");

		if (employerName != null) {
			setEmployerName(employerName);
		}

		String employerAddress = (String)attributes.get("employerAddress");

		if (employerAddress != null) {
			setEmployerAddress(employerAddress);
		}

		String employerEmail = (String)attributes.get("employerEmail");

		if (employerEmail != null) {
			setEmployerEmail(employerEmail);
		}

		String employerPhone = (String)attributes.get("employerPhone");

		if (employerPhone != null) {
			setEmployerPhone(employerPhone);
		}

		String employerIntroduce = (String)attributes.get("employerIntroduce");

		if (employerIntroduce != null) {
			setEmployerIntroduce(employerIntroduce);
		}

		String employerAchievements = (String)attributes.get(
				"employerAchievements");

		if (employerAchievements != null) {
			setEmployerAchievements(employerAchievements);
		}

		String employerLogoName = (String)attributes.get("employerLogoName");

		if (employerLogoName != null) {
			setEmployerLogoName(employerLogoName);
		}

		Blob employerLogo = (Blob)attributes.get("employerLogo");

		if (employerLogo != null) {
			setEmployerLogo(employerLogo);
		}
	}

	/**
	* Returns the primary key of this employer.
	*
	* @return the primary key of this employer
	*/
	@Override
	public long getPrimaryKey() {
		return _employer.getPrimaryKey();
	}

	/**
	* Sets the primary key of this employer.
	*
	* @param primaryKey the primary key of this employer
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_employer.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the employer ID of this employer.
	*
	* @return the employer ID of this employer
	*/
	@Override
	public long getEmployerId() {
		return _employer.getEmployerId();
	}

	/**
	* Sets the employer ID of this employer.
	*
	* @param employerId the employer ID of this employer
	*/
	@Override
	public void setEmployerId(long employerId) {
		_employer.setEmployerId(employerId);
	}

	/**
	* Returns the employer name of this employer.
	*
	* @return the employer name of this employer
	*/
	@Override
	public java.lang.String getEmployerName() {
		return _employer.getEmployerName();
	}

	/**
	* Sets the employer name of this employer.
	*
	* @param employerName the employer name of this employer
	*/
	@Override
	public void setEmployerName(java.lang.String employerName) {
		_employer.setEmployerName(employerName);
	}

	/**
	* Returns the employer address of this employer.
	*
	* @return the employer address of this employer
	*/
	@Override
	public java.lang.String getEmployerAddress() {
		return _employer.getEmployerAddress();
	}

	/**
	* Sets the employer address of this employer.
	*
	* @param employerAddress the employer address of this employer
	*/
	@Override
	public void setEmployerAddress(java.lang.String employerAddress) {
		_employer.setEmployerAddress(employerAddress);
	}

	/**
	* Returns the employer email of this employer.
	*
	* @return the employer email of this employer
	*/
	@Override
	public java.lang.String getEmployerEmail() {
		return _employer.getEmployerEmail();
	}

	/**
	* Sets the employer email of this employer.
	*
	* @param employerEmail the employer email of this employer
	*/
	@Override
	public void setEmployerEmail(java.lang.String employerEmail) {
		_employer.setEmployerEmail(employerEmail);
	}

	/**
	* Returns the employer phone of this employer.
	*
	* @return the employer phone of this employer
	*/
	@Override
	public java.lang.String getEmployerPhone() {
		return _employer.getEmployerPhone();
	}

	/**
	* Sets the employer phone of this employer.
	*
	* @param employerPhone the employer phone of this employer
	*/
	@Override
	public void setEmployerPhone(java.lang.String employerPhone) {
		_employer.setEmployerPhone(employerPhone);
	}

	/**
	* Returns the employer introduce of this employer.
	*
	* @return the employer introduce of this employer
	*/
	@Override
	public java.lang.String getEmployerIntroduce() {
		return _employer.getEmployerIntroduce();
	}

	/**
	* Sets the employer introduce of this employer.
	*
	* @param employerIntroduce the employer introduce of this employer
	*/
	@Override
	public void setEmployerIntroduce(java.lang.String employerIntroduce) {
		_employer.setEmployerIntroduce(employerIntroduce);
	}

	/**
	* Returns the employer achievements of this employer.
	*
	* @return the employer achievements of this employer
	*/
	@Override
	public java.lang.String getEmployerAchievements() {
		return _employer.getEmployerAchievements();
	}

	/**
	* Sets the employer achievements of this employer.
	*
	* @param employerAchievements the employer achievements of this employer
	*/
	@Override
	public void setEmployerAchievements(java.lang.String employerAchievements) {
		_employer.setEmployerAchievements(employerAchievements);
	}

	/**
	* Returns the employer logo name of this employer.
	*
	* @return the employer logo name of this employer
	*/
	@Override
	public java.lang.String getEmployerLogoName() {
		return _employer.getEmployerLogoName();
	}

	/**
	* Sets the employer logo name of this employer.
	*
	* @param employerLogoName the employer logo name of this employer
	*/
	@Override
	public void setEmployerLogoName(java.lang.String employerLogoName) {
		_employer.setEmployerLogoName(employerLogoName);
	}

	/**
	* Returns the employer logo of this employer.
	*
	* @return the employer logo of this employer
	*/
	@Override
	public java.sql.Blob getEmployerLogo() {
		return _employer.getEmployerLogo();
	}

	/**
	* Sets the employer logo of this employer.
	*
	* @param employerLogo the employer logo of this employer
	*/
	@Override
	public void setEmployerLogo(java.sql.Blob employerLogo) {
		_employer.setEmployerLogo(employerLogo);
	}

	@Override
	public boolean isNew() {
		return _employer.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_employer.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _employer.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_employer.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _employer.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _employer.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_employer.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _employer.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_employer.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_employer.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_employer.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new EmployerWrapper((Employer)_employer.clone());
	}

	@Override
	public int compareTo(com.portlets.action.model.Employer employer) {
		return _employer.compareTo(employer);
	}

	@Override
	public int hashCode() {
		return _employer.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.Employer> toCacheModel() {
		return _employer.toCacheModel();
	}

	@Override
	public com.portlets.action.model.Employer toEscapedModel() {
		return new EmployerWrapper(_employer.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.Employer toUnescapedModel() {
		return new EmployerWrapper(_employer.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _employer.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _employer.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_employer.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof EmployerWrapper)) {
			return false;
		}

		EmployerWrapper employerWrapper = (EmployerWrapper)obj;

		if (Validator.equals(_employer, employerWrapper._employer)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public Employer getWrappedEmployer() {
		return _employer;
	}

	@Override
	public Employer getWrappedModel() {
		return _employer;
	}

	@Override
	public void resetOriginalValues() {
		_employer.resetOriginalValues();
	}

	private Employer _employer;
}