/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.portlets.action.service.persistence.UserSkillListenerPK;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.UserSkillListenerServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.UserSkillListenerServiceSoap
 * @generated
 */
public class UserSkillListenerSoap implements Serializable {
	public static UserSkillListenerSoap toSoapModel(UserSkillListener model) {
		UserSkillListenerSoap soapModel = new UserSkillListenerSoap();

		soapModel.setUserObjectId(model.getUserObjectId());
		soapModel.setSkillId(model.getSkillId());

		return soapModel;
	}

	public static UserSkillListenerSoap[] toSoapModels(
		UserSkillListener[] models) {
		UserSkillListenerSoap[] soapModels = new UserSkillListenerSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static UserSkillListenerSoap[][] toSoapModels(
		UserSkillListener[][] models) {
		UserSkillListenerSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new UserSkillListenerSoap[models.length][models[0].length];
		}
		else {
			soapModels = new UserSkillListenerSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static UserSkillListenerSoap[] toSoapModels(
		List<UserSkillListener> models) {
		List<UserSkillListenerSoap> soapModels = new ArrayList<UserSkillListenerSoap>(models.size());

		for (UserSkillListener model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new UserSkillListenerSoap[soapModels.size()]);
	}

	public UserSkillListenerSoap() {
	}

	public UserSkillListenerPK getPrimaryKey() {
		return new UserSkillListenerPK(_userObjectId, _skillId);
	}

	public void setPrimaryKey(UserSkillListenerPK pk) {
		setUserObjectId(pk.userObjectId);
		setSkillId(pk.skillId);
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	public long getSkillId() {
		return _skillId;
	}

	public void setSkillId(long skillId) {
		_skillId = skillId;
	}

	private long _userObjectId;
	private long _skillId;
}