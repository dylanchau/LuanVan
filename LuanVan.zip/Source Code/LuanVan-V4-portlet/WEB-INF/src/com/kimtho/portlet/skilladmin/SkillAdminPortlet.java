package com.kimtho.portlet.skilladmin;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.kimtho.portlet.ActionUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.Skill;
import com.portlets.action.service.SkillLocalServiceUtil;

/**
 * Portlet implementation class SkillAdminPortlet
 */
public class SkillAdminPortlet extends MVCPortlet {
 
	@ProcessAction(name = "addSkill")
	public void addSkill(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException {
		Skill skill = ActionUtil.skillsFromRequest(actionRequest);
		SkillLocalServiceUtil.addSkill(skill);
		SessionMessages.add(actionRequest, "added-skills"); 
	   _log.info("#################Added Skills Successfully#########################");
	}
	
	@ProcessAction(name = "deleteSkill")
	public void deleteSkill(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long skillId = ParamUtil.getLong(actionRequest, "skillId");
		SkillLocalServiceUtil.deleteSkill(skillId);
		SessionMessages.add(actionRequest, "deleted-skills"); 
		_log.info("#################Skills Deleted Successfully#########################");
	}
	
	@ProcessAction(name = "updateSkill")
	public void updateSkill(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, PortalException {
		long skillId = ParamUtil.getLong(actionRequest, "skillId");
		Skill skill = ActionUtil.skillsFromRequest(actionRequest);
		skill.setSkillId(skillId);
		SkillLocalServiceUtil.updateSkill(skill);
		SessionMessages.add(actionRequest, "updated-skills"); 
		_log.info("#################Updated Skills Successfully#########################");
		
	}
	
	private Log _log = LogFactoryUtil.getLog(SkillAdminPortlet.class.getName());



}
