package com.kimtho.portlet.listener;

import java.util.ArrayList;
import java.util.List;

import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.portlets.action.model.Course;
import com.portlets.action.model.LinkUserCourse;
import com.portlets.action.model.TrainingProgram;
import com.portlets.action.model.UserSkillListener;
import com.portlets.action.model.impl.LinkUserCourseImpl;
import com.portlets.action.service.CourseLocalServiceUtil;
import com.portlets.action.service.LinkUserCourseLocalServiceUtil;
import com.portlets.action.service.TrainingProgramLocalServiceUtil;
import com.portlets.action.service.UserSkillListenerLocalServiceUtil;

public class ListenerUserCourse {
	
	public ListenerUserCourse() {
		// TODO Auto-generated constructor stub
	}
	
	public void addLinkUserCourseId(Long courseId, Long skillId) throws SystemException, PortalException {
		List<UserSkillListener> userSkillListener = new ArrayList<UserSkillListener>();
		userSkillListener = UserSkillListenerLocalServiceUtil.getBySkillId(skillId);
		
		LinkUserCourse linkUserCourse1 = new LinkUserCourseImpl();
		linkUserCourse1.setCourseId(courseId);
		linkUserCourse1.setLinkUserCourseNo(1);
		for(UserSkillListener su:userSkillListener){
			System.out.println("#################"+su.getUserObjectId()+"################"+courseId+"##############");
			linkUserCourse1.setUserObjectId(su.getUserObjectId());
			try {
				LinkUserCourseLocalServiceUtil.getLinkUserCourse(linkUserCourse1.getPrimaryKey());
				
				linkUserCourse1=LinkUserCourseLocalServiceUtil.getLinkUserCourse(linkUserCourse1.getPrimaryKey());
				linkUserCourse1.setLinkUserCourseNo(linkUserCourse1.getLinkUserCourseNo()+1);
				LinkUserCourseLocalServiceUtil.updateLinkUserCourse(linkUserCourse1);
			} catch(Exception e){
				LinkUserCourseLocalServiceUtil.addLinkUserCourse(linkUserCourse1);
			}
		}
	}
	
	public void deleteLinkUserCourseId(Long courseId) throws SystemException, PortalException {
		List<LinkUserCourse> linkUserCourse = LinkUserCourseLocalServiceUtil.getByCourseId(courseId);
		for(LinkUserCourse su:linkUserCourse){
			if(su.getLinkUserCourseNo()==1){
				LinkUserCourseLocalServiceUtil.deleteLinkUserCourse(su);
			} else {
				su.setLinkUserCourseNo(su.getLinkUserCourseNo()-1);
				LinkUserCourseLocalServiceUtil.updateLinkUserCourse(su);
			}
		}
	}
	
	public void addLinkUserUserId(Long userId, Long skillId) throws SystemException, PortalException {
		LinkUserCourse linkUserCourse1 = new LinkUserCourseImpl();
		linkUserCourse1.setUserObjectId(userId);
		linkUserCourse1.setLinkUserCourseNo(1);
		List<TrainingProgram> train = TrainingProgramLocalServiceUtil.getSkillTrainingPrograms(skillId);
		for(TrainingProgram tr:train){
			List<Course> co = CourseLocalServiceUtil.getByTrainingProgramId(tr.getTrainingProgramId());
			for(Course su:co){
				System.out.println("#################"+su.getCourseId()+"################"+userId+"##############");
				linkUserCourse1.setCourseId(su.getCourseId());
				try {
					LinkUserCourseLocalServiceUtil.getLinkUserCourse(linkUserCourse1.getPrimaryKey());
					
					linkUserCourse1=LinkUserCourseLocalServiceUtil.getLinkUserCourse(linkUserCourse1.getPrimaryKey());
					linkUserCourse1.setLinkUserCourseNo(linkUserCourse1.getLinkUserCourseNo()+1);
					LinkUserCourseLocalServiceUtil.updateLinkUserCourse(linkUserCourse1);
				} catch(Exception e){
					LinkUserCourseLocalServiceUtil.addLinkUserCourse(linkUserCourse1);
				}
			}
		}
	}
	
	public void deleteLinkUserUserId(Long userId, Long skillId) throws SystemException, PortalException {	
		LinkUserCourse link = new LinkUserCourseImpl();
		link.setUserObjectId(userId);
		System.out.println("++++++"+userId);
		List<TrainingProgram> train = TrainingProgramLocalServiceUtil.getSkillTrainingPrograms(skillId);
		for(TrainingProgram tr:train){
			List<Course> co = CourseLocalServiceUtil.getByTrainingProgramId(tr.getTrainingProgramId());
			for(Course su:co){
				link.setCourseId(su.getCourseId());
				System.out.println("++++++"+userId+"++++++"+su.getCourseId());
				try {
					link = LinkUserCourseLocalServiceUtil.getLinkUserCourse(link.getPrimaryKey());
					if(link.getLinkUserCourseNo()==1){
						LinkUserCourseLocalServiceUtil.deleteLinkUserCourse(link);
					} else {
						link.setLinkUserCourseNo(link.getLinkUserCourseNo()-1);
						LinkUserCourseLocalServiceUtil.updateLinkUserCourse(link);
					}
				} catch (Exception e) {
					
				}
			}
		}
	}
}
