/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.portlets.action.service.persistence.RegisterCoursePK;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.portlets.action.service.http.RegisterCourseServiceSoap}.
 *
 * @author Computer
 * @see com.portlets.action.service.http.RegisterCourseServiceSoap
 * @generated
 */
public class RegisterCourseSoap implements Serializable {
	public static RegisterCourseSoap toSoapModel(RegisterCourse model) {
		RegisterCourseSoap soapModel = new RegisterCourseSoap();

		soapModel.setCourseId(model.getCourseId());
		soapModel.setUserObjectId(model.getUserObjectId());
		soapModel.setStatesId(model.getStatesId());

		return soapModel;
	}

	public static RegisterCourseSoap[] toSoapModels(RegisterCourse[] models) {
		RegisterCourseSoap[] soapModels = new RegisterCourseSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static RegisterCourseSoap[][] toSoapModels(RegisterCourse[][] models) {
		RegisterCourseSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new RegisterCourseSoap[models.length][models[0].length];
		}
		else {
			soapModels = new RegisterCourseSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static RegisterCourseSoap[] toSoapModels(List<RegisterCourse> models) {
		List<RegisterCourseSoap> soapModels = new ArrayList<RegisterCourseSoap>(models.size());

		for (RegisterCourse model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new RegisterCourseSoap[soapModels.size()]);
	}

	public RegisterCourseSoap() {
	}

	public RegisterCoursePK getPrimaryKey() {
		return new RegisterCoursePK(_courseId, _userObjectId);
	}

	public void setPrimaryKey(RegisterCoursePK pk) {
		setCourseId(pk.courseId);
		setUserObjectId(pk.userObjectId);
	}

	public long getCourseId() {
		return _courseId;
	}

	public void setCourseId(long courseId) {
		_courseId = courseId;
	}

	public long getUserObjectId() {
		return _userObjectId;
	}

	public void setUserObjectId(long userObjectId) {
		_userObjectId = userObjectId;
	}

	public long getStatesId() {
		return _statesId;
	}

	public void setStatesId(long statesId) {
		_statesId = statesId;
	}

	private long _courseId;
	private long _userObjectId;
	private long _statesId;
}