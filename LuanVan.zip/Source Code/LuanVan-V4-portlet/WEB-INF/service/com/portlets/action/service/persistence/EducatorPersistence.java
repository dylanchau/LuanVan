/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.service.persistence;

import com.liferay.portal.service.persistence.BasePersistence;

import com.portlets.action.model.Educator;

/**
 * The persistence interface for the educator service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Computer
 * @see EducatorPersistenceImpl
 * @see EducatorUtil
 * @generated
 */
public interface EducatorPersistence extends BasePersistence<Educator> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link EducatorUtil} to access the educator persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Returns the educator where educatorId = &#63; or throws a {@link com.portlets.action.NoSuchEducatorException} if it could not be found.
	*
	* @param educatorId the educator ID
	* @return the matching educator
	* @throws com.portlets.action.NoSuchEducatorException if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByEducatorId(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the educator where educatorId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param educatorId the educator ID
	* @return the matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorId(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the educator where educatorId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param educatorId the educator ID
	* @param retrieveFromCache whether to use the finder cache
	* @return the matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorId(
		long educatorId, boolean retrieveFromCache)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the educator where educatorId = &#63; from the database.
	*
	* @param educatorId the educator ID
	* @return the educator that was removed
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator removeByEducatorId(
		long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the number of educators where educatorId = &#63;.
	*
	* @param educatorId the educator ID
	* @return the number of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public int countByEducatorId(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the educators where educatorName = &#63;.
	*
	* @param educatorName the educator name
	* @return the matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorName(
		java.lang.String educatorName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the educators where educatorName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorName the educator name
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @return the range of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorName(
		java.lang.String educatorName, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the educators where educatorName = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorName the educator name
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorName(
		java.lang.String educatorName, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first educator in the ordered set where educatorName = &#63;.
	*
	* @param educatorName the educator name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching educator
	* @throws com.portlets.action.NoSuchEducatorException if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByEducatorName_First(
		java.lang.String educatorName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the first educator in the ordered set where educatorName = &#63;.
	*
	* @param educatorName the educator name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorName_First(
		java.lang.String educatorName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last educator in the ordered set where educatorName = &#63;.
	*
	* @param educatorName the educator name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching educator
	* @throws com.portlets.action.NoSuchEducatorException if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByEducatorName_Last(
		java.lang.String educatorName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the last educator in the ordered set where educatorName = &#63;.
	*
	* @param educatorName the educator name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorName_Last(
		java.lang.String educatorName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the educators before and after the current educator in the ordered set where educatorName = &#63;.
	*
	* @param educatorId the primary key of the current educator
	* @param educatorName the educator name
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next educator
	* @throws com.portlets.action.NoSuchEducatorException if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator[] findByEducatorName_PrevAndNext(
		long educatorId, java.lang.String educatorName,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Removes all the educators where educatorName = &#63; from the database.
	*
	* @param educatorName the educator name
	* @throws SystemException if a system exception occurred
	*/
	public void removeByEducatorName(java.lang.String educatorName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of educators where educatorName = &#63;.
	*
	* @param educatorName the educator name
	* @return the number of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public int countByEducatorName(java.lang.String educatorName)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the educators where educatorEmail = &#63;.
	*
	* @param educatorEmail the educator email
	* @return the matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorEmail(
		java.lang.String educatorEmail)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the educators where educatorEmail = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorEmail the educator email
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @return the range of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorEmail(
		java.lang.String educatorEmail, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the educators where educatorEmail = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorEmail the educator email
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorEmail(
		java.lang.String educatorEmail, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first educator in the ordered set where educatorEmail = &#63;.
	*
	* @param educatorEmail the educator email
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching educator
	* @throws com.portlets.action.NoSuchEducatorException if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByEducatorEmail_First(
		java.lang.String educatorEmail,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the first educator in the ordered set where educatorEmail = &#63;.
	*
	* @param educatorEmail the educator email
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorEmail_First(
		java.lang.String educatorEmail,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last educator in the ordered set where educatorEmail = &#63;.
	*
	* @param educatorEmail the educator email
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching educator
	* @throws com.portlets.action.NoSuchEducatorException if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByEducatorEmail_Last(
		java.lang.String educatorEmail,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the last educator in the ordered set where educatorEmail = &#63;.
	*
	* @param educatorEmail the educator email
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorEmail_Last(
		java.lang.String educatorEmail,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the educators before and after the current educator in the ordered set where educatorEmail = &#63;.
	*
	* @param educatorId the primary key of the current educator
	* @param educatorEmail the educator email
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next educator
	* @throws com.portlets.action.NoSuchEducatorException if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator[] findByEducatorEmail_PrevAndNext(
		long educatorId, java.lang.String educatorEmail,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Removes all the educators where educatorEmail = &#63; from the database.
	*
	* @param educatorEmail the educator email
	* @throws SystemException if a system exception occurred
	*/
	public void removeByEducatorEmail(java.lang.String educatorEmail)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of educators where educatorEmail = &#63;.
	*
	* @param educatorEmail the educator email
	* @return the number of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public int countByEducatorEmail(java.lang.String educatorEmail)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the educators where educatorAddress = &#63;.
	*
	* @param educatorAddress the educator address
	* @return the matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorAddress(
		java.lang.String educatorAddress)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the educators where educatorAddress = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorAddress the educator address
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @return the range of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorAddress(
		java.lang.String educatorAddress, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the educators where educatorAddress = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param educatorAddress the educator address
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findByEducatorAddress(
		java.lang.String educatorAddress, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the first educator in the ordered set where educatorAddress = &#63;.
	*
	* @param educatorAddress the educator address
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching educator
	* @throws com.portlets.action.NoSuchEducatorException if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByEducatorAddress_First(
		java.lang.String educatorAddress,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the first educator in the ordered set where educatorAddress = &#63;.
	*
	* @param educatorAddress the educator address
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorAddress_First(
		java.lang.String educatorAddress,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the last educator in the ordered set where educatorAddress = &#63;.
	*
	* @param educatorAddress the educator address
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching educator
	* @throws com.portlets.action.NoSuchEducatorException if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByEducatorAddress_Last(
		java.lang.String educatorAddress,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the last educator in the ordered set where educatorAddress = &#63;.
	*
	* @param educatorAddress the educator address
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching educator, or <code>null</code> if a matching educator could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByEducatorAddress_Last(
		java.lang.String educatorAddress,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the educators before and after the current educator in the ordered set where educatorAddress = &#63;.
	*
	* @param educatorId the primary key of the current educator
	* @param educatorAddress the educator address
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next educator
	* @throws com.portlets.action.NoSuchEducatorException if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator[] findByEducatorAddress_PrevAndNext(
		long educatorId, java.lang.String educatorAddress,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Removes all the educators where educatorAddress = &#63; from the database.
	*
	* @param educatorAddress the educator address
	* @throws SystemException if a system exception occurred
	*/
	public void removeByEducatorAddress(java.lang.String educatorAddress)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of educators where educatorAddress = &#63;.
	*
	* @param educatorAddress the educator address
	* @return the number of matching educators
	* @throws SystemException if a system exception occurred
	*/
	public int countByEducatorAddress(java.lang.String educatorAddress)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Caches the educator in the entity cache if it is enabled.
	*
	* @param educator the educator
	*/
	public void cacheResult(com.portlets.action.model.Educator educator);

	/**
	* Caches the educators in the entity cache if it is enabled.
	*
	* @param educators the educators
	*/
	public void cacheResult(
		java.util.List<com.portlets.action.model.Educator> educators);

	/**
	* Creates a new educator with the primary key. Does not add the educator to the database.
	*
	* @param educatorId the primary key for the new educator
	* @return the new educator
	*/
	public com.portlets.action.model.Educator create(long educatorId);

	/**
	* Removes the educator with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param educatorId the primary key of the educator
	* @return the educator that was removed
	* @throws com.portlets.action.NoSuchEducatorException if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator remove(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	public com.portlets.action.model.Educator updateImpl(
		com.portlets.action.model.Educator educator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the educator with the primary key or throws a {@link com.portlets.action.NoSuchEducatorException} if it could not be found.
	*
	* @param educatorId the primary key of the educator
	* @return the educator
	* @throws com.portlets.action.NoSuchEducatorException if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator findByPrimaryKey(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException,
			com.portlets.action.NoSuchEducatorException;

	/**
	* Returns the educator with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param educatorId the primary key of the educator
	* @return the educator, or <code>null</code> if a educator with the primary key could not be found
	* @throws SystemException if a system exception occurred
	*/
	public com.portlets.action.model.Educator fetchByPrimaryKey(long educatorId)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the educators.
	*
	* @return the educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the educators.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @return the range of educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findAll(
		int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the educators.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of educators
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.Educator> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes all the educators from the database.
	*
	* @throws SystemException if a system exception occurred
	*/
	public void removeAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of educators.
	*
	* @return the number of educators
	* @throws SystemException if a system exception occurred
	*/
	public int countAll()
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns all the user objects associated with the educator.
	*
	* @param pk the primary key of the educator
	* @return the user objects associated with the educator
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk) throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns a range of all the user objects associated with the educator.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the educator
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @return the range of user objects associated with the educator
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk, int start, int end)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns an ordered range of all the user objects associated with the educator.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.portlets.action.model.impl.EducatorModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param pk the primary key of the educator
	* @param start the lower bound of the range of educators
	* @param end the upper bound of the range of educators (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of user objects associated with the educator
	* @throws SystemException if a system exception occurred
	*/
	public java.util.List<com.portlets.action.model.UserObject> getUserObjects(
		long pk, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator orderByComparator)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns the number of user objects associated with the educator.
	*
	* @param pk the primary key of the educator
	* @return the number of user objects associated with the educator
	* @throws SystemException if a system exception occurred
	*/
	public int getUserObjectsSize(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the user object is associated with the educator.
	*
	* @param pk the primary key of the educator
	* @param userObjectPK the primary key of the user object
	* @return <code>true</code> if the user object is associated with the educator; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Returns <code>true</code> if the educator has any user objects associated with it.
	*
	* @param pk the primary key of the educator to check for associations with user objects
	* @return <code>true</code> if the educator has any user objects associated with it; <code>false</code> otherwise
	* @throws SystemException if a system exception occurred
	*/
	public boolean containsUserObjects(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the educator and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjectPK the primary key of the user object
	* @throws SystemException if a system exception occurred
	*/
	public void addUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the educator and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObject the user object
	* @throws SystemException if a system exception occurred
	*/
	public void addUserObject(long pk,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the educator and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjectPKs the primary keys of the user objects
	* @throws SystemException if a system exception occurred
	*/
	public void addUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Adds an association between the educator and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjects the user objects
	* @throws SystemException if a system exception occurred
	*/
	public void addUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Clears all associations between the educator and its user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator to clear the associated user objects from
	* @throws SystemException if a system exception occurred
	*/
	public void clearUserObjects(long pk)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the educator and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjectPK the primary key of the user object
	* @throws SystemException if a system exception occurred
	*/
	public void removeUserObject(long pk, long userObjectPK)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the educator and the user object. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObject the user object
	* @throws SystemException if a system exception occurred
	*/
	public void removeUserObject(long pk,
		com.portlets.action.model.UserObject userObject)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the educator and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjectPKs the primary keys of the user objects
	* @throws SystemException if a system exception occurred
	*/
	public void removeUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Removes the association between the educator and the user objects. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjects the user objects
	* @throws SystemException if a system exception occurred
	*/
	public void removeUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the user objects associated with the educator, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjectPKs the primary keys of the user objects to be associated with the educator
	* @throws SystemException if a system exception occurred
	*/
	public void setUserObjects(long pk, long[] userObjectPKs)
		throws com.liferay.portal.kernel.exception.SystemException;

	/**
	* Sets the user objects associated with the educator, removing and adding associations as necessary. Also notifies the appropriate model listeners and clears the mapping table finder cache.
	*
	* @param pk the primary key of the educator
	* @param userObjects the user objects to be associated with the educator
	* @throws SystemException if a system exception occurred
	*/
	public void setUserObjects(long pk,
		java.util.List<com.portlets.action.model.UserObject> userObjects)
		throws com.liferay.portal.kernel.exception.SystemException;
}