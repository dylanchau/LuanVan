/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.bean.AutoEscapeBeanHandler;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.ProxyUtil;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.BaseModel;
import com.liferay.portal.model.impl.BaseModelImpl;

import com.portlets.action.service.ClpSerializer;
import com.portlets.action.service.LinkUsersLocalServiceUtil;
import com.portlets.action.service.persistence.LinkUsersPK;

import java.io.Serializable;

import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Computer
 */
public class LinkUsersClp extends BaseModelImpl<LinkUsers> implements LinkUsers {
	public LinkUsersClp() {
	}

	@Override
	public Class<?> getModelClass() {
		return LinkUsers.class;
	}

	@Override
	public String getModelClassName() {
		return LinkUsers.class.getName();
	}

	@Override
	public LinkUsersPK getPrimaryKey() {
		return new LinkUsersPK(_userIdA, _userIdB);
	}

	@Override
	public void setPrimaryKey(LinkUsersPK primaryKey) {
		setUserIdA(primaryKey.userIdA);
		setUserIdB(primaryKey.userIdB);
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return new LinkUsersPK(_userIdA, _userIdB);
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		setPrimaryKey((LinkUsersPK)primaryKeyObj);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("userIdA", getUserIdA());
		attributes.put("userIdB", getUserIdB());
		attributes.put("linkUsersNumber", getLinkUsersNumber());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long userIdA = (Long)attributes.get("userIdA");

		if (userIdA != null) {
			setUserIdA(userIdA);
		}

		Long userIdB = (Long)attributes.get("userIdB");

		if (userIdB != null) {
			setUserIdB(userIdB);
		}

		Integer linkUsersNumber = (Integer)attributes.get("linkUsersNumber");

		if (linkUsersNumber != null) {
			setLinkUsersNumber(linkUsersNumber);
		}
	}

	@Override
	public long getUserIdA() {
		return _userIdA;
	}

	@Override
	public void setUserIdA(long userIdA) {
		_userIdA = userIdA;

		if (_linkUsersRemoteModel != null) {
			try {
				Class<?> clazz = _linkUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setUserIdA", long.class);

				method.invoke(_linkUsersRemoteModel, userIdA);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public long getUserIdB() {
		return _userIdB;
	}

	@Override
	public void setUserIdB(long userIdB) {
		_userIdB = userIdB;

		if (_linkUsersRemoteModel != null) {
			try {
				Class<?> clazz = _linkUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setUserIdB", long.class);

				method.invoke(_linkUsersRemoteModel, userIdB);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	@Override
	public int getLinkUsersNumber() {
		return _linkUsersNumber;
	}

	@Override
	public void setLinkUsersNumber(int linkUsersNumber) {
		_linkUsersNumber = linkUsersNumber;

		if (_linkUsersRemoteModel != null) {
			try {
				Class<?> clazz = _linkUsersRemoteModel.getClass();

				Method method = clazz.getMethod("setLinkUsersNumber", int.class);

				method.invoke(_linkUsersRemoteModel, linkUsersNumber);
			}
			catch (Exception e) {
				throw new UnsupportedOperationException(e);
			}
		}
	}

	public BaseModel<?> getLinkUsersRemoteModel() {
		return _linkUsersRemoteModel;
	}

	public void setLinkUsersRemoteModel(BaseModel<?> linkUsersRemoteModel) {
		_linkUsersRemoteModel = linkUsersRemoteModel;
	}

	public Object invokeOnRemoteModel(String methodName,
		Class<?>[] parameterTypes, Object[] parameterValues)
		throws Exception {
		Object[] remoteParameterValues = new Object[parameterValues.length];

		for (int i = 0; i < parameterValues.length; i++) {
			if (parameterValues[i] != null) {
				remoteParameterValues[i] = ClpSerializer.translateInput(parameterValues[i]);
			}
		}

		Class<?> remoteModelClass = _linkUsersRemoteModel.getClass();

		ClassLoader remoteModelClassLoader = remoteModelClass.getClassLoader();

		Class<?>[] remoteParameterTypes = new Class[parameterTypes.length];

		for (int i = 0; i < parameterTypes.length; i++) {
			if (parameterTypes[i].isPrimitive()) {
				remoteParameterTypes[i] = parameterTypes[i];
			}
			else {
				String parameterTypeName = parameterTypes[i].getName();

				remoteParameterTypes[i] = remoteModelClassLoader.loadClass(parameterTypeName);
			}
		}

		Method method = remoteModelClass.getMethod(methodName,
				remoteParameterTypes);

		Object returnValue = method.invoke(_linkUsersRemoteModel,
				remoteParameterValues);

		if (returnValue != null) {
			returnValue = ClpSerializer.translateOutput(returnValue);
		}

		return returnValue;
	}

	@Override
	public void persist() throws SystemException {
		if (this.isNew()) {
			LinkUsersLocalServiceUtil.addLinkUsers(this);
		}
		else {
			LinkUsersLocalServiceUtil.updateLinkUsers(this);
		}
	}

	@Override
	public LinkUsers toEscapedModel() {
		return (LinkUsers)ProxyUtil.newProxyInstance(LinkUsers.class.getClassLoader(),
			new Class[] { LinkUsers.class }, new AutoEscapeBeanHandler(this));
	}

	@Override
	public Object clone() {
		LinkUsersClp clone = new LinkUsersClp();

		clone.setUserIdA(getUserIdA());
		clone.setUserIdB(getUserIdB());
		clone.setLinkUsersNumber(getLinkUsersNumber());

		return clone;
	}

	@Override
	public int compareTo(LinkUsers linkUsers) {
		LinkUsersPK primaryKey = linkUsers.getPrimaryKey();

		return getPrimaryKey().compareTo(primaryKey);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof LinkUsersClp)) {
			return false;
		}

		LinkUsersClp linkUsers = (LinkUsersClp)obj;

		LinkUsersPK primaryKey = linkUsers.getPrimaryKey();

		if (getPrimaryKey().equals(primaryKey)) {
			return true;
		}
		else {
			return false;
		}
	}

	public Class<?> getClpSerializerClass() {
		return _clpSerializerClass;
	}

	@Override
	public int hashCode() {
		return getPrimaryKey().hashCode();
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{userIdA=");
		sb.append(getUserIdA());
		sb.append(", userIdB=");
		sb.append(getUserIdB());
		sb.append(", linkUsersNumber=");
		sb.append(getLinkUsersNumber());
		sb.append("}");

		return sb.toString();
	}

	@Override
	public String toXmlString() {
		StringBundler sb = new StringBundler(13);

		sb.append("<model><model-name>");
		sb.append("com.portlets.action.model.LinkUsers");
		sb.append("</model-name>");

		sb.append(
			"<column><column-name>userIdA</column-name><column-value><![CDATA[");
		sb.append(getUserIdA());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>userIdB</column-name><column-value><![CDATA[");
		sb.append(getUserIdB());
		sb.append("]]></column-value></column>");
		sb.append(
			"<column><column-name>linkUsersNumber</column-name><column-value><![CDATA[");
		sb.append(getLinkUsersNumber());
		sb.append("]]></column-value></column>");

		sb.append("</model>");

		return sb.toString();
	}

	private long _userIdA;
	private long _userIdB;
	private int _linkUsersNumber;
	private BaseModel<?> _linkUsersRemoteModel;
	private Class<?> _clpSerializerClass = com.portlets.action.service.ClpSerializer.class;
}