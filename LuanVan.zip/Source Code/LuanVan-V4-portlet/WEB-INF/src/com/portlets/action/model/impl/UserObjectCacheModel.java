/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.UserObject;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing UserObject in entity cache.
 *
 * @author Computer
 * @see UserObject
 * @generated
 */
public class UserObjectCacheModel implements CacheModel<UserObject>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(17);

		sb.append("{userObjectId=");
		sb.append(userObjectId);
		sb.append(", userObjectName=");
		sb.append(userObjectName);
		sb.append(", userObjectGender=");
		sb.append(userObjectGender);
		sb.append(", userObjectAddress=");
		sb.append(userObjectAddress);
		sb.append(", userObjectBirthday=");
		sb.append(userObjectBirthday);
		sb.append(", userObjectEmail=");
		sb.append(userObjectEmail);
		sb.append(", userObjectPhone=");
		sb.append(userObjectPhone);
		sb.append(", userObjectIntroduce=");
		sb.append(userObjectIntroduce);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public UserObject toEntityModel() {
		UserObjectImpl userObjectImpl = new UserObjectImpl();

		userObjectImpl.setUserObjectId(userObjectId);

		if (userObjectName == null) {
			userObjectImpl.setUserObjectName(StringPool.BLANK);
		}
		else {
			userObjectImpl.setUserObjectName(userObjectName);
		}

		userObjectImpl.setUserObjectGender(userObjectGender);

		if (userObjectAddress == null) {
			userObjectImpl.setUserObjectAddress(StringPool.BLANK);
		}
		else {
			userObjectImpl.setUserObjectAddress(userObjectAddress);
		}

		if (userObjectBirthday == Long.MIN_VALUE) {
			userObjectImpl.setUserObjectBirthday(null);
		}
		else {
			userObjectImpl.setUserObjectBirthday(new Date(userObjectBirthday));
		}

		if (userObjectEmail == null) {
			userObjectImpl.setUserObjectEmail(StringPool.BLANK);
		}
		else {
			userObjectImpl.setUserObjectEmail(userObjectEmail);
		}

		if (userObjectPhone == null) {
			userObjectImpl.setUserObjectPhone(StringPool.BLANK);
		}
		else {
			userObjectImpl.setUserObjectPhone(userObjectPhone);
		}

		if (userObjectIntroduce == null) {
			userObjectImpl.setUserObjectIntroduce(StringPool.BLANK);
		}
		else {
			userObjectImpl.setUserObjectIntroduce(userObjectIntroduce);
		}

		userObjectImpl.resetOriginalValues();

		return userObjectImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		userObjectId = objectInput.readLong();
		userObjectName = objectInput.readUTF();
		userObjectGender = objectInput.readBoolean();
		userObjectAddress = objectInput.readUTF();
		userObjectBirthday = objectInput.readLong();
		userObjectEmail = objectInput.readUTF();
		userObjectPhone = objectInput.readUTF();
		userObjectIntroduce = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(userObjectId);

		if (userObjectName == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userObjectName);
		}

		objectOutput.writeBoolean(userObjectGender);

		if (userObjectAddress == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userObjectAddress);
		}

		objectOutput.writeLong(userObjectBirthday);

		if (userObjectEmail == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userObjectEmail);
		}

		if (userObjectPhone == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userObjectPhone);
		}

		if (userObjectIntroduce == null) {
			objectOutput.writeUTF(StringPool.BLANK);
		}
		else {
			objectOutput.writeUTF(userObjectIntroduce);
		}
	}

	public long userObjectId;
	public String userObjectName;
	public boolean userObjectGender;
	public String userObjectAddress;
	public long userObjectBirthday;
	public String userObjectEmail;
	public String userObjectPhone;
	public String userObjectIntroduce;
}