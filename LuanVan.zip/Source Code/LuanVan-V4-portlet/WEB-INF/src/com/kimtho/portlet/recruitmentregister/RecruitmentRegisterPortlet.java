package com.kimtho.portlet.recruitmentregister;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.ProcessAction;

import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.RegisterRecruitment;
import com.portlets.action.model.impl.RegisterRecruitmentImpl;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;

/**
 * Portlet implementation class RecruitmentRegisterPortlet
 */
public class RecruitmentRegisterPortlet extends MVCPortlet {
 
	@ProcessAction(name = "registerRecruitment")
	public void registerRecruitment(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterRecruitment re = new RegisterRecruitmentImpl();
		re.setStatesId(new Long(10));
		re.setUserObjectId(userId);
		re.setRecruitmentId(recruitmentId);
		RegisterRecruitmentLocalServiceUtil.addRegisterRecruitment(re);
		SessionMessages.add(actionRequest, "added-registerrecruitmentId"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Added Register Recruitment Successfully#########################");
	}
	
	@ProcessAction(name = "unRegisterRecruitment")
	public void unRegisterEmployerInfo(ActionRequest actionRequest,ActionResponse actionResponse) throws SystemException, IOException {
		String redirect = ParamUtil.getString(actionRequest, "redirect","");
		Long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId",0);
		Long userId = ParamUtil.getLong(actionRequest, "userId",0);
		//
		RegisterRecruitment re = new RegisterRecruitmentImpl();
		re.setStatesId(new Long(10));
		re.setUserObjectId(userId);
		re.setRecruitmentId(recruitmentId);
		RegisterRecruitmentLocalServiceUtil.deleteRegisterRecruitment(re);
		SessionMessages.add(actionRequest, "deleted-registerrecruitment"); 
		actionResponse.sendRedirect(redirect);
	   _log.info("#################Deleted Register Recruitment Successfully#########################");
	}
	private Log _log = LogFactoryUtil.getLog(RecruitmentRegisterPortlet.class.getName());
}
