/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model;

import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.model.ModelWrapper;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link ExperienceUsers}.
 * </p>
 *
 * @author Computer
 * @see ExperienceUsers
 * @generated
 */
public class ExperienceUsersWrapper implements ExperienceUsers,
	ModelWrapper<ExperienceUsers> {
	public ExperienceUsersWrapper(ExperienceUsers experienceUsers) {
		_experienceUsers = experienceUsers;
	}

	@Override
	public Class<?> getModelClass() {
		return ExperienceUsers.class;
	}

	@Override
	public String getModelClassName() {
		return ExperienceUsers.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("experienceUsersId", getExperienceUsersId());
		attributes.put("experienceUsersJob", getExperienceUsersJob());
		attributes.put("experienceUsersCompany", getExperienceUsersCompany());
		attributes.put("experienceUsersDateStart", getExperienceUsersDateStart());
		attributes.put("experienceUsersDateFinish",
			getExperienceUsersDateFinish());
		attributes.put("experienceUsersDescription",
			getExperienceUsersDescription());
		attributes.put("userObjectId", getUserObjectId());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long experienceUsersId = (Long)attributes.get("experienceUsersId");

		if (experienceUsersId != null) {
			setExperienceUsersId(experienceUsersId);
		}

		String experienceUsersJob = (String)attributes.get("experienceUsersJob");

		if (experienceUsersJob != null) {
			setExperienceUsersJob(experienceUsersJob);
		}

		String experienceUsersCompany = (String)attributes.get(
				"experienceUsersCompany");

		if (experienceUsersCompany != null) {
			setExperienceUsersCompany(experienceUsersCompany);
		}

		Date experienceUsersDateStart = (Date)attributes.get(
				"experienceUsersDateStart");

		if (experienceUsersDateStart != null) {
			setExperienceUsersDateStart(experienceUsersDateStart);
		}

		Date experienceUsersDateFinish = (Date)attributes.get(
				"experienceUsersDateFinish");

		if (experienceUsersDateFinish != null) {
			setExperienceUsersDateFinish(experienceUsersDateFinish);
		}

		String experienceUsersDescription = (String)attributes.get(
				"experienceUsersDescription");

		if (experienceUsersDescription != null) {
			setExperienceUsersDescription(experienceUsersDescription);
		}

		Long userObjectId = (Long)attributes.get("userObjectId");

		if (userObjectId != null) {
			setUserObjectId(userObjectId);
		}
	}

	/**
	* Returns the primary key of this experience users.
	*
	* @return the primary key of this experience users
	*/
	@Override
	public long getPrimaryKey() {
		return _experienceUsers.getPrimaryKey();
	}

	/**
	* Sets the primary key of this experience users.
	*
	* @param primaryKey the primary key of this experience users
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_experienceUsers.setPrimaryKey(primaryKey);
	}

	/**
	* Returns the experience users ID of this experience users.
	*
	* @return the experience users ID of this experience users
	*/
	@Override
	public long getExperienceUsersId() {
		return _experienceUsers.getExperienceUsersId();
	}

	/**
	* Sets the experience users ID of this experience users.
	*
	* @param experienceUsersId the experience users ID of this experience users
	*/
	@Override
	public void setExperienceUsersId(long experienceUsersId) {
		_experienceUsers.setExperienceUsersId(experienceUsersId);
	}

	/**
	* Returns the experience users job of this experience users.
	*
	* @return the experience users job of this experience users
	*/
	@Override
	public java.lang.String getExperienceUsersJob() {
		return _experienceUsers.getExperienceUsersJob();
	}

	/**
	* Sets the experience users job of this experience users.
	*
	* @param experienceUsersJob the experience users job of this experience users
	*/
	@Override
	public void setExperienceUsersJob(java.lang.String experienceUsersJob) {
		_experienceUsers.setExperienceUsersJob(experienceUsersJob);
	}

	/**
	* Returns the experience users company of this experience users.
	*
	* @return the experience users company of this experience users
	*/
	@Override
	public java.lang.String getExperienceUsersCompany() {
		return _experienceUsers.getExperienceUsersCompany();
	}

	/**
	* Sets the experience users company of this experience users.
	*
	* @param experienceUsersCompany the experience users company of this experience users
	*/
	@Override
	public void setExperienceUsersCompany(
		java.lang.String experienceUsersCompany) {
		_experienceUsers.setExperienceUsersCompany(experienceUsersCompany);
	}

	/**
	* Returns the experience users date start of this experience users.
	*
	* @return the experience users date start of this experience users
	*/
	@Override
	public java.util.Date getExperienceUsersDateStart() {
		return _experienceUsers.getExperienceUsersDateStart();
	}

	/**
	* Sets the experience users date start of this experience users.
	*
	* @param experienceUsersDateStart the experience users date start of this experience users
	*/
	@Override
	public void setExperienceUsersDateStart(
		java.util.Date experienceUsersDateStart) {
		_experienceUsers.setExperienceUsersDateStart(experienceUsersDateStart);
	}

	/**
	* Returns the experience users date finish of this experience users.
	*
	* @return the experience users date finish of this experience users
	*/
	@Override
	public java.util.Date getExperienceUsersDateFinish() {
		return _experienceUsers.getExperienceUsersDateFinish();
	}

	/**
	* Sets the experience users date finish of this experience users.
	*
	* @param experienceUsersDateFinish the experience users date finish of this experience users
	*/
	@Override
	public void setExperienceUsersDateFinish(
		java.util.Date experienceUsersDateFinish) {
		_experienceUsers.setExperienceUsersDateFinish(experienceUsersDateFinish);
	}

	/**
	* Returns the experience users description of this experience users.
	*
	* @return the experience users description of this experience users
	*/
	@Override
	public java.lang.String getExperienceUsersDescription() {
		return _experienceUsers.getExperienceUsersDescription();
	}

	/**
	* Sets the experience users description of this experience users.
	*
	* @param experienceUsersDescription the experience users description of this experience users
	*/
	@Override
	public void setExperienceUsersDescription(
		java.lang.String experienceUsersDescription) {
		_experienceUsers.setExperienceUsersDescription(experienceUsersDescription);
	}

	/**
	* Returns the user object ID of this experience users.
	*
	* @return the user object ID of this experience users
	*/
	@Override
	public long getUserObjectId() {
		return _experienceUsers.getUserObjectId();
	}

	/**
	* Sets the user object ID of this experience users.
	*
	* @param userObjectId the user object ID of this experience users
	*/
	@Override
	public void setUserObjectId(long userObjectId) {
		_experienceUsers.setUserObjectId(userObjectId);
	}

	@Override
	public boolean isNew() {
		return _experienceUsers.isNew();
	}

	@Override
	public void setNew(boolean n) {
		_experienceUsers.setNew(n);
	}

	@Override
	public boolean isCachedModel() {
		return _experienceUsers.isCachedModel();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_experienceUsers.setCachedModel(cachedModel);
	}

	@Override
	public boolean isEscapedModel() {
		return _experienceUsers.isEscapedModel();
	}

	@Override
	public java.io.Serializable getPrimaryKeyObj() {
		return _experienceUsers.getPrimaryKeyObj();
	}

	@Override
	public void setPrimaryKeyObj(java.io.Serializable primaryKeyObj) {
		_experienceUsers.setPrimaryKeyObj(primaryKeyObj);
	}

	@Override
	public com.liferay.portlet.expando.model.ExpandoBridge getExpandoBridge() {
		return _experienceUsers.getExpandoBridge();
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.model.BaseModel<?> baseModel) {
		_experienceUsers.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portlet.expando.model.ExpandoBridge expandoBridge) {
		_experienceUsers.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.service.ServiceContext serviceContext) {
		_experienceUsers.setExpandoBridgeAttributes(serviceContext);
	}

	@Override
	public java.lang.Object clone() {
		return new ExperienceUsersWrapper((ExperienceUsers)_experienceUsers.clone());
	}

	@Override
	public int compareTo(
		com.portlets.action.model.ExperienceUsers experienceUsers) {
		return _experienceUsers.compareTo(experienceUsers);
	}

	@Override
	public int hashCode() {
		return _experienceUsers.hashCode();
	}

	@Override
	public com.liferay.portal.model.CacheModel<com.portlets.action.model.ExperienceUsers> toCacheModel() {
		return _experienceUsers.toCacheModel();
	}

	@Override
	public com.portlets.action.model.ExperienceUsers toEscapedModel() {
		return new ExperienceUsersWrapper(_experienceUsers.toEscapedModel());
	}

	@Override
	public com.portlets.action.model.ExperienceUsers toUnescapedModel() {
		return new ExperienceUsersWrapper(_experienceUsers.toUnescapedModel());
	}

	@Override
	public java.lang.String toString() {
		return _experienceUsers.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _experienceUsers.toXmlString();
	}

	@Override
	public void persist()
		throws com.liferay.portal.kernel.exception.SystemException {
		_experienceUsers.persist();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof ExperienceUsersWrapper)) {
			return false;
		}

		ExperienceUsersWrapper experienceUsersWrapper = (ExperienceUsersWrapper)obj;

		if (Validator.equals(_experienceUsers,
					experienceUsersWrapper._experienceUsers)) {
			return true;
		}

		return false;
	}

	/**
	 * @deprecated As of 6.1.0, replaced by {@link #getWrappedModel}
	 */
	public ExperienceUsers getWrappedExperienceUsers() {
		return _experienceUsers;
	}

	@Override
	public ExperienceUsers getWrappedModel() {
		return _experienceUsers;
	}

	@Override
	public void resetOriginalValues() {
		_experienceUsers.resetOriginalValues();
	}

	private ExperienceUsers _experienceUsers;
}