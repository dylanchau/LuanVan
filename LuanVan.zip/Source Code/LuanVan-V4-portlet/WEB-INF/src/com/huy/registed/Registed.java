package com.huy.registed;

import java.io.IOException;

import javax.mail.internet.InternetAddress;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletURL;

import com.liferay.mail.service.MailServiceUtil;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.mail.MailMessage;
import com.liferay.portal.kernel.messaging.MessageBusUtil;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.portal.theme.ThemeDisplay;
import com.liferay.portal.util.PortalUtil;
import com.liferay.portlet.PortletURLFactoryUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;
import com.portlets.action.model.RegisterRecruitment;
import com.portlets.action.service.RegisterRecruitmentLocalServiceUtil;

/**
 * Portlet implementation class Registed
 */
public class Registed extends MVCPortlet {

	public void changeStateRegis(ActionRequest actionRequest, ActionResponse actionResponse) 
			throws Exception {
		ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		String portletName = (String)actionRequest.getAttribute(WebKeys.PORTLET_ID);
		PortletURL redirectURL = PortletURLFactoryUtil.create(PortalUtil.getHttpServletRequest(actionRequest), 
				portletName, themeDisplay.getLayout().getPlid(), PortletRequest.RENDER_PHASE);
		
		
		long stateId = ParamUtil.getLong(actionRequest, "states");
		long recruitmentId = ParamUtil.getLong(actionRequest, "recruitmentId");
		long userId = ParamUtil.getLong(actionRequest, "userObjectId");
		RegisterRecruitment reg = RegisterRecruitmentLocalServiceUtil.getRegisterRecruitmentByRe_Use(recruitmentId,userId);
		
			reg.setStatesId(stateId);
			reg.setUserObjectId(userId);
			reg.setRecruitmentId(recruitmentId);
			RegisterRecruitmentLocalServiceUtil.updateRegisterRecruitment(reg);
			String message = null;
			if (stateId == 11){
				message = "your aplication is accepted";
			}
			else {message = "your aplication is not accepted";}
			// add new massage
			if(message != null) {
				String destination = "messageListener/registed_userObject/destination";
				System.out.println("a message is sending ...");
				JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
				
				redirectURL.setParameter("RecruitmentId", String.valueOf(recruitmentId));
				jsonObject.put("RecruitmentId2", recruitmentId);
				jsonObject.put("employerId", themeDisplay.getUserId());
				
				jsonObject.put("message", message);
				jsonObject.put("userId", userId);
				jsonObject.put("companyId", themeDisplay.getCompanyId());
				
				
				MessageBusUtil.sendMessage(destination, jsonObject.toString());
			}
			actionResponse.sendRedirect(redirectURL.toString());
			
			}

	public void sendMail(ActionRequest actionRequest,
			ActionResponse actionResponse) throws IOException, PortletException {
		
		try {
			
	             
	             String From= "liferay.luanvan@gmail.com";
	             String To =ParamUtil.getString(actionRequest,"To");
	             String Subject = ParamUtil.getString(actionRequest, "Subject");
	             String body = ParamUtil.getString(actionRequest, "body");
	             
	             InternetAddress From1 = new InternetAddress(From);
	             InternetAddress To1 = new InternetAddress(To);
	             
	             
	             
	            
		             try {
		            	 	 MailMessage mailMessage =new MailMessage(); 
	
		                    mailMessage.setFrom(From1);
		                    mailMessage.setTo(To1);
		              
		                    mailMessage.setSubject(Subject);
		                    mailMessage.setBody(body);
		                    mailMessage.setHTMLFormat(true);
		                    
		                   
		                    
		                    MailServiceUtil.sendEmail(mailMessage);
		                    System.out.println("mail is sent");
		                    SessionMessages.add(actionRequest.getPortletSession(),"mail-send-success");
		                    
		             } catch (Exception e) {
							e.printStackTrace();
					}
	             
			} catch (Exception e) {
					e.printStackTrace();
				}
			}
	
	private static Log _log = LogFactoryUtil.getLog(Registed.class);

}
