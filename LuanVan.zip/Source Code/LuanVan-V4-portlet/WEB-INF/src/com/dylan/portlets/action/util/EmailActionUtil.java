package com.dylan.portlets.action.util;

import java.util.List;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.model.EmailAddress;
import com.liferay.portal.service.EmailAddressLocalServiceUtil;

public class EmailActionUtil {

	@SuppressWarnings("unchecked")
	public static List<EmailAddress> getEmailByUserId(long userId) 
			throws Exception {
		
		DynamicQuery dq = DynamicQueryFactoryUtil.forClass(EmailAddress.class);
		dq.add(PropertyFactoryUtil.forName("userId").eq(userId));
		
		try {
			
			return EmailAddressLocalServiceUtil.dynamicQuery(dq);
			
		}catch(Exception e) {
			System.err.println(e.getMessage()); return null;
		}
	}
}
