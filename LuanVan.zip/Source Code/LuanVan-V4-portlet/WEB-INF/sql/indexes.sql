create index IX_8D6FE07D on NewSocial_Course (courseId);
create index IX_F97735ED on NewSocial_Course (courseName);
create index IX_EC7382E4 on NewSocial_Course (statesId);
create index IX_352E2C62 on NewSocial_Course (trainingProgramId);

create index IX_1E19C8C7 on NewSocial_EducationUsers (educationUsersId);
create index IX_E3915871 on NewSocial_EducationUsers (userObjectId);

create index IX_B36D16A6 on NewSocial_Educator (educatorAddress);
create index IX_95711C4E on NewSocial_Educator (educatorEmail);
create index IX_EF29050D on NewSocial_Educator (educatorId);
create index IX_D179767D on NewSocial_Educator (educatorName);

create index IX_EBB90FFD on NewSocial_Employer (employerId);
create index IX_EA32856D on NewSocial_Employer (employerName);

create index IX_FEC7FE77 on NewSocial_ExperienceUsers (experienceUsersId);
create index IX_FBF65B0B on NewSocial_ExperienceUsers (userObjectId);

create index IX_2DCB6137 on NewSocial_Level (levelId);
create index IX_F0F57027 on NewSocial_Level (levelName);

create index IX_65465E42 on NewSocial_LinkUserCourse (courseId);
create index IX_CDAFF82D on NewSocial_LinkUserCourse (linkUserCourseNo);
create index IX_8B1E2891 on NewSocial_LinkUserCourse (userObjectId);

create index IX_8B167C3D on NewSocial_LinkUserRecruitment (linkUserRecruitmentNo);
create index IX_9B60C1BC on NewSocial_LinkUserRecruitment (recruitmentId);
create index IX_70EBCCC4 on NewSocial_LinkUserRecruitment (userObjectId);

create index IX_7BEFFCA5 on NewSocial_LinkUsers (linkUsersNumber);
create index IX_C6B5349 on NewSocial_LinkUsers (userIdA);
create index IX_C6B570A on NewSocial_LinkUsers (userIdB);

create index IX_1170A8BA on NewSocial_Recruitment (employerId);
create index IX_D7C4F637 on NewSocial_Recruitment (recruitmentId);
create index IX_60456101 on NewSocial_Recruitment (statesId);

create index IX_2A9632C5 on NewSocial_Recruitment_Skill (recruitmentId);
create index IX_D11E19FA on NewSocial_Recruitment_Skill (skillId);

create index IX_B773D680 on NewSocial_RegisterCourse (courseId);
create index IX_167778E7 on NewSocial_RegisterCourse (statesId);
create index IX_9D3951CF on NewSocial_RegisterCourse (userObjectId);

create index IX_1C7B847A on NewSocial_RegisterRecruitment (recruitmentId);
create index IX_B5B0E953 on NewSocial_RegisterRecruitment (recruitmentId, userObjectId);
create index IX_CD69B4DE on NewSocial_RegisterRecruitment (statesId);
create index IX_D82EBA46 on NewSocial_RegisterRecruitment (userObjectId);

create index IX_DC899FCF on NewSocial_Skill (skillAncestor);
create index IX_512D9787 on NewSocial_Skill (skillName);

create index IX_8E3DCE4B on NewSocial_States (statesId);
create index IX_FE80E83B on NewSocial_States (statesName);

create index IX_33440F70 on NewSocial_TrainingProgram (educatorId);
create index IX_C9CDE6E7 on NewSocial_TrainingProgram (trainingProgramName);

create index IX_D5DC1C0C on NewSocial_TrainingProgram_Skill (skillId);
create index IX_A1443805 on NewSocial_TrainingProgram_Skill (trainingProgramId);

create index IX_36D8D51B on NewSocial_UserObject (userObjectId);
create index IX_EC757B0B on NewSocial_UserObject (userObjectName);

create index IX_6D53CFAE on NewSocial_UserObject_Course (courseId);
create index IX_2FD03FD on NewSocial_UserObject_Course (userObjectId);

create index IX_502FF3BE on NewSocial_UserObject_Educator (educatorId);
create index IX_36161965 on NewSocial_UserObject_Educator (userObjectId);

create index IX_4CBFFEAE on NewSocial_UserObject_Employer (employerId);
create index IX_A41345DD on NewSocial_UserObject_Employer (userObjectId);

create index IX_7A905C28 on NewSocial_UserObject_Recruitment (recruitmentId);
create index IX_A16934D8 on NewSocial_UserObject_Recruitment (userObjectId);

create index IX_3E4528B9 on NewSocial_UserSkillLevel (levelId);
create index IX_17AC2906 on NewSocial_UserSkillLevel (skillId);
create index IX_598D0F0F on NewSocial_UserSkillLevel (userObjectId);

create index IX_FBE8402E on NewSocial_UserSkillListener (skillId);
create index IX_3E8930E7 on NewSocial_UserSkillListener (userObjectId);