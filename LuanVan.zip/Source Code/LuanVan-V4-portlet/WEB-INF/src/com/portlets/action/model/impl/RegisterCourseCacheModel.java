/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.portlets.action.model.impl;

import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.model.CacheModel;

import com.portlets.action.model.RegisterCourse;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing RegisterCourse in entity cache.
 *
 * @author Computer
 * @see RegisterCourse
 * @generated
 */
public class RegisterCourseCacheModel implements CacheModel<RegisterCourse>,
	Externalizable {
	@Override
	public String toString() {
		StringBundler sb = new StringBundler(7);

		sb.append("{courseId=");
		sb.append(courseId);
		sb.append(", userObjectId=");
		sb.append(userObjectId);
		sb.append(", statesId=");
		sb.append(statesId);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public RegisterCourse toEntityModel() {
		RegisterCourseImpl registerCourseImpl = new RegisterCourseImpl();

		registerCourseImpl.setCourseId(courseId);
		registerCourseImpl.setUserObjectId(userObjectId);
		registerCourseImpl.setStatesId(statesId);

		registerCourseImpl.resetOriginalValues();

		return registerCourseImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		courseId = objectInput.readLong();
		userObjectId = objectInput.readLong();
		statesId = objectInput.readLong();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		objectOutput.writeLong(courseId);
		objectOutput.writeLong(userObjectId);
		objectOutput.writeLong(statesId);
	}

	public long courseId;
	public long userObjectId;
	public long statesId;
}